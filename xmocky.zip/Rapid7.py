from flask import Blueprint, request
import logging

# Add api endpoint and integration
BASE_URL = 'idr/v1'.strip('/')         # Endpoint base 
INTEGRATION = 'rapid7_api'      # This has to be the same name as the Blueprint registered in XMocky.py

rapid7_api = Blueprint(f'{INTEGRATION}', __name__)
logger = logging.getLogger(__name__)

# Define your routes here
@rapid7_api.route(f'/{BASE_URL}/investigations')
def list_investigations():
    return {
            "data": [
            {
            "alerts": [
            {
            "first_event_time": "2018-06-06T16:56:42Z",
            "type": "Account Created",
            "type_description": "A new account has been created."
            }
            ],
            "assignee": {
            "email": "example@test.com",
            "name": "Ellen Example"
            },
            "created_time": "2018-06-06T16:56:42Z",
            "id": "174e4f99-2ac7-4481-9301-4d24c34baf06",
            "source": "ALERT",
            "status": "OPEN",
            "title": "Joe enabled account Joebob"
            }
            ],
            "metadata": {
            "index": 0,
            "size": 20,
            "total_data": 15,
            "total_pages": 1
        }
    }