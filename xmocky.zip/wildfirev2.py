from flask import Blueprint, request, Response
from werkzeug.datastructures import Headers
import json
import logging
from wildfirev2_reports import mock_file_report_xml, mock_file_report_pdf
from base64 import b64decode

BASE_URL = '/publicapi'.strip('/')
INTEGRATION = 'wildfire_api'

mock_url_md5 = "3f42fa98621807c5a326cbcec3e01e84"
mock_url_sha256 = "c60b0e33def97d8e7f5b8d8acb30c931810e7dae57710b1bb3d421d85dc60f0f"
mock_sumit_link = f"""<?xml version="1.0" encoding="UTF-8" ?>
<wildfire><submit-link-info><md5>{mock_url_md5}</md5><sha256>{mock_url_sha256}</sha256>
<url>%URL%</url></submit-link-info></wildfire>"""
mock_url_verdict = f"""<?xml version="1.0" encoding="UTF-8" ?>
<wildfire><get-verdict-info><md5>{mock_url_md5}</md5>
<sha256>{mock_url_sha256}</sha256><verdict>1</verdict>
</get-verdict-info></wildfire>
"""
mock_url_report = """"""
mock_file_md5 = "e7c098adba278310a3de2f57335df7e3"
mock_file_sha256 = "9c3eccc9c4ff45d564c86b774fd623480971243c6b3b5b5e41b4bbe2d630e0bf"
mock_submit_file = f"""<?xml version="1.0" encoding="UTF-8" ?>
<wildfire><upload-file-info><md5>{mock_file_md5}</md5><sha256>{mock_file_sha256}</sha256>
</upload-file-info></wildfire>"""
mock_sumit_file_url = f"""<?xml version="1.0" encoding="UTF-8" ?>
<wildfire><upload-file-info><md5>{mock_file_md5}</md5><sha256>{mock_file_sha256}</sha256>
<url>%URL%</url></upload-file-info></wildfire>"""
mock_file_verdict = f"""<?xml version="1.0" encoding="UTF-8" ?>
<wildfire><get-verdict-info><md5>{mock_file_md5}</md5>
<sha256>{mock_file_sha256}</sha256><verdict>1</verdict>
</get-verdict-info></wildfire>
"""
mock_invalid_verdict = """<?xml version="1.0" encoding="UTF-8" ?>
<wildfire><get-verdict-info><md5>%MD5%</md5>
<sha256>%SHA256%</sha256><verdict>-102</verdict>
</get-verdict-info></wildfire>
"""

wildfire_api = Blueprint(f'{INTEGRATION}', __name__)
logger = logging.getLogger(__name__)


@wildfire_api.route(f'/{BASE_URL}/submit/link', methods=['POST'])
def submit_link():
    if request.method == 'POST':
        submitted_url = request.form.get('link')
        return_data = mock_sumit_link
        return_data = return_data.replace("%URL%", submitted_url)
        return return_data


@wildfire_api.route(f'/{BASE_URL}/submit/url', methods=['POST'])
def submit_url():
    if request.method == 'POST':
        submitted_url = request.form.get('url')
        return_data = mock_sumit_file_url
        return_data = return_data.replace("%URL%", submitted_url)
        return return_data


@wildfire_api.route(f'/{BASE_URL}/submit/file', methods=['POST'])
def submit_file():
    if request.method == 'POST':
        return_data = mock_submit_file
        return return_data


@wildfire_api.route(f'/{BASE_URL}/get/verdict', methods=['POST'])
def get_verdict():
    if request.method == 'POST':
        request_hash = request.form.get('hash')
        if request_hash in [mock_url_md5, mock_url_sha256]:
            return mock_url_verdict
        elif request_hash in [mock_file_md5, mock_file_sha256]:
            return mock_file_verdict
        else:
            return_data = mock_invalid_verdict
            if len(request_hash) == 32:
                return_data = return_data.replace("%MD5%", request_hash)
                return_data = return_data.replace("%SHA256%", "")
            else:
                return_data = return_data.replace("%SHA256%", request_hash)
                return_data = return_data.replace("%MD5%", "")
            return return_data


@wildfire_api.route(f'/{BASE_URL}/get/report', methods=['POST'])
def get_report():
    if request.method == 'POST':
        request_hash = request.args.get('hash')
        request_format = request.args.get('format')
        if request_hash in [mock_file_md5, mock_file_sha256]:
            if request_format == "xml":
                return_data = mock_file_report_xml
                return_data = return_data.replace("%FILEHASH%", request_hash)
                print("Sending XML report")
            else:
                return_data = Response(
                    b64decode(mock_file_report_pdf),
                    headers={'Content-Type': 'application/octet-stream'},
                    status=200
                )
            return return_data
        else:
            return mock_invalid_verdict


@wildfire_api.route(f'/{BASE_URL}/get/sample', methods=['POST'])
def get_sample():
    if request.method == 'POST':
        request_hash = request.args.get('hash')
        if request_hash in [mock_file_md5, mock_file_sha256]:
            return_data = Response()
            return_headers = Headers()
            return_headers.add_header('Content-Type', 'application/octet-stream')
            return_headers.add_header('Content-Disposition', 'attachment',  filename=f'{request_hash}.txtfilename=')
            return_data.content = b64decode(mock_file_report_pdf)
            return_data.headers = return_headers
            return return_data
