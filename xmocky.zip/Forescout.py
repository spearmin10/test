'''
version 1

For any comments please reach out to Bertrand Le Bail, EMEA Cortex SA
'''

from flask import Blueprint, request
import json
import logging
import string
import random
import re

INTEGRATION = 'forescout_api'

forescout_api = Blueprint(f'{INTEGRATION}', __name__)
logger = logging.getLogger(__name__)

class forescoutMocky:
	def __init__(self,init=True):
		self.init=init

	def localip(self):
		return('192.168.{}.{}'.format(random.randint(1,254),random.randint(1,254)))
	def hostname(self):
		hostname_list=['Xmocky_Office','Xmocky_Home','Xmocky_Host']
		return(random.choice(hostname_list))

	def mac(self):
		return(''.join(random.choices(random.choice(['a','b','c','d','e','f']) + string.digits, k=12)))

	def hostId(self):
		return(''.join(random.choices(string.digits, k=10)))

	def os(self):
		return(random.choice(['Windows','Linux','MacOS']))

	def classification(self):
		return(random.choice(['Workstation','Server','IOT','mobile','tablet']))
	
	def id(self):
		return(''.join(random.choices(string.digits, k=19)))

@forescout_api.route(f'/api/test')
def test():
	return {'result': 'it works'}

@forescout_api.route(f'/api/login',methods=['POST'])
def login():
#	print ('{}:{}'.format(username,password))
	return ('abc.def.ghi')

@forescout_api.route(f'/api/hosts/ip/<ip>',methods=['GET','POST','DELETE'])
def get_host_by_ip(ip):
	fsct=forescoutMocky()
	response={
	'host':{
		'mac':fsct.mac(),
		'ip':str(ip),
		'id':fsct.hostId(),
		'fields':{
		'dhcp_server':{'value':fsct.localip()},
		'os_classification':{'value':fsct.os()},
		'nbtdomain':{'value':random.choice(['XMocky',None])},
		'vendor_classification':{'value':fsct.classification()},
		'hostname':{'value':random.choice([fsct.hostname(),None])},
		'nbthost':{'value':fsct.hostname()}
		}
	}
	}
	return(response)

@forescout_api.route(f'/api/hosts/<id>',methods=['GET','POST','DELETE'])
def get_host_by_id(id):
	fsct=forescoutMocky()
	response={
	'host':{
		'mac':fsct.mac(),
		'ip':fsct.localip(),
		'id':id,
		'fields':{
		'dhcp_server':{'value':fsct.localip()},
		'os_classification':{'value':fsct.os()},
		'nbtdomain':{'value':random.choice(['XMocky',None])},
		'vendor_classification':{'value':fsct.classification()},
		'hostname':{'value':random.choice([fsct.hostname(),None])},
		'nbthost':{'value':fsct.hostname()}
		}
	}
	}
	return(response)

@forescout_api.route(f'/api/hosts/mac/<mac>',methods=['GET','POST','DELETE'])
def get_host_by_mac(mac):
	fsct=forescoutMocky()
	response={
	'host':{
		'mac':mac,
		'ip':fsct.localip(),
		'id':fsct.hostId(),
		'fields':{
		'dhcp_server':{'value':fsct.localip()},
		'os_classification':{'value':fsct.os()},
		'nbtdomain':{'value':random.choice(['XMocky',None])},
		'vendor_classification':{'value':fsct.classification()},
		'hostname':{'value':random.choice([fsct.hostname(),None])},
		'nbthost':{'value':fsct.hostname()}
		}
	}
	}
	return(response)


@forescout_api.route(f'/api/hosts',methods=['GET','POST','DELETE'])
def get_hosts():
	response={
	"hosts": [
		{
			"mac": "000c29e9e452", 
			"ip": "192.168.1.44", 
			"hostId": "3232235820"
		}, 
		{
			"mac": "000c297cc5ae", 
			"ip": "192.168.1.125", 
			"hostId": "3232235901"
		}, 
		{
			"mac": "005056a1ad60", 
			"ip": "192.168.1.52", 
			"hostId": "3232235828"
		}, 
		{
			"mac": "000c29497e4e", 
			"ip": "192.168.1.119", 
			"hostId": "3232235895"
		}, 
		{
			"mac": "000000000000", 
			"ip": "192.168.1.8", 
			"hostId": "3232235784"
		}, 
		{
			"mac": None, 
			"ip": "192.168.1.1", 
			"hostId": "3232235777"
		}, 
		{
			"mac": "005056b1488d", 
			"ip": "192.168.1.31", 
			"hostId": "3232235807"
		}, 
		{
			"mac": "005056b1a93f", 
			"ip": "192.168.1.17", 
			"hostId": "3232235793"
		}, 
		{
			"mac": None, 
			"ip": "192.168.1.212", 
			"hostId": "3232235988"
		}
	]
}


	return(response)

@forescout_api.route(f'/fsapi/niCore/Lists',methods=['GET','POST','DELETE'])
def update_lists():
	requested_data=request.data
	lists=re.split('<LIST NAME=',str(requested_data))
	response='<?xml version="1.0" encoding="UTF-8"?>\n<FSAPI TYPE="response" API_VERSION="2.0">\n\t<STATUS>\n\t<CODE>FSAPI_OK</CODE>\n\t<MESSAGE>Successfully added values to the [{}] lists.</MESSAGE>\n\t</STATUS>\n</FSAPI>'.format(len(lists)-1)
	return(response)

def get_rule():
	fsct=forescoutMocky()
	available_rule = ['NAT Devices','Windows','Linux/Unix','Macintosh','Network Devices','Unclassified','Asset Classification','Corporate Hosts','Signed In Hosts','Guest Hosts','Corporate/Guest Control']
	available_comment = ['Created by XMocky','This rule is part of XMocky','In production, you would likely get a clear description, but you are not','Brought to you by XMocky','XMocky is pleased to serve this rule']
	rule_list=[]
	for i in range(1,random.choice([2,11])):
		rule_list.append({'ruleId':random.choice([-1,1])*int(fsct.id()),
			'name':random.choice(available_rule),
			'description':random.choice(available_comment)}
			)
	return (rule_list)

def get_policy():
	fsct=forescoutMocky()
	available_name=['XMocky Policy','XMocky Asset Policy','XMocky NAC Policy','XMocky Forescout Policy']
	available_comment=['','Forescout Policy by XMocky','An interesting policy by Xmocky','A policy brought to you by Xmocky','A policy which is not from production']
	response={'policyId':fsct.id(),
			'rules':get_rule(),
			'name':random.choice(available_name),
			'description':random.choice(available_comment)}
	return(response)


@forescout_api.route(f'/api/policies',methods=['GET','POST','DELETE'])
def get_policies():
	policy_list=[]
	for i in range(1,random.choice([2,7])):
		policy_list.append(get_policy())
	response={'policies':policy_list}
	return(response)


@forescout_api.route(f'/api/hostfields',methods=['GET','POST','DELETE'])
def get_host_fields():
	response = {
		"hostFields":[
		{
			"Name": "nbthost", 
			"Type": "string", 
			"Description": "Indicates the NetBIOS hostname of the host.", 
			"Label": "NetBIOS Hostname"
		}, 
		{
			"Name": "hostname", 
			"Type": "string", 
			"Description": "Indicates the DNS name of the host.", 
			"Label": "DNS Name"
		}, 
		{
			"Name": "aws_instance_public_dns", 
			"Type": "string", 
			"Description": "The public hostname of the EC2 instance, which resolves to the public IP address or Elastic IP address of the instance.", 
			"Label": "EC2 Public DNS"
		}, 
		{
			"Name": "dhcp_hostname", 
			"Type": "string", 
			"Description": "The device Host Name as advertised by DHCP", 
			"Label": "DHCP Hostname"
		}, 
		{
			"Name": "linux_hostname", 
			"Type": "string", 
			"Description": "Indicates a hostname. Use of this property requires that the host is managed by CounterACT via SecureConnector or remotely.", 
			"Label": "Linux Hostname"
		}, 
		{
			"Name": "mac_hostname", 
			"Type": "string", 
			"Description": "Indicates a hostname. Use of this property requires that the host is managed by CounterACT via SecureConnector or remotely.", 
			"Label": "Macintosh Hostname"
		}, 
		{
			"Name": "sw_hostname", 
			"Type": "string", 
			"Description": "The switch name as defined in the switch", 
			"Label": "Switch Hostname"
		}, 
		{
			"Name": "wifi_end_point_host_name", 
			"Type": "string", 
			"Description": "", 
			"Label": "WiFi End Point Hostname"
		}, 
		{
			"Name": "vmware_guest_host", 
			"Type": "string", 
			"Description": "Indicates the hostname of the guest operating system. VMware Tools must be running on the endpoint to resolve this property.", 
			"Label": "Virtual Machine Guest Hostname"
		}, 
		{
			"Name": "vmware_esxi_hostname", 
			"Type": "string", 
			"Description": "Indicates the hostname of the ESXi server.", 
			"Label": "VMware ESXi Server Name"
		}, 
		{
			"Name": "wifi_client_hostname", 
			"Type": "string", 
			"Description": "Indicates the user name of the client.", 
			"Label": "WLAN Client Username"
		}
		]
		}


	return(response)

@forescout_api.route(f'/fsapi/niCore/Hosts',methods=['GET','POST','DELETE'])
def update_host_fields():
	requested_data = str(request.data)
	ip=re.split('NAME="ip"',requested_data)[1]
	ip=re.split('VALUE="',ip)[1]
	ip=re.split('"',ip)[0]
	response='<?xml version="1.0" encoding="UTF-8"?>\n<FSAPI TYPE="response" API_VERSION="1.0">\n\t<STATUS>\n\t\t<CODE>FSAPI_OK</CODE>\n\t\t<MESSAGE>Successfully updated 1 properties for host ip={}</MESSAGE>\n\t</STATUS>\n</FSAPI>'.format(ip)
	return (response)


