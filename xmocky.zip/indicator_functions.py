# This provides a method that returns a bad hash

import random

BADHASHES = 'badhashes.txt'
BADURLS = 'badurls.txt'


def get_bad_hash() -> str:
    indicator_count = _get_indicator_size_((BADHASHES))
    indicators = (row for row in open(BADHASHES, "r"))
    ran = random.randint(0, (indicator_count - 1))
    indicator = ""
    for x in range(0, ran):
        indicator = next(indicators)
    return indicator


def get_bad_url() -> str:
    indicator_count = _get_indicator_size_((BADURLS))
    indicators = (row for row in open(BADURLS, "r"))
    ran = random.randint(0, (indicator_count - 1))
    indicator = ""
    for x in range(0, ran):
        indicator = next(indicators)
    return indicator


def _get_indicator_size_(filename: str) -> int:
    count = 0
    for r in (row for row in open(filename, 'r')):
        count += 1
    return count
