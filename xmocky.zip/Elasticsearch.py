from flask import Blueprint, request, jsonify
import time
from time import gmtime, strftime
import random
import os
import binascii
from indicator_functions import get_bad_hash, get_bad_url

elasticsearch_api = Blueprint('elasticsearch_api', __name__)

@elasticsearch_api.route('/', methods=['GET'])
def test_button():
    if request.authorization is not None: 
        return {}
    else:
        response = jsonify({'message':'Auth Failed'})
        return response, 401

@elasticsearch_api.route('/<idx>/_search')
def search(idx):

	rand = random.randint(1,5)

	if rand == 1:
		return {
		  "took" : 5,
		  "timed_out" : False,
		  "_shards" : {
		    "total" : 1,
		    "successful" : 1,
		    "skipped" : 0,
		    "failed" : 0
		  },
		  "hits" : {
		    "total" : {
		      "value" : 1,
		      "relation" : "eq"
		    },
		    "max_score" : 1.3862942,
		    "hits" : [
		      {
		        "_index" : idx,
		        "_type" : "_doc",
		        "_id" : random.randint(1,99999),
		        "_score" : 1.3862942,
		        "_source" : {
		          "date" : strftime('%Y-%m-%dT%H:%M:00Z', gmtime()),
		          "timestamp" : int(round(time.time() * 1000)),
		          "type" : "Malware",
		          "message" : "Malware Alert",
		          "user" : "jd19567",
		          "host" : "win10-" + str(random.randint(1,9999)),
		          "sha256" : get_bad_hash(),
		          "path" : "C:\windows32\dropper.exe",
		          "malware_family" : "WannaCry"
		          }
		       }
		    ]
		  }
		}

	elif rand == 2:
		return {
		  "took" : 5,
		  "timed_out" : False,
		  "_shards" : {
		    "total" : 1,
		    "successful" : 1,
		    "skipped" : 0,
		    "failed" : 0
		  },
		  "hits" : {
		    "total" : {
		      "value" : 1,
		      "relation" : "eq"
		    },
		    "max_score" : 1.3862942,
		    "hits" : [
		      {
		        "_index" : idx,
		        "_type" : "_doc",
		        "_id" : random.randint(1,99999),
		        "_score" : 1.3862942,
		        "_source" : {
		          "date" : strftime('%Y-%m-%dT%H:%M:00Z', gmtime()),
		          "timestamp" : int(round(time.time() * 1000)),
		          "type" : "Phishing",
		          "message" : "Phishing Alert",
		          "user" : "jdoe",
		          "host" : "win10-" + str(random.randint(1,9999)),
		          "sha256" : get_bad_hash(),
		          "subject" : "See Attached 2020 Finanials",
		          "sender" : "fred.smith@outlook.com",
		          "recipient" : "johndoe@company.com",
		          "url" : get_bad_url(),
		          "message_id" : "<CAKBqNfyKo+ZXtkz6DUAHw6FjmsDjWDB-pvHkJy6kwO82jTbkNA@mail.outlook.com>"
		          }
		       }
		    ]
		  }
		}
		       

	elif rand == 3:
		return {
		  "took" : 5,
		  "timed_out" : False,
		  "_shards" : {
		    "total" : 1,
		    "successful" : 1,
		    "skipped" : 0,
		    "failed" : 0
		  },
		  "hits" : {
		    "total" : {
		      "value" : 1,
		      "relation" : "eq"
		    },
		    "max_score" : 1.3862942,
		    "hits" : [
		      {
		        "_index" : idx,
		        "_type" : "_doc",
		        "_id" : random.randint(1,99999),
		        "_score" : 1.3862942,
		        "_source" : {
		          "date" : strftime('%Y-%m-%dT%H:%M:00Z', gmtime()),
		          "timestamp" : int(round(time.time() * 1000)),
		          "type" : "Login Failure",
		          "message" : "Login Failure Alert",
		          "user" : "vp4453",
		          "host" : "win10-" + str(random.randint(1,9999)),
		          }
		       }
		    ]
		  }
		}

	elif rand == 4:
		return {
		  "took" : 5,
		  "timed_out" : False,
		  "_shards" : {
		    "total" : 1,
		    "successful" : 1,
		    "skipped" : 0,
		    "failed" : 0
		  },
		  "hits" : {
		    "total" : {
		      "value" : 1,
		      "relation" : "eq"
		    },
		    "max_score" : 1.3862942,
		    "hits" : [
		      {
		        "_index" : idx,
		        "_type" : "_doc",
		        "_id" : random.randint(1,99999),
		        "_score" : 1.3862942,
		        "_source" : {
		          "date" : strftime('%Y-%m-%dT%H:%M:00Z', gmtime()),
		          "timestamp" : int(round(time.time() * 1000)),
		          "type" : "DDOS",
		          "message" : "DDOS Alert",
		          "source_ip" : "34.245.56.3",
		          "dest_host" : "www-corp",
		          "port" : 80,
		          "resp_code" : 503
		          }
		       }
		    ]
		  }
		}

	elif rand == 5:
		return {
		  "took" : 5,
		  "timed_out" : False,
		  "_shards" : {
		    "total" : 1,
		    "successful" : 1,
		    "skipped" : 0,
		    "failed" : 0
		  },
		  "hits" : {
		    "total" : {
		      "value" : 1,
		      "relation" : "eq"
		    },
		    "max_score" : 1.3862942,
		    "hits" : [
		      {
		        "_index" : idx,
		        "_type" : "_doc",
		        "_id" : random.randint(1,99999),
		        "_score" : 1.3862942,
		        "_source" : {
		          "date" : strftime('%Y-%m-%dT%H:%M:00Z', gmtime()),
		          "timestamp" : int(round(time.time() * 1000)),
		          "type" : "Exfiltration",
		          "message" : "Firwall Alert - Data Exfiltration",
		          "user" : "ak7366",
		          "host" : "win10-" + str(random.randint(1,9999)),
		          "source_ip" : "10.10.145.56",
		          "sha256" : str(binascii.hexlify(os.urandom(32)).decode("utf-8")),
		          "file_type" : "zip"
		          }
		       }
		    ]
		  }
		}

	else:
		return {}
