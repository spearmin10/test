from flask import Blueprint, request
# from flask import json
import json
import time
from datetime import datetime, timedelta, timezone
import logging

min_ago = datetime.now(timezone.utc) - timedelta(seconds=45)
start_time = int(round(min_ago.timestamp() * 1000))

# Add api endpoint and integration
BASE_URL = '/api/siem/'.strip('/')
INTEGRATION = 'qradar_api'

qradar_api = Blueprint(f'{INTEGRATION}', __name__)
logger = logging.getLogger(__name__)

null = None
false = False
true = True

@qradar_api.route('/api/ariel/databases')
def login():
    return {'ok': 'ok'}

@qradar_api.route(f'/{BASE_URL}/offenses')
def get_offenses():
    result = [
        {
        "username_count": 0,
        "description": "DJM\n preceded by Port Scan detected\n containing Traffic End\n",
        "rules": [
            {
                "id": 100406,
                "type": "CRE_RULE"
            }
        ],
        "event_count": 338,
        "flow_count": 0,
        "assigned_to": null,
        "security_category_count": 3,
        "follow_up": false,
        "source_address_ids": [
            162
        ],
        "source_count": 1,
        "inactive": true,
        "protected": true,
        "closing_user": null,
        "destination_networks": [
            "Net-10-172-192.Net_192_168_0_0"
        ],
        "source_network": "Net-10-172-192.Net_10_0_0_0",
        "category_count": 3,
        "close_time": null,
        "remote_destination_count": 0,
        "start_time": start_time,
        "magnitude": 2,
        "last_updated_time": 1586195311458,
        "credibility": 3,
        "id": 356,
        "categories": [
            "Firewall Session Closed",
            "Host Port Scan",
            "Firewall Session Opened"
        ],
        "severity": 3,
        "policy_category_count": 0,
        "closing_reason_id": null,
        "device_count": 2,
        "offense_type": 0,
        "relevance": 0,
        "domain_id": 0,
        "offense_source": "10.2.2.20",
        "local_destination_address_ids": [
            6
        ],
        "local_destination_count": 1,
        "status": "OPEN"
    },
    {
        "username_count": 0,
        "description": "Access on RDP port\n",
        "rules": [
            {
                "id": 100406,
                "type": "CRE_RULE"
            }
        ],
        "event_count": 157,
        "flow_count": 0,
        "assigned_to": null,
        "security_category_count": 5,
        "follow_up": false,
        "source_address_ids": [
            162
        ],
        "source_count": 1,
        "inactive": true,
        "protected": false,
        "closing_user": "admin",
        "destination_networks": [
            "other",
            "Net-10-172-192.Net_192_168_0_0",
            "Net-10-172-192.Net_10_0_0_0"
        ],
        "source_network": "Net-10-172-192.Net_10_0_0_0",
        "category_count": 5,
        "close_time": 1585950765000,
        "remote_destination_count": 1,
        "start_time": start_time,
        "magnitude": 2,
        "last_updated_time": 1585950657979,
        "credibility": 3,
        "id": 351,
        "categories": [
            "Firewall Session Closed",
            "Firewall Session Opened",
            "Access Denied",
            "Potential Botnet Connection",
            "Alert"
        ],
        "severity": 6,
        "policy_category_count": 0,
        "closing_reason_id": 2,
        "device_count": 2,
        "offense_type": 0,
        "relevance": 0,
        "domain_id": 0,
        "offense_source": "10.2.2.20",
        "local_destination_address_ids": [
            7,
            6,
            9
        ],
        "local_destination_count": 3,
        "status": "CLOSED"
    },
    {
        "username_count": 0,
        "description": "Ido port scan\n",
        "rules": [
            {
                "id": 100406,
                "type": "CRE_RULE"
            }
        ],
        "event_count": 3,
        "flow_count": 0,
        "assigned_to": null,
        "security_category_count": 2,
        "follow_up": false,
        "source_address_ids": [
            44
        ],
        "source_count": 1,
        "inactive": true,
        "protected": true,
        "closing_user": null,
        "destination_networks": [
            "Net-10-172-192.Net_10_0_0_0"
        ],
        "source_network": "other",
        "category_count": 2,
        "close_time": null,
        "remote_destination_count": 0,
        "start_time": start_time,
        "magnitude": 2,
        "last_updated_time": 1582816066169,
        "credibility": 3,
        "id": 200,
        "categories": [
            "Firewall Session Closed",
            "Access Denied"
        ],
        "severity": 5,
        "policy_category_count": 0,
        "closing_reason_id": null,
        "device_count": 2,
        "offense_type": 0,
        "relevance": 0,
        "domain_id": 0,
        "offense_source": "52.114.132.23",
        "local_destination_address_ids": [
            4
        ],
        "local_destination_count": 1,
        "status": "OPEN"
    },
    {
        "username_count": 1,
        "description": "Access by honeypot user\n",
        "rules": [
            {
                "id": 100404,
                "type": "CRE_RULE"
            }
        ],
        "event_count": 16,
        "flow_count": 0,
        "assigned_to": null,
        "security_category_count": 3,
        "follow_up": false,
        "source_address_ids": [
            42,
            43
        ],
        "source_count": 2,
        "inactive": true,
        "protected": true,
        "closing_user": null,
        "destination_networks": [
            "Net-10-172-192.Net_172_16_0_0"
        ],
        "source_network": "other",
        "category_count": 3,
        "close_time": null,
        "remote_destination_count": 0,
        "start_time": start_time,
        "magnitude": 2,
        "last_updated_time": 1582795793369,
        "credibility": 3,
        "id": 198,
        "categories": [
            "User Login Failure",
            "General Authentication Failed",
            "Access Denied"
        ],
        "severity": 4,
        "policy_category_count": 0,
        "closing_reason_id": null,
        "device_count": 2,
        "offense_type": 3,
        "relevance": 0,
        "domain_id": 0,
        "offense_source": "yaron",
        "local_destination_address_ids": [
            2
        ],
        "local_destination_count": 1,
        "status": "OPEN"
    },
    {
        "username_count": 1,
        "description": "Blacklisted hash detected in use\n",
        "rules": [
            {
                "id": 100403,
                "type": "CRE_RULE"
            },
            {
                "id": 100406,
                "type": "CRE_RULE"
            }
        ],
        "event_count": 43,
        "flow_count": 0,
        "assigned_to": null,
        "security_category_count": 3,
        "follow_up": false,
        "source_address_ids": [
            42
        ],
        "source_count": 1,
        "inactive": true,
        "protected": true,
        "closing_user": null,
        "destination_networks": [
            "Net-10-172-192.Net_172_16_0_0"
        ],
        "source_network": "Net-10-172-192.Net_172_16_0_0",
        "category_count": 3,
        "close_time": null,
        "remote_destination_count": 0,
        "start_time": start_time,
        "magnitude": 1,
        "last_updated_time": 1584007231698,
        "credibility": 3,
        "id": 197,
        "categories": [
            "Access Denied",
            "Information",
            "Create Activity Succeeded    "
        ],
        "severity": 2,
        "policy_category_count": 0,
        "closing_reason_id": null,
        "device_count": 3,
        "offense_type": 0,
        "relevance": 0,
        "domain_id": 0,
        "offense_source": "172.31.14.252",
        "local_destination_address_ids": [
            2
        ],
        "local_destination_count": 1,
        "status": "OPEN"
    },
    {
        "username_count": 1,
        "description": "Multiple Login Failures for the Same User\n containing Failure Audit: An account failed to log on\n",
        "rules": [
            {
                "id": 100056,
                "type": "CRE_RULE"
            }
        ],
        "event_count": 37,
        "flow_count": 0,
        "assigned_to": null,
        "security_category_count": 2,
        "follow_up": false,
        "source_address_ids": [
            41,
            42
        ],
        "source_count": 2,
        "inactive": true,
        "protected": false,
        "closing_user": null,
        "destination_networks": [
            "Net-10-172-192.Net_172_16_0_0"
        ],
        "source_network": "other",
        "category_count": 2,
        "close_time": null,
        "remote_destination_count": 0,
        "start_time": start_time,
        "magnitude": 1,
        "last_updated_time": 1579533171859,
        "credibility": 2,
        "id": 196,
        "categories": [
            "User Login Failure",
            "General Authentication Failed"
        ],
        "severity": 3,
        "policy_category_count": 0,
        "closing_reason_id": null,
        "device_count": 2,
        "offense_type": 3,
        "relevance": 0,
        "domain_id": 0,
        "offense_source": "123123",
        "local_destination_address_ids": [
            2
        ],
        "local_destination_count": 1,
        "status": "OPEN"
    }
]
    return json.dumps(result)

@qradar_api.route(f'/{BASE_URL}/offense_types')
def get_offense_types():      
    return {
        "custom": True,
        "database_type": "EVENTS",
        "id": 42,
        "name": "test",
        "property_name": "String"
    }

@qradar_api.route(f'/{BASE_URL}/offense_closing_reasons')
def get_offense_closing_reasons():      
    result = [
                {
                "id": 1,
                "is_deleted": True,
                "is_reserved": True,
                "text": 'False Positive'
            },
                {
                "id": 2,
                "is_deleted": True,
                "is_reserved": True,
                "text": 'Endpoint Reinstalled'
            }    
        ]
    return json.dumps(result)

@qradar_api.route(f'/{BASE_URL}/offenses/<int:id>')
def get_offense_id(id):      
    return {
                # "id": id,
                "assigned_to": "mocker",
                "categories": [
                    "Unknown Potential Exploit Attack",
                    "Potential Web Exploit"
                ],
                "category_count": 2,
                "close_time": None,
                "closing_reason_id": 1,
                "closing_user": None,
                "credibility": 2,
                "description": "Activacion",
                "destination_networks": [
                    "mock_net"
                ],
                "device_count": 2,
                "domain_id": 27,
                "event_count": 2,
                "flow_count": 0,
                "follow_up": False,
                "inactive": False,
                "last_updated_time": 1563433313767,
                "local_destination_address_ids": [
                    1234412
                ],
                "local_destination_count": 1,
                "log_sources": [
                    {
                        "id": 115,
                        "name": "Custom Rule Engine",
                        "type_id": 18,
                        "type_name": "EventCRE"
                    },
                    {
                        "id": 2439,
                        "name": "FortiGate 02",
                        "type_id": 73,
                        "type_name": "FortiGate"
                    }
                ],
                "magnitude": 4,
                "offense_source": "192.168.0.1",
                "offense_type": 0,
                "policy_category_count": 0,
                "protected": False,
                "relevance": 4,
                "remote_destination_count": 0,
                "rules": [
                    {
                        "id": 166,
                        "type": "CRE_RULE"
                    }
                ],
                "security_category_count": 2,
                "severity": 6,
                "source_address_ids": [
                    294626
                ],
                "source_count": 1,
                "source_network": "other",
                "start_time": start_time,
                "status": "OPEN",
                "username_count": 0
            }

@qradar_api.route(f'/{BASE_URL}/<path:path>/notes/', defaults={'note_id': None})
@qradar_api.route(f'/{BASE_URL}/<path:path>/notes/<int:note_id>')
def get_note(path, note_id):
    return {
            "create_time": start_time,
            "id": note_id,
            "note_text": "XMocky is aweeeeesome!!",
            "username": "Neo"
        }

@qradar_api.route(f'/{BASE_URL}/source_addresses')
def get_source_addresses():
    return {
            "create_time": "time",
            "id": "id",
            "note_text": "XMocky is aweeeeesome!!",
            "username": "Neo"
        }

@qradar_api.route(f'/api/asset_model/assets/')
def get_assets():
    id = request.args.get('filter')
    if not id:
        id = 1001
    result = [
    {
        "interfaces": [
            {
                "mac_address": "Unknown NIC",
                "last_seen_profiler": 1587712352012,
                "created": 1587712352012,
                "last_seen_scanner": 0,
                "first_seen_scanner": 0,
                "ip_addresses": [
                    {
                        "last_seen_profiler": 1587712351496,
                        "created": 1587712351496,
                        "last_seen_scanner": 0,
                        "first_seen_scanner": 0,
                        "network_id": 2,
                        "id": id,
                        "type": "IPV4",
                        "first_seen_profiler": 1587712351496,
                        "value": "34.209.40.39"
                    }
                ],
                "id": id,
                "first_seen_profiler": 1587712352012
            }
        ],
        "id": id,
        "properties": [
            {
                "last_reported": 1587712352014,
                "name": "Unified Name",
                "type_id": 1002,
                "id": 1299,
                "last_reported_by": "IDENTITY:0",
                "value": "ec2-34-209-40-39.us-west-2.compute.amazonaws.com"
            }
        ],
        "domain_id": 0
    }]
    return json.dumps(result)

@qradar_api.route(f'/api/ariel/searches', methods=['GET', 'POST'])
def get_searches():
    return {
            "status": "EXECUTE", 
            "search_id": "14b1d702-edba-43e7-b01c-36f8da1ed016"
    }

@qradar_api.route(f'/api/ariel/searches/<id>', methods=['GET', 'POST'])
def get_search(id):
    return {
            "cursor_id": id,
            "status": "COMPLETED",
            "compressed_data_file_count": 0,
            "compressed_data_total_size": 0,
            "data_file_count": 30,
            "data_total_size": 2760,
            "index_file_count": 0,
            "index_total_size": 0,
            "processed_record_count": 30,
            "desired_retention_time_msec": 86400000,
            "progress": 100,
            "progress_details": [],
            "query_execution_time": 192,
            "query_string": "SELECT \"Flow Source\", avg(\"AVG_Flows per Second - Average 15 Min\"), max(\"AVG_Flows per Second - Peak 1 Min\") FROM GV_10024_DAILY GROUP BY \"Flow Source\" last 30 days",
            "record_count": 1,
            "save_results": False,
            "completed": True,
            "subsearch_ids": [],
            "snapshot": None,
            "search_id": id
        }

@qradar_api.route(f'/api/ariel/searches/<id>/results', methods=['GET', 'POST'])
def get_search_results(id):
    return {
        "starttime": 1589254680112,
        "protocolid": 255,
        "sourceip": "172.31.45.236",
        "logsourceid": 65,
        "qid": id,
        "sourceport": 0,
        "eventcount": 1,
        "magnitude": 5,
        "identityip": "0.0.0.0",
        "destinationip": "194.224.52.6",
        "destinationport": 0,
        "category": 8052,
        "username": "it-user"
    }

@qradar_api.route(f'/api/siem/offenses/<id>', methods=['GET', 'POST'])
def update_offense(id):
    protected = request.args.get('protected')
    return {
            "Followup": False, 
            "OffenseSource": "admin", 
            "Description": "Multiple Login Failures for the Same User\n preceded by shachar_test\n containing Failed Login Attempt\n", 
            "EventCount": 3, 
            "Credibility": 3, 
            "Status": "OPEN", 
            "DestinationHostname": [
                "Net-10-172-192.Net_172_16_0_0"
            ], 
            "StartTime": "2018-10-16T13:07:36.245000Z", 
            "Protected": protected, 
            "Magnitude": 3, 
            "FlowCount": 0, 
            "OffenseType": "Username", 
            "SourceAddress": [
                "94.188.164.68"
            ], 
            "Relevance": 3, 
            "Severity": 7, 
            "ID": id, 
            "Categories": [
                "User Login Failure", 
                "SIM User Authentication"
            ], 
            "LastUpdatedTime": "2018-10-16T13:07:40.675000Z"
        }
    
@qradar_api.route(f'/api/siem/offenses/<id>/notes', methods=['POST'])
def create_note(id):
    text = request.args.get('note_text')
    result =  {
                    "note_text": text, 
                    "create_time": start_time, 
                    "username": "API_user: admin", 
                    "id": id
                }
        
    return json.dumps(result)

@qradar_api.route(f'/api/reference_data/sets/<set_name>')
def get_reference_name(set_name):
    return {
        "timeout_type": "UNKNOWN",
        "number_of_elements": 70652,
        "creation_time": 1583771823122,
        "name": set_name,
        "element_type": "ALNIC"
    }

@qradar_api.route(f'/api/reference_data/sets', methods=['POST'])
def create_reference_name():
    type = request.args.get('element_type')
    name = request.args.get('name')
    return {
        "timeout_type": type,
        "number_of_elements": 70652,
        "creation_time": 1583771823122,
        "name": name,
        "element_type": "ALNIC",
        "number_of_elements": 1,
    }

@qradar_api.route(f'/api/reference_data/sets/<ref_name>', methods=['DELETE'])
def delete_reference_name(ref_name):
    return {
        "timeout_type": type,
        "number_of_elements": 70652,
        "creation_time": 1583771823122,
        "name": ref_name,
        "element_type": "ALNIC",
        "number_of_elements": 1,
    }

@qradar_api.route(f'/api/reference_data/sets/<name>', methods=['POST'])
def create_reference_set_value(name):
    value = request.args.get('value')
    if name == 'Date':
        return {
                "TimeoutType": "UNKNOWN", 
                "ElementType": "DATE", 
                "CreationTime": int(value), 
                "Name": name, 
                "NumberOfElements": 1
            }
    else:
        return {
                "TimeoutType": "UNKNOWN", 
                "ElementType": "DATE", 
                "CreationTime": 1583771823122, 
                "Name": name, 
                "NumberOfElements": 1
            }
        
