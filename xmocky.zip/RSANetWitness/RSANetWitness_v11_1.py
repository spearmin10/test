from flask import Blueprint, request
import json
import logging

BASE_URL = '/rest/api/'.strip('/')
INTEGRATION = 'rsa_netwitness_v11_1_api'

rsa_netwitness_v11_1_api = Blueprint(f'{INTEGRATION}', __name__)
logger = logging.getLogger(__name__)

with open('RSANetWitness/RSANetWitness_v11_1.json', 'r') as f:
    mock_data = json.load(f)

@rsa_netwitness_v11_1_api.route(f'/{BASE_URL}/test')
def test():
    return {'result': 'it works'}

@rsa_netwitness_v11_1_api.route(f'/{BASE_URL}/auth/userpass', methods=['POST'])
def auth():
    return mock_data['auth']

@rsa_netwitness_v11_1_api.route(f'/{BASE_URL}/incidents')
def get_incidents():
    return json.dumps(mock_data['incidents'])

@rsa_netwitness_v11_1_api.route(f'/{BASE_URL}/incidents/<id>/alerts')
def get_alerts(id):
    return json.dumps(mock_data['alerts'])

@rsa_netwitness_v11_1_api.route(f'/{BASE_URL}/incidents/<id>', methods=['GET','PATCH','DELETE'])
def delete_incident(id):
    if request.method == 'DELETE':
        return {}
    elif request.method == 'GET':
        return json.dumps(mock_data['incident'])
    elif request.method == 'PATCH':
        data = mock_data['update']
        data['status'] = request.json['status']
        data['assignee'] = request.json['assignee']
        return json.dumps(data)
