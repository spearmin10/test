# RSA Netwitness

### v 11.1
#### Setup Instructions
Add the XMOCKY url and port to the "Server URL" parameter of the integration.
Add a username and password which can be any value.
Test the integration works.

#### Notes
The parameters for each command are passed as is.

#### Tested Commands


### Logs and Packets
#### Setup Instructions
Add XMOCKY URL without the port to the "Server URL" integration parameters.
For the concentrator port add the xmocky port followed by `/rsa`. IE `30102/rsa`.
Enter and username/password combination.
Do NOT validate server certificate.

#### Tested Commands
`!nw-database-dump session=1`
`!nw-sdk-summary`
`!netwitness-query size=10`
`!nw-sdk-session id1=1 id2=1`
`!nw-sdk-content session=1`
`!nw-sdk-values fieldName=ip.src id1=1 id2=29`

#### TODO
[] `!netwitness-msearch`
[] `!netwitness-packets`
