import os
import json
import logging
from flask import Blueprint, request, send_from_directory

# Note you must add /rsa to integration configuration
# for the appliance port.  IE appliance port: 3000/rsa
BASE_URL = 'rsa'
INTEGRATION = 'rsa_nw_logs_packets_api'

rsa_nw_logs_packets_api = Blueprint(f'{INTEGRATION}', __name__)
logger = logging.getLogger(__name__)

with open('RSANetWitness/logs_packets.json', 'r') as f:
    mock_data = json.load(f)

@rsa_nw_logs_packets_api.route(f'/{BASE_URL}/test')
def test():
    return {'result': 'it works'}

@rsa_nw_logs_packets_api.route(f'/{BASE_URL}/sdk/')
def sdk():
    txt = ''
    print(request.args)
    msg = request.args.get('msg')
    if msg == 'help':
      return {'status': 'ok'}
    # !nw-sdk-summary
    if msg == 'summary':
      txt = mock_data['sdk-summary']
    # !netwitness-query size=10
    elif msg == 'query':
      txt = mock_data['query']
    # !nw-sdk-session id1=1 id2=1
    elif msg == 'session':
      txt = mock_data['sdk-session']
    # !nw-sdk-content session=1
    elif msg == 'content':
      path = os.path.join(os.getcwd(), 'RSANetWitness')
      return send_from_directory(path, 'nw-sdk-content.txt')
    #!nw-sdk-values fieldName=ip.src id2=1 id2=29
    elif msg == 'values':
      txt = mock_data['sdk-values']
    return json.dumps(txt)


@rsa_nw_logs_packets_api.route(f'/{BASE_URL}/database')
def database():
    msg = request.args.get('msg')
    # !nw-database-dump session=1
    if msg == 'dump':
      txt = mock_data['database-dump']
    return json.dumps(txt)

