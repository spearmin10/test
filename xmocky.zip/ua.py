# ua = [
#     "Python-httplib2/0.13.1 (gzip)",
#     "Python-httplib2/0.13.1",
#     "python-requests/2.18.4",
#     "Go-http-client/1.1",
#     "splunk-sdk-python/1.6.12",
#     "splunk-sdk-python/1.6.6",
#     "python-requests/2.22.0",
#     "python-requests/2.23.0",
#     "python-requests/2.21.0",
#     "python-requests/2.24.0",
#     "elasticsearch-py/7.0.4 (Python 3.7.4)",
#     "splunk-sdk-python",
# ]

ua = [
    "Python-httplib2",
    "Python-httplib2",
    "python-requests",
    "Go-http-client",
    "splunk-sdk-python",
    "splunk-sdk-python",
    "python-requests",
    "python-requests",
    "python-requests",
    "python-requests",
    "elasticsearch-py",
    "splunk-sdk-python",
]

