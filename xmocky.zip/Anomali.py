from flask import Blueprint, request

anomali_api = Blueprint('anomali_api', __name__)

@anomali_api.route('/api/v2/intelligence/')
def reputation():
    ioc = request.args.get('value')
    type = request.args.get('type')
    return {
            "objects":[
                {   
                    "asn": 7777,
                    "value": ioc,
                    "classification": "public",
                    "confidence": "90",
                    "country": "SG",
                    "status": "Active",
                    "detail": "running V2Dir, Valid, tor-version=0.2.4.23",
                    "detail2": "imported by user GSerrano",
                    "lat": "59.8944",
                    "lon": "30.2642",
                    "source": "Anomali Labs TOR Nodes",
                    "meta":{
                        "severity": "high"
                        }
                }
            ]
        }

@anomali_api.route('/api/v1/submit/new/', methods=['POST', 'GET'])
def submit_url():
    return {
            "success": 'true',
            "reports":{
                "WINDOWS7": {
                    "id": "7"
                }
            }
        }

@anomali_api.route('/api/v1/submit/<id>/')
def report_result(id):
    return {
            "status": "done",
            "verdict": "malicious",
        }

@anomali_api.route('/api/v1/submit/<id>/report')
def report_status(id):
    return {
        "results": 
        {
            "info": {
                "category": "malware",
                "duration": "5 minutes",
                "verdict": "malicious",
                "name": "WINDOWS7",
                "id": "5"
                }
            }
        }

@anomali_api.route('/api/v1/intelligence/import/')
def import_ioc():
    url = request.args.get('url')
    return {
            "success": True,
            "import_session_id": "1"
            }

