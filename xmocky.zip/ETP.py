from flask import Blueprint

etp_api = Blueprint("etp_api", __name__, static_folder="files")

null = None
false = False
true = True


@etp_api.route("/etp/api/v1/alerts", methods=["GET", "DELETE", "POST"])
def test():
    return {
        "data": [
            {
                "attributes": {
                    "meta": {
                        "read": false,
                        "from_last_modified_on": "2018-04-02T22:28:46.133",
                        "legacy_id": 52564988,
                        "acknowledged": false,
                    },
                    "ati": {"data": {}},
                    "alert": {
                        "product": "ETP",
                        "alert_type": ["at"],
                        "severity": "major",
                        "ack": "no",
                        "explanation": {
                            "analysis": "binary",
                            "anomaly": "",
                            "cnc_services": {},
                            "malware_detected": {
                                "malware": [
                                    {
                                        "domain": "xxx.xxx.xx.xxx",
                                        "downloaded_at": "2020-09-03T15:57:58Z",
                                        "executed_at": "2020-00-03T15:57:59Z",
                                        "name": "Phish.LIVE.DTI.URL",
                                        "sid": "88000012",
                                        "stype": "known-url",
                                        "submitted_at": "2020-09-03T15:57:58Z",
                                    }
                                ]
                            },
                            "os_changes": [],
                            "protocol": "",
                            "timestamp": "2020-09-03T15:57:59Z",
                        },
                        "timestamp": "2020-09-03T15:58:01.614",
                        "action": "notified",
                        "name": "malware-object",
                    },
                    "email": {
                        "status": "quarantined",
                        "source_ip": "xx.xxx.xxx.xx",
                        "smtp": {
                            "rcpt_to": "hiongkc@singaporepower.com.sg",
                            "mail_from": "semangatbraybadaiinipastiberlalu895245-0109207@mandhayuang.com",
                        },
                        "etp_message_id": "76CF1709028AAAA5d61a8dbe",
                        "headers": {
                            "cc": "",
                            "to": "hiongkc@singaporepower.com.sg",
                            "from": "semangatbraybadaiinipastiberlalu895245-0109207@mandhayuang.com",
                            "subject": "Receipts From Apple, Thank your for purchasing COINS MASTER Spin Mobile [dot] invoice attachment automatically send by our system on September, 01 2020 PDT",
                        },
                        "attachment": "hxxps://t[dot]umblr[dot]com/redirect?z=hxxps%3A%2F%2Fmybabyshrt[dot]com%2Fr%2Fj1XStjh&t=ZDgzMzdhZjVlMWI5ODU3NmQ0MTc3MzE2MjJmMjRiMDI2ZmVhNDA2ZCw5OWJiMzZmYTg4MjQ3OTllZWE0MjE2OTRiYzI3ODVhMTMwN2JmNjY3&ts=1598937582",
                        "timestamp": {"accepted": "2020-09-03T15:57:55"},
                    },
                },
                "id": "AWKMOs-2_r7_CWOc2okO",
            }
        ],
        "meta": {
            "total": 1,
            "copyright": "Copyright 2017 Fireeye Inc.",
            "fromLastModifiedOn": {"end": "2018-04-02T22:28:46.133"},
        },
        "type": "alerts",
    }

