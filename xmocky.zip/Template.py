from flask import Blueprint, request
import json
import logging

BASE_URL = '[endpoint_url]'.strip('/')
INTEGRATION = '[template_api]'

[template_api] = Blueprint(f'{INTEGRATION}', __name__) # noqa 
logger = logging.getLogger(__name__)

@template_api.route(f'/{BASE_URL}/test')
def test():
    return {'result': 'it works'}
