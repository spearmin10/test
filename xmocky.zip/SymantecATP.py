from flask import Blueprint, request, Response, make_response
import random
import string
import datetime
import base64
import threading
import hashlib
import copy

satp_api = Blueprint('satp', __name__)

ACCESS_TOKEN = 'SYMANTEC_ATP_MOCK_TOKEN'
COMMAND_IDS = [f'b742dd6d-d4ab-4207-9581-d923e56fdc{i:#02}' for i in range(0,255)]
HOST_NAME = 'XSJOHNDOE'
USER_NAME = 'jdoe'
HOST_IP = '192.168.7.66'
DEVICE_UID = '28cfa165-d024-485e-a96a-a7c041f153d5'

command_ids = COMMAND_IDS
operating_commands = {}

lock = threading.Lock()

def make_target(id, state, qcount = 0):

  if state == 0:
    message = 'Completed'
  elif state == 1:
    message = 'In Progress'
  elif state == 3:
    message = 'Cancelled'
  else:
    message = 'Error'
  
  return {
    'id' : id,
    'state': state,
    'message': message,
    'qcount': qcount
  }

def make_command_state_response(command_id):
  global operating_commands
  global lock
  
  lock.acquire()
  try:
    command = operating_commands[command_id]
    targets = []
    status = []
    for target in command['targets']:
      if target['state'] == 1:
        qcount = target.get('qcount', 0)
        state = 0 if qcount >= 2 else 1
        target = make_target(target['id'], state, qcount+1)
      
      targets.append(target)
      status.append({
        'target': target['id'],
        'state': target['state'],
        'error_code': 0,
        'message': target['message']
      })
    
    command['targets'] = targets
    
    out = {
      'command_id': command_id,
      'action': command['action'],
      'status': status
    }
  finally:
    lock.release()

  return out


def make_command_cancel_state_response(command_id):
  global operating_commands
  global lock
  
  lock.acquire()
  try:
    command = operating_commands[command_id]
    targets = [make_target(target['id'], 3) for target in command['targets']]
    command['targets'] = targets
    
    out = {
      'command_id': command_id,
      'action': command['action'],
      'status': [{
          'target': target['id'],
          'state': target['state'],
          'error_code': 0,
          'message': target['message']
        } for target in targets
      ]
    }
  finally:
    lock.release()

  return out


def make_file_info():
  return {
    "sha2": "8692251329fef60490be1c26281710b7e88250fd82b3f679f87d6785db854ed5",
    "md5": "98c22a12101fae9b3b65820dd5d45b52",
    "file_instances": [
      {
        "name": "da_midpoint-gray12jd!.pdf.exe.exe",
        "folder": "csidl_system_drive\\temp\\midpointgray\\hsdfuow-dslkf1213"
      },
      {
        "name": "socar12jd!.pdf.exe",
        "folder": "csidl_system_drive\\temp\\midpointgray\\kgcbac-mopnf4922"
      }
    ],
    "mime_type": "application/x-dosexec",
    "size": 5092,
    "signature_company_name": "Google Inc",
    "signature_issuer": "VeriSign Class 3 Code Signing 2010 CA",
    "file_health": 2,
    "reputation_band": 4,
    "prevalence_band": 3,
    "file_age": 1,
    "cynic_verdict": 2,
    "targeted_attack": "no"
  }


@satp_api.route('/atpapi/oauth2/tokens', methods=['POST'])
def get_access_token():
  return {
    'access_token': ACCESS_TOKEN
  }

@satp_api.route('/atpapi/v1/appliances', methods=['GET'])
def get_appliances():
  return {
    "appliance_list": [
      {
        "appliance_id": "4219549d-31cc-fe0b-75b7-19a156cb918a",
        "software_version": "2.2.0-101",
        "appliance_name": "ATP",
        "role": ["endpoint", "network scanner", "management"],
        "appliance_time": "2016-06-06T17:56:06Z"
      }
    ]
  }


@satp_api.route('/atpapi/v1/commands', methods=['POST'])
def do_commands():
  global command_ids
  global operating_commands
  global lock
  
  lock.acquire()
  try:
    command_id = command_ids[0]
    command_ids = command_ids[1:] + command_ids[:1]
    
    target_ids = request.json.get('targets')
    target_ids = target_ids if isinstance(target_ids, list) else [target_ids]
    targets = [make_target(id, 1) for id in target_ids]
    
    operating_commands[command_id] = {
      'action': request.json.get('action'),
      'targets': targets
    }
  finally:
    lock.release()
  
  return {"command_id": command_id}


@satp_api.route('/atpapi/v1/commands/<command_id>', methods=['GET'])
def get_command_state(command_id):
  return make_command_state_response(command_id)


@satp_api.route('/atpapi/v1/commands/<command_id>', methods=['PATCH'])
def get_command_cancel(command_id):
  return make_command_cancel_state_response(command_id)


@satp_api.route('/atpapi/v1/files/<file_hash>', methods=['GET'])
def get_file(file_hash):
  file = make_file_info()
  if len(file_hash) == 64:
    file['md5'] = hashlib.md5(file_hash.lower().encode()).hexdigest()
  else:
    file['sha2'] = hashlib.md5(file_hash.lower().encode()).hexdigest()
  
  return {
    "file_list": [ file ],
    "total":1
  }


@satp_api.route('/atpapi/v1/events', methods=['POST'])
def get_events():
  result = [
    {
      "data_direction": "inbound",
      "device_ip": HOST_IP,
      "device_name": HOST_NAME,
      "device_time": "2020-09-24T02:16:54.144Z",
      "device_uid": DEVICE_UID,
      "file": {
        "file_age": 2,
        "folder": "CSIDL_WINDOWS\\assembly\\nativeimages_v2.0.50727_32\\microsoft.powershel#\\de238537206b657f56cc33c67dadf23b",
        "md5": "1f67f0c43a9c46d25a56ab96b152296a",
        "name": "Microsoft.PowerShell.Commands.Utility.ni.dll",
        "prevalence_band": 6,
        "reputation_band": 2,
        "sha2": "38479d21c4c0ef6b476034fdf0b8bf2837e82b5e71af667091b4b25ea9bdfb84",
        "size": 1681920
      },
      "log_name": "epmp_events-rrs-2020-09-24",
      "log_time": "2020-09-24T02:16:56.293Z",
      "sep_installed": True,
      "type_id": 4096,
      "user_name": USER_NAME,
      "uuid": "0395e800-fe0c-11ea-c8fc-000003f58c48"
    },
    {
      "bash": {
        "recommended_action": "0",
        "signature_version": "20200914.001",
        "virus_id": "4294925046",
        "virus_name": "SONAR.SymcTamper!g14"
      },
      "device_ip": HOST_IP,
      "device_name": HOST_NAME,
      "device_time": "2020-09-24T02:16:52.924Z",
      "device_uid": DEVICE_UID,
      "file": {
        "folder": "CSIDL_PROGRAM_FILES\\sky product\\skysea client view",
        "md5": "83d188acbdf462bd6343b8b23463656",
        "name": "astagent.exe",
        "sha2": "bb24742481cb444d6fcacf96e592f6a6dc49fb1a2e42b46ffe96c4ad53dcf751",
        "size": 10776633
      },
      "log_name": "epmp_events-2020-09-24",
      "log_time": "2020-09-24T02:16:53.272Z",
      "sep_installed": True,
      "type_id": 4100,
      "user_name": USER_NAME,
      "uuid": "02dbbfc0-fe0c-11ea-e3e0-000003f58b90"
    }
  ]
  
  return {
    "next": None,
    "total": len(result),
    "result": result
  }


@satp_api.route('/atpapi/v1/incidentevents', methods=['POST'])
def get_incident_events():
  result = [
    {
      "device_end_time": "2020-08-25T05:00:27.000Z",
      "device_ip": HOST_IP,
      "device_name": HOST_NAME,
      "device_time": "2020-08-25T05:00:27.000Z",
      "device_uid": DEVICE_UID,
      "event_actor": {
        "file": {
          "name": "excel.exe",
          "normalized_path": "CSIDL_PROGRAM_FILES\\microsoft office\\root\\office16\\excel.exe",
          "path": "CSIDL_PROGRAM_FILES\\microsoft office\\root\\office16\\excel.exe",
          "sha2": "b26729023f31c8d01f398ad4c63f75050575bb1c901cafb9bd1304dcf8821ed9"
        },
        "pid": 13780
      },
      "incident": "a77d45b0-e6b7-11ea-edb8-000000000004",
      "log_name": "epmp_incident-2020-08-25",
      "log_time": "2020-08-25T09:45:05.163Z",
      "operation": "LAUNCH",
      "process": {
        "cmd_line": "CSIDL_SYSTEMX86\\cmd.exe /c certutil -f -decode CSIDL_DRIVE_FIXED\\work\\5_1.txt CSIDL_DRIVE_FIXED\\work\\5_1.pdf",
        "file": {
          "name": "cmd.exe",
          "normalized_path": "CSIDL_SYSTEMX86\\cmd.exe",
          "path": "CSIDL_SYSTEMX86\\cmd.exe",
          "sha2": "3685495d051137b1c4efde22c26df0883614b6453b762fa84588da55ed2e7744"
        },
        "pid": 14916
      },
      "sep_installed": True,
      "severity_id": 1,
      "type_id": 8001,
      "user_name": USER_NAME,
      "uuid": "a77dbae0-e6b7-11ea-d6d4-00000000004f"
    },
    {
      "device_end_time": "2020-08-25T05:00:28.000Z",
      "device_ip": HOST_IP,
      "device_name": HOST_NAME,
      "device_time": "2020-08-25T05:00:28.000Z",
      "device_uid": DEVICE_UID,
      "event_actor": {
        "file": {
          "name": "cmd.exe",
          "normalized_path": "CSIDL_SYSTEMX86\\cmd.exe",
          "path": "CSIDL_SYSTEMX86\\cmd.exe",
          "sha2": "3685495d051137b1c4efde22c26df0883614b6453b762fa84588da55ed2e7744"
        },
        "pid": 14916
      },
      "incident": "a77d45b0-e6b7-11ea-edb8-000000000004",
      "log_name": "epmp_incident-2020-08-25",
      "log_time": "2020-08-25T09:45:05.400Z",
      "operation": "LAUNCH",
      "process": {
        "cmd_line": "certutil -f -decode CSIDL_DRIVE_FIXED\\work\\5_1.txt CSIDL_DRIVE_FIXED\\work\\5_1.pdf",
        "file": {
          "name": "certutil.exe",
          "normalized_path": "CSIDL_SYSTEMX86\\certutil.exe",
          "path": "CSIDL_SYSTEMX86\\certutil.exe",
          "sha2": "5c2493777e2d11aa088b9e927219f5bf02ba91e7e94235a14436d16d939c0101"
        },
        "pid": 3320
      },
      "sep_installed": True,
      "severity_id": 1,
      "type_id": 8001,
      "user_name": USER_NAME,
      "uuid": "a7a16f80-e6b7-11ea-ff61-000000000053"
    },
    {
      "device_end_time": "2020-08-25T05:00:28.000Z",
      "device_ip": HOST_IP,
      "device_name": HOST_NAME,
      "device_time": "2020-08-25T05:00:28.000Z",
      "device_uid": DEVICE_UID,
      "event_actor": {
        "file": {
          "name": "cmd.exe",
          "normalized_path": "CSIDL_SYSTEMX86\\cmd.exe",
          "path": "CSIDL_SYSTEMX86\\cmd.exe",
          "sha2": "3685495d051137b1c4efde22c26df0883614b6453b762fa84588da55ed2e7744"
        }
      },
      "incident": "a77d45b0-e6b7-11ea-edb8-000000000004",
      "log_name": "epmp_incident-2020-08-25",
      "log_time": "2020-08-25T09:45:05.313Z",
      "operation": "LAUNCH",
      "process": {
        "cmd_line": "certutil -f -decode CSIDL_DRIVE_FIXED\\work\\5_1.txt CSIDL_DRIVE_FIXED\\work\\5_1.pdf",
        "file": {
          "name": "certutil.exe",
          "normalized_path": "CSIDL_SYSTEMX86\\certutil.exe",
          "path": "CSIDL_SYSTEMX86\\certutil.exe",
          "sha2": "5c2493777e2d11aa088b9e927219f5bf02ba91e7e94235a14436d16d939c0101"
        },
        "pid": 3320
      },
      "sep_installed": True,
      "severity_id": 1,
      "type_id": 8001,
      "user_name": USER_NAME,
      "uuid": "a7942910-e6b7-11ea-eba0-000000000050"
    }
  ]
  
  return {
    "next": None,
    "total": len(result),
    "result": result
  }


@satp_api.route('/atpapi/v1/incidents', methods=['POST'])
def get_incidents():
  result = [
    {
      "atp_incident_id": 100000,
      "deviceUid": [
        DEVICE_UID
      ],
      "device_time": "2020-09-14T00:14:56.161Z",
      "event_count": 1,
      "filehash": [
        "null"
      ],
      "first_event_seen": "2020-09-14T00:14:55.585Z",
      "last_event_seen": "2020-09-14T00:14:55.585Z",
      "log_name": "epmp_incident-2020-09-14",
      "priority_level": 3,
      "recommended_action": "Symantec Endpoint Protection blocked the memory attack. However, the endpoints may still be infected. Investigate the infected endpoints. Retrieve all related recorded process or endpoint events for further investigation. Isolate the endpoints and/or clean the detection.",
      "state": 1,
      "summary": "Memory Exploit Attack: Structured Exception Handler Overwrite detected.",
      "time": "2020-09-14T00:14:56.161Z",
      "updated": "2020-09-14T00:14:56.161Z",
      "uuid": "5198d110-f61f-11ea-f697-000000000009"
    },
    {
      "atp_incident_id": 100001,
      "deviceUid": [
        DEVICE_UID
      ],
      "device_time": "2020-09-23T04:53:26.974Z",
      "domainId": [
        "lodder7.bizlodder7.biz"
      ],
      "event_count": 1,
      "filehash": [
        "4b15e5d66e2500549bc55c8cb0d6d1667cbc00ed0040b1b54f815232130a60db"
      ],
      "first_event_seen": "2020-09-23T04:53:26.120Z",
      "last_event_seen": "2020-09-23T04:53:26.120Z",
      "log_name": "epmp_incident-2020-09-23",
      "priority_level": 1,
      "recommended_action": "Consider blacklisting the site. In addition, you may need to investigate the source of the exposure to see if further action is required.",
      "state": 1,
      "summary": "Malicious domain lodder7.bizlodder7.biz detected",
      "time": "2020-09-23T04:53:26.974Z",
      "updated": "2020-09-23T04:53:26.974Z",
      "uuid": "b7bc45e0-fd58-11ea-f17b-00000000000c"
    }
  ]
  
  return {
    "next": "aaaa",
    "total": len(result),
    "result": result
  }
