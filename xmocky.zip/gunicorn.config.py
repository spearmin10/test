import multiprocessing
  
bind = "0.0.0.0:3000"
certfile = "cert.pem"
keyfile = "key.pem"
workers = multiprocessing.cpu_count() * 2 + 1
access_log = "/var/log/xmocky-access.log"