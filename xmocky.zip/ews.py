from flask import Blueprint, request, Response, send_file
import json
import logging
import os
import sys


BASE_URL = '/ews-xmocky-api'.strip('/')
INTEGRATION = 'ews_api'

ews_api = Blueprint(f'{INTEGRATION}', __name__)
logger = logging.getLogger(__name__)


@ews_api.route(f'/{BASE_URL}/test')
def test():
    return "ok"

@ews_api.route(f'/{BASE_URL}/get-folder')
def get_folder():
    get_folder_response = '''{
    "changeKey": "BwAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAFm",
    "childrenFolderCount": 0,
    "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIZMAAAAA==",
    "name": "AllItems",
    "totalCount": 199,
    "unreadCount": 6
}'''
    return get_folder_response

@ews_api.route(f'/{BASE_URL}/find-folder')
def find_folder():
    find_folder_response = '''[
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAACA",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBBgAAAA==",
        "name": "Common Views",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "BwAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAFm",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIZMAAAAA==",
        "name": "AllItems",
        "totalCount": 199,
        "unreadCount": 6
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAABqV",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJX/gAAAA==",
        "name": "PeoplePublicData",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAVs",
        "childrenFolderCount": 3,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBSgAAAA==",
        "name": "SubstrateFiles",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAABM4kA",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBSwAAAA==",
        "name": "GraphWorkingSet",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAWC",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBTAAAAA==",
        "name": "ClassicAttachments",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEsiH",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBTgAAAA==",
        "name": "SPOOLS",
        "totalCount": 9,
        "unreadCount": 0
    },
    {
        "changeKey": "BwAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAFu",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIZNAAAAA==",
        "name": "People I Know",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAKL",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBPQAAAA==",
        "name": "SharePointNotifications",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAACR",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBEwAAAA==",
        "name": "DefaultFoldersChangeHistory",
        "totalCount": 358,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAABPx",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJX8gAAAA==",
        "name": "CalendarSharingCacheCollection",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAABM4zT",
        "childrenFolderCount": 0,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAABNIV/AAA=",
        "name": "O365 Suite Notifications",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAABtQ",
        "childrenFolderCount": 1,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBRAAAAA==",
        "name": "FreeBusyLocalCache",
        "totalCount": 2,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAABtJ",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJYAgAAAA==",
        "name": "FreeBusyLocalCacheSubscriptions",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAHd",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBLQAAAA==",
        "name": "XrmActivityStream",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAIC",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBLgAAAA==",
        "name": "TemporarySaves",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAIm",
        "childrenFolderCount": 2,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBMgAAAA==",
        "name": "SkypeSpacesData",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAIv",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBMwAAAA==",
        "name": "SkypeMessages",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAJC",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBNQAAAA==",
        "name": "TeamsMeetings",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAA5s",
        "childrenFolderCount": 1,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBYwAAAA==",
        "name": "Connectors",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAA50",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJX2QAAAA==",
        "name": "ConnectorConfigurations",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAKU",
        "childrenFolderCount": 1,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBPgAAAA==",
        "name": "QuarantinedEmail",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAKd",
        "childrenFolderCount": 4,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBPwAAAA==",
        "name": "QuarantinedEmailDefaultCategory",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAK4",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBQgAAAA==",
        "name": "QedcLongRetention",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAALB",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBQwAAAA==",
        "name": "QedcDefaultRetention",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAKm",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBQAAAAA==",
        "name": "QedcShortRetention",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAKv",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBQQAAAA==",
        "name": "QedcMediumRetention",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAABnW",
        "childrenFolderCount": 1,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJX+AAAAA==",
        "name": "PACE",
        "totalCount": 5,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAABM4zb",
        "childrenFolderCount": 0,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAABNIWAAAA=",
        "name": "DelveNotifications",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAACC",
        "childrenFolderCount": 18,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBCAAAAA==",
        "name": "Top of Information Store",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAACJ",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBDwAAAA==",
        "name": "Drafts",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "BAAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAACM",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBEgAAAA==",
        "name": "Tasks",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAACD",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBCQAAAA==",
        "name": "Sent Items",
        "totalCount": 6,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAD6",
        "childrenFolderCount": 1,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBHgAAAA==",
        "name": "Conversation History",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAABM4j/",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBMAAAAA==",
        "name": "Team Chat",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AwAAABYAAAChoF6VqpRgTrGKgS5rIadRAAABM7m9",
        "childrenFolderCount": 7,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBDgAAAA==",
        "name": "Contacts",
        "totalCount": 0,
        "unreadCount": null
    },
    {
        "changeKey": "AwAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAGP",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBJwAAAA==",
        "name": "PeopleCentricConversation Buddies",
        "totalCount": 0,
        "unreadCount": null
    },
    {
        "changeKey": "AwAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAER",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBIAAAAA==",
        "name": "{06967759-274D-40B2-A3EB-D7F9E73727D7}",
        "totalCount": 0,
        "unreadCount": null
    },
    {
        "changeKey": "AwAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAEf",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBIQAAAA==",
        "name": "{A9E2BC46-B3A0-4243-B315-60D991004455}",
        "totalCount": 0,
        "unreadCount": null
    },
    {
        "changeKey": "AwAAABYAAAChoF6VqpRgTrGKgS5rIadRAAABM4j6",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBJAAAAA==",
        "name": "Recipient Cache",
        "totalCount": 6,
        "unreadCount": null
    },
    {
        "changeKey": "AwAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAGb",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBKAAAAA==",
        "name": "Organizational Contacts",
        "totalCount": 0,
        "unreadCount": null
    },
    {
        "changeKey": "AwAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAGk",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBKQAAAA==",
        "name": "GAL Contacts",
        "totalCount": 0,
        "unreadCount": null
    },
    {
        "changeKey": "AwAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAG1",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBKgAAAA==",
        "name": "Companies",
        "totalCount": 0,
        "unreadCount": null
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAJV",
        "childrenFolderCount": 3,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBNwAAAA==",
        "name": "Yammer Root",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAJn",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBOQAAAA==",
        "name": "Outbound",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAJw",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBOgAAAA==",
        "name": "Feeds",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAJe",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBOAAAAA==",
        "name": "Inbound",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AwAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAABps",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJX/QAAAA==",
        "name": "PersonMetadata",
        "totalCount": 6,
        "unreadCount": null
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAKC",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBPAAAAA==",
        "name": "Archive",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAACE",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBCgAAAA==",
        "name": "Deleted Items",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAACF",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBCwAAAA==",
        "name": "Outbox",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AgAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAA4b",
        "childrenFolderCount": 2,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBDQAAAA==",
        "name": "Calendar",
        "totalCount": 0,
        "unreadCount": null
    },
    {
        "changeKey": "AgAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEq11",
        "childrenFolderCount": 0,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBV5AAA=",
        "name": "Birthdays",
        "totalCount": 0,
        "unreadCount": null
    },
    {
        "changeKey": "AgAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADErDD",
        "childrenFolderCount": 0,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBV6AAA=",
        "name": "United States holidays",
        "totalCount": 175,
        "unreadCount": null
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAEo",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBIgAAAA==",
        "name": "Junk Email",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAA6p",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJX3gAAAA==",
        "name": "Conversation Action Settings",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "BQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAACL",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBEQAAAA==",
        "name": "Notes",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAABM4j5",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBTQAAAA==",
        "name": "Files",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AwAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAFd",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBJQAAAA==",
        "name": "ExternalContacts",
        "totalCount": 0,
        "unreadCount": null
    },
    {
        "changeKey": "BgAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAACK",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBEAAAAA==",
        "name": "Journal",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADErbx",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBDAAAAA==",
        "name": "Inbox",
        "totalCount": 6,
        "unreadCount": 6
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAABP5",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJX8wAAAA==",
        "name": "MergedViewFolderCollection",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "BwAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAHK",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIZWgAAAA==",
        "name": "AllPersonMetadata",
        "totalCount": 6,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAB/",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBBQAAAA==",
        "name": "Views",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAE4",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBIwAAAA==",
        "name": "PeopleConnect",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "BwAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAFK",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIVPAAAAA==",
        "name": "To-Do Search",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "BwAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAGG",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIZPwAAAA==",
        "name": "Document Centric Conversations",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAHV",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBLAAAAA==",
        "name": "XrmProjects",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAA4a",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBVgAAAA==",
        "name": "Sharing",
        "totalCount": 1,
        "unreadCount": 0
    },
    {
        "changeKey": "BwAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAHy",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIZbAAAAA==",
        "name": "XrmDealSearch",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAABnT",
        "childrenFolderCount": 2,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBTwAAAA==",
        "name": "GraphStore",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAXD",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBUAAAAA==",
        "name": "GraphNodes",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAABnN",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJX9wAAAA==",
        "name": "GraphRelations",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAVS",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBRwAAAA==",
        "name": "CrawlerData",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAF2",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBJgAAAA==",
        "name": "Inference",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAACl",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBFwAAAA==",
        "name": "System",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAB7",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBAgAAAA==",
        "name": "Deferred Action",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAZE",
        "childrenFolderCount": 2,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBUwAAAA==",
        "name": "SwssItems",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "BwAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAEM",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIVJQAAAA==",
        "name": "Favorites",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "BwAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAXz",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIq/QAAAA==",
        "name": "GraphFilesAndWorkingSetSearchFolder",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAABM4j1",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBMQAAAA==",
        "name": "TeamChatHistory",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAACV",
        "childrenFolderCount": 22,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBFAAAAA==",
        "name": "ApplicationDataRoot",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOe",
        "childrenFolderCount": 1,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJX+wAAAA==",
        "name": "48af08dc-f6d2-435f-b2a7-069abd99c086",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAABpZ",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJX/AAAAA==",
        "name": "InsightsProvidersSettings",
        "totalCount": 1,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOf",
        "childrenFolderCount": 1,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBWGAAA=",
        "name": "49499048-0129-47f5-b95e-f9d315b861a6",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEq4S",
        "childrenFolderCount": 0,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBWIAAA=",
        "name": "OutlookAccountCloudSettings",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOr",
        "childrenFolderCount": 2,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBWBAAA=",
        "name": "d71dfe16-1070-48f3-bd3a-c3ec919d34e7",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEq4w",
        "childrenFolderCount": 0,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBWKAAA=",
        "name": "TxpUserSettings",
        "totalCount": 10,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEq33",
        "childrenFolderCount": 0,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBWCAAA=",
        "name": "TxpAutoblocking",
        "totalCount": 1,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOh",
        "childrenFolderCount": 3,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBSAAAAA==",
        "name": "644c1b11-f63f-45fa-826b-a9d2801db711",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEq6C",
        "childrenFolderCount": 0,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBWPAAA=",
        "name": "cmljaGFAYmFkYXZhLm9ubWljcm9zb2Z0LmNvbQ==_PolicyContainer",
        "totalCount": 1,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEq6O",
        "childrenFolderCount": 0,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBWQAAA=",
        "name": "cmljaGFAYmFkYXZhLm9ubWljcm9zb2Z0LmNvbQ==_LabelFile",
        "totalCount": 1,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAVi",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBSQAAAA==",
        "name": "_PolicyContainer",
        "totalCount": 2,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOE",
        "childrenFolderCount": 1,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBV/AAA=",
        "name": "32d4b5e5-7d33-4e7f-b073-f8cffbbb47a1",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEq3q",
        "childrenFolderCount": 0,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBWAAAA=",
        "name": "outlookfavorites",
        "totalCount": 3,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvN+",
        "childrenFolderCount": 3,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBFgAAAA==",
        "name": "00000002-0000-0ff1-ce00-000000000000",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOs",
        "childrenFolderCount": 2,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJX5wAAAA==",
        "name": "e69932cd-f814-4087-8ab1-5ab3f1ad18eb",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOd",
        "childrenFolderCount": 9,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBVwAAAA==",
        "name": "441509e5-a165-4363-8ee7-bcf0b7d26739",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvPH",
        "childrenFolderCount": 0,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBWeAAA=",
        "name": "UserDocKpeStats",
        "totalCount": 1,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvO6",
        "childrenFolderCount": 0,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBWcAAA=",
        "name": "UserStatistics",
        "totalCount": 1,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAABM4kC",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBWQAAAA==",
        "name": "SimpleAcronymsIndex",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAA4z",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBWgAAAA==",
        "name": "Idf",
        "totalCount": 1,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAA5W",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBXgAAAA==",
        "name": "UserDocWithKpes",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAA5o",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBYgAAAA==",
        "name": "GenericWorkflowProcessor.SessionManager.Data",
        "totalCount": 1,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOz",
        "childrenFolderCount": 0,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBWbAAA=",
        "name": "UserKpeState",
        "totalCount": 1,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAA5j",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBYQAAAA==",
        "name": "IdfMeeting",
        "totalCount": 1,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvO/",
        "childrenFolderCount": 0,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBWdAAA=",
        "name": "UserKpes",
        "totalCount": 2,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOm",
        "childrenFolderCount": 1,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBWLAAA=",
        "name": "80723a00-368e-4d64-8281-210e49e593a8",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEq4/",
        "childrenFolderCount": 0,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBWMAAA=",
        "name": "ActivityFeed_201905",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOo",
        "childrenFolderCount": 1,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJX7QAAAA==",
        "name": "ae8e128e-080f-4086-b0e3-4c19301ada69",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAA8s",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJX7gAAAA==",
        "name": "Scheduling",
        "totalCount": 2,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOA",
        "childrenFolderCount": 1,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJYDAAAAA==",
        "name": "13937bba-652e-4c46-b222-3003f4d1ff97",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvN/",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJYDQAAAA==",
        "name": "SubstrateContextData",
        "totalCount": 6,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOD",
        "childrenFolderCount": 1,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJX4gAAAA==",
        "name": "2a486b53-dbd2-49c0-a2bc-278bdfc30833",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOC",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJX4wAAAA==",
        "name": "PersonalGrammars",
        "totalCount": 5,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOg",
        "childrenFolderCount": 1,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBWZAAA=",
        "name": "4e445925-163e-42ca-b801-9073bfa46d17",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEtJP",
        "childrenFolderCount": 0,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBWaAAA=",
        "name": "NewsSubscriptionSourcesv2",
        "totalCount": 1,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOn",
        "childrenFolderCount": 1,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBV8AAA=",
        "name": "8c22b648-ee54-4ece-a4ca-3015b6d24f8e",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEq3P",
        "childrenFolderCount": 0,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBV9AAA=",
        "name": "Images",
        "totalCount": 2,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOB",
        "childrenFolderCount": 2,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBVzAAA=",
        "name": "1caee58f-eb14-4a6b-9339-1fe2ddf6692b",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEsiL",
        "childrenFolderCount": 0,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBV1AAA=",
        "name": "Recent",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEsiK",
        "childrenFolderCount": 0,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBV0AAA=",
        "name": "Settings",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOq",
        "childrenFolderCount": 1,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJYEwAAAA==",
        "name": "b669c6ea-1adf-453f-b8bc-6d526592b419",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOp",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJYFAAAAA==",
        "name": "FocusedInboxMailboxData",
        "totalCount": 2,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOF",
        "childrenFolderCount": 1,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBVxAAA=",
        "name": "35d54a08-36c9-4847-9018-93934c62740c",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEq02",
        "childrenFolderCount": 0,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBVyAAA=",
        "name": "PeoplePredictions.profile",
        "totalCount": 1,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOH",
        "childrenFolderCount": 1,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBV2AAA=",
        "name": "3b2e5a14-128d-48aa-b581-482aac616d32",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOk",
        "childrenFolderCount": 15,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJX3wAAAA==",
        "name": "66a88757-258c-4c72-893c-3e8bed4d6899",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAABM22Y",
        "childrenFolderCount": 0,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAABNIV9AAA=",
        "name": "SubstrateSearch.TeamsChats",
        "totalCount": 1,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAA69",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJX4AAAAA==",
        "name": "SubstrateSearch.CalendarEvents",
        "totalCount": 3,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAA7p",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJX5AAAAA==",
        "name": "SubstrateSearch.EmailEntities",
        "totalCount": 1,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAA8f",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJX6wAAAA==",
        "name": "SubstrateSearch.SearchHistoryState",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAA8X",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJX6gAAAA==",
        "name": "SubstrateSearch.SearchHistoryBootstrapStateV2",
        "totalCount": 1,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOj",
        "childrenFolderCount": 0,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAABNIV8AAA=",
        "name": "SubstrateSearch.TeamsEntities",
        "totalCount": 3,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAA8T",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJX6QAAAA==",
        "name": "SubstrateSearch.SearchHistory.Main",
        "totalCount": 1,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAA7t",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJX5QAAAA==",
        "name": "SubstrateSearch.EmailTokens",
        "totalCount": 22,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOi",
        "childrenFolderCount": 0,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAABNIV+AAA=",
        "name": "SubstrateSearch.TeamsAndChannels",
        "totalCount": 1,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAA82",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJX7wAAAA==",
        "name": "SubstrateSearch.SharePointDocuments",
        "totalCount": 3,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAABM4kF",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJX8QAAAA==",
        "name": "SubstrateSearch.GroupsRoomsMiscIndex",
        "totalCount": 1,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEsiJ",
        "childrenFolderCount": 0,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBWTAAA=",
        "name": "SubstrateSearch.SsaSessionManager",
        "totalCount": 1,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAA7x",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJX5gAAAA==",
        "name": "SubstrateSearch.People",
        "totalCount": 5,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAA8k",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJX7AAAAA==",
        "name": "SubstrateSearch.FreshHistory",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAABM4kE",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJX8AAAAA==",
        "name": "SubstrateSearch.PeopleIndex",
        "totalCount": 1,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOG",
        "childrenFolderCount": 1,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBWRAAA=",
        "name": "394866fc-eedb-4f01-8536-3ff84b16be2a",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEq9F",
        "childrenFolderCount": 0,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBWSAAA=",
        "name": "InsightInstancesActions",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOc",
        "childrenFolderCount": 20,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJX2wAAAA==",
        "name": "3c896ded-22c5-450f-91f6-3d1ef0848f6e",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOI",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJYAAAB",
        "name": "ActivitiesDaily",
        "totalCount": 48,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOP",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJYBQAAAA==",
        "name": "CumulativeOutOfOfficeClustering",
        "totalCount": 96,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOJ",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJYBgAAAA==",
        "name": "ActivitiesWeekly",
        "totalCount": 7,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOW",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJYBwAAAA==",
        "name": "ImportantContact",
        "totalCount": 3,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAA6S",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJX3AAAAA==",
        "name": "HeterogeneousItems",
        "totalCount": 10,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOX",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJX9gAAAA==",
        "name": "ManagementOperationExecutionRecords",
        "totalCount": 2,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOM",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJX9AAAAA==",
        "name": "ChatsInterruptionStatistics",
        "totalCount": 40,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOZ",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJYBAAAAA==",
        "name": "OutOfOffice",
        "totalCount": 34,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvON",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJX9QAAAA==",
        "name": "ComputeLogs",
        "totalCount": 22,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOR",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJX+gAAAA==",
        "name": "DailyAppointments",
        "totalCount": 86,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOK",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJYCgAAAA==",
        "name": "AfterHoursEmailImpact",
        "totalCount": 40,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOS",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJYCAAAAA==",
        "name": "DailyInteractions",
        "totalCount": 40,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOY",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJYDwAAAA==",
        "name": "MeetingActionStatistics",
        "totalCount": 8,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOa",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJYEgAAAA==",
        "name": "WeeklyInteractions",
        "totalCount": 6,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOO",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJYCwAAAA==",
        "name": "CumulativeNetworkSnapshot",
        "totalCount": 2,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOV",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJYEAAAAA==",
        "name": "EmailActionStatistics",
        "totalCount": 41,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOL",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJYEQAAAA==",
        "name": "AutomaticRepliesHistory",
        "totalCount": 7,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOb",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJYCQAAAA==",
        "name": "WeeklyOutOfOfficeAndWorkingDay",
        "totalCount": 6,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOT",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJYAwAAAA==",
        "name": "DailyNetworkSnapshot",
        "totalCount": 41,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOU",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJYAQAAAA==",
        "name": "DetailedMeetings",
        "totalCount": 40,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEvOl",
        "childrenFolderCount": 5,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBWDAAA=",
        "name": "7ae974c5-1af7-4923-af3a-fb1fd14dcb7e",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEq5X",
        "childrenFolderCount": 0,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBWOAAA=",
        "name": "LightningStore",
        "totalCount": 43,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEq4M",
        "childrenFolderCount": 0,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBWFAAA=",
        "name": "GetStartedStore",
        "totalCount": 15,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEq44",
        "childrenFolderCount": 0,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBWHAAA=",
        "name": "lightning",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEq4K",
        "childrenFolderCount": 0,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBWEAAA=",
        "name": "WhatsNewStore",
        "totalCount": 33,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEq5K",
        "childrenFolderCount": 0,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBWNAAA=",
        "name": "LightningSharedStore",
        "totalCount": 1,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAABM4jz",
        "childrenFolderCount": 5,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBFQAAAA==",
        "name": "Recoverable Items",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAABM4j8",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBGgAAAA==",
        "name": "Versions",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAABM4j7",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBGQAAAA==",
        "name": "Deletions",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEsiG",
        "childrenFolderCount": 0,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBWUAAA=",
        "name": "Audits",
        "totalCount": 1,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAABM4j9",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBHAAAAA==",
        "name": "Purges",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAABM4j+",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBHQAAAA==",
        "name": "Calendar Logging",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "BwAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAGx",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIZUAAAAA==",
        "name": "UserCuratedContacts",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAB9",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBAwAAAA==",
        "name": "Shortcuts",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAI5",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBNAAAAA==",
        "name": "TeamsMessagesData",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "BAAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAIK",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBLwAAAA==",
        "name": "Orion Notes",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "BwAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAHq",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIZaAAAAA==",
        "name": "XrmSearch",
        "totalCount": 6,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAA7A",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJX4QAAAA==",
        "name": "ExchangeODataSyncData",
        "totalCount": 14,
        "unreadCount": 0
    },
    {
        "changeKey": "BwAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAVo",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIq1gAAAA==",
        "name": "SharedFilesSearchFolder",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "BwAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAHS",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIZXgAAAA==",
        "name": "XrmCompanySearch",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEq3S",
        "childrenFolderCount": 0,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBV+AAA=",
        "name": "UserSocialActivityNotifications",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAA6d",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJX3QAAAA==",
        "name": "Freebusy Data",
        "totalCount": 1,
        "unreadCount": 0
    },
    {
        "changeKey": "BwAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEq2z",
        "childrenFolderCount": 0,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFECDAAA=",
        "name": "Reminders",
        "totalCount": 12,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAB+",
        "childrenFolderCount": 2,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBBAAAAA==",
        "name": "Finder",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "CAAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAFT",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIVQAAAAA==",
        "name": "Voice Mail",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "BwAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEq2X",
        "childrenFolderCount": 0,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFEB9AAA=",
        "name": "OwaFV15.1AllFocusedAQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBDAAAAA==",
        "totalCount": 6,
        "unreadCount": 6
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAACB",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBBwAAAA==",
        "name": "Schedule",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "BwAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAABqL",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIZRgAAAA==",
        "name": "RelevantContacts",
        "totalCount": 6,
        "unreadCount": 0
    },
    {
        "changeKey": "BwAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAH6",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIZcAAAAA==",
        "name": "XrmActivityStreamSearch",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "BwAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAEw",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIVMgAAAA==",
        "name": "My Contacts",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAXh",
        "childrenFolderCount": 1,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBUQAAAA==",
        "name": "MessageIngestion",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAXq",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBUgAAAA==",
        "name": "Yammer",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAA58",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAJX2gAAAA==",
        "name": "MailboxAssociations",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEq4e",
        "childrenFolderCount": 0,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBWJAAA=",
        "name": "BulkActions",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAHC",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBKwAAAA==",
        "name": "XrmInsights",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAJ5",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBOwAAAA==",
        "name": "OneDriveRoot",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "BwAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAB8",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBZAAAAA==",
        "name": "Spooler Queue",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "BwAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEq3g",
        "childrenFolderCount": 0,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFEhhAAA=",
        "name": "AllCategorizedItems",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAADEq2+",
        "childrenFolderCount": 0,
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQAuAAAAAADFL6XTy3wQRZOMsy4xY6N/AQChoF6VqpRgTrGKgS5rIadRAAADFBV7AAA=",
        "name": "BrokerSubscriptions",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "AQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAABM4j2",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBNgAAAA==",
        "name": "YammerData",
        "totalCount": 0,
        "unreadCount": 0
    },
    {
        "changeKey": "BwAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAAAAF+",
        "childrenFolderCount": 0,
        "id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIZOwAAAA==",
        "name": "AllContacts",
        "totalCount": 6,
        "unreadCount": 0
    }
]'''
    return json.dumps({'results': find_folder_response})

@ews_api.route(f'/{BASE_URL}/find-folder-tree')
def get_folder_tree():
    get_folder_tree_response = r'''root
├── AllCategorizedItems
├── AllContacts
├── AllItems
├── AllPersonMetadata
├── ApplicationDataRoot
│   ├── 00000002-0000-0ff1-ce00-000000000000
│   ├── 13937bba-652e-4c46-b222-3003f4d1ff97
│   │   └── SubstrateContextData
│   ├── 1caee58f-eb14-4a6b-9339-1fe2ddf6692b
│   │   ├── Recent
│   │   └── Settings
│   ├── 2a486b53-dbd2-49c0-a2bc-278bdfc30833
│   │   └── PersonalGrammars
│   ├── 32d4b5e5-7d33-4e7f-b073-f8cffbbb47a1
│   │   └── outlookfavorites
│   ├── 35d54a08-36c9-4847-9018-93934c62740c
│   │   └── PeoplePredictions.profile
│   ├── 394866fc-eedb-4f01-8536-3ff84b16be2a
│   │   └── InsightInstancesActions
│   ├── 3b2e5a14-128d-48aa-b581-482aac616d32
│   ├── 3c896ded-22c5-450f-91f6-3d1ef0848f6e
│   │   ├── ActivitiesDaily
│   │   ├── ActivitiesWeekly
│   │   ├── AfterHoursEmailImpact
│   │   ├── AutomaticRepliesHistory
│   │   ├── ChatsInterruptionStatistics
│   │   ├── ComputeLogs
│   │   ├── CumulativeNetworkSnapshot
│   │   ├── CumulativeOutOfOfficeClustering
│   │   ├── DailyAppointments
│   │   ├── DailyInteractions
│   │   ├── DailyNetworkSnapshot
│   │   ├── DetailedMeetings
│   │   ├── EmailActionStatistics
│   │   ├── HeterogeneousItems
│   │   ├── ImportantContact
│   │   ├── ManagementOperationExecutionRecords
│   │   ├── MeetingActionStatistics
│   │   ├── OutOfOffice
│   │   ├── WeeklyInteractions
│   │   └── WeeklyOutOfOfficeAndWorkingDay
│   ├── 441509e5-a165-4363-8ee7-bcf0b7d26739
│   │   ├── GenericWorkflowProcessor.SessionManager.Data
│   │   ├── Idf
│   │   ├── IdfMeeting
│   │   ├── SimpleAcronymsIndex
│   │   ├── UserDocKpeStats
│   │   ├── UserDocWithKpes
│   │   ├── UserKpeState
│   │   ├── UserKpes
│   │   └── UserStatistics
│   ├── 48af08dc-f6d2-435f-b2a7-069abd99c086
│   │   └── InsightsProvidersSettings
│   ├── 49499048-0129-47f5-b95e-f9d315b861a6
│   │   └── OutlookAccountCloudSettings
│   ├── 4e445925-163e-42ca-b801-9073bfa46d17
│   │   └── NewsSubscriptionSourcesv2
│   ├── 644c1b11-f63f-45fa-826b-a9d2801db711
│   │   ├── _PolicyContainer
│   │   ├── cmljaGFAYmFkYXZhLm9ubWljcm9zb2Z0LmNvbQ==_LabelFile
│   │   └── cmljaGFAYmFkYXZhLm9ubWljcm9zb2Z0LmNvbQ==_PolicyContainer
│   ├── 66a88757-258c-4c72-893c-3e8bed4d6899
│   │   ├── SubstrateSearch.CalendarEvents
│   │   ├── SubstrateSearch.EmailEntities
│   │   ├── SubstrateSearch.EmailTokens
│   │   ├── SubstrateSearch.FreshHistory
│   │   ├── SubstrateSearch.GroupsRoomsMiscIndex
│   │   ├── SubstrateSearch.People
│   │   ├── SubstrateSearch.PeopleIndex
│   │   ├── SubstrateSearch.SearchHistory.Main
│   │   ├── SubstrateSearch.SearchHistoryBootstrapStateV2
│   │   ├── SubstrateSearch.SearchHistoryState
│   │   ├── SubstrateSearch.SharePointDocuments
│   │   ├── SubstrateSearch.SsaSessionManager
│   │   ├── SubstrateSearch.TeamsAndChannels
│   │   ├── SubstrateSearch.TeamsChats
│   │   └── SubstrateSearch.TeamsEntities
│   ├── 7ae974c5-1af7-4923-af3a-fb1fd14dcb7e
│   │   ├── GetStartedStore
│   │   ├── LightningSharedStore
│   │   ├── LightningStore
│   │   ├── WhatsNewStore
│   │   └── lightning
│   ├── 80723a00-368e-4d64-8281-210e49e593a8
│   │   └── ActivityFeed_201905
│   ├── 8c22b648-ee54-4ece-a4ca-3015b6d24f8e
│   │   └── Images
│   ├── ae8e128e-080f-4086-b0e3-4c19301ada69
│   │   └── Scheduling
│   ├── b669c6ea-1adf-453f-b8bc-6d526592b419
│   │   └── FocusedInboxMailboxData
│   ├── d71dfe16-1070-48f3-bd3a-c3ec919d34e7
│   │   ├── TxpAutoblocking
│   │   └── TxpUserSettings
│   └── e69932cd-f814-4087-8ab1-5ab3f1ad18eb
├── BrokerSubscriptions
├── BulkActions
├── CalendarSharingCacheCollection
├── Common Views
├── Connectors
│   └── ConnectorConfigurations
├── CrawlerData
├── DefaultFoldersChangeHistory
├── Deferred Action
├── Document Centric Conversations
├── ExchangeODataSyncData
├── Favorites
├── Finder
│   ├── OwaFV15.1AllFocusedAQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkALgAAA8UvpdPLfBBFk4yzLjFjo38BAKGgXpWqlGBOsYqBLmshp1EAAAIBDAAAAA==
│   └── Voice Mail
├── FreeBusyLocalCache
│   └── FreeBusyLocalCacheSubscriptions
├── Freebusy Data
├── GraphFilesAndWorkingSetSearchFolder
├── GraphStore
│   ├── GraphNodes
│   └── GraphRelations
├── Inference
├── MailboxAssociations
├── MergedViewFolderCollection
├── MessageIngestion
│   └── Yammer
├── My Contacts
├── O365 Suite Notifications
├── OneDriveRoot
├── Orion Notes
├── PACE
│   └── DelveNotifications
├── People I Know
├── PeopleConnect
├── PeoplePublicData
├── QuarantinedEmail
│   └── QuarantinedEmailDefaultCategory
│       ├── QedcDefaultRetention
│       ├── QedcLongRetention
│       ├── QedcMediumRetention
│       └── QedcShortRetention
├── Recoverable Items
│   ├── Audits
│   ├── Calendar Logging
│   ├── Deletions
│   ├── Purges
│   └── Versions
├── RelevantContacts
├── Reminders
├── Schedule
├── SharePointNotifications
├── SharedFilesSearchFolder
├── Sharing
├── Shortcuts
├── SkypeSpacesData
│   ├── SkypeMessages
│   └── TeamsMeetings
├── Spooler Queue
├── SubstrateFiles
│   ├── ClassicAttachments
│   ├── GraphWorkingSet
│   └── SPOOLS
├── SwssItems
├── System
├── TeamChatHistory
├── TeamsMessagesData
├── TemporarySaves
├── To-Do Search
├── Top of Information Store
│   ├── Archive
│   ├── Calendar
│   │   ├── Birthdays
│   │   └── United States holidays
│   ├── Contacts
│   │   ├── Companies
│   │   ├── GAL Contacts
│   │   ├── Organizational Contacts
│   │   ├── PeopleCentricConversation Buddies
│   │   ├── Recipient Cache
│   │   ├── {06967759-274D-40B2-A3EB-D7F9E73727D7}
│   │   └── {A9E2BC46-B3A0-4243-B315-60D991004455}
│   ├── Conversation Action Settings
│   ├── Conversation History
│   │   └── Team Chat
│   ├── Deleted Items
│   ├── Drafts
│   ├── ExternalContacts
│   ├── Files
│   ├── Inbox
│   │   ├── TEST01
│   │   └── TEST02
│   ├── Journal
│   ├── Junk Email
│   ├── Notes
│   ├── Outbox
│   ├── PersonMetadata
│   ├── Sent Items
│   ├── Tasks
│   └── Yammer Root
│       ├── Feeds
│       ├── Inbound
│       └── Outbound
├── UserCuratedContacts
├── UserSocialActivityNotifications
├── Views
├── XrmActivityStream
├── XrmActivityStreamSearch
├── XrmCompanySearch
├── XrmDealSearch
├── XrmInsights
├── XrmProjects
├── XrmSearch
└── YammerData'''
    return get_folder_tree_response

@ews_api.route(f'/{BASE_URL}/get-items')
def get_items():
    get_items_response = r'''{"results":[
  {
    "body": "Hey, how are you? Click on this link to win prizes! http://coffeebox.fun/laposte-adS20/http://sg-cont.u730143x83.ha004.t.justns.ru/sg/sg/",
    "text_body": "Hey, how are you? Click on this link to win prizes! http://coffeebox.fun/laposte-adS20/http://sg-cont.u730143x83.ha004.t.justns.ru/sg/sg/",
    "subject": "Click here to view prizes",
    "sender": {
      "email_address": "jimhalpert@dundermifflin.com"
    },
    "to_recipients": [
      {
      "email_address": "pambeasely@dundermifflin.com"
    }],
    "cc_recipients": [
      {
        "email_address": "mikescott@dundermifflin.com"
      }],
      "bcc_recipients": [
      {
        "email_address": "mikescott@dundermifflin.com"
      }],
      "datetime_created": "2018-03-08T15:30:25Z",
      "attachments": [],
      "headers": [{"received": "from MSGEXSV2D4003.ent.wfb.fdg.corp (162.101.226.238) by MSGEXSILD4001.ent.wfb.fdg.corp (162.103.173.228) with Microsoft SMTP Server (version=TLS1_2, cipher=TLS_RSA_WITH_AES_128_CBC_SHA) id 15.1.1261.35 via Mailbox Transport; Thu, 8 Mar 2018 10:30:18 -0500"}, {"received": "from MSGEXSV2D3708.ent.wfb.fdg.corp (162.101.226.227) by MSGEXSV2D4003.ent.wfb.fdg.corp (162.101.226.238) with Microsoft SMTP Server (version=TLS1_2, cipher=TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256_P256) id 15.1.1261.35; Thu, 8 Mar 2018 09:30:17 -0600"}, {"received": "from MSGEXSV2D3708.ent.wfb.fdg.corp (162.101.226.227) by MSGEXSV2D3708.ent.wfb.fdg.corp (162.101.226.227) with Microsoft SMTP Server (version=TLS1_2, cipher=TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256_P256) id 15.1.1261.35; Thu, 8 Mar 2018 09:30:17 -0600"}, {"received": "from mxiinv06.fdg.com (162.101.224.235) by MSGEXSV2D3708.fdg.com (162.101.226.227) with Microsoft SMTP Server id 15.1.1261.35 via Frontend Transport; Thu, 8 Mar 2018 09:30:17 -0600"}, {"received": "from mxdinv28.fdg.com (mxdinv28.fdg.com [159.45.16.81]) by mxiinv06.fdg.com (Sentrion-MTA-4.3.2/Sentrion-MTA-4.3.2) with ESMTP id w28FU9I5015405 for <email.misuse@fdg.com>; Thu, 8 Mar 2018 15:30:16 GMT"}, {"x-auditid": "9f2d1051-863ff7000000a3b8-73-5aa15704eb33"}, {"received": "from mail6.bemta12.messagelabs.com ( [216.82.250.247]) (using TLS with cipher ECDHE-RSA-AES256-GCM-SHA384 (256/256 bits)) (Client did not present a certificate) by mxdinv28.fdg.com (postmaster@fdg.com) with SMTP id 66.0A.41912.40751AA5; Thu, 8 Mar 2018 15:30:12 +0000 (GMT)"}, {"received": "from [216.82.251.42] (using TLSv1.2 with cipher DHE-RSA-AES256-GCM-SHA384 (256 bits)) by server-15.bemta-12.messagelabs.com id BF/ED-18455-30751AA5; Thu, 08 Mar 2018 15:30:11 +0000"}, {"message-id": "66.0A.41912.40751AA5@mxdinv28.fdg.com"}, {"x-brightmail-tracker": "H4sIAAAAAAAAA11Uf0wTZxjmu7uWA3ruuIK8FH8kZWpYBHRKwogCiaBsxKgbGxlb4uo4aEdb SFsQXLIwhGGREILBzI4A1W38CA4EHbqsyO/pAjMKOMycc8ZNUWAYDTBE2X39Wmj2z+X5nvd7 nvd93vaOpYV6PxUr5ltEk1GjV8t9mfG3F+bCmVR72pbB6wHR9qYOOh4lXTve770fpfnuSBf1 ujzRFBn7ka/WWlRG58zF5U9c6JYVovMxZciHFfgIuGGdZzAGfjv8vfCMLkO+Et9GwfXiaTk5 dCMYGS2j8C2Oj4HH3UMMLgD/vQ9crr3lkofD0bkX3gTvgtLWAZpgNZy8NYWIoBzBXONpWRli pUMAnCiKIXfCoL+iXEZwEJywN9FkvD0wO3ubIlNcQlA/WSgjh7sIbla3OA8MP0NB/2mHHLsK fCbYJlKxOoBfD59PWSlMy/kN8My+DUOGD4UFWzqGSily281kkssfrp66z2Ca5nXQ2ZhCpomD xYE/EMEcTAwWyyqRyuahsK0oME3zm+FK8yBN8HronKqhyZUQaHjJEnoD1A2f8SZ4DXRUW9H/ rgjSFUfTnMzmDDtEQe3oP8jmHCIeqk41u3AoLPVcY4jgA6gseYpszjVX+cEv9vveNuea1VDZ koh5xFcgmJlqdbnaECyVfkWRQzsFjh9fOm0Z/ikFZwcMpPAbgsaqPldBDY2OLymM5fxWuGR7 TuEWAXwg/FT2GaaVUvqpF8+9yUhR0HVvgCLLEmCxrdG1iX0w37abDBcKrQ9FEiYKnjT3MQQH QmHjOE3wRhhuHZYRlyRouVxN1aNNzSjIkJ+uM+a9Hh1xWNTrzRkaU2Z2xMfZhnYkvRZ14fyB i+hOw75exLNIreAKFfVpgkyTZy4w9KJkllIHcns/kahVh7LTC7Qas/agKVcvmtUBnPxde5rA LdOHcvVZahXXiVnlMmsUD5v1okV6D3sRsLQk2x+JZemagiOiKZuY9aIQllEHcePx374v/S81 FjFLFHNEk7uawrJq4Na9Jwn9TWKmmJ+h01vcZUkXcVIakPesOIdZy/06IhVWexY856FYn16U xCqkoRKxN2fO0RjMukyXr5ILS5FYhZt1egZz7+CAgptc8fsZfcrOOO5+QbPjDx9Lz4V2h5Vm u0bmbiOBMWYbRfJUBXEJuBmPHbS5xuUcqtWcIao2TXjFo4BbqtZwoWGSINCDX+nq/rTdQGtV Sg55eXkJCmlzBp3FlcJVf4QSpZ9XyUXi3gqd0bKSU+D+PCCRfi7SGRO4D3FMfxe30u+RtDBK WpgDb5YzWzQWz4Ul4AAKN+taWCwmBTe5YqUqRMe7D2ZVUccmdz3YvpkbqsuNLZcXn+jYOX90 /Mm67L7k2bfmd4/PfNMQe/7KmxXJwVdlZ8ZejZ627hjrSa35oXPvtLYo+EjS73sSRpv4uIv/ rhrJPRvS83VSxLY3LhSfO2evrdnZ/eBYSXvB4OJk7dhSV8n8dMvYlr+a0b0735XGb5JnbHSo GbNWs/U12mTW/AeKNmdfMwYAAA=="}, {"x-brightmail-tracker": "H4sIAAAAAAAAA11Sa0hUaRie95wz48k8cToqvZoajLi1kdZkN/p RggRCd0iKidg91mnmxMzozplilqAsKnKkEsPSU+aIP5wGWcsL1razXmrKIikKQoOKxA21Hdh1 tws2Xeabr/u/53ue532+9315eVYaMaXzitejuF2yw2xK5G5n/t6Xy25utC54UQXLGs+3swVQd KfyWsIGsBpVV0mp92ej/XjkMZS9WuEd6+wxlkPHch8k8pL4GPCPcx0m8uDEcQbf+ifBB3xMsa E+ttkHU/gUcRYeiFQwhDaJOfh/Yz6BnJiNk/oOApPFRXjhwWpiFsTpeLNuhCM0K6rYFdhEaBR XYjT8BCgWcOz6IWMVTNW/qtC/VBCaFedhf/A6S/Es7IqcZallJja/4ymdgw0DTQkUZ2B7TQV8 Z5FiltD5V0Y9Pmw/g+HDE0Y93kQBVtcFgeJsfN97h6MFW7Hq8H9AClCMJuKV9voEEoqiGataV hEexOOA/0RaP6bWAdb6Oxla3crgwYsuPb7OCIP3jr5kqGsIsLuyJT4OF4sKhGrjFSbRgpf1Nw z5IkVMxRu+fYROjk0fefsmgYYuxj+HwwxdloTRC4GPW1mHz84MsLS7bGwdVeg0i/Hf4FWO4lQ sDwyyFP+AA60DRhpThC3dNYwfZgdhjqa49yju3EWWvBK3arN7nLLqyLVYFuY5FU2TbYpDLtHy tpc62yB2a/sNBrgEf3dv7YM0njGnCmt3+a3StJLSHb/aZc3+k3u3Q9H6IIPnzSgEixut0nS3Y lO8O1VH7GA/ycgnmVOES0QWtDLZqak2Kt2CfH5w9PkRlp9sC1WwEucqdSnpM4RKYhWJ1b7b9T no0/Hfg8z0ZAEMBoOUVKa4narnW30cZvBgThaOkJQk1eX5/N94rBUm1krovp+04pG/SOnlMK1 t3YvCNY82vgz/Mhi6mxl6dnB9R6FUO7r0r+qGoS2O9jXW0/2GJc0nVv0G8/XXtYXbJqr3VgzX N3l71jYVH4qOFBxrTuvM2tmTe9Hetf9hfRbsafAVDp16yJqjT5cEaiZOXk4b1iLFRcasups/h n0ZvQ1bevNvXMt5ZHlq75rwq2ZOs8uWuaxbkz8A9LkX9/cDAAA="}, {"x-env-sender": "fbl-no-reply@postmaster.aol.com"}, {"x-msg-ref": "server-9.tower-160.messagelabs.com!1520523010!25073656!1"}, {"x-originating-ip": "204.29.186.194"}, {"x-spamreason": "No, hits=2.1 required=7.0 tests=msgid: No Message-ID, ratty_date: Non-RFC but legit format in Thu, 08 Mar 2018 10:30:07 EST"}, {"x-starscan-received": ""}, {"x-starscan-version": "9.9.15; banners=-,-,-"}, {"x-viruschecked": "Checked"}, {"received": "(qmail 11620 invoked from network); 8 Mar 2018 15:30:10 -0000"}, {"received": "from smr-m05e.mx.aol.com (HELO smr-m05e.mx.aol.com) (204.29.186.194) by server-9.tower-160.messagelabs.com with DHE-RSA-AES256-SHA encrypted SMTP; 8 Mar 2018 15:30:10 -0000"}, {"received": "from scmp-m009.mail.aol.com (scmp-m009.mail.aol.com [172.26.180.17]) by smr-m05e.mx.aol.com (AOL Mail Bouncer) with ESMTP id 25C2C3800086 for <email.misuse@fdg.com>; Thu, 8 Mar 2018 10:30:10 -0500 (EST)"}, {"dkim-signature": "v=1; a=rsa-sha256; c=relaxed/relaxed; d=mx.postmaster.aol.com; s=20160722; t=1520523010; bh=XXgf3dv0C4JwmcbaonOEABRGqMLhHnHejZwCtutQUzM=; h=To:From:Date:Subject; b=wqyeeqMviIC8tM4xLUexJTQpbwJ5C2ZhxggVt3nXYqfIEOKHUVvX9H1QHGYMyWJ37 fa/dy/oRLn49cUQi8HFdUONBh+H3qlb2vYmrMPW5jshNCi8UHyg8MnrBvn718tXMGf zldbJeZJHbRIy6ASo85zjsjAz6aLtCj0XCFT5ouI="}, {"received": "from fbl-no-reply@postmaster.aol.com by scmp-m009.mail.aol.com; Thu, 08 Mar 2018 10:30:07 EST"}, {"to": "email.misuse@fdg.com"}, {"from": "fbl-no-reply@postmaster.aol.com"}, {"date": "Thu, 08 Mar 2018 10:30:07 EST"}, {"subject": "Email Feedback Report for IP 159.45.132.174"}, {"content-type": "multipart/report; report-type=feedback-report;"}, {"x-aol-inrly": "mxdapi04.fdg.com [159.45.132.174] scmp-m009"}, {"x-loop": "scomp"}, {"return-path": "fbl-no-reply@postmaster.aol.com"}, {"x-ms-exchange-organization-network-message-id": "eb3cd734-7321-47fb-acd0-08d585097ed4"}, {"x-ms-exchange-organization-authsource": "MSGEXSV2D3708.ent.wfb.fdg.corp"}, {"x-ms-exchange-organization-authas": "Anonymous"}, {"x-ms-exchange-transport-endtoendlatency": "00:00:01.4737064"}, {"mime-version": "1.0"}, {"content-type": "text/plain; charset=\"US-ASCII\""}, {"content-transfer-encoding": "7bit"}, {"content-disposition": "inline"}, {"content-type": "message/feedback-report"}, {"feedback-type": "abuse"}, {"user-agent": "AOL SComp"}, {"version": "0.1"}, {"received-date": "Thu, 8 Mar 2018 07:55:01 -0500 (EST)"}, {"source-ip": "159.45.132.174"}, {"reported-domain": "mxdapi04.fdg.com"}, {"redacted-address": "redacted"}, {"redacted-address": "redacted@"}, {"content-type": "message/rfc822"}, {"return-path": "<Billpay@fdg.com>"}, {"received": "from mxdapi04.fdg.com (mpq409.aol.consmr.mail.ne1.yahoo.com [159.45.132.174]) (using TLSv1 with cipher ECDHE-RSA-AES256-SHA (256/256 bits)) (No client certificate requested) by mtaiw-mbc04.mx.aol.com (Internet Inbound) with ESMTPS id E8E437000009F for <bcorff@aol.com>; Thu, 8 Mar 2018 07:55:01 -0500 (EST)"}, {"x-apparently-to": "bcorff@aol.com; Thu, 08 Mar 2018 12:55:01 +0000"}, {"x-yahoofilteredbulk": "159.45.132.174"}, {"received-spf": "pass (domain of fdg.com designates 159.45.132.174 as permitted sender)"}, {"x-ymailisg": ".CvTMQ0WLDv3cdAPlenkeyy2dTuZx6LUyoAIeCDYLdkAfmcn vYbWPwK1uQdimO_H5Bxaq4NSnQ5NCPY0eh6bBl5q22TrFHaeGlWCzT_1dSlN LqFLTWwmIApKbR9S0nETWty7BUu1UA0Nv_YOFoC_NMo8u9OsJP80pQLtvfAn ezWeGD.WwKz8w8u_8vJpUlDJ.5weFrzxhUL4wqxhcTOmzMaAdlqUJSaulN_l QFw2z5izUeswVr0tvLOjRDhY06M_WtrBU97VgBxK88T_1jz_gqOlGCx5Xeey 8s1se8rYo8b2hK81T.1gST8ic25v6aeVP7YQahiHzJpXdM5cA0baPmSOrYJg jin6kJDuyiCWKBILQ3.nTnKXsVuM_Ugn4jVc8nGM9FdeqylWPkLSfE4oKRHS 9XyaV5t6WymwUng_jS6lqu80MXViueIhb7NEbihoKzYtnGtoLd3TmNYVI.fx DVVuEpUWsGdisBUVw5mPaytXfrZct2jcTJu758bB2AdMqQ6fpbJqwCWtXE6_ FHDHi6H7JAUNqhJRUoCW582bSXK5mb3hSS1vIIoN0PPWXv5E0KcJOvzRSY58 pPNansPQw3QDooeC7RxlA_lIieLnb.qZqYgIwnoLXidD_esE_Mi.EYmPUf_2 EUOwCYynxY11ZEB3Y.kk2jpE4azyNflO4dQVy71sxWw3Xiwef_QwenvGJzL6 jvT7t.Uwsk1rQrLqfZ2EXVpCJoDtsZzjIVshuNcdJpMNng3jNS3KXtmBRqKb HNzTpgGNIF7QNg7qPr1fbOwr00XFb5_D4olUkAiLMgaRVgkPQKKzxl9CfRWi 6_gr.43LCNWmpxo_OHbEccSYKFfRIoiS0PRXXBguplvo.gA2seWdt01bSwxD 5GxiqVt6Oy.5.h9IxmCHau1gN1KlsTh4h.DgFRA.V_gRb7y4swuPama3hTE6 zi8ZoNa3bV9Zsj3dtsb8fqFNwDnyXUCEDbTHPxuTcFnNEe7uPM4NyyTjfyz. p6LjS30Wrl4h8Q0SVY51ZVWti_oRUhz0jUo1z4wgv7TmSWY027dgr20.nOo7 NdCCuI2ivzmKa9OpN6fdq_LRtNzAJ0FG_r7FFKNIH_fuNgq4U.3YY1a.EtZP .1hktiJYNzm9xuvDwcl0MrNOR.N.GPKf507Qjunpih_3McNF824U7tvLTPg6 w.FZlT2O8vL42Hdhw3ythB0Ec.r19UkGk1Pp4zFEydjC2iML5SWfF8PMcL7m R_X3Qy2H.c4ZZMgzzREQ_QffWL0mQw_pBIe5irbWdeReNLx7bFulHZr5Dwq9 lviDUnmc56MlTWp_iwWzVF3bXd3YT2b9X2KsPKhd"}, {"x-originating-ip": "159.45.132.174"}, {"authentication-results": "mta4168.aol.mail.ne1.yahoo.com from=fdg.com; domainkeys=neutral (no sig); from=fdg.com; dkim=pass (ok)"}, {"received": "from 127.0.0.1 (EHLO mxdapi04.fdg.com) (159.45.132.174) by mta4168.aol.mail.ne1.yahoo.com with SMTPS; Thu, 08 Mar 2018 12:55:01 +0000"}, {"received": "from mxiapi04.fdg.com (mxiapi04.fdg.com [162.103.116.17]) by mxdapi04.fdg.com (Sentrion-MTA-4.3.2/Sentrion-MTA-4.3.2) with ESMTP id w28Ct09m002052 (version=TLSv1.2 cipher=ECDHE-RSA-AES256-GCM-SHA384 bits=256 verify=OK) for <BCORFF@AOL.COM>; Thu, 8 Mar 2018 12:55:00 GMT"}, {"dkim-signature": "v=1; a=rsa-sha256; c=simple/simple; d=fdg.com; s=2011-05-wfb; t=1520513700; bh=7kT1yPqSkj3rHsjr732lrMNjcX17WmVVFkiWmUX0wr4=; h=Date:From:To:Subject:Reply-To; b=XKQ4ZuElySDlGQX3p48clzm6g92vQSZc+OVJe8x5Wdu53ZPKzTjU3nQrByf/sZ+IY wODKx7xhJMIviAoRTPwGgOrljKfcGtzSGunmd95iULnuhRLg8YgcJLzrf2RKAOrena MM5XmOEOoHMQwzD+onPWK2oRk+6Q4MASSqq8VutY="}, {"received": "from rumII (al1-blurr-isb-es.fdg.com [162.102.118.58]) by mxiapi04.fdg.com (Sentrion-MTA-4.3.2/Sentrion-MTA-4.3.2) with SMTP id w28CswD4016488 for BCORFF@AOL.COM; Thu, 8 Mar 2018 12:55:00 GMT"}, {"date": "Thu, 8 Mar 2018 12:55:00 GMT"}, {"from": "fdg Online <Billpay@fdg.com>"}, {"to": "redacted@AOL.COM"}, {"subject": "fdg Bill Pay: eBill Summary"}, {"reply-to": "fdg Online <Billpay@fdg.com>"}, {"content-type": "multipart/mixed;"}, {"x-mailer_profile": "BillManager_Alert"}, {"x-mailer_osid": "9ae633d:16205a5fee7:7213-22.45.35.167"}, {"x-mailer_status": "sent"}, {"x-mailer_rsid": "bma_K4A5thE2T-K4A5v1_12"}, {"message-id": "EDSRUM16210211805804bma_K4A5thE2T-K4A5v1_12@fdg.com"}, {"x-aol-global-disposition": "S"}, {"x-oath-mig-data": "AXA7HvkQgcTJ6odIchf3WELq38j0+scX7PcAsrJrcfMFl7juJcSFwCKXeQiIAV6sA69UXi1o5Z+wl0mmL5QTFlTzn5+5fFqdlKWC3bcxOyjjLI5prhBIGVK54QkA5TNbwkmcpoNQ86/h1ZZAmRvIU3kjqiemz8YMkldom+9Nw5qakJ7wiuSNoGAJdLLbtqnWe2MnmDcYxIvmYWXu3LN10zFsJLq85Whivg5i5v/lR7Uvtguq0P7wsy6HYr0QFjUmR4QADHRkdj7ePE6IfuP+wZAnT/WNsVV1cTCQOavD3CEzozA9760vqiNNjf4xLccaQ5tPM5WOeSIpmwsK4zzpkFeZkqq+sRXItEG+34mB/DOEvZiAzykcQzkyI9aLzXKG1GgWq42AXd9q6X1FDsT1Z4DZoattmnNWEjEUxhFjzXy9ZxFUctiPUwf1I9tePzft4bpvNMWEjEDlAd8tbol1DnJDz4jVwquzCiDFpvFOLBSgEvM2NyxWVAxbJMgbQgdkV5zxFX0dUfm6c6UGzHvScO+7qRkzNlkVyzFr0UaaX1NCS5nNXvnTEiPGx/Oi4lpwqjr5dzKVvO56wb06QdnEhkzjGiyBYPWBF0OIV/72GOzow3AguCBTZmWyh5kCydOJM85MCgYtYhd/NEpf7VYwec2MdCqgWAI0XaQM3pGViTsiCqjtxmILuPdWFhRnyN1j9Cr7vuDvPPuWCWbaX3XaFcEtmd0yEII2YdvGQqMyE2FkRq9ESRUK+nPSaSs1W0rM8AgGr4Op6ICbg7dkb9Ee3kWq2l1aVSArgErJcutKo8oblWRJWyxMd8FedFXunbVJaU9DzCmppbICkmBR+iAsXN3LM4Uayj/L+Gxp44cN1OeDl7YkJ8U+HAeivMLytlcjd13U6UD5XTZ7vE8gWlDzbGyg83tFxuZB8zp/h+qJemTBQuKAEL0QyBytTItDXxuOkODkhd8KXxn3z 4zmgGcuRqbKg5iOsYQskGvCbGkpsrUudc9d5iK/Db65F8m5A49S0/uDftcZO0IB7ssTx2NfjgiIEEBv45apTqcDJWFAFCWCcRv75GY55AQfjZB266WQkw6ingZkLXnRzQ7g0R5H/+yFICGDdA0JGT+FixkskR4m1tiM7ViBUbarvgORdR0xxNSTE5WqdizStvRu9dljsEvqpak2R4BS4fakh9nAmdVcWB247xMndMggYhiwg7Ey1RtaE2k8TXHZituer6f4T8pead0Mkv6GIIMxms0l4YH8uBQUa/K4tJxH001fpLLBJ89FkqKAjSLqE2Gen4ne+3MlrkrLT/Tdr1/dO/5RoUCNywQnhsoEXPwRJMt994TCmlRRArwhfWmkv8zGjI79h6wiKtC89RG7Zdjc7rOuOe9u6dEEgtm4eeizWh67pvedv7FyWI5ZcJo7s6yCAAqMU/gC5LsK06bMt+QerOlC1PfLVm9rxD9DdUP4cM/qfgzp/4ww4n1CWDZPumqHRcjdgJo+e9jCJ9hqdjKB/pA29J+2evLMe0tqVKyzcs3I46nqb/SBnRAvyOKffB+DplTFRlSr4XW4ET8Xpgu06bwHJ8qgUutQYeylR01/McAllINW1QClkSQsa2TAtrxzQ2i+MRzysWOGuYU2DAtc4HuHucJSYbWmrn0yd88OTN+Xm0fTPrrXeZpwSjKHPwsk/TaTSh45PibCahR0DpIVZPz4OHW96wNbLm/i3mX/pRY3VYuadKE6Hs126PSV7smxX7ToggU2FUX58IaghHIB+f5NuE+SqzhOe7H8xua6+E7fwHW41DMj/i8YCG5xvILDiyJ3f5RYchVJfn76FuQM3/Lwv5q84wjrFQZOcObTs5x7vPu0wnU9W9U9UHWZjRIw8MEHfvmd+GSANhS/ED5fHXz/Iy5SWXGa27MlYom0JkzyHVvSax2WtA4qDN8xk03zs1ghynRTCEo78A/1ueRMudmNEd aI1bajp4u8gw5oeq0vXpoQAXhFjZvMO3gh/z7Rqo8QeXyHo20ohCdZXGMt+nuHhnr/SmXs9i8JxnamruKyhj7vxtYAGy/c+V0zUZVORDZg6Clz"}, {"x-aol-reroute": "YES"}, {"x-aol-sid": "3039ac1add8a5aa132a53b13"}, {"x-aol-ip": "159.45.132.174"}, {"x-aol-spf": "domain : fdg.com SPF : pass"}, {"content-type": "text/plain; charset=\"UTF-8\""}],
      "message_id": "AHFJKWEKFJKLWEJLKWJEKLDJLKSJGLKWEJ==",
      "item_id": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkARgAAA8UvpdPLfBBFk4yzLjFjo38HAKGgXpWqlGBOsYqBLmshp1EAAAIBDAAAAKGgXpWqlGBOsYqBLmshp1EAAAIFhgAAAA==",
      "conversation_id": {
        "id": "atwBIGrep"
      }

  }

  ]}'''
    return get_items_response

@ews_api.route(f'/{BASE_URL}/get-items-from-folder')
def get_items_from_folder():
    get_items_from_folder_response = r'''{"results":[
    {
        "ItemAttachments": [
            {
                "attachmentContentId": "888DDFB4FB851C4AAAA2A70FD978B9FE@INDPRD01.PROD.OUTLOOK.COM",
                "attachmentContentLocation": null,
                "attachmentContentType": "message/rfc822",
                "attachmentId": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkARgAAA8UvpdPLfBBFk4yzLjFjo38HAKGgXpWqlGBOsYqBLmshp1EAAAIBDAAAAKGgXpWqlGBOsYqBLmshp1EAAAIFhgAAAAESABAA9dMsF6Uz2EKW1qVA4rT+aw==",
                "attachmentIsInline": false,
                "attachmentLastModifiedTime": "2020-05-21T07:46:16+00:00",
                "attachmentName": "Message from Cortex XSOAR Security Operations Server",
                "attachmentSHA256": "3a487ce2f9801449da365d642a4c69602f70a1f6579ab837f9b39301128907fa",
                "attachmentSize": 26592,
                "attachmentType": "ItemAttachment",
                "originalItemId": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkARgAAA8UvpdPLfBBFk4yzLjFjo38HAKGgXpWqlGBOsYqBLmshp1EAAAIBDAAAAKGgXpWqlGBOsYqBLmshp1EAAAIFhgAAAA=="
            }
        ],
        "author": "MicrosoftExchange329e71ec88ae4615bbc36ab6ce41109e@badava.onmicrosoft.com",
        "body": "\u003chtml\u003e\u003chead\u003e\r\n\u003cmeta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"\u003e\u003cmeta name=\"viewport\" content=\"width=device-width, initial-scale=1\"\u003e\u003ctitle\u003eDSN\u003c/title\u003e\u003c/head\u003e\u003cbody style=\"        background-color: white;      \"\u003e\u003ctable style=\"        background-color: white;         max-width: 548px;         color: black;         border-spacing: 0px 0px;         padding-top: 0px;         padding-bottom: 0px;        border-collapse: collapse;      \" width=\"548\" cellspacing=\"0\" cellpadding=\"0\"\u003e\u003ctbody\u003e\u003ctr\u003e\u003ctd style=\"        text-align: left;        padding-bottom: 20px;      \"\u003e\u003cimg height=\"28\" width=\"126\" style=\"        max-width: 100%;      \" src=\"http://products.office.com/en-us/CMSImages/Office365Logo_Orange.png?version=b8d100a9-0a8b-8e6a-88e1-ef488fee0470\"\u003e \u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 16px;         padding-bottom: 10px;         -ms-text-size-adjust: 100%;        text-align: left;      \"\u003eYour message to \u003cspan style=\"        color: #0072c6;      \"\u003eadmin@company.com\u003c/span\u003e couldn't be delivered.\u003cbr\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;         font-size: 24px;         padding-top: 0px;         padding-bottom: 20px;         text-align: center;         -ms-text-size-adjust: 100%;      \"\u003e\u003cspan style=\"        color: #0072c6;      \"\u003eadmin\u003c/span\u003e wasn't found at \u003cspan style=\"        color: #0072c6;      \"\u003ecompany.com\u003c/span\u003e.\u003cbr\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        padding-bottom: 15px;         padding-left: 0px;         padding-right: 0px;         border-spacing: 0px 0px;      \"\u003e\u003ctable style=\"        max-width: 548px;         font-weight: 600;        border-spacing: 0px 0px;         padding-top: 0px;         padding-bottom: 0px;        border-collapse: collapse;      \"\u003e\u003ctbody\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 15px;        font-weight: 600;        text-align: left;        width: 181px;        -ms-text-size-adjust: 100%;        vertical-align: bottom;      \"\u003e\u003cfont color=\"#ffffff\"\u003e\u003cspan style=\"color:#000000\"\u003ericha\u003c/span\u003e \u003c/font\u003e\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 15px;        font-weight: 600;        text-align: center;        width: 186px;        -ms-text-size-adjust: 100%;        vertical-align: bottom;      \"\u003e\u003cfont color=\"#ffffff\"\u003e\u003cspan style=\"color:#000000\"\u003eOffice 365\u003c/span\u003e \u003c/font\u003e\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;         -ms-text-size-adjust: 100%;         font-size: 15px;         font-weight: 600;        text-align: right;         width: 181px;         vertical-align: bottom;      \"\u003e\u003cfont color=\"#ffffff\"\u003e\u003cspan style=\"color:#000000\"\u003eadmin\u003c/span\u003e \u003c/font\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;        text-align: left;        padding-top: 0px;        padding-bottom: 0px;        vertical-align: middle;        width: 181px;      \"\u003e\u003cfont color=\"#ffffff\"\u003e\u003cspan style=\"        color: #c00000;      \"\u003e\u003cb\u003eAction Required\u003c/b\u003e \u003c/span\u003e\u003c/font\u003e\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;        text-align: center;        padding-top: 0px;        padding-bottom: 0px;        vertical-align: middle;        width: 186px;      \"\u003e\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;        text-align: right;        padding-top: 0px;        padding-bottom: 0px;        vertical-align: middle;        width: 181px;      \"\u003e\u003cfont color=\"#ffffff\"\u003e\u003cspan style=\"color:#000000\"\u003eRecipient\u003c/span\u003e \u003c/font\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd colspan=\"3\" style=\"        padding-top:0;        padding-bottom:0;        padding-left:0;        padding-right:0      \"\u003e\u003ctable cellspacing=\"0\" cellpadding=\"0\" style=\"        border-spacing: 0px 0px;        padding-top: 0px;        padding-bottom: 0px;        padding-left: 0px;        padding-right: 0px;        border-collapse: collapse;      \"\u003e\u003ctbody\u003e\u003ctr height=\"10\"\u003e\u003ctd width=\"180\" height=\"10\" bgcolor=\"#c00000\" style=\"        width: 180px;        line-height: 10px;        height: 10px;        font-size: 6px;        padding-top: 0;        padding-bottom: 0;        padding-left: 0;        padding-right: 0;      \"\u003e\u003c!--[if gte mso 15]\u003e\u0026nbsp;\u003c![endif]--\u003e\u003c/td\u003e\u003ctd width=\"4\" height=\"10\" bgcolor=\"#ffffff\" style=\"        width: 4px;        line-height: 10px;        height: 10px;        font-size: 6px;        padding-top: 0;        padding-bottom: 0;        padding-left: 0;        padding-right: 0;      \"\u003e\u003c!--[if gte mso 15]\u003e\u0026nbsp;\u003c![endif]--\u003e\u003c/td\u003e\u003ctd width=\"180\" height=\"10\" bgcolor=\"#cccccc\" style=\"        width: 180px;        line-height: 10px;        height: 10px;        font-size: 6px;        padding-top: 0;        padding-bottom: 0;        padding-left: 0;        padding-right: 0;      \"\u003e\u003c!--[if gte mso 15]\u003e\u0026nbsp;\u003c![endif]--\u003e\u003c/td\u003e\u003ctd width=\"4\" height=\"10\" bgcolor=\"#ffffff\" style=\"        width: 4px;        line-height: 10px;        height: 10px;        font-size: 6px;        padding-top: 0;        padding-bottom: 0;        padding-left: 0;        padding-right: 0;      \"\u003e\u003c!--[if gte mso 15]\u003e\u0026nbsp;\u003c![endif]--\u003e\u003c/td\u003e\u003ctd width=\"180\" height=\"10\" bgcolor=\"#cccccc\" style=\"        width: 180px;        line-height: 10px;        height: 10px;        font-size: 6px;        padding-top: 0;        padding-bottom: 0;        padding-left: 0;        padding-right: 0;      \"\u003e\u003c!--[if gte mso 15]\u003e\u0026nbsp;\u003c![endif]--\u003e\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        text-align: left;        width: 181px;        line-height: 20px;        font-weight: 400;        padding-top: 0px;        padding-left: 0px;        padding-right: 0px;        padding-bottom: 0px;      \"\u003e\u003cfont color=\"#ffffff\"\u003e\u003cspan style=\"        color: #c00000;      \"\u003eUnknown To address\u003c/span\u003e \u003c/font\u003e\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        text-align: center;        width: 186px;        line-height: 20px;        font-weight: 400;        padding-top: 0px;        padding-left: 0px;        padding-right: 0px;        padding-bottom: 0px;      \"\u003e\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        text-align: right;        width: 181px;        line-height: 20px;        font-weight: 400;        padding-top: 0px;        padding-left: 0px;        padding-right: 0px;        padding-bottom: 0px;      \"\u003e\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        width: 100%;        padding-top: 0px;        padding-right: 10px;        padding-left: 10px;      \"\u003e\u003cbr\u003e\u003ctable style=\"        width: 100%;        padding-right: 0px;        padding-left: 0px;        padding-top: 0px;        padding-bottom: 0px;        background-color: #f2f5fa;        margin-left: 0px;      \"\u003e\u003ctbody\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 21px;        font-weight: 500;        background-color: #f2f5fa;        padding-top: 0px;        padding-bottom: 0px;        padding-left: 10px;        padding-right: 10px;      \"\u003eHow to Fix It\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 16px;        font-weight: 400;        padding-top: 0px;        padding-bottom: 6px;        padding-left: 10px;        padding-right: 10px;        background-color: #f2f5fa;      \"\u003eThe address may be misspelled or may not exist. Try one or more of the following:\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"         padding-top: 0px;         padding-bottom: 0px;         padding-left: 0px;         padding-right: 0px;        border-spacing: 0px 0px;      \"\u003e\u003cul style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 16px;        font-weight: 400;        margin-left: 40px;        margin-bottom: 5px;        background-color: #f2f5fa;        padding-top: 0px;        padding-bottom: 0px;        padding-left: 6px;        padding-right: 6px;      \"\u003e\u003cli\u003eSend the message again following these steps: In Outlook, open this non-delivery report (NDR) and choose \u003cb\u003eSend Again\u003c/b\u003e from the Report ribbon. In Outlook on the web, select this NDR, then select the link \u0026quot;\u003cb\u003eTo send this message again, click here.\u003c/b\u003e\u0026quot; Then delete and retype the entire recipient address. If prompted with an Auto-Complete List suggestion don't select it. After typing the complete address, click \u003cb\u003eSend\u003c/b\u003e.\u003c/li\u003e\u003cli\u003eContact the recipient (by phone, for example) to check that the address exists and is correct.\u003c/li\u003e\u003cli\u003eThe recipient may have set up email forwarding to an incorrect address. Ask them to check that any forwarding they've set up is working correctly.\u003c/li\u003e\u003cli\u003eClear the recipient Auto-Complete List in Outlook or Outlook on the web by following the steps in this article: \u003ca href=\"https://go.microsoft.com/fwlink/?LinkId=389363\"\u003eFix email delivery issues for error code 5.1.1 in Office 365\u003c/a\u003e, and then send the message again. Retype the entire recipient address before selecting \u003cb\u003eSend\u003c/b\u003e.\u003c/li\u003e\u003c/ul\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 16px;        font-weight: 400;        padding-top: 0px;        padding-bottom: 6px;        padding-left: 10px;        padding-right: 10px;        background-color: #f2f5fa;      \"\u003eIf the problem continues, forward this message to your email admin. If you're an email admin, refer to the \u003cb\u003eMore Info for Email Admins\u003c/b\u003e section below.\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;        padding-top: 10px;        padding-bottom: 0px;        padding-bottom: 4px;      \"\u003e\u003cbr\u003e\u003cem\u003eWas this helpful? \u003ca href=\"https://go.microsoft.com/fwlink/?LinkId=525920\"\u003eSend feedback to Microsoft\u003c/a\u003e.\u003c/em\u003e \u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        -ms-text-size-adjust: 100%;        font-size: 0px;        line-height: 0px;        padding-top: 0px;        padding-bottom: 0px;      \"\u003e\u003chr\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 21px;        font-weight: 500;      \"\u003e\u003cbr\u003eMore Info for Email Admins\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;      \"\u003e\u003cem\u003eStatus code: 550 5.1.1\u003c/em\u003e \u003cbr\u003e\u003cbr\u003eThis error occurs because the sender sent a message to an email address outside of Office 365, but the address is incorrect or doesn't exist at the destination domain. The error is reported by the recipient domain's email server, but most often it must be fixed by the person who sent the message. If the steps in the \u003cb\u003eHow to Fix It\u003c/b\u003e section above don't fix the problem, and you're the email admin for the recipient, try one or more of the following:\u003cbr\u003e\u003cbr\u003e\u003cb\u003eThe email address exists and is correct\u003c/b\u003e - Confirm that the recipient address exists, is correct, and is accepting messages.\u003cbr\u003e\u003cbr\u003e\u003cb\u003eSynchronize your directories\u003c/b\u003e - If you have a hybrid environment and are using directory synchronization make sure the recipient's email address is synced correctly in both Office 365 and in your on-premises directory.\u003cbr\u003e\u003cbr\u003e\u003cb\u003eErrant forwarding rule\u003c/b\u003e - Check for forwarding rules that aren't behaving as expected. Forwarding can be set up by an admin via mail flow rules or mailbox forwarding address settings, or by the recipient via the Inbox Rules feature.\u003cbr\u003e\u003cbr\u003e\u003cb\u003eMail flow settings and MX records are not correct\u003c/b\u003e - Misconfigured mail flow or MX record settings can cause this error. Check your Office 365 mail flow settings to make sure your domain and any mail flow connectors are set up correctly. Also, work with your domain registrar to make sure the MX records for your domain are configured correctly.\u003cbr\u003e\u003cbr\u003eFor more information and additional tips to fix this issue, see \u003ca href=\"https://go.microsoft.com/fwlink/?LinkId=389363\"\u003eFix email delivery issues for error code 550 5.1.1 in Office 365\u003c/a\u003e.\u003cbr\u003e\u003cbr\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 17px;        font-weight: 500;      \"\u003eOriginal Message Details\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-size: 14px;        line-height: 20px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;      \"\u003e\u003ctable style=\"        width: 100%;        border-collapse: collapse;        margin-left: 10px;      \"\u003e\u003ctbody\u003e\u003ctr\u003e\u003ctd valign=\"top\" style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eCreated Date:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003e5/21/2020 7:46:13 AM\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd valign=\"top\" style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eSender Address:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003ericha@badava.onmicrosoft.com\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eRecipient Address:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003eadmin@company.com\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eSubject:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003eMessage from Cortex XSOAR Security Operations Server\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 17px;        font-weight: 500;      \"\u003e\u003cbr\u003eError Details\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-size: 14px;        line-height: 20px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;      \"\u003e\u003ctable style=\"        width: 100%;        border-collapse: collapse;        margin-left: 10px;      \"\u003e\u003ctbody\u003e\u003ctr\u003e\u003ctd valign=\"top\" style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eReported error:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003e\u003cem\u003e550 5.1.1 \u0026lt;admin@company.com\u0026gt;: Email address could not be found, or was misspelled (G8)\u003c/em\u003e \u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eDSN generated by:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003eBMXPR01MB4101.INDPRD01.PROD.OUTLOOK.COM\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eRemote server:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003esmtp19.gate.iad3a.rsapps.net\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003cbr\u003e\u003ctable style=\"width: 880px;\" cellspacing=\"0\"\u003e\u003ctbody\u003e\u003ctr\u003e\u003ctd colspan=\"6\" style=\"        padding-top: 4px;        border-bottom: 1px solid #999999;        padding-bottom: 4px;        line-height: 120%;        font-size: 17px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;      \"\u003eMessage Hops\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        background-color: #f2f5fa;        border-bottom: 1px solid #999999;        white-space: nowrap;        padding: 8px;      \"\u003eHOP\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        background-color: #f2f5fa;        border-bottom: 1px solid #999999;        white-space: nowrap;        padding: 8px;        width: 80px;      \"\u003eTIME (UTC)\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        background-color: #f2f5fa;        border-bottom: 1px solid #999999;        white-space: nowrap;        padding: 8px;      \"\u003eFROM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        background-color: #f2f5fa;        border-bottom: 1px solid #999999;        white-space: nowrap;        padding: 8px;      \"\u003eTO\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        background-color: #f2f5fa;        border-bottom: 1px solid #999999;        white-space: nowrap;        padding: 8px;      \"\u003eWITH\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        background-color: #f2f5fa;        border-bottom: 1px solid #999999;        white-space: nowrap;        padding: 8px;      \"\u003eRELAY TIME\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: center;      \"\u003e1\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;        width: 80px;      \"\u003e5/21/2020\u003cbr\u003e7:46:13 AM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003eBMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003eBMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003emapi\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003e*\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: center;      \"\u003e2\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;        width: 80px;      \"\u003e5/21/2020\u003cbr\u003e7:46:13 AM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003eBMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003eBMXPR01MB4101.INDPRD01.PROD.OUTLOOK.COM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003eMicrosoft SMTP Server (version=TLS1_2, cipher=TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384)\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003e*\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003cp style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 17px;        font-weight: 500;        padding-top: 4px;        padding-bottom: 0;        margin-top: 19px;        margin-bottom: 5px;      \"\u003eOriginal Message Headers\u003c/p\u003e\u003cpre style=\"        color: gray;        white-space: pre;        padding-top: 0;        margin-top: 5px;      \"\u003eARC-Seal: i=1; a=rsa-sha256; s=arcselector9901; d=microsoft.com; cv=none;\r\n b=LFbo7sNrXV5UstsXz02FPVp38DM5e8gY1SU42fu7D9/uhuzFJT9GzUcUwyd17m5XvqT5XV9vUsT9tQKdDBrT7Gm1u7OkcWTa92\u0026#43;iga8CFs2w6ImlWPzECTy1Sf/iyaJbleD/lU5kGkCxyGF9pab\u0026#43;CBqeQKg4Z9iDNHwdUpaDrjQ/gHkrDBU/MsDhq4EwEoy5N2/ir1X/F3Jot9C4we1XPcW2TEGBVeVtnhpKQj28ILSrzbMPhVB8jswHjUcUfes/mL/wWb8bPhWMIDXb1bK16BUl\u0026#43;0eZwpCL0rbt82wMIW/yf17nx7nIOfIfwo1qB5evr8IGoSBHsnq/Ul8TRQ4DpA==\r\nARC-Message-Signature: i=1; a=rsa-sha256; c=relaxed/relaxed; d=microsoft.com;\r\n s=arcselector9901;\r\n h=From:Date:Subject:Message-ID:Content-Type:MIME-Version:X-MS-Exchange-SenderADCheck;\r\n bh=qIWvkA3bhacvdckysZVE3GPD/jiqEZ\u0026#43;nmgqdAOmGW/k=;\r\n b=VAdY0x36F9trkWRDOgFXwUVOmDnRkABVGQcoecsPwpJlCLRUoxgVLNeKxHBe2XWy\u0026#43;JKSN8OB2Tjw16kH6lHmYfy1ObyygjsIuhDjz/4CYt2l2IYv1W5Qltrsid5ivfSqFjf64uEPTBB06fXnez4BxHB7UhudGaKO1csd4/0X0fv4qDdDu//yYARK24aKa9b/MH3Jmw4cHKQvegwSdwrJ3db7gl81S1v/fPhorzY5waRtmAo\u0026#43;aIDEWgs6jumZvqn98IiwINTpheRnFIFYOtDtDuTB5Szm09mYXjqEo6YBS9e\u0026#43;swsAav0VYgxmETJhCCC4bJ2M1/ugL4dA\u0026#43;ubFDrFwqg==\r\nARC-Authentication-Results: i=1; mx.microsoft.com 1; spf=pass\r\n smtp.mailfrom=badava.onmicrosoft.com; dmarc=pass action=none\r\n header.from=badava.onmicrosoft.com; dkim=pass\r\n header.d=badava.onmicrosoft.com; arc=none\r\nDKIM-Signature: v=1; a=rsa-sha256; c=relaxed/relaxed;\r\n d=badava.onmicrosoft.com; s=selector1-badava-onmicrosoft-com;\r\n h=From:Date:Subject:Message-ID:Content-Type:MIME-Version:X-MS-Exchange-SenderADCheck;\r\n bh=qIWvkA3bhacvdckysZVE3GPD/jiqEZ\u0026#43;nmgqdAOmGW/k=;\r\n b=Iy8HQAX61nuN091co8iwk\u0026#43;G0b\u0026#43;4uqmdiao53ffytMANL0ywKMTGnYMJARvyQ5QHRZrM2\u0026#43;47JtunbOL\u0026#43;JPl6xPrIb5oO9nVaUTSKFHLaRopYLx1UwLL7eZH1uyI46pfeBJte\u0026#43;iHSVjpoSSxiMTkJIVd/zwpaOGloyO/VLhz/ZZHI=\r\nReceived: from BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM (2603:1096:b00:59::12)\r\n by BMXPR01MB4101.INDPRD01.PROD.OUTLOOK.COM (2603:1096:b00:5b::10) with\r\n Microsoft SMTP Server (version=TLS1_2,\r\n cipher=TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384) id 15.20.3021.25; Thu, 21 May\r\n 2020 07:46:13 \u0026#43;0000\r\nReceived: from BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\r\n ([fe80::1d03:43d1:9bf:ce0d]) by BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\r\n ([fe80::1d03:43d1:9bf:ce0d%7]) with mapi id 15.20.3000.034; Thu, 21 May 2020\r\n 07:46:13 \u0026#43;0000\r\nFrom: richa priyanka \u0026lt;richa@badava.onmicrosoft.com\u0026gt;\r\nTo: \u0026quot;admin@company.com\u0026quot; \u0026lt;admin@company.com\u0026gt;\r\nSubject: Message from Cortex XSOAR Security Operations Server\r\nThread-Topic: Message from Cortex XSOAR Security Operations Server\r\nThread-Index: AQHWL0PmLaSzMHKaAEO8WgfRLKD7cQ==\r\nDate: Thu, 21 May 2020 07:46:13 \u0026#43;0000\r\nMessage-ID: \u0026lt;BMXPR01MB37670194D407D3006B2DC48C8EB70@BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u0026gt;\r\nAccept-Language: en-US\r\nContent-Language: en-US\r\nX-MS-Has-Attach:\r\nX-MS-TNEF-Correlator:\r\nauthentication-results: company.com; dkim=none (message not signed)\r\n header.d=none;company.com; dmarc=none action=none\r\n header.from=badava.onmicrosoft.com;\r\nx-originating-ip: [54.176.61.115]\r\nx-ms-publictraffictype: Email\r\nx-ms-office365-filtering-correlation-id: 420b9772-976c-44b5-d73d-08d7fd5b090c\r\nx-ms-traffictypediagnostic: BMXPR01MB4101:\r\nx-microsoft-antispam-prvs: \u0026lt;BMXPR01MB4101398DC6BAC2D9E3F6BD3A8EB70@BMXPR01MB4101.INDPRD01.PROD.OUTLOOK.COM\u0026gt;\r\nx-ms-oob-tlc-oobclassifiers: OLM:4303;\r\nx-forefront-prvs: 041032FF37\r\nx-ms-exchange-senderadcheck: 1\r\nx-microsoft-antispam: BCL:0;\r\nx-microsoft-antispam-message-info: Kt5k41ONSmDZL5VV8MvoLlW34UPhqPhY4ibYvBlLO6rZ7/H44tcJ1HGV3/Wv9F3qDeX9fkhyvcQNkU0\u0026#43;rABWgmOhXev5xSVSVr4v6jPgi8RspBEfij28A3gM6rCi\u0026#43;CH/qHV4E3XgrZNeVpajHKvqMDcHV1al/LxBObpx96OjAZSQcQHaMVCY91NqgwrP3me\u0026#43;j1ufpvrysJjzOUH2TH3ssEkjJ0uJ46G0jwV9ZB4SlgTJnROjrb/vNorFkEuFLD/UFRMUtZNZxPRYoCAO9ZLAT4xL\u0026#43;ZUOVhBTD\u0026#43;ikXy7d7L\u0026#43;VjAukIaDqmWWib14bdiG7PUhwtsGtP9fPLw8R\u0026#43;T2rwasnLs4xmw7KT6UhJHv5uJM=\r\nx-forefront-antispam-report: CIP:255.255.255.255;CTRY:;LANG:en;SCL:1;SRV:;IPV:NLI;SFV:NSPM;H:BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM;PTR:;CAT:NONE;SFTY:;SFS:(34036004)(136003)(366004)(396003)(346002)(39830400003)(376002)(26005)(186003)(558084003)(9686003)(508600001)(86362001)(966005)(8676002)(2906002)(6916009)(5660300002)(71200400001)(52536014)(7696005)(55236004)(6506007)(66446008)(66476007)(64756008)(66556008)(66946007)(55016002)(33656002)(15650500001)(91956017)(8936002)(316002)(76116006);DIR:OUT;SFP:1101;\r\nx-ms-exchange-antispam-messagedata: 1B18OJUTrCIlsyc6RZsAc\u0026#43;ciI/s/W01ZATZccm4dmZR/RcY7WTVI1Cut2qytcCPO6s7GStLrwWT/EByJenYe\u0026#43;CDw1jhHDAriOqiH56q7DfWo4\u0026#43;xZn\u0026#43;b7UOo94AjXA\u0026#43;aXIehUm/ZYVlLGhzVHaSRR7N8f/9fyd5V2rwdle7XsbmO3rljoiJ0xQItu0ua3c42QRuRqnQYqGymU3TCJyxLY1eUkD7f4/K5rEr1XwIRDhXCMkGKpJi/Nz93rM9CgNwg7IY9I3zUh8ywahrg/ktqM\u0026#43;YZ6/0TF03LnoSzjIaMJSK9sfoPkgqk3hO6ZlOMTLfdpx9q1ZO\u0026#43;yunLYJUM3eflPVhyjOnFQL2IptA5SpALQSt2V3xJ/ww614oHNOK162SF0YBkwZbm\u0026#43;51IaVjdgeY81vG5YYQMMzAS\u0026#43;Sv/3Qfs6eVhzsPlXSnSe8JdhIEtSNelL\u0026#43;\u0026#43;oM/BizD1jMXMGXh4fwe81dgtDnQXg0Hmw06zJIdCg=\r\nx-ms-exchange-transport-forked: True\r\nContent-Type: text/plain; charset=\u0026quot;us-ascii\u0026quot;\r\nContent-Transfer-Encoding: quoted-printable\r\nMIME-Version: 1.0\r\nX-OriginatorOrg: badava.onmicrosoft.com\r\nX-MS-Exchange-CrossTenant-Network-Message-Id: 420b9772-976c-44b5-d73d-08d7fd5b090c\r\nX-MS-Exchange-CrossTenant-originalarrivaltime: 21 May 2020 07:46:13.1532\r\n (UTC)\r\nX-MS-Exchange-CrossTenant-fromentityheader: Hosted\r\nX-MS-Exchange-CrossTenant-id: a3da2674-d726-4da3-9d8e-2b65566ef88a\r\nX-MS-Exchange-CrossTenant-mailboxtype: HOSTED\r\nX-MS-Exchange-CrossTenant-userprincipalname: xtS6AAJM5KdJuqg5B\u0026#43;W0DWm7OxiTZvAZYjlzJQGIj38KlaaYmwkByd5FKLfNPKBGDYht5Myws1SALa1zVzJIX7TnpcOa\u0026#43;YXJk9aUE7CPQHg=\r\nX-MS-Exchange-Transport-CrossTenantHeadersStamped: BMXPR01MB4101\r\n\u003c/pre\u003e\u003c/body\u003e\u003c/html\u003e",
        "datetimeCreated": "2020-05-21T07:46:16Z",
        "datetimeReceived": "2020-05-21T07:46:16Z",
        "datetimeSent": "2020-05-21T07:46:15Z",
        "hasAttachments": true,
        "headers": [
            {
                "name": "Received",
                "value": "from BMXPR01MB4101.INDPRD01.PROD.OUTLOOK.COM (2603:1096:b00:40::14) by BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM with HTTPS via BM1PR01CA0120.INDPRD01.PROD.OUTLOOK.COM; Thu, 21 May 2020 07:46:16 +0000"
            },
            {
                "name": "MIME-Version",
                "value": "1.0"
            },
            {
                "name": "Date",
                "value": "Thu, 21 May 2020 07:46:15 +0000"
            },
            {
                "name": "Content-Type",
                "value": "multipart/report"
            },
            {
                "name": "X-MS-Exchange-Organization-SCL",
                "value": "-1"
            },
            {
                "name": "Content-Language",
                "value": "en-US"
            },
            {
                "name": "Message-ID",
                "value": "\u003cbbc5d1ac-082b-458b-96b2-7a7d6c4452d6@BMXPR01MB4101.INDPRD01.PROD.OUTLOOK.COM\u003e"
            },
            {
                "name": "In-Reply-To",
                "value": "\u003cBMXPR01MB37670194D407D3006B2DC48C8EB70@BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003e"
            },
            {
                "name": "References",
                "value": "\u003cBMXPR01MB37670194D407D3006B2DC48C8EB70@BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003e"
            },
            {
                "name": "Thread-Topic",
                "value": "Message from Cortex XSOAR Security Operations Server"
            },
            {
                "name": "Thread-Index",
                "value": "AQHWL0PmLaSzMHKaAEO8WgfRLKD7caiyKUh2"
            },
            {
                "name": "Subject",
                "value": "Undeliverable: Message from Cortex XSOAR Security Operations Server"
            },
            {
                "name": "Auto-Submitted",
                "value": "auto-replied"
            },
            {
                "name": "X-MS-PublicTrafficType",
                "value": "Email"
            },
            {
                "name": "X-MS-Exchange-Organization-AuthSource",
                "value": "BMXPR01MB4101.INDPRD01.PROD.OUTLOOK.COM"
            },
            {
                "name": "X-MS-Exchange-Organization-AuthAs",
                "value": "Internal"
            },
            {
                "name": "X-MS-Exchange-Organization-AuthMechanism",
                "value": "05"
            },
            {
                "name": "X-MS-Exchange-Organization-Network-Message-Id",
                "value": "51a17653-d50f-4bc4-d52e-08d7fd5b0ab2"
            },
            {
                "name": "X-MS-TrafficTypeDiagnostic",
                "value": "BMXPR01MB4101:"
            },
            {
                "name": "X-MS-Exchange-Organization-ExpirationStartTime",
                "value": "21 May 2020 07:46:15.9497 (UTC)"
            },
            {
                "name": "X-MS-Exchange-Organization-ExpirationStartTimeReason",
                "value": "SideEffectMessage"
            },
            {
                "name": "X-MS-Exchange-Organization-ExpirationInterval",
                "value": "1:00:00:00.0000000"
            },
            {
                "name": "X-MS-Exchange-Organization-ExpirationIntervalReason",
                "value": "SideEffectMessage"
            },
            {
                "name": "X-MS-Oob-TLC-OOBClassifiers",
                "value": "OLM:923;"
            },
            {
                "name": "X-Microsoft-Antispam",
                "value": "BCL:0;"
            },
            {
                "name": "X-Forefront-Antispam-Report",
                "value": "CIP:255.255.255.255;CTRY:;LANG:en;SCL:-1;SRV:;IPV:NLI;SFV:SKI;H:;PTR:;CAT:NONE;SFTY:;SFS:;DIR:INB;SFP:;"
            },
            {
                "name": "X-MS-Exchange-CrossTenant-OriginalArrivalTime",
                "value": "21 May 2020 07:46:15.9527 (UTC)"
            },
            {
                "name": "X-MS-Exchange-CrossTenant-FromEntityHeader",
                "value": "Hosted"
            },
            {
                "name": "X-MS-Exchange-CrossTenant-Network-Message-Id",
                "value": "51a17653-d50f-4bc4-d52e-08d7fd5b0ab2"
            },
            {
                "name": "X-MS-Exchange-Transport-CrossTenantHeadersStamped",
                "value": "BMXPR01MB4101"
            },
            {
                "name": "X-MS-Exchange-Organization-MessageDirectionality",
                "value": "Originating"
            },
            {
                "name": "X-MS-Exchange-Transport-EndToEndLatency",
                "value": "00:00:00.1768409"
            },
            {
                "name": "X-MS-Exchange-Processed-By-BccFoldering",
                "value": "15.20.3000.034"
            },
            {
                "name": "X-Microsoft-Antispam-Mailbox-Delivery",
                "value": "ucf:0;jmr:0;auth:0;dest:I;ENG:(750128)(520011016)(706158)(944506383)(944626604);"
            },
            {
                "name": "X-Microsoft-Antispam-Message-Info",
                "value": "xBFbGCNjaIzyEwr2fP2m15i89dPrq3MsHZZPqNbYt3SygwLlmwNmEbrdEDd/BcpjqkHi7EzpGTa0AKXAHA1uGvz2zPBxz6wrQ5ZZ9zlcNJ8pvRa5v7cjtjCfuhZ7mckcCB7RWgbzSEUmZWL0GPOVHlEOpFjZLmflaoS6TILcBY/wz9LkxInJ/+43NQ3nILipJdgbIfSE6od5B9AYnqHRP4fpWKRKI9KVONfwc1ssT/+u/N9AU8F2QO2StP5+LO8UKtep6A92F9POAF7+urP9QQT/8tTnVub9gfLhmpsHgNfTWZ75WWAmuOX7TWa+ejfzJl1pSFzh8FCJgyMzTGPbZvt6V9ne9aR42IYCNyG5t18KzljCroqcWllLNRQrJdY8UEmXYoCBk5nIa0av99j+pSo6SNQJef58rb8Dnib6/q7b6yHXFYLOzUpTBJ9mUsMr9lb4lEaaHsdUJ9mNhvwn95VnswWf0SOW7IK0/XwPsvVgKTo9HhZ5c0rjFX5FXmaReOsizd9HkmEyU4NUAg6zQA=="
            }
        ],
        "importance": "Normal",
        "isRead": false,
        "itemId": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkARgAAA8UvpdPLfBBFk4yzLjFjo38HAKGgXpWqlGBOsYqBLmshp1EAAAIBDAAAAKGgXpWqlGBOsYqBLmshp1EAAAIFhgAAAA==",
        "lastModifiedTime": "2020-05-21T07:46:17Z",
        "mailbox": "richa@badava.onmicrosoft.com",
        "messageId": "\u003cbbc5d1ac-082b-458b-96b2-7a7d6c4452d6@BMXPR01MB4101.INDPRD01.PROD.OUTLOOK.COM\u003e",
        "receivedBy": "richa@badava.onmicrosoft.com",
        "sender": "MicrosoftExchange329e71ec88ae4615bbc36ab6ce41109e@badava.onmicrosoft.com",
        "size": 188386,
        "subject": "Undeliverable: Message from Cortex XSOAR Security Operations Server",
        "textBody": "[http://products.office.com/en-us/CMSImages/Office365Logo_Orange.png?version=b8d100a9-0a8b-8e6a-88e1-ef488fee0470]\r\nYour message to admin@company.com couldn't be delivered.\r\nadmin wasn't found at company.com.\r\nricha   Office 365      admin\r\nAction Required                 Recipient\r\nUnknown To address\r\n\r\nHow to Fix It\r\nThe address may be misspelled or may not exist. Try one or more of the following:\r\n\r\n  *   Send the message again following these steps: In Outlook, open this non-delivery report (NDR) and choose Send Again from the Report ribbon. In Outlook on the web, select this NDR, then select the link \"To send this message again, click here.\" Then delete and retype the entire recipient address. If prompted with an Auto-Complete List suggestion don't select it. After typing the complete address, click Send.\r\n  *   Contact the recipient (by phone, for example) to check that the address exists and is correct.\r\n  *   The recipient may have set up email forwarding to an incorrect address. Ask them to check that any forwarding they've set up is working correctly.\r\n  *   Clear the recipient Auto-Complete List in Outlook or Outlook on the web by following the steps in this article: Fix email delivery issues for error code 5.1.1 in Office 365\u003chttps://go.microsoft.com/fwlink/?LinkId=389363\u003e, and then send the message again. Retype the entire recipient address before selecting Send.\r\n\r\nIf the problem continues, forward this message to your email admin. If you're an email admin, refer to the More Info for Email Admins section below.\r\n\r\nWas this helpful? Send feedback to Microsoft\u003chttps://go.microsoft.com/fwlink/?LinkId=525920\u003e.\r\n________________________________\r\n\r\nMore Info for Email Admins\r\nStatus code: 550 5.1.1\r\n\r\nThis error occurs because the sender sent a message to an email address outside of Office 365, but the address is incorrect or doesn't exist at the destination domain. The error is reported by the recipient domain's email server, but most often it must be fixed by the person who sent the message. If the steps in the How to Fix It section above don't fix the problem, and you're the email admin for the recipient, try one or more of the following:\r\n\r\nThe email address exists and is correct - Confirm that the recipient address exists, is correct, and is accepting messages.\r\n\r\nSynchronize your directories - If you have a hybrid environment and are using directory synchronization make sure the recipient's email address is synced correctly in both Office 365 and in your on-premises directory.\r\n\r\nErrant forwarding rule - Check for forwarding rules that aren't behaving as expected. Forwarding can be set up by an admin via mail flow rules or mailbox forwarding address settings, or by the recipient via the Inbox Rules feature.\r\n\r\nMail flow settings and MX records are not correct - Misconfigured mail flow or MX record settings can cause this error. Check your Office 365 mail flow settings to make sure your domain and any mail flow connectors are set up correctly. Also, work with your domain registrar to make sure the MX records for your domain are configured correctly.\r\n\r\nFor more information and additional tips to fix this issue, see Fix email delivery issues for error code 550 5.1.1 in Office 365\u003chttps://go.microsoft.com/fwlink/?LinkId=389363\u003e.\r\n\r\nOriginal Message Details\r\nCreated Date:   5/21/2020 7:46:13 AM\r\nSender Address: richa@badava.onmicrosoft.com\r\nRecipient Address:      admin@company.com\r\nSubject:        Message from Cortex XSOAR Security Operations Server\r\n\r\nError Details\r\nReported error: 550 5.1.1 \u003cadmin@company.com\u003e: Email address could not be found, or was misspelled (G8)\r\nDSN generated by:       BMXPR01MB4101.INDPRD01.PROD.OUTLOOK.COM\r\nRemote server:  smtp19.gate.iad3a.rsapps.net\r\n\r\nMessage Hops\r\nHOP     TIME (UTC)      FROM    TO      WITH    RELAY TIME\r\n1       5/21/2020\r\n7:46:13 AM      BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM mapi    *\r\n2       5/21/2020\r\n7:46:13 AM      BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM BMXPR01MB4101.INDPRD01.PROD.OUTLOOK.COM Microsoft SMTP Server (version=TLS1_2, cipher=TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384)    *\r\n\r\nOriginal Message Headers\r\n\r\nARC-Seal: i=1; a=rsa-sha256; s=arcselector9901; d=microsoft.com; cv=none;\r\n b=LFbo7sNrXV5UstsXz02FPVp38DM5e8gY1SU42fu7D9/uhuzFJT9GzUcUwyd17m5XvqT5XV9vUsT9tQKdDBrT7Gm1u7OkcWTa92+iga8CFs2w6ImlWPzECTy1Sf/iyaJbleD/lU5kGkCxyGF9pab+CBqeQKg4Z9iDNHwdUpaDrjQ/gHkrDBU/MsDhq4EwEoy5N2/ir1X/F3Jot9C4we1XPcW2TEGBVeVtnhpKQj28ILSrzbMPhVB8jswHjUcUfes/mL/wWb8bPhWMIDXb1bK16BUl+0eZwpCL0rbt82wMIW/yf17nx7nIOfIfwo1qB5evr8IGoSBHsnq/Ul8TRQ4DpA==\r\nARC-Message-Signature: i=1; a=rsa-sha256; c=relaxed/relaxed; d=microsoft.com;\r\n s=arcselector9901;\r\n h=From:Date:Subject:Message-ID:Content-Type:MIME-Version:X-MS-Exchange-SenderADCheck;\r\n bh=qIWvkA3bhacvdckysZVE3GPD/jiqEZ+nmgqdAOmGW/k=;\r\n b=VAdY0x36F9trkWRDOgFXwUVOmDnRkABVGQcoecsPwpJlCLRUoxgVLNeKxHBe2XWy+JKSN8OB2Tjw16kH6lHmYfy1ObyygjsIuhDjz/4CYt2l2IYv1W5Qltrsid5ivfSqFjf64uEPTBB06fXnez4BxHB7UhudGaKO1csd4/0X0fv4qDdDu//yYARK24aKa9b/MH3Jmw4cHKQvegwSdwrJ3db7gl81S1v/fPhorzY5waRtmAo+aIDEWgs6jumZvqn98IiwINTpheRnFIFYOtDtDuTB5Szm09mYXjqEo6YBS9e+swsAav0VYgxmETJhCCC4bJ2M1/ugL4dA+ubFDrFwqg==\r\nARC-Authentication-Results: i=1; mx.microsoft.com 1; spf=pass\r\n smtp.mailfrom=badava.onmicrosoft.com; dmarc=pass action=none\r\n header.from=badava.onmicrosoft.com; dkim=pass\r\n header.d=badava.onmicrosoft.com; arc=none\r\nDKIM-Signature: v=1; a=rsa-sha256; c=relaxed/relaxed;\r\n d=badava.onmicrosoft.com; s=selector1-badava-onmicrosoft-com;\r\n h=From:Date:Subject:Message-ID:Content-Type:MIME-Version:X-MS-Exchange-SenderADCheck;\r\n bh=qIWvkA3bhacvdckysZVE3GPD/jiqEZ+nmgqdAOmGW/k=;\r\n b=Iy8HQAX61nuN091co8iwk+G0b+4uqmdiao53ffytMANL0ywKMTGnYMJARvyQ5QHRZrM2+47JtunbOL+JPl6xPrIb5oO9nVaUTSKFHLaRopYLx1UwLL7eZH1uyI46pfeBJte+iHSVjpoSSxiMTkJIVd/zwpaOGloyO/VLhz/ZZHI=\r\nReceived: from BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM (2603:1096:b00:59::12)\r\n by BMXPR01MB4101.INDPRD01.PROD.OUTLOOK.COM (2603:1096:b00:5b::10) with\r\n Microsoft SMTP Server (version=TLS1_2,\r\n cipher=TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384) id 15.20.3021.25; Thu, 21 May\r\n 2020 07:46:13 +0000\r\nReceived: from BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\r\n ([fe80::1d03:43d1:9bf:ce0d]) by BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\r\n ([fe80::1d03:43d1:9bf:ce0d%7]) with mapi id 15.20.3000.034; Thu, 21 May 2020\r\n 07:46:13 +0000\r\nFrom: richa priyanka \u003cricha@badava.onmicrosoft.com\u003e\r\nTo: \"admin@company.com\" \u003cadmin@company.com\u003e\r\nSubject: Message from Cortex XSOAR Security Operations Server\r\nThread-Topic: Message from Cortex XSOAR Security Operations Server\r\nThread-Index: AQHWL0PmLaSzMHKaAEO8WgfRLKD7cQ==\r\nDate: Thu, 21 May 2020 07:46:13 +0000\r\nMessage-ID: \u003cBMXPR01MB37670194D407D3006B2DC48C8EB70@BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003e\r\nAccept-Language: en-US\r\nContent-Language: en-US\r\nX-MS-Has-Attach:\r\nX-MS-TNEF-Correlator:\r\nauthentication-results: company.com; dkim=none (message not signed)\r\n header.d=none;company.com; dmarc=none action=none\r\n header.from=badava.onmicrosoft.com;\r\nx-originating-ip: [54.176.61.115]\r\nx-ms-publictraffictype: Email\r\nx-ms-office365-filtering-correlation-id: 420b9772-976c-44b5-d73d-08d7fd5b090c\r\nx-ms-traffictypediagnostic: BMXPR01MB4101:\r\nx-microsoft-antispam-prvs: \u003cBMXPR01MB4101398DC6BAC2D9E3F6BD3A8EB70@BMXPR01MB4101.INDPRD01.PROD.OUTLOOK.COM\u003e\r\nx-ms-oob-tlc-oobclassifiers: OLM:4303;\r\nx-forefront-prvs: 041032FF37\r\nx-ms-exchange-senderadcheck: 1\r\nx-microsoft-antispam: BCL:0;\r\nx-microsoft-antispam-message-info: Kt5k41ONSmDZL5VV8MvoLlW34UPhqPhY4ibYvBlLO6rZ7/H44tcJ1HGV3/Wv9F3qDeX9fkhyvcQNkU0+rABWgmOhXev5xSVSVr4v6jPgi8RspBEfij28A3gM6rCi+CH/qHV4E3XgrZNeVpajHKvqMDcHV1al/LxBObpx96OjAZSQcQHaMVCY91NqgwrP3me+j1ufpvrysJjzOUH2TH3ssEkjJ0uJ46G0jwV9ZB4SlgTJnROjrb/vNorFkEuFLD/UFRMUtZNZxPRYoCAO9ZLAT4xL+ZUOVhBTD+ikXy7d7L+VjAukIaDqmWWib14bdiG7PUhwtsGtP9fPLw8R+T2rwasnLs4xmw7KT6UhJHv5uJM=\r\nx-forefront-antispam-report: CIP:255.255.255.255;CTRY:;LANG:en;SCL:1;SRV:;IPV:NLI;SFV:NSPM;H:BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM;PTR:;CAT:NONE;SFTY:;SFS:(34036004)(136003)(366004)(396003)(346002)(39830400003)(376002)(26005)(186003)(558084003)(9686003)(508600001)(86362001)(966005)(8676002)(2906002)(6916009)(5660300002)(71200400001)(52536014)(7696005)(55236004)(6506007)(66446008)(66476007)(64756008)(66556008)(66946007)(55016002)(33656002)(15650500001)(91956017)(8936002)(316002)(76116006);DIR:OUT;SFP:1101;\r\nx-ms-exchange-antispam-messagedata: 1B18OJUTrCIlsyc6RZsAc+ciI/s/W01ZATZccm4dmZR/RcY7WTVI1Cut2qytcCPO6s7GStLrwWT/EByJenYe+CDw1jhHDAriOqiH56q7DfWo4+xZn+b7UOo94AjXA+aXIehUm/ZYVlLGhzVHaSRR7N8f/9fyd5V2rwdle7XsbmO3rljoiJ0xQItu0ua3c42QRuRqnQYqGymU3TCJyxLY1eUkD7f4/K5rEr1XwIRDhXCMkGKpJi/Nz93rM9CgNwg7IY9I3zUh8ywahrg/ktqM+YZ6/0TF03LnoSzjIaMJSK9sfoPkgqk3hO6ZlOMTLfdpx9q1ZO+yunLYJUM3eflPVhyjOnFQL2IptA5SpALQSt2V3xJ/ww614oHNOK162SF0YBkwZbm+51IaVjdgeY81vG5YYQMMzAS+Sv/3Qfs6eVhzsPlXSnSe8JdhIEtSNelL++oM/BizD1jMXMGXh4fwe81dgtDnQXg0Hmw06zJIdCg=\r\nx-ms-exchange-transport-forked: True\r\nContent-Type: text/plain; charset=\"us-ascii\"\r\nContent-Transfer-Encoding: quoted-printable\r\nMIME-Version: 1.0\r\nX-OriginatorOrg: badava.onmicrosoft.com\r\nX-MS-Exchange-CrossTenant-Network-Message-Id: 420b9772-976c-44b5-d73d-08d7fd5b090c\r\nX-MS-Exchange-CrossTenant-originalarrivaltime: 21 May 2020 07:46:13.1532\r\n (UTC)\r\nX-MS-Exchange-CrossTenant-fromentityheader: Hosted\r\nX-MS-Exchange-CrossTenant-id: a3da2674-d726-4da3-9d8e-2b65566ef88a\r\nX-MS-Exchange-CrossTenant-mailboxtype: HOSTED\r\nX-MS-Exchange-CrossTenant-userprincipalname: xtS6AAJM5KdJuqg5B+W0DWm7OxiTZvAZYjlzJQGIj38KlaaYmwkByd5FKLfNPKBGDYht5Myws1SALa1zVzJIX7TnpcOa+YXJk9aUE7CPQHg=\r\nX-MS-Exchange-Transport-CrossTenantHeadersStamped: BMXPR01MB4101\r\n\r\n",
        "toRecipients": [
            "admin@company.com"
        ]
    },
    {
        "ItemAttachments": [
            {
                "attachmentContentId": "9E9814D2BFFCAA4CBE931EDB2835DBB5@INDPRD01.PROD.OUTLOOK.COM",
                "attachmentContentLocation": null,
                "attachmentContentType": "message/rfc822",
                "attachmentId": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkARgAAA8UvpdPLfBBFk4yzLjFjo38HAKGgXpWqlGBOsYqBLmshp1EAAAIBDAAAAKGgXpWqlGBOsYqBLmshp1EAAAIFhQAAAAESABAAFoD0cLCL9Ey7HWZfKiylbA==",
                "attachmentIsInline": false,
                "attachmentLastModifiedTime": "2020-05-21T07:46:13+00:00",
                "attachmentName": "Message from Cortex XSOAR Security Operations Server",
                "attachmentSHA256": "593f44935f5a2def6bac6051405d45a397019196e24e96efe425f7c527c93cff",
                "attachmentSize": 26592,
                "attachmentType": "ItemAttachment",
                "originalItemId": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkARgAAA8UvpdPLfBBFk4yzLjFjo38HAKGgXpWqlGBOsYqBLmshp1EAAAIBDAAAAKGgXpWqlGBOsYqBLmshp1EAAAIFhQAAAA=="
            }
        ],
        "author": "MicrosoftExchange329e71ec88ae4615bbc36ab6ce41109e@badava.onmicrosoft.com",
        "body": "\u003chtml\u003e\u003chead\u003e\r\n\u003cmeta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"\u003e\u003cmeta name=\"viewport\" content=\"width=device-width, initial-scale=1\"\u003e\u003ctitle\u003eDSN\u003c/title\u003e\u003c/head\u003e\u003cbody style=\"        background-color: white;      \"\u003e\u003ctable style=\"        background-color: white;         max-width: 548px;         color: black;         border-spacing: 0px 0px;         padding-top: 0px;         padding-bottom: 0px;        border-collapse: collapse;      \" width=\"548\" cellspacing=\"0\" cellpadding=\"0\"\u003e\u003ctbody\u003e\u003ctr\u003e\u003ctd style=\"        text-align: left;        padding-bottom: 20px;      \"\u003e\u003cimg height=\"28\" width=\"126\" style=\"        max-width: 100%;      \" src=\"http://products.office.com/en-us/CMSImages/Office365Logo_Orange.png?version=b8d100a9-0a8b-8e6a-88e1-ef488fee0470\"\u003e \u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 16px;         padding-bottom: 10px;         -ms-text-size-adjust: 100%;        text-align: left;      \"\u003eYour message to \u003cspan style=\"        color: #0072c6;      \"\u003eadmin@company.com\u003c/span\u003e couldn't be delivered.\u003cbr\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;         font-size: 24px;         padding-top: 0px;         padding-bottom: 20px;         text-align: center;         -ms-text-size-adjust: 100%;      \"\u003e\u003cspan style=\"        color: #0072c6;      \"\u003eadmin\u003c/span\u003e wasn't found at \u003cspan style=\"        color: #0072c6;      \"\u003ecompany.com\u003c/span\u003e.\u003cbr\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        padding-bottom: 15px;         padding-left: 0px;         padding-right: 0px;         border-spacing: 0px 0px;      \"\u003e\u003ctable style=\"        max-width: 548px;         font-weight: 600;        border-spacing: 0px 0px;         padding-top: 0px;         padding-bottom: 0px;        border-collapse: collapse;      \"\u003e\u003ctbody\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 15px;        font-weight: 600;        text-align: left;        width: 181px;        -ms-text-size-adjust: 100%;        vertical-align: bottom;      \"\u003e\u003cfont color=\"#ffffff\"\u003e\u003cspan style=\"color:#000000\"\u003ericha\u003c/span\u003e \u003c/font\u003e\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 15px;        font-weight: 600;        text-align: center;        width: 186px;        -ms-text-size-adjust: 100%;        vertical-align: bottom;      \"\u003e\u003cfont color=\"#ffffff\"\u003e\u003cspan style=\"color:#000000\"\u003eOffice 365\u003c/span\u003e \u003c/font\u003e\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;         -ms-text-size-adjust: 100%;         font-size: 15px;         font-weight: 600;        text-align: right;         width: 181px;         vertical-align: bottom;      \"\u003e\u003cfont color=\"#ffffff\"\u003e\u003cspan style=\"color:#000000\"\u003eadmin\u003c/span\u003e \u003c/font\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;        text-align: left;        padding-top: 0px;        padding-bottom: 0px;        vertical-align: middle;        width: 181px;      \"\u003e\u003cfont color=\"#ffffff\"\u003e\u003cspan style=\"        color: #c00000;      \"\u003e\u003cb\u003eAction Required\u003c/b\u003e \u003c/span\u003e\u003c/font\u003e\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;        text-align: center;        padding-top: 0px;        padding-bottom: 0px;        vertical-align: middle;        width: 186px;      \"\u003e\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;        text-align: right;        padding-top: 0px;        padding-bottom: 0px;        vertical-align: middle;        width: 181px;      \"\u003e\u003cfont color=\"#ffffff\"\u003e\u003cspan style=\"color:#000000\"\u003eRecipient\u003c/span\u003e \u003c/font\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd colspan=\"3\" style=\"        padding-top:0;        padding-bottom:0;        padding-left:0;        padding-right:0      \"\u003e\u003ctable cellspacing=\"0\" cellpadding=\"0\" style=\"        border-spacing: 0px 0px;        padding-top: 0px;        padding-bottom: 0px;        padding-left: 0px;        padding-right: 0px;        border-collapse: collapse;      \"\u003e\u003ctbody\u003e\u003ctr height=\"10\"\u003e\u003ctd width=\"180\" height=\"10\" bgcolor=\"#c00000\" style=\"        width: 180px;        line-height: 10px;        height: 10px;        font-size: 6px;        padding-top: 0;        padding-bottom: 0;        padding-left: 0;        padding-right: 0;      \"\u003e\u003c!--[if gte mso 15]\u003e\u0026nbsp;\u003c![endif]--\u003e\u003c/td\u003e\u003ctd width=\"4\" height=\"10\" bgcolor=\"#ffffff\" style=\"        width: 4px;        line-height: 10px;        height: 10px;        font-size: 6px;        padding-top: 0;        padding-bottom: 0;        padding-left: 0;        padding-right: 0;      \"\u003e\u003c!--[if gte mso 15]\u003e\u0026nbsp;\u003c![endif]--\u003e\u003c/td\u003e\u003ctd width=\"180\" height=\"10\" bgcolor=\"#cccccc\" style=\"        width: 180px;        line-height: 10px;        height: 10px;        font-size: 6px;        padding-top: 0;        padding-bottom: 0;        padding-left: 0;        padding-right: 0;      \"\u003e\u003c!--[if gte mso 15]\u003e\u0026nbsp;\u003c![endif]--\u003e\u003c/td\u003e\u003ctd width=\"4\" height=\"10\" bgcolor=\"#ffffff\" style=\"        width: 4px;        line-height: 10px;        height: 10px;        font-size: 6px;        padding-top: 0;        padding-bottom: 0;        padding-left: 0;        padding-right: 0;      \"\u003e\u003c!--[if gte mso 15]\u003e\u0026nbsp;\u003c![endif]--\u003e\u003c/td\u003e\u003ctd width=\"180\" height=\"10\" bgcolor=\"#cccccc\" style=\"        width: 180px;        line-height: 10px;        height: 10px;        font-size: 6px;        padding-top: 0;        padding-bottom: 0;        padding-left: 0;        padding-right: 0;      \"\u003e\u003c!--[if gte mso 15]\u003e\u0026nbsp;\u003c![endif]--\u003e\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        text-align: left;        width: 181px;        line-height: 20px;        font-weight: 400;        padding-top: 0px;        padding-left: 0px;        padding-right: 0px;        padding-bottom: 0px;      \"\u003e\u003cfont color=\"#ffffff\"\u003e\u003cspan style=\"        color: #c00000;      \"\u003eUnknown To address\u003c/span\u003e \u003c/font\u003e\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        text-align: center;        width: 186px;        line-height: 20px;        font-weight: 400;        padding-top: 0px;        padding-left: 0px;        padding-right: 0px;        padding-bottom: 0px;      \"\u003e\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        text-align: right;        width: 181px;        line-height: 20px;        font-weight: 400;        padding-top: 0px;        padding-left: 0px;        padding-right: 0px;        padding-bottom: 0px;      \"\u003e\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        width: 100%;        padding-top: 0px;        padding-right: 10px;        padding-left: 10px;      \"\u003e\u003cbr\u003e\u003ctable style=\"        width: 100%;        padding-right: 0px;        padding-left: 0px;        padding-top: 0px;        padding-bottom: 0px;        background-color: #f2f5fa;        margin-left: 0px;      \"\u003e\u003ctbody\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 21px;        font-weight: 500;        background-color: #f2f5fa;        padding-top: 0px;        padding-bottom: 0px;        padding-left: 10px;        padding-right: 10px;      \"\u003eHow to Fix It\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 16px;        font-weight: 400;        padding-top: 0px;        padding-bottom: 6px;        padding-left: 10px;        padding-right: 10px;        background-color: #f2f5fa;      \"\u003eThe address may be misspelled or may not exist. Try one or more of the following:\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"         padding-top: 0px;         padding-bottom: 0px;         padding-left: 0px;         padding-right: 0px;        border-spacing: 0px 0px;      \"\u003e\u003cul style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 16px;        font-weight: 400;        margin-left: 40px;        margin-bottom: 5px;        background-color: #f2f5fa;        padding-top: 0px;        padding-bottom: 0px;        padding-left: 6px;        padding-right: 6px;      \"\u003e\u003cli\u003eSend the message again following these steps: In Outlook, open this non-delivery report (NDR) and choose \u003cb\u003eSend Again\u003c/b\u003e from the Report ribbon. In Outlook on the web, select this NDR, then select the link \u0026quot;\u003cb\u003eTo send this message again, click here.\u003c/b\u003e\u0026quot; Then delete and retype the entire recipient address. If prompted with an Auto-Complete List suggestion don't select it. After typing the complete address, click \u003cb\u003eSend\u003c/b\u003e.\u003c/li\u003e\u003cli\u003eContact the recipient (by phone, for example) to check that the address exists and is correct.\u003c/li\u003e\u003cli\u003eThe recipient may have set up email forwarding to an incorrect address. Ask them to check that any forwarding they've set up is working correctly.\u003c/li\u003e\u003cli\u003eClear the recipient Auto-Complete List in Outlook or Outlook on the web by following the steps in this article: \u003ca href=\"https://go.microsoft.com/fwlink/?LinkId=389363\"\u003eFix email delivery issues for error code 5.1.1 in Office 365\u003c/a\u003e, and then send the message again. Retype the entire recipient address before selecting \u003cb\u003eSend\u003c/b\u003e.\u003c/li\u003e\u003c/ul\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 16px;        font-weight: 400;        padding-top: 0px;        padding-bottom: 6px;        padding-left: 10px;        padding-right: 10px;        background-color: #f2f5fa;      \"\u003eIf the problem continues, forward this message to your email admin. If you're an email admin, refer to the \u003cb\u003eMore Info for Email Admins\u003c/b\u003e section below.\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;        padding-top: 10px;        padding-bottom: 0px;        padding-bottom: 4px;      \"\u003e\u003cbr\u003e\u003cem\u003eWas this helpful? \u003ca href=\"https://go.microsoft.com/fwlink/?LinkId=525920\"\u003eSend feedback to Microsoft\u003c/a\u003e.\u003c/em\u003e \u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        -ms-text-size-adjust: 100%;        font-size: 0px;        line-height: 0px;        padding-top: 0px;        padding-bottom: 0px;      \"\u003e\u003chr\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 21px;        font-weight: 500;      \"\u003e\u003cbr\u003eMore Info for Email Admins\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;      \"\u003e\u003cem\u003eStatus code: 550 5.1.1\u003c/em\u003e \u003cbr\u003e\u003cbr\u003eThis error occurs because the sender sent a message to an email address outside of Office 365, but the address is incorrect or doesn't exist at the destination domain. The error is reported by the recipient domain's email server, but most often it must be fixed by the person who sent the message. If the steps in the \u003cb\u003eHow to Fix It\u003c/b\u003e section above don't fix the problem, and you're the email admin for the recipient, try one or more of the following:\u003cbr\u003e\u003cbr\u003e\u003cb\u003eThe email address exists and is correct\u003c/b\u003e - Confirm that the recipient address exists, is correct, and is accepting messages.\u003cbr\u003e\u003cbr\u003e\u003cb\u003eSynchronize your directories\u003c/b\u003e - If you have a hybrid environment and are using directory synchronization make sure the recipient's email address is synced correctly in both Office 365 and in your on-premises directory.\u003cbr\u003e\u003cbr\u003e\u003cb\u003eErrant forwarding rule\u003c/b\u003e - Check for forwarding rules that aren't behaving as expected. Forwarding can be set up by an admin via mail flow rules or mailbox forwarding address settings, or by the recipient via the Inbox Rules feature.\u003cbr\u003e\u003cbr\u003e\u003cb\u003eMail flow settings and MX records are not correct\u003c/b\u003e - Misconfigured mail flow or MX record settings can cause this error. Check your Office 365 mail flow settings to make sure your domain and any mail flow connectors are set up correctly. Also, work with your domain registrar to make sure the MX records for your domain are configured correctly.\u003cbr\u003e\u003cbr\u003eFor more information and additional tips to fix this issue, see \u003ca href=\"https://go.microsoft.com/fwlink/?LinkId=389363\"\u003eFix email delivery issues for error code 550 5.1.1 in Office 365\u003c/a\u003e.\u003cbr\u003e\u003cbr\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 17px;        font-weight: 500;      \"\u003eOriginal Message Details\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-size: 14px;        line-height: 20px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;      \"\u003e\u003ctable style=\"        width: 100%;        border-collapse: collapse;        margin-left: 10px;      \"\u003e\u003ctbody\u003e\u003ctr\u003e\u003ctd valign=\"top\" style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eCreated Date:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003e5/21/2020 7:46:09 AM\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd valign=\"top\" style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eSender Address:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003ericha@badava.onmicrosoft.com\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eRecipient Address:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003eadmin@company.com\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eSubject:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003eMessage from Cortex XSOAR Security Operations Server\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 17px;        font-weight: 500;      \"\u003e\u003cbr\u003eError Details\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-size: 14px;        line-height: 20px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;      \"\u003e\u003ctable style=\"        width: 100%;        border-collapse: collapse;        margin-left: 10px;      \"\u003e\u003ctbody\u003e\u003ctr\u003e\u003ctd valign=\"top\" style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eReported error:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003e\u003cem\u003e550 5.1.1 \u0026lt;admin@company.com\u0026gt;: Email address could not be found, or was misspelled (G8)\u003c/em\u003e \u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eDSN generated by:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003eBMXPR01MB4101.INDPRD01.PROD.OUTLOOK.COM\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eRemote server:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003esmtp15.gate.iad3b.rsapps.net\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003cbr\u003e\u003ctable style=\"width: 880px;\" cellspacing=\"0\"\u003e\u003ctbody\u003e\u003ctr\u003e\u003ctd colspan=\"6\" style=\"        padding-top: 4px;        border-bottom: 1px solid #999999;        padding-bottom: 4px;        line-height: 120%;        font-size: 17px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;      \"\u003eMessage Hops\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        background-color: #f2f5fa;        border-bottom: 1px solid #999999;        white-space: nowrap;        padding: 8px;      \"\u003eHOP\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        background-color: #f2f5fa;        border-bottom: 1px solid #999999;        white-space: nowrap;        padding: 8px;        width: 80px;      \"\u003eTIME (UTC)\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        background-color: #f2f5fa;        border-bottom: 1px solid #999999;        white-space: nowrap;        padding: 8px;      \"\u003eFROM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        background-color: #f2f5fa;        border-bottom: 1px solid #999999;        white-space: nowrap;        padding: 8px;      \"\u003eTO\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        background-color: #f2f5fa;        border-bottom: 1px solid #999999;        white-space: nowrap;        padding: 8px;      \"\u003eWITH\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        background-color: #f2f5fa;        border-bottom: 1px solid #999999;        white-space: nowrap;        padding: 8px;      \"\u003eRELAY TIME\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: center;      \"\u003e1\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;        width: 80px;      \"\u003e5/21/2020\u003cbr\u003e7:46:09 AM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003eBMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003eBMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003emapi\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003e*\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: center;      \"\u003e2\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;        width: 80px;      \"\u003e5/21/2020\u003cbr\u003e7:46:09 AM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003eBMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003eBMXPR01MB4101.INDPRD01.PROD.OUTLOOK.COM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003eMicrosoft SMTP Server (version=TLS1_2, cipher=TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384)\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003e*\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003cp style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 17px;        font-weight: 500;        padding-top: 4px;        padding-bottom: 0;        margin-top: 19px;        margin-bottom: 5px;      \"\u003eOriginal Message Headers\u003c/p\u003e\u003cpre style=\"        color: gray;        white-space: pre;        padding-top: 0;        margin-top: 5px;      \"\u003eARC-Seal: i=1; a=rsa-sha256; s=arcselector9901; d=microsoft.com; cv=none;\r\n b=ZCd/6UGIYyL8ichvpiAlOcSG6YIR\u0026#43;YnQkKqF174fmH1PvIP\u0026#43;MiQSMb6Tx0mzMJc3GazmJkPABrd6W9n1saUjW0eNjrqg2\u0026#43;tmOFzHe1zhs10Om39mV5MYTUwyT1xtU5w/EY8IL6\u0026#43;ovGjNZZmzhXANPmxjAmLzO0sQPD4Tf\u0026#43;W0jrYs9EZyWmntf7ELc2O3QtFlZxFh4hOhce9XPkqzNTFeEzXMYM/HVo8cxTLcZUz\u0026#43;/KE0kixgwn2Ca6ZT0h1Zp8GqwOtSuvqHFH3VAsFMkTpmMElj71hwB4z\u0026#43;Kr/gj3w7bgyaNTbOB\u0026#43;G/TWbQsU41ZriM2GvPKaybbG\u0026#43;Jw2HLMu/xGQ==\r\nARC-Message-Signature: i=1; a=rsa-sha256; c=relaxed/relaxed; d=microsoft.com;\r\n s=arcselector9901;\r\n h=From:Date:Subject:Message-ID:Content-Type:MIME-Version:X-MS-Exchange-SenderADCheck;\r\n bh=qIWvkA3bhacvdckysZVE3GPD/jiqEZ\u0026#43;nmgqdAOmGW/k=;\r\n b=IFEb/cJFmy5dWshqDYzxiuFmqAK9ZceHmKqxw4FFSHOROFGXqe2PKHHc5EBsznOvma5eKg3zakonZm4eVo0v5\u0026#43;\u0026#43;3Axg4cPCOwA/Y5BAj2XzJEWSk4R7AgbpdhWqOogd7MIZzyjAzDnRCl6h0dO8uggX8R7rtNZWWvX843E0jqo5QfgTnBNaqy90mMlbQ0WIampZyNrneRbSZwjRN1NMGSRFcAj1M4PW4z\u0026#43;bmWtiQ4UYuaZiu4YXwRlre8L/L\u0026#43;BPwIrQhm3d2THCAX57P1RHxukIaKTUa8t8CNuTMYxIvJrttbNB2A0OAbD8wrT/\u0026#43;aCnXpuiXbfZ/QLPk\u0026#43;XKzN0n3lw==\r\nARC-Authentication-Results: i=1; mx.microsoft.com 1; spf=pass\r\n smtp.mailfrom=badava.onmicrosoft.com; dmarc=pass action=none\r\n header.from=badava.onmicrosoft.com; dkim=pass\r\n header.d=badava.onmicrosoft.com; arc=none\r\nDKIM-Signature: v=1; a=rsa-sha256; c=relaxed/relaxed;\r\n d=badava.onmicrosoft.com; s=selector1-badava-onmicrosoft-com;\r\n h=From:Date:Subject:Message-ID:Content-Type:MIME-Version:X-MS-Exchange-SenderADCheck;\r\n bh=qIWvkA3bhacvdckysZVE3GPD/jiqEZ\u0026#43;nmgqdAOmGW/k=;\r\n b=c8CalLXQJY3COuq\u0026#43;JOflwXBgv4iUr88u4TUlN2dkdFzFRtZXAsxeg\u0026#43;noESYwLVKUN36CREFpqmMS0fE9FhX267SYtMUU8prgApeah/wvw98GYyU3wfPf7HLmoyIOgIibbd8rMrwR23RRq\u0026#43;DU4gEot2yeBdHDtlK4cCsnnuuBxlA=\r\nReceived: from BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM (2603:1096:b00:59::12)\r\n by BMXPR01MB4101.INDPRD01.PROD.OUTLOOK.COM (2603:1096:b00:5b::10) with\r\n Microsoft SMTP Server (version=TLS1_2,\r\n cipher=TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384) id 15.20.3021.25; Thu, 21 May\r\n 2020 07:46:09 \u0026#43;0000\r\nReceived: from BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\r\n ([fe80::1d03:43d1:9bf:ce0d]) by BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\r\n ([fe80::1d03:43d1:9bf:ce0d%7]) with mapi id 15.20.3000.034; Thu, 21 May 2020\r\n 07:46:09 \u0026#43;0000\r\nFrom: richa priyanka \u0026lt;richa@badava.onmicrosoft.com\u0026gt;\r\nTo: \u0026quot;admin@company.com\u0026quot; \u0026lt;admin@company.com\u0026gt;\r\nSubject: Message from Cortex XSOAR Security Operations Server\r\nThread-Topic: Message from Cortex XSOAR Security Operations Server\r\nThread-Index: AQHWL0Pk8vBDxq2wYUCqRgfhK1FjKg==\r\nDate: Thu, 21 May 2020 07:46:09 \u0026#43;0000\r\nMessage-ID: \u0026lt;BMXPR01MB3767F19E1B1D8D3E94D8B0DA8EB70@BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u0026gt;\r\nAccept-Language: en-US\r\nContent-Language: en-US\r\nX-MS-Has-Attach:\r\nX-MS-TNEF-Correlator:\r\nauthentication-results: company.com; dkim=none (message not signed)\r\n header.d=none;company.com; dmarc=none action=none\r\n header.from=badava.onmicrosoft.com;\r\nx-originating-ip: [54.176.61.115]\r\nx-ms-publictraffictype: Email\r\nx-ms-office365-filtering-correlation-id: 8f372d9c-e814-449c-7aba-08d7fd5b06f6\r\nx-ms-traffictypediagnostic: BMXPR01MB4101:\r\nx-microsoft-antispam-prvs: \u0026lt;BMXPR01MB41013D5627E9E28823D06CAE8EB70@BMXPR01MB4101.INDPRD01.PROD.OUTLOOK.COM\u0026gt;\r\nx-ms-oob-tlc-oobclassifiers: OLM:4303;\r\nx-forefront-prvs: 041032FF37\r\nx-ms-exchange-senderadcheck: 1\r\nx-microsoft-antispam: BCL:0;\r\nx-microsoft-antispam-message-info: tfAMtifaKFUYVOp5ydeBeJ1pQLP4pVXdCTeFTd7HtWr5NDHz7pHSdjL\u0026#43;3lGo0xwieEvZZeKRt2URYd4w3mPUzpKqj3QtTOZm\u0026#43;r6TT4CZFnSV8hFMNprW0eCUl4p9clZrWF\u0026#43;vOPKAaiZg44mVaeeF7sVDutwLfYjS/eNJbXY0NAl/TFZ6FEg4foiGEFIbe/f3B78bKhIWuN7dunrNTC1oaxwmBe9EqRqVZ32/Sv63qNcqYAAeRnQlZnXNcOxgiHkv5OcvA4PhR4dZq8jNuJZYWd3aZoH4UT9zQ2lHmXqpM47YE878fOfRj7F6BKSRjgSwFv0an1JTb8KKlDDAEus7Oz/7lb7ga65DX5CKSel\u0026#43;HX8=\r\nx-forefront-antispam-report: CIP:255.255.255.255;CTRY:;LANG:en;SCL:1;SRV:;IPV:NLI;SFV:NSPM;H:BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM;PTR:;CAT:NONE;SFTY:;SFS:(34036004)(136003)(366004)(396003)(346002)(39830400003)(376002)(26005)(186003)(558084003)(9686003)(508600001)(86362001)(966005)(8676002)(2906002)(6916009)(5660300002)(71200400001)(52536014)(7696005)(55236004)(6506007)(66446008)(66476007)(64756008)(66556008)(66946007)(55016002)(33656002)(15650500001)(91956017)(8936002)(316002)(76116006);DIR:OUT;SFP:1101;\r\nx-ms-exchange-antispam-messagedata: reX2X2StahPOTjGnBUVhcORncp/8tp\u0026#43;uz\u0026#43;XY4pednPkQRY4JDnvlxo0NtvvbTPUjBTu03PbCT0bjMSVwEw27x8g5SYn7sbibs1bp2OYyWxmEC/gQAhg6wBguGlLyscRyADZStyfpqPF/VAjEgRKUybOnmEa\u0026#43;qqiq\u0026#43;1DP8T6gn5w4eH5fSWAYcL7EFIKX8m6RnIWuQmDJS0ufH1/1IzlrlkbEXy6LIStcI0p6RPHiRgFhWrw531DaoUne6j7HCUERWI3x4vExDQOfd2U\u0026#43;/KLCAeAIdPkXCZf4m08PFltIJG/svWzelkjUgGkYdfjWyzJnyrcnx3L5DuhndpgpuI/dh7PV7UchvHv1\u0026#43;Hq2rn9wxrIsivhW1qeb7sMjkXwz6YbK91BuSuUSjZz/O5caEUhV1sbB6rKXPo2Br08uuDrGlSgSO/F5eOQRcxnpydoI1eOiFP4iKRs\u0026#43;vqipCBjuxwODNR4nDhhbxY7haHn8mduByV4=\r\nx-ms-exchange-transport-forked: True\r\nContent-Type: text/plain; charset=\u0026quot;us-ascii\u0026quot;\r\nContent-Transfer-Encoding: quoted-printable\r\nMIME-Version: 1.0\r\nX-OriginatorOrg: badava.onmicrosoft.com\r\nX-MS-Exchange-CrossTenant-Network-Message-Id: 8f372d9c-e814-449c-7aba-08d7fd5b06f6\r\nX-MS-Exchange-CrossTenant-originalarrivaltime: 21 May 2020 07:46:09.5723\r\n (UTC)\r\nX-MS-Exchange-CrossTenant-fromentityheader: Hosted\r\nX-MS-Exchange-CrossTenant-id: a3da2674-d726-4da3-9d8e-2b65566ef88a\r\nX-MS-Exchange-CrossTenant-mailboxtype: HOSTED\r\nX-MS-Exchange-CrossTenant-userprincipalname: 9EkulCQ\u0026#43;CVphdRLj8I9sa4xrwvnzs9WhHDVzbtmGKeBMdTpXxKWf5gvY8tuxrnf28ldaAjI7sCUBZb6EmYWkrzQIVWwRiRMYAIclZv85E4I=\r\nX-MS-Exchange-Transport-CrossTenantHeadersStamped: BMXPR01MB4101\r\n\u003c/pre\u003e\u003c/body\u003e\u003c/html\u003e",
        "datetimeCreated": "2020-05-21T07:46:13Z",
        "datetimeReceived": "2020-05-21T07:46:13Z",
        "datetimeSent": "2020-05-21T07:46:12Z",
        "hasAttachments": true,
        "headers": [
            {
                "name": "Received",
                "value": "from BMXPR01MB4101.INDPRD01.PROD.OUTLOOK.COM (2603:1096:b00:40::14) by BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM with HTTPS via BM1PR01CA0120.INDPRD01.PROD.OUTLOOK.COM; Thu, 21 May 2020 07:46:12 +0000"
            },
            {
                "name": "MIME-Version",
                "value": "1.0"
            },
            {
                "name": "Date",
                "value": "Thu, 21 May 2020 07:46:12 +0000"
            },
            {
                "name": "Content-Type",
                "value": "multipart/report"
            },
            {
                "name": "X-MS-Exchange-Organization-SCL",
                "value": "-1"
            },
            {
                "name": "Content-Language",
                "value": "en-US"
            },
            {
                "name": "Message-ID",
                "value": "\u003cb4220d28-d7a9-475d-ab93-77fa33c07b14@BMXPR01MB4101.INDPRD01.PROD.OUTLOOK.COM\u003e"
            },
            {
                "name": "In-Reply-To",
                "value": "\u003cBMXPR01MB3767F19E1B1D8D3E94D8B0DA8EB70@BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003e"
            },
            {
                "name": "References",
                "value": "\u003cBMXPR01MB3767F19E1B1D8D3E94D8B0DA8EB70@BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003e"
            },
            {
                "name": "Thread-Topic",
                "value": "Message from Cortex XSOAR Security Operations Server"
            },
            {
                "name": "Thread-Index",
                "value": "AQHWL0Pk8vBDxq2wYUCqRgfhK1FjKqiyKUS0"
            },
            {
                "name": "Subject",
                "value": "Undeliverable: Message from Cortex XSOAR Security Operations Server"
            },
            {
                "name": "Auto-Submitted",
                "value": "auto-replied"
            },
            {
                "name": "X-MS-PublicTrafficType",
                "value": "Email"
            },
            {
                "name": "X-MS-Exchange-Organization-AuthSource",
                "value": "BMXPR01MB4101.INDPRD01.PROD.OUTLOOK.COM"
            },
            {
                "name": "X-MS-Exchange-Organization-AuthAs",
                "value": "Internal"
            },
            {
                "name": "X-MS-Exchange-Organization-AuthMechanism",
                "value": "05"
            },
            {
                "name": "X-MS-Exchange-Organization-Network-Message-Id",
                "value": "d64c2a9e-e8a6-47c1-e6ff-08d7fd5b08c2"
            },
            {
                "name": "X-MS-TrafficTypeDiagnostic",
                "value": "BMXPR01MB4101:"
            },
            {
                "name": "X-MS-Exchange-Organization-ExpirationStartTime",
                "value": "21 May 2020 07:46:12.6996 (UTC)"
            },
            {
                "name": "X-MS-Exchange-Organization-ExpirationStartTimeReason",
                "value": "SideEffectMessage"
            },
            {
                "name": "X-MS-Exchange-Organization-ExpirationInterval",
                "value": "1:00:00:00.0000000"
            },
            {
                "name": "X-MS-Exchange-Organization-ExpirationIntervalReason",
                "value": "SideEffectMessage"
            },
            {
                "name": "X-MS-Oob-TLC-OOBClassifiers",
                "value": "OLM:923;"
            },
            {
                "name": "X-Microsoft-Antispam",
                "value": "BCL:0;"
            },
            {
                "name": "X-Forefront-Antispam-Report",
                "value": "CIP:255.255.255.255;CTRY:;LANG:en;SCL:-1;SRV:;IPV:NLI;SFV:SKI;H:;PTR:;CAT:NONE;SFTY:;SFS:;DIR:INB;SFP:;"
            },
            {
                "name": "X-MS-Exchange-CrossTenant-OriginalArrivalTime",
                "value": "21 May 2020 07:46:12.7026 (UTC)"
            },
            {
                "name": "X-MS-Exchange-CrossTenant-FromEntityHeader",
                "value": "Hosted"
            },
            {
                "name": "X-MS-Exchange-CrossTenant-Network-Message-Id",
                "value": "d64c2a9e-e8a6-47c1-e6ff-08d7fd5b08c2"
            },
            {
                "name": "X-MS-Exchange-Transport-CrossTenantHeadersStamped",
                "value": "BMXPR01MB4101"
            },
            {
                "name": "X-MS-Exchange-Organization-MessageDirectionality",
                "value": "Originating"
            },
            {
                "name": "X-MS-Exchange-Transport-EndToEndLatency",
                "value": "00:00:00.2277765"
            },
            {
                "name": "X-MS-Exchange-Processed-By-BccFoldering",
                "value": "15.20.3000.034"
            },
            {
                "name": "X-Microsoft-Antispam-Mailbox-Delivery",
                "value": "ucf:0;jmr:0;auth:0;dest:I;ENG:(750128)(520011016)(706158)(944506383)(944626604);"
            },
            {
                "name": "X-Microsoft-Antispam-Message-Info",
                "value": "Jj5cMTUEqEGyV3C8LQopjPDZAg6w0XfcYElmHbQqi7PYALH1CzoT83RKppXFUyRG8F4wLSeJlrqEBkQjLD53a897dyig3v2KguaUHXA3gXv+k7hbbpCcGtfhZsOLjaO1tAFGIfP+QVy618UkSxrXcOEDmchlssALVWou2DFEz3u4GXb5Hh1TJroyFDNOvtajzCpnlcowI8cM3pO0b8ZDTl9jRxvYdeX0IdonoTLE/t69a4lEj5jH5liawp2eKJMvqsm8WkNO8PsmVMF8EiGTB1OHcOPcYQWXGueUR3PESGiQi1meZUpaf9nrSOklLChLweY1YOimAydX7QDbuRiyanUOra0nm4Zwc/hJyksliRE9IUNgNKXYmg0hj5PPNyCtKul91EczNKfy+C/rEzIZejTh8ErG87fIcEcUFlpeDSC4ARVAe6FexsO+eY7z8dDdjHmNRiorecuIPxweVWDL8y8oeYIYpZBTjP16Knan8O/TBk5gwCSCfHLwxDnlvqk8JEkxGRse4/LvZkCWYbm7PtJVAZrqfiX1I1+XhRF3N8E="
            }
        ],
        "importance": "Normal",
        "isRead": false,
        "itemId": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkARgAAA8UvpdPLfBBFk4yzLjFjo38HAKGgXpWqlGBOsYqBLmshp1EAAAIBDAAAAKGgXpWqlGBOsYqBLmshp1EAAAIFhQAAAA==",
        "lastModifiedTime": "2020-05-21T07:46:14Z",
        "mailbox": "richa@badava.onmicrosoft.com",
        "messageId": "\u003cb4220d28-d7a9-475d-ab93-77fa33c07b14@BMXPR01MB4101.INDPRD01.PROD.OUTLOOK.COM\u003e",
        "receivedBy": "richa@badava.onmicrosoft.com",
        "sender": "MicrosoftExchange329e71ec88ae4615bbc36ab6ce41109e@badava.onmicrosoft.com",
        "size": 188564,
        "subject": "Undeliverable: Message from Cortex XSOAR Security Operations Server",
        "textBody": "[http://products.office.com/en-us/CMSImages/Office365Logo_Orange.png?version=b8d100a9-0a8b-8e6a-88e1-ef488fee0470]\r\nYour message to admin@company.com couldn't be delivered.\r\nadmin wasn't found at company.com.\r\nricha   Office 365      admin\r\nAction Required                 Recipient\r\nUnknown To address\r\n\r\nHow to Fix It\r\nThe address may be misspelled or may not exist. Try one or more of the following:\r\n\r\n  *   Send the message again following these steps: In Outlook, open this non-delivery report (NDR) and choose Send Again from the Report ribbon. In Outlook on the web, select this NDR, then select the link \"To send this message again, click here.\" Then delete and retype the entire recipient address. If prompted with an Auto-Complete List suggestion don't select it. After typing the complete address, click Send.\r\n  *   Contact the recipient (by phone, for example) to check that the address exists and is correct.\r\n  *   The recipient may have set up email forwarding to an incorrect address. Ask them to check that any forwarding they've set up is working correctly.\r\n  *   Clear the recipient Auto-Complete List in Outlook or Outlook on the web by following the steps in this article: Fix email delivery issues for error code 5.1.1 in Office 365\u003chttps://go.microsoft.com/fwlink/?LinkId=389363\u003e, and then send the message again. Retype the entire recipient address before selecting Send.\r\n\r\nIf the problem continues, forward this message to your email admin. If you're an email admin, refer to the More Info for Email Admins section below.\r\n\r\nWas this helpful? Send feedback to Microsoft\u003chttps://go.microsoft.com/fwlink/?LinkId=525920\u003e.\r\n________________________________\r\n\r\nMore Info for Email Admins\r\nStatus code: 550 5.1.1\r\n\r\nThis error occurs because the sender sent a message to an email address outside of Office 365, but the address is incorrect or doesn't exist at the destination domain. The error is reported by the recipient domain's email server, but most often it must be fixed by the person who sent the message. If the steps in the How to Fix It section above don't fix the problem, and you're the email admin for the recipient, try one or more of the following:\r\n\r\nThe email address exists and is correct - Confirm that the recipient address exists, is correct, and is accepting messages.\r\n\r\nSynchronize your directories - If you have a hybrid environment and are using directory synchronization make sure the recipient's email address is synced correctly in both Office 365 and in your on-premises directory.\r\n\r\nErrant forwarding rule - Check for forwarding rules that aren't behaving as expected. Forwarding can be set up by an admin via mail flow rules or mailbox forwarding address settings, or by the recipient via the Inbox Rules feature.\r\n\r\nMail flow settings and MX records are not correct - Misconfigured mail flow or MX record settings can cause this error. Check your Office 365 mail flow settings to make sure your domain and any mail flow connectors are set up correctly. Also, work with your domain registrar to make sure the MX records for your domain are configured correctly.\r\n\r\nFor more information and additional tips to fix this issue, see Fix email delivery issues for error code 550 5.1.1 in Office 365\u003chttps://go.microsoft.com/fwlink/?LinkId=389363\u003e.\r\n\r\nOriginal Message Details\r\nCreated Date:   5/21/2020 7:46:09 AM\r\nSender Address: richa@badava.onmicrosoft.com\r\nRecipient Address:      admin@company.com\r\nSubject:        Message from Cortex XSOAR Security Operations Server\r\n\r\nError Details\r\nReported error: 550 5.1.1 \u003cadmin@company.com\u003e: Email address could not be found, or was misspelled (G8)\r\nDSN generated by:       BMXPR01MB4101.INDPRD01.PROD.OUTLOOK.COM\r\nRemote server:  smtp15.gate.iad3b.rsapps.net\r\n\r\nMessage Hops\r\nHOP     TIME (UTC)      FROM    TO      WITH    RELAY TIME\r\n1       5/21/2020\r\n7:46:09 AM      BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM mapi    *\r\n2       5/21/2020\r\n7:46:09 AM      BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM BMXPR01MB4101.INDPRD01.PROD.OUTLOOK.COM Microsoft SMTP Server (version=TLS1_2, cipher=TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384)    *\r\n\r\nOriginal Message Headers\r\n\r\nARC-Seal: i=1; a=rsa-sha256; s=arcselector9901; d=microsoft.com; cv=none;\r\n b=ZCd/6UGIYyL8ichvpiAlOcSG6YIR+YnQkKqF174fmH1PvIP+MiQSMb6Tx0mzMJc3GazmJkPABrd6W9n1saUjW0eNjrqg2+tmOFzHe1zhs10Om39mV5MYTUwyT1xtU5w/EY8IL6+ovGjNZZmzhXANPmxjAmLzO0sQPD4Tf+W0jrYs9EZyWmntf7ELc2O3QtFlZxFh4hOhce9XPkqzNTFeEzXMYM/HVo8cxTLcZUz+/KE0kixgwn2Ca6ZT0h1Zp8GqwOtSuvqHFH3VAsFMkTpmMElj71hwB4z+Kr/gj3w7bgyaNTbOB+G/TWbQsU41ZriM2GvPKaybbG+Jw2HLMu/xGQ==\r\nARC-Message-Signature: i=1; a=rsa-sha256; c=relaxed/relaxed; d=microsoft.com;\r\n s=arcselector9901;\r\n h=From:Date:Subject:Message-ID:Content-Type:MIME-Version:X-MS-Exchange-SenderADCheck;\r\n bh=qIWvkA3bhacvdckysZVE3GPD/jiqEZ+nmgqdAOmGW/k=;\r\n b=IFEb/cJFmy5dWshqDYzxiuFmqAK9ZceHmKqxw4FFSHOROFGXqe2PKHHc5EBsznOvma5eKg3zakonZm4eVo0v5++3Axg4cPCOwA/Y5BAj2XzJEWSk4R7AgbpdhWqOogd7MIZzyjAzDnRCl6h0dO8uggX8R7rtNZWWvX843E0jqo5QfgTnBNaqy90mMlbQ0WIampZyNrneRbSZwjRN1NMGSRFcAj1M4PW4z+bmWtiQ4UYuaZiu4YXwRlre8L/L+BPwIrQhm3d2THCAX57P1RHxukIaKTUa8t8CNuTMYxIvJrttbNB2A0OAbD8wrT/+aCnXpuiXbfZ/QLPk+XKzN0n3lw==\r\nARC-Authentication-Results: i=1; mx.microsoft.com 1; spf=pass\r\n smtp.mailfrom=badava.onmicrosoft.com; dmarc=pass action=none\r\n header.from=badava.onmicrosoft.com; dkim=pass\r\n header.d=badava.onmicrosoft.com; arc=none\r\nDKIM-Signature: v=1; a=rsa-sha256; c=relaxed/relaxed;\r\n d=badava.onmicrosoft.com; s=selector1-badava-onmicrosoft-com;\r\n h=From:Date:Subject:Message-ID:Content-Type:MIME-Version:X-MS-Exchange-SenderADCheck;\r\n bh=qIWvkA3bhacvdckysZVE3GPD/jiqEZ+nmgqdAOmGW/k=;\r\n b=c8CalLXQJY3COuq+JOflwXBgv4iUr88u4TUlN2dkdFzFRtZXAsxeg+noESYwLVKUN36CREFpqmMS0fE9FhX267SYtMUU8prgApeah/wvw98GYyU3wfPf7HLmoyIOgIibbd8rMrwR23RRq+DU4gEot2yeBdHDtlK4cCsnnuuBxlA=\r\nReceived: from BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM (2603:1096:b00:59::12)\r\n by BMXPR01MB4101.INDPRD01.PROD.OUTLOOK.COM (2603:1096:b00:5b::10) with\r\n Microsoft SMTP Server (version=TLS1_2,\r\n cipher=TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384) id 15.20.3021.25; Thu, 21 May\r\n 2020 07:46:09 +0000\r\nReceived: from BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\r\n ([fe80::1d03:43d1:9bf:ce0d]) by BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\r\n ([fe80::1d03:43d1:9bf:ce0d%7]) with mapi id 15.20.3000.034; Thu, 21 May 2020\r\n 07:46:09 +0000\r\nFrom: richa priyanka \u003cricha@badava.onmicrosoft.com\u003e\r\nTo: \"admin@company.com\" \u003cadmin@company.com\u003e\r\nSubject: Message from Cortex XSOAR Security Operations Server\r\nThread-Topic: Message from Cortex XSOAR Security Operations Server\r\nThread-Index: AQHWL0Pk8vBDxq2wYUCqRgfhK1FjKg==\r\nDate: Thu, 21 May 2020 07:46:09 +0000\r\nMessage-ID: \u003cBMXPR01MB3767F19E1B1D8D3E94D8B0DA8EB70@BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003e\r\nAccept-Language: en-US\r\nContent-Language: en-US\r\nX-MS-Has-Attach:\r\nX-MS-TNEF-Correlator:\r\nauthentication-results: company.com; dkim=none (message not signed)\r\n header.d=none;company.com; dmarc=none action=none\r\n header.from=badava.onmicrosoft.com;\r\nx-originating-ip: [54.176.61.115]\r\nx-ms-publictraffictype: Email\r\nx-ms-office365-filtering-correlation-id: 8f372d9c-e814-449c-7aba-08d7fd5b06f6\r\nx-ms-traffictypediagnostic: BMXPR01MB4101:\r\nx-microsoft-antispam-prvs: \u003cBMXPR01MB41013D5627E9E28823D06CAE8EB70@BMXPR01MB4101.INDPRD01.PROD.OUTLOOK.COM\u003e\r\nx-ms-oob-tlc-oobclassifiers: OLM:4303;\r\nx-forefront-prvs: 041032FF37\r\nx-ms-exchange-senderadcheck: 1\r\nx-microsoft-antispam: BCL:0;\r\nx-microsoft-antispam-message-info: tfAMtifaKFUYVOp5ydeBeJ1pQLP4pVXdCTeFTd7HtWr5NDHz7pHSdjL+3lGo0xwieEvZZeKRt2URYd4w3mPUzpKqj3QtTOZm+r6TT4CZFnSV8hFMNprW0eCUl4p9clZrWF+vOPKAaiZg44mVaeeF7sVDutwLfYjS/eNJbXY0NAl/TFZ6FEg4foiGEFIbe/f3B78bKhIWuN7dunrNTC1oaxwmBe9EqRqVZ32/Sv63qNcqYAAeRnQlZnXNcOxgiHkv5OcvA4PhR4dZq8jNuJZYWd3aZoH4UT9zQ2lHmXqpM47YE878fOfRj7F6BKSRjgSwFv0an1JTb8KKlDDAEus7Oz/7lb7ga65DX5CKSel+HX8=\r\nx-forefront-antispam-report: CIP:255.255.255.255;CTRY:;LANG:en;SCL:1;SRV:;IPV:NLI;SFV:NSPM;H:BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM;PTR:;CAT:NONE;SFTY:;SFS:(34036004)(136003)(366004)(396003)(346002)(39830400003)(376002)(26005)(186003)(558084003)(9686003)(508600001)(86362001)(966005)(8676002)(2906002)(6916009)(5660300002)(71200400001)(52536014)(7696005)(55236004)(6506007)(66446008)(66476007)(64756008)(66556008)(66946007)(55016002)(33656002)(15650500001)(91956017)(8936002)(316002)(76116006);DIR:OUT;SFP:1101;\r\nx-ms-exchange-antispam-messagedata: reX2X2StahPOTjGnBUVhcORncp/8tp+uz+XY4pednPkQRY4JDnvlxo0NtvvbTPUjBTu03PbCT0bjMSVwEw27x8g5SYn7sbibs1bp2OYyWxmEC/gQAhg6wBguGlLyscRyADZStyfpqPF/VAjEgRKUybOnmEa+qqiq+1DP8T6gn5w4eH5fSWAYcL7EFIKX8m6RnIWuQmDJS0ufH1/1IzlrlkbEXy6LIStcI0p6RPHiRgFhWrw531DaoUne6j7HCUERWI3x4vExDQOfd2U+/KLCAeAIdPkXCZf4m08PFltIJG/svWzelkjUgGkYdfjWyzJnyrcnx3L5DuhndpgpuI/dh7PV7UchvHv1+Hq2rn9wxrIsivhW1qeb7sMjkXwz6YbK91BuSuUSjZz/O5caEUhV1sbB6rKXPo2Br08uuDrGlSgSO/F5eOQRcxnpydoI1eOiFP4iKRs+vqipCBjuxwODNR4nDhhbxY7haHn8mduByV4=\r\nx-ms-exchange-transport-forked: True\r\nContent-Type: text/plain; charset=\"us-ascii\"\r\nContent-Transfer-Encoding: quoted-printable\r\nMIME-Version: 1.0\r\nX-OriginatorOrg: badava.onmicrosoft.com\r\nX-MS-Exchange-CrossTenant-Network-Message-Id: 8f372d9c-e814-449c-7aba-08d7fd5b06f6\r\nX-MS-Exchange-CrossTenant-originalarrivaltime: 21 May 2020 07:46:09.5723\r\n (UTC)\r\nX-MS-Exchange-CrossTenant-fromentityheader: Hosted\r\nX-MS-Exchange-CrossTenant-id: a3da2674-d726-4da3-9d8e-2b65566ef88a\r\nX-MS-Exchange-CrossTenant-mailboxtype: HOSTED\r\nX-MS-Exchange-CrossTenant-userprincipalname: 9EkulCQ+CVphdRLj8I9sa4xrwvnzs9WhHDVzbtmGKeBMdTpXxKWf5gvY8tuxrnf28ldaAjI7sCUBZb6EmYWkrzQIVWwRiRMYAIclZv85E4I=\r\nX-MS-Exchange-Transport-CrossTenantHeadersStamped: BMXPR01MB4101\r\n\r\n",
        "toRecipients": [
            "admin@company.com"
        ]
    },
    {
        "ItemAttachments": [
            {
                "attachmentContentId": "F5E04D92A740F74BB1B8F38276012B2A@INDPRD01.PROD.OUTLOOK.COM",
                "attachmentContentLocation": null,
                "attachmentContentType": "message/rfc822",
                "attachmentId": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkARgAAA8UvpdPLfBBFk4yzLjFjo38HAKGgXpWqlGBOsYqBLmshp1EAAAIBDAAAAKGgXpWqlGBOsYqBLmshp1EAAAIFhAAAAAESABAA+7Kd68yqB0W7bBETl+LMYg==",
                "attachmentIsInline": false,
                "attachmentLastModifiedTime": "2020-05-21T07:27:27+00:00",
                "attachmentName": "Message from Cortex XSOAR Security Operations Server",
                "attachmentSHA256": "608bb796499894fd5bf26f501d7d2bf4512e0db99b255028d29d467fb433f7b4",
                "attachmentSize": 27232,
                "attachmentType": "ItemAttachment",
                "originalItemId": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkARgAAA8UvpdPLfBBFk4yzLjFjo38HAKGgXpWqlGBOsYqBLmshp1EAAAIBDAAAAKGgXpWqlGBOsYqBLmshp1EAAAIFhAAAAA=="
            }
        ],
        "author": "MicrosoftExchange329e71ec88ae4615bbc36ab6ce41109e@badava.onmicrosoft.com",
        "body": "\u003chtml\u003e\u003chead\u003e\r\n\u003cmeta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"\u003e\u003cmeta name=\"viewport\" content=\"width=device-width, initial-scale=1\"\u003e\u003ctitle\u003eDSN\u003c/title\u003e\u003c/head\u003e\u003cbody style=\"        background-color: white;      \"\u003e\u003ctable style=\"        background-color: white;         max-width: 548px;         color: black;         border-spacing: 0px 0px;         padding-top: 0px;         padding-bottom: 0px;        border-collapse: collapse;      \" width=\"548\" cellspacing=\"0\" cellpadding=\"0\"\u003e\u003ctbody\u003e\u003ctr\u003e\u003ctd style=\"        text-align: left;        padding-bottom: 20px;      \"\u003e\u003cimg height=\"28\" width=\"126\" style=\"        max-width: 100%;      \" src=\"http://products.office.com/en-us/CMSImages/Office365Logo_Orange.png?version=b8d100a9-0a8b-8e6a-88e1-ef488fee0470\"\u003e \u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 16px;         padding-bottom: 10px;         -ms-text-size-adjust: 100%;        text-align: left;      \"\u003eYour message to \u003cspan style=\"        color: #0072c6;      \"\u003eadmin@company.com\u003c/span\u003e couldn't be delivered.\u003cbr\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;         font-size: 24px;         padding-top: 0px;         padding-bottom: 20px;         text-align: center;         -ms-text-size-adjust: 100%;      \"\u003e\u003cspan style=\"        color: #0072c6;      \"\u003eadmin\u003c/span\u003e wasn't found at \u003cspan style=\"        color: #0072c6;      \"\u003ecompany.com\u003c/span\u003e.\u003cbr\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        padding-bottom: 15px;         padding-left: 0px;         padding-right: 0px;         border-spacing: 0px 0px;      \"\u003e\u003ctable style=\"        max-width: 548px;         font-weight: 600;        border-spacing: 0px 0px;         padding-top: 0px;         padding-bottom: 0px;        border-collapse: collapse;      \"\u003e\u003ctbody\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 15px;        font-weight: 600;        text-align: left;        width: 181px;        -ms-text-size-adjust: 100%;        vertical-align: bottom;      \"\u003e\u003cfont color=\"#ffffff\"\u003e\u003cspan style=\"color:#000000\"\u003ericha\u003c/span\u003e \u003c/font\u003e\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 15px;        font-weight: 600;        text-align: center;        width: 186px;        -ms-text-size-adjust: 100%;        vertical-align: bottom;      \"\u003e\u003cfont color=\"#ffffff\"\u003e\u003cspan style=\"color:#000000\"\u003eOffice 365\u003c/span\u003e \u003c/font\u003e\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;         -ms-text-size-adjust: 100%;         font-size: 15px;         font-weight: 600;        text-align: right;         width: 181px;         vertical-align: bottom;      \"\u003e\u003cfont color=\"#ffffff\"\u003e\u003cspan style=\"color:#000000\"\u003eadmin\u003c/span\u003e \u003c/font\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;        text-align: left;        padding-top: 0px;        padding-bottom: 0px;        vertical-align: middle;        width: 181px;      \"\u003e\u003cfont color=\"#ffffff\"\u003e\u003cspan style=\"        color: #c00000;      \"\u003e\u003cb\u003eAction Required\u003c/b\u003e \u003c/span\u003e\u003c/font\u003e\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;        text-align: center;        padding-top: 0px;        padding-bottom: 0px;        vertical-align: middle;        width: 186px;      \"\u003e\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;        text-align: right;        padding-top: 0px;        padding-bottom: 0px;        vertical-align: middle;        width: 181px;      \"\u003e\u003cfont color=\"#ffffff\"\u003e\u003cspan style=\"color:#000000\"\u003eRecipient\u003c/span\u003e \u003c/font\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd colspan=\"3\" style=\"        padding-top:0;        padding-bottom:0;        padding-left:0;        padding-right:0      \"\u003e\u003ctable cellspacing=\"0\" cellpadding=\"0\" style=\"        border-spacing: 0px 0px;        padding-top: 0px;        padding-bottom: 0px;        padding-left: 0px;        padding-right: 0px;        border-collapse: collapse;      \"\u003e\u003ctbody\u003e\u003ctr height=\"10\"\u003e\u003ctd width=\"180\" height=\"10\" bgcolor=\"#c00000\" style=\"        width: 180px;        line-height: 10px;        height: 10px;        font-size: 6px;        padding-top: 0;        padding-bottom: 0;        padding-left: 0;        padding-right: 0;      \"\u003e\u003c!--[if gte mso 15]\u003e\u0026nbsp;\u003c![endif]--\u003e\u003c/td\u003e\u003ctd width=\"4\" height=\"10\" bgcolor=\"#ffffff\" style=\"        width: 4px;        line-height: 10px;        height: 10px;        font-size: 6px;        padding-top: 0;        padding-bottom: 0;        padding-left: 0;        padding-right: 0;      \"\u003e\u003c!--[if gte mso 15]\u003e\u0026nbsp;\u003c![endif]--\u003e\u003c/td\u003e\u003ctd width=\"180\" height=\"10\" bgcolor=\"#cccccc\" style=\"        width: 180px;        line-height: 10px;        height: 10px;        font-size: 6px;        padding-top: 0;        padding-bottom: 0;        padding-left: 0;        padding-right: 0;      \"\u003e\u003c!--[if gte mso 15]\u003e\u0026nbsp;\u003c![endif]--\u003e\u003c/td\u003e\u003ctd width=\"4\" height=\"10\" bgcolor=\"#ffffff\" style=\"        width: 4px;        line-height: 10px;        height: 10px;        font-size: 6px;        padding-top: 0;        padding-bottom: 0;        padding-left: 0;        padding-right: 0;      \"\u003e\u003c!--[if gte mso 15]\u003e\u0026nbsp;\u003c![endif]--\u003e\u003c/td\u003e\u003ctd width=\"180\" height=\"10\" bgcolor=\"#cccccc\" style=\"        width: 180px;        line-height: 10px;        height: 10px;        font-size: 6px;        padding-top: 0;        padding-bottom: 0;        padding-left: 0;        padding-right: 0;      \"\u003e\u003c!--[if gte mso 15]\u003e\u0026nbsp;\u003c![endif]--\u003e\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        text-align: left;        width: 181px;        line-height: 20px;        font-weight: 400;        padding-top: 0px;        padding-left: 0px;        padding-right: 0px;        padding-bottom: 0px;      \"\u003e\u003cfont color=\"#ffffff\"\u003e\u003cspan style=\"        color: #c00000;      \"\u003eUnknown To address\u003c/span\u003e \u003c/font\u003e\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        text-align: center;        width: 186px;        line-height: 20px;        font-weight: 400;        padding-top: 0px;        padding-left: 0px;        padding-right: 0px;        padding-bottom: 0px;      \"\u003e\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        text-align: right;        width: 181px;        line-height: 20px;        font-weight: 400;        padding-top: 0px;        padding-left: 0px;        padding-right: 0px;        padding-bottom: 0px;      \"\u003e\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        width: 100%;        padding-top: 0px;        padding-right: 10px;        padding-left: 10px;      \"\u003e\u003cbr\u003e\u003ctable style=\"        width: 100%;        padding-right: 0px;        padding-left: 0px;        padding-top: 0px;        padding-bottom: 0px;        background-color: #f2f5fa;        margin-left: 0px;      \"\u003e\u003ctbody\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 21px;        font-weight: 500;        background-color: #f2f5fa;        padding-top: 0px;        padding-bottom: 0px;        padding-left: 10px;        padding-right: 10px;      \"\u003eHow to Fix It\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 16px;        font-weight: 400;        padding-top: 0px;        padding-bottom: 6px;        padding-left: 10px;        padding-right: 10px;        background-color: #f2f5fa;      \"\u003eThe address may be misspelled or may not exist. Try one or more of the following:\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"         padding-top: 0px;         padding-bottom: 0px;         padding-left: 0px;         padding-right: 0px;        border-spacing: 0px 0px;      \"\u003e\u003cul style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 16px;        font-weight: 400;        margin-left: 40px;        margin-bottom: 5px;        background-color: #f2f5fa;        padding-top: 0px;        padding-bottom: 0px;        padding-left: 6px;        padding-right: 6px;      \"\u003e\u003cli\u003eSend the message again following these steps: In Outlook, open this non-delivery report (NDR) and choose \u003cb\u003eSend Again\u003c/b\u003e from the Report ribbon. In Outlook on the web, select this NDR, then select the link \u0026quot;\u003cb\u003eTo send this message again, click here.\u003c/b\u003e\u0026quot; Then delete and retype the entire recipient address. If prompted with an Auto-Complete List suggestion don't select it. After typing the complete address, click \u003cb\u003eSend\u003c/b\u003e.\u003c/li\u003e\u003cli\u003eContact the recipient (by phone, for example) to check that the address exists and is correct.\u003c/li\u003e\u003cli\u003eThe recipient may have set up email forwarding to an incorrect address. Ask them to check that any forwarding they've set up is working correctly.\u003c/li\u003e\u003cli\u003eClear the recipient Auto-Complete List in Outlook or Outlook on the web by following the steps in this article: \u003ca href=\"https://go.microsoft.com/fwlink/?LinkId=389363\"\u003eFix email delivery issues for error code 5.1.1 in Office 365\u003c/a\u003e, and then send the message again. Retype the entire recipient address before selecting \u003cb\u003eSend\u003c/b\u003e.\u003c/li\u003e\u003c/ul\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 16px;        font-weight: 400;        padding-top: 0px;        padding-bottom: 6px;        padding-left: 10px;        padding-right: 10px;        background-color: #f2f5fa;      \"\u003eIf the problem continues, forward this message to your email admin. If you're an email admin, refer to the \u003cb\u003eMore Info for Email Admins\u003c/b\u003e section below.\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;        padding-top: 10px;        padding-bottom: 0px;        padding-bottom: 4px;      \"\u003e\u003cbr\u003e\u003cem\u003eWas this helpful? \u003ca href=\"https://go.microsoft.com/fwlink/?LinkId=525920\"\u003eSend feedback to Microsoft\u003c/a\u003e.\u003c/em\u003e \u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        -ms-text-size-adjust: 100%;        font-size: 0px;        line-height: 0px;        padding-top: 0px;        padding-bottom: 0px;      \"\u003e\u003chr\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 21px;        font-weight: 500;      \"\u003e\u003cbr\u003eMore Info for Email Admins\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;      \"\u003e\u003cem\u003eStatus code: 550 5.1.1\u003c/em\u003e \u003cbr\u003e\u003cbr\u003eThis error occurs because the sender sent a message to an email address outside of Office 365, but the address is incorrect or doesn't exist at the destination domain. The error is reported by the recipient domain's email server, but most often it must be fixed by the person who sent the message. If the steps in the \u003cb\u003eHow to Fix It\u003c/b\u003e section above don't fix the problem, and you're the email admin for the recipient, try one or more of the following:\u003cbr\u003e\u003cbr\u003e\u003cb\u003eThe email address exists and is correct\u003c/b\u003e - Confirm that the recipient address exists, is correct, and is accepting messages.\u003cbr\u003e\u003cbr\u003e\u003cb\u003eSynchronize your directories\u003c/b\u003e - If you have a hybrid environment and are using directory synchronization make sure the recipient's email address is synced correctly in both Office 365 and in your on-premises directory.\u003cbr\u003e\u003cbr\u003e\u003cb\u003eErrant forwarding rule\u003c/b\u003e - Check for forwarding rules that aren't behaving as expected. Forwarding can be set up by an admin via mail flow rules or mailbox forwarding address settings, or by the recipient via the Inbox Rules feature.\u003cbr\u003e\u003cbr\u003e\u003cb\u003eMail flow settings and MX records are not correct\u003c/b\u003e - Misconfigured mail flow or MX record settings can cause this error. Check your Office 365 mail flow settings to make sure your domain and any mail flow connectors are set up correctly. Also, work with your domain registrar to make sure the MX records for your domain are configured correctly.\u003cbr\u003e\u003cbr\u003eFor more information and additional tips to fix this issue, see \u003ca href=\"https://go.microsoft.com/fwlink/?LinkId=389363\"\u003eFix email delivery issues for error code 550 5.1.1 in Office 365\u003c/a\u003e.\u003cbr\u003e\u003cbr\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 17px;        font-weight: 500;      \"\u003eOriginal Message Details\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-size: 14px;        line-height: 20px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;      \"\u003e\u003ctable style=\"        width: 100%;        border-collapse: collapse;        margin-left: 10px;      \"\u003e\u003ctbody\u003e\u003ctr\u003e\u003ctd valign=\"top\" style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eCreated Date:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003e5/21/2020 7:27:23 AM\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd valign=\"top\" style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eSender Address:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003ericha@badava.onmicrosoft.com\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eRecipient Address:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003eadmin@company.com\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eSubject:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003eMessage from Cortex XSOAR Security Operations Server\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 17px;        font-weight: 500;      \"\u003e\u003cbr\u003eError Details\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-size: 14px;        line-height: 20px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;      \"\u003e\u003ctable style=\"        width: 100%;        border-collapse: collapse;        margin-left: 10px;      \"\u003e\u003ctbody\u003e\u003ctr\u003e\u003ctd valign=\"top\" style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eReported error:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003e\u003cem\u003e550 5.1.1 \u0026lt;admin@company.com\u0026gt;: Email address could not be found, or was misspelled (G8)\u003c/em\u003e \u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eDSN generated by:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003eBMXPR01MB2294.INDPRD01.PROD.OUTLOOK.COM\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eRemote server:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003esmtp29.gate.ord1d.rsapps.net\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003cbr\u003e\u003ctable style=\"width: 880px;\" cellspacing=\"0\"\u003e\u003ctbody\u003e\u003ctr\u003e\u003ctd colspan=\"6\" style=\"        padding-top: 4px;        border-bottom: 1px solid #999999;        padding-bottom: 4px;        line-height: 120%;        font-size: 17px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;      \"\u003eMessage Hops\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        background-color: #f2f5fa;        border-bottom: 1px solid #999999;        white-space: nowrap;        padding: 8px;      \"\u003eHOP\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        background-color: #f2f5fa;        border-bottom: 1px solid #999999;        white-space: nowrap;        padding: 8px;        width: 80px;      \"\u003eTIME (UTC)\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        background-color: #f2f5fa;        border-bottom: 1px solid #999999;        white-space: nowrap;        padding: 8px;      \"\u003eFROM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        background-color: #f2f5fa;        border-bottom: 1px solid #999999;        white-space: nowrap;        padding: 8px;      \"\u003eTO\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        background-color: #f2f5fa;        border-bottom: 1px solid #999999;        white-space: nowrap;        padding: 8px;      \"\u003eWITH\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        background-color: #f2f5fa;        border-bottom: 1px solid #999999;        white-space: nowrap;        padding: 8px;      \"\u003eRELAY TIME\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: center;      \"\u003e1\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;        width: 80px;      \"\u003e5/21/2020\u003cbr\u003e7:27:23 AM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003eBMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003eBMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003emapi\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003e*\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: center;      \"\u003e2\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;        width: 80px;      \"\u003e5/21/2020\u003cbr\u003e7:27:23 AM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003eBMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003eBMXPR01MB2294.INDPRD01.PROD.OUTLOOK.COM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003eMicrosoft SMTP Server (version=TLS1_2, cipher=TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384)\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003e*\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003cp style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 17px;        font-weight: 500;        padding-top: 4px;        padding-bottom: 0;        margin-top: 19px;        margin-bottom: 5px;      \"\u003eOriginal Message Headers\u003c/p\u003e\u003cpre style=\"        color: gray;        white-space: pre;        padding-top: 0;        margin-top: 5px;      \"\u003eARC-Seal: i=1; a=rsa-sha256; s=arcselector9901; d=microsoft.com; cv=none;\r\n b=mm01JMheOi8KX97nZKrC7LSWoBCCoRtiVcHaoM\u0026#43;e\u0026#43;IMmOEvFrrR9kQ3KqVkIlKYv/5z/7p7jBQ440vWJTrqEpqyCVEh9EGpEW5PFD3p\u0026#43;5oUVEKh2aYZgvAYs1QTj6dO5wmF5A/vgRQVRJeug6tRMWSgzp8eDaDcwxQsGGsvUMBHeJVn/p3geM7ls7BKoxgeNJvfZ7VRL7O51p06nPoBoxcBTON8cQQMRdBG6bTqObIfgCAZMA1UzmzXoDRznZ578RPtYAdmtqi7cf3GyxAFDCWWNGtVDQ5uKnxllbOMTmC\u0026#43;SN7CqMkw3COedqEbVSiMC0mfVuLLMZ5FdUa9Xl7Q1sA==\r\nARC-Message-Signature: i=1; a=rsa-sha256; c=relaxed/relaxed; d=microsoft.com;\r\n s=arcselector9901;\r\n h=From:Date:Subject:Message-ID:Content-Type:MIME-Version:X-MS-Exchange-SenderADCheck;\r\n bh=qIWvkA3bhacvdckysZVE3GPD/jiqEZ\u0026#43;nmgqdAOmGW/k=;\r\n b=h\u0026#43;Em2Qm9dm0ji53SoAtEIBFAVUv0TXvexqozjBKUVItIPmw0J/Kh2n8Il53O/wsAbeRcRDete0tFq0swp84XEYj2q8dGXeluJ6UAI3rdEQrIVv09uv1P7edtQ/GcFF/p2bltpOHywM4zrwgf1/nIL3aTzpr19MQYzUyYfnj/LBoHu0BMyAIOmltSurPNgjyVF2oQmlLPiXXSfyhXRJvm2KrVFc9H33Lwz8JK6ha9EZrpgWOamOhu2xuyFBConFglroLvr/sUCi8mRBPxHE4s2/E5cfkTAdtxtNwEYVnooOQSIHLCeQbxifU7jdHTRLVB6XJ0dfx904HJwq5c9VcfIQ==\r\nARC-Authentication-Results: i=1; mx.microsoft.com 1; spf=pass\r\n smtp.mailfrom=badava.onmicrosoft.com; dmarc=pass action=none\r\n header.from=badava.onmicrosoft.com; dkim=pass\r\n header.d=badava.onmicrosoft.com; arc=none\r\nDKIM-Signature: v=1; a=rsa-sha256; c=relaxed/relaxed;\r\n d=badava.onmicrosoft.com; s=selector1-badava-onmicrosoft-com;\r\n h=From:Date:Subject:Message-ID:Content-Type:MIME-Version:X-MS-Exchange-SenderADCheck;\r\n bh=qIWvkA3bhacvdckysZVE3GPD/jiqEZ\u0026#43;nmgqdAOmGW/k=;\r\n b=SERUGWIKaKKBUp6zaUh4JT86PcxD6ZHNklLeC8q3wJIdquQy0zFahELQLfA0aDJf8tUqMDJY1qW7g/YGAdqpDPungdTj3qbREwf\u0026#43;5ULcgYLu995FMFWYKL1MYm9B9ShaA/Qq0MtxjzhlUOlAxak9qhi/Li4kBYW8uLnmO9BjzLg=\r\nReceived: from BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM (2603:1096:b00:59::12)\r\n by BMXPR01MB2294.INDPRD01.PROD.OUTLOOK.COM (2603:1096:b00:39::13) with\r\n Microsoft SMTP Server (version=TLS1_2,\r\n cipher=TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384) id 15.20.3000.27; Thu, 21 May\r\n 2020 07:27:23 \u0026#43;0000\r\nReceived: from BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\r\n ([fe80::1d03:43d1:9bf:ce0d]) by BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\r\n ([fe80::1d03:43d1:9bf:ce0d%7]) with mapi id 15.20.3000.034; Thu, 21 May 2020\r\n 07:27:23 \u0026#43;0000\r\nFrom: richa priyanka \u0026lt;richa@badava.onmicrosoft.com\u0026gt;\r\nTo: \u0026quot;admin@company.com\u0026quot; \u0026lt;admin@company.com\u0026gt;\r\nSubject: Message from Cortex XSOAR Security Operations Server\r\nThread-Topic: Message from Cortex XSOAR Security Operations Server\r\nThread-Index: AQHWL0FFDwMfzdk/4kGnOqHwe6CQKg==\r\nDate: Thu, 21 May 2020 07:27:23 \u0026#43;0000\r\nMessage-ID: \u0026lt;BMXPR01MB37679C23EA9212F31C0C51FD8EB70@BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u0026gt;\r\nAccept-Language: en-US\r\nContent-Language: en-US\r\nX-MS-Has-Attach:\r\nX-MS-TNEF-Correlator:\r\nauthentication-results: company.com; dkim=none (message not signed)\r\n header.d=none;company.com; dmarc=none action=none\r\n header.from=badava.onmicrosoft.com;\r\nx-originating-ip: [54.176.61.115]\r\nx-ms-publictraffictype: Email\r\nx-ms-office365-filtering-correlation-id: b59d174c-10cf-45e4-fc57-08d7fd586791\r\nx-ms-traffictypediagnostic: BMXPR01MB2294:\r\nx-microsoft-antispam-prvs: \u0026lt;BMXPR01MB22944B7225140130590A9DFC8EB70@BMXPR01MB2294.INDPRD01.PROD.OUTLOOK.COM\u0026gt;\r\nx-ms-oob-tlc-oobclassifiers: OLM:4303;\r\nx-forefront-prvs: 041032FF37\r\nx-ms-exchange-senderadcheck: 1\r\nx-microsoft-antispam: BCL:0;\r\nx-microsoft-antispam-message-info: 42hxfQVw09yJJH1RWTKsas5Mg0hDJTdlLSWWOIwV4KNpcbU6dhKaENpgSZB97UsG7FJoU6LtQlSHVUMmlh4EKQiMBfAdDos1OcpkfNL/ZsV3hMQIE3AVp7TsA3apXd2MQQwNBoFZLTnASq7wR5J8da\u0026#43;paVEBo4TbfQQEc2h3ATW0\u0026#43;WKXyCziJH1jdQFTwV8GnUEcWRgfRstMafIJdBrytVRj4BISGE1GE/cGuxYD1a4LUiZfDFMBjm\u0026#43;EfxyCEKpckX6L8G/t6pbcqjuIT4cX1xmQ1WGwCuo718HsJaYAZEzKucuyg7b\u0026#43;aM3lRorKzKssGZh7yUkbEse1t4qiBTWABgikMhCQNNeztJ0G36XcMirnIFYgvLxnrmC4Ubg5tH261IYq5N67rq2srysmrp4/VsGiPnxL8CEDdxBYH3WuhS7Yybw7dhym3ptsz0KMaNYrpqsB\u0026#43;QLi/xn628/k55TLABHPCR8Fetj0RCzXTIXRIWA=\r\nx-forefront-antispam-report: CIP:255.255.255.255;CTRY:;LANG:en;SCL:1;SRV:;IPV:NLI;SFV:NSPM;H:BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM;PTR:;CAT:NONE;SFTY:;SFS:(346002)(366004)(34036004)(136003)(39830400003)(376002)(396003)(55236004)(558084003)(33656002)(966005)(8676002)(2906002)(316002)(55016002)(6916009)(86362001)(66476007)(8936002)(52536014)(186003)(91956017)(76116006)(5660300002)(15650500001)(7696005)(71200400001)(508600001)(64756008)(66946007)(66556008)(66446008)(26005)(6506007)(9686003);DIR:OUT;SFP:1101;\r\nx-ms-exchange-antispam-messagedata: NzllT6WzmxCvLzE87e5JhWnXLgTf/laR5mKoityqSSMGM9ccASdtJa2BWSv0upoEEZJJYUmQyd6JjjEesGA7pieEybIcKA/9R4X0QjveSwVMenROIHItXZW1\u0026#43;TxMwG\u0026#43;Vum8zAo7PSI40sfudmnZJChDHYcv84AP40aCrg/C9BSN1T\u0026#43;XXiBFH\u0026#43;oeADOX/4vJoht1qX5jdbj0K5LShNYDaHI7Jc42Pd7QS3dVvBv\u0026#43;oWRFBX5g8kGE6A9myzhxTu46lwXLHSTI7zCWsX4ibFCguN2e6PlglE857cxAtwVLPeBcZGHmAgTgB6vsmd4H/eoRAE8llbXSlBzxHA5O0CvNOOY1kfxX3bdSz2Zhcl5ZZLi01Alilr8Mj/lQ/B59DXmdaL3E87xhkDtYbSaRgrd48kJ8dJyPKK7foB3RVPL7ErmBr0B/tqVnr9Xq0Ri5prKMr0xnqCycwksRMASkyTbf5fDOCaD478IvMtzx6mWQfHgs=\r\nx-ms-exchange-transport-forked: True\r\nContent-Type: text/plain; charset=\u0026quot;us-ascii\u0026quot;\r\nContent-Transfer-Encoding: quoted-printable\r\nMIME-Version: 1.0\r\nX-OriginatorOrg: badava.onmicrosoft.com\r\nX-MS-Exchange-CrossTenant-Network-Message-Id: b59d174c-10cf-45e4-fc57-08d7fd586791\r\nX-MS-Exchange-CrossTenant-originalarrivaltime: 21 May 2020 07:27:23.1665\r\n (UTC)\r\nX-MS-Exchange-CrossTenant-fromentityheader: Hosted\r\nX-MS-Exchange-CrossTenant-id: a3da2674-d726-4da3-9d8e-2b65566ef88a\r\nX-MS-Exchange-CrossTenant-mailboxtype: HOSTED\r\nX-MS-Exchange-CrossTenant-userprincipalname: j3Shi4SvePAUNr9jgIztLf1Ns7mvs21Y4EIV3aIyY/OUgTlzr6p3jg/rcm\u0026#43;UaG4ijVc\u0026#43;7kj8esv8sDDv3I59UzXIQBDS0q0Dsrw3pE8y\u0026#43;Xo=\r\nX-MS-Exchange-Transport-CrossTenantHeadersStamped: BMXPR01MB2294\r\n\u003c/pre\u003e\u003c/body\u003e\u003c/html\u003e",
        "datetimeCreated": "2020-05-21T07:27:27Z",
        "datetimeReceived": "2020-05-21T07:27:27Z",
        "datetimeSent": "2020-05-21T07:27:27Z",
        "hasAttachments": true,
        "headers": [
            {
                "name": "Received",
                "value": "from BMXPR01MB2294.INDPRD01.PROD.OUTLOOK.COM (2603:1096:b00::18) by BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM with HTTPS via BM1PR01CA0102.INDPRD01.PROD.OUTLOOK.COM; Thu, 21 May 2020 07:27:27 +0000"
            },
            {
                "name": "MIME-Version",
                "value": "1.0"
            },
            {
                "name": "Date",
                "value": "Thu, 21 May 2020 07:27:27 +0000"
            },
            {
                "name": "Content-Type",
                "value": "multipart/report"
            },
            {
                "name": "X-MS-Exchange-Organization-SCL",
                "value": "-1"
            },
            {
                "name": "Content-Language",
                "value": "en-US"
            },
            {
                "name": "Message-ID",
                "value": "\u003c9cf326fc-241b-4d15-9782-4de81ccfa686@BMXPR01MB2294.INDPRD01.PROD.OUTLOOK.COM\u003e"
            },
            {
                "name": "In-Reply-To",
                "value": "\u003cBMXPR01MB37679C23EA9212F31C0C51FD8EB70@BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003e"
            },
            {
                "name": "References",
                "value": "\u003cBMXPR01MB37679C23EA9212F31C0C51FD8EB70@BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003e"
            },
            {
                "name": "Thread-Topic",
                "value": "Message from Cortex XSOAR Security Operations Server"
            },
            {
                "name": "Thread-Index",
                "value": "AQHWL0FFDwMfzdk/4kGnOqHwe6CQKqiyJAwu"
            },
            {
                "name": "Subject",
                "value": "Undeliverable: Message from Cortex XSOAR Security Operations Server"
            },
            {
                "name": "Auto-Submitted",
                "value": "auto-replied"
            },
            {
                "name": "X-MS-PublicTrafficType",
                "value": "Email"
            },
            {
                "name": "X-MS-Exchange-Organization-AuthSource",
                "value": "BMXPR01MB2294.INDPRD01.PROD.OUTLOOK.COM"
            },
            {
                "name": "X-MS-Exchange-Organization-AuthAs",
                "value": "Internal"
            },
            {
                "name": "X-MS-Exchange-Organization-AuthMechanism",
                "value": "05"
            },
            {
                "name": "X-MS-Exchange-Organization-Network-Message-Id",
                "value": "75d2cb6e-d66f-4ff5-ac59-08d7fd5869d2"
            },
            {
                "name": "X-MS-TrafficTypeDiagnostic",
                "value": "BMXPR01MB2294:"
            },
            {
                "name": "X-MS-Exchange-Organization-ExpirationStartTime",
                "value": "21 May 2020 07:27:27.0528 (UTC)"
            },
            {
                "name": "X-MS-Exchange-Organization-ExpirationStartTimeReason",
                "value": "SideEffectMessage"
            },
            {
                "name": "X-MS-Exchange-Organization-ExpirationInterval",
                "value": "1:00:00:00.0000000"
            },
            {
                "name": "X-MS-Exchange-Organization-ExpirationIntervalReason",
                "value": "SideEffectMessage"
            },
            {
                "name": "X-MS-Oob-TLC-OOBClassifiers",
                "value": "OLM:923;"
            },
            {
                "name": "X-Microsoft-Antispam",
                "value": "BCL:0;"
            },
            {
                "name": "X-Forefront-Antispam-Report",
                "value": "CIP:255.255.255.255;CTRY:;LANG:en;SCL:-1;SRV:;IPV:NLI;SFV:SKI;H:;PTR:;CAT:NONE;SFTY:;SFS:;DIR:INB;SFP:;"
            },
            {
                "name": "X-MS-Exchange-CrossTenant-OriginalArrivalTime",
                "value": "21 May 2020 07:27:27.0558 (UTC)"
            },
            {
                "name": "X-MS-Exchange-CrossTenant-FromEntityHeader",
                "value": "Hosted"
            },
            {
                "name": "X-MS-Exchange-CrossTenant-Network-Message-Id",
                "value": "75d2cb6e-d66f-4ff5-ac59-08d7fd5869d2"
            },
            {
                "name": "X-MS-Exchange-Transport-CrossTenantHeadersStamped",
                "value": "BMXPR01MB2294"
            },
            {
                "name": "X-MS-Exchange-Organization-MessageDirectionality",
                "value": "Originating"
            },
            {
                "name": "X-MS-Exchange-Transport-EndToEndLatency",
                "value": "00:00:00.1834013"
            },
            {
                "name": "X-MS-Exchange-Processed-By-BccFoldering",
                "value": "15.20.3000.034"
            },
            {
                "name": "X-Microsoft-Antispam-Mailbox-Delivery",
                "value": "ucf:0;jmr:0;auth:0;dest:I;ENG:(750128)(520011016)(706158)(944506383)(944626604);"
            },
            {
                "name": "X-Microsoft-Antispam-Message-Info",
                "value": "urZBoViO0JmkIubccZbpQiUGDUda/7rsUrMY1tt5ed4xaUdF/hHeGa/Ail24CC+7qiDxsUwaL0JBlYiQrNK38idZnJEB7FmK02TazYI+N3sHIp33B1HFQYQX7DZSxBxSLLzKV7fvEzWOAEDCLbt1TnfEoyCS1p7l8RhdidPQlA1CTYlHzdZcRRJOMG379QXSKP9bwegYMutVKaBjSpLKWWKbibdEtZgNtRNUJuX4kAK6xtHWF7LAnoW19fC5818xIYbWyG08J9sfsvfI0vbRfQ0Pxc44cXMGgRuK1B9AKvYo5b7wof0BGgf9Cg42CoApXWn5t9+DPKvt1vu0i9XLQh0YU4tJK7wpp3SOA9z4v4Xl5kvfGIXdfyDnuVnw5xzRU1E2Knv1f/YKEp6XI80EUGzS9Qk6jpVf6dswWxcT26NHIlOJZhpUV829sPBAHnEB1M0g/BRLx6Ku0d3Ec0lQaRxj10mz34Isl0pNU8wHbo6/36+E65w82fbHFbbhdPgUy5K5OAINbTyc4WF7hbB1VHvQk/D82BP9T5EfteA7sOZUztfa4E5i8W9UGqsoWU4a6E9JZJwE6uU2ZeBgw2HJx3YMESv23ojyRVuCcXxlSjG967q69rhpjB0CarUWcb6UC+1srM8hqhPlVMIvPR7Dzg=="
            }
        ],
        "importance": "Normal",
        "isRead": false,
        "itemId": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkARgAAA8UvpdPLfBBFk4yzLjFjo38HAKGgXpWqlGBOsYqBLmshp1EAAAIBDAAAAKGgXpWqlGBOsYqBLmshp1EAAAIFhAAAAA==",
        "lastModifiedTime": "2020-05-21T07:27:28Z",
        "mailbox": "richa@badava.onmicrosoft.com",
        "messageId": "\u003c9cf326fc-241b-4d15-9782-4de81ccfa686@BMXPR01MB2294.INDPRD01.PROD.OUTLOOK.COM\u003e",
        "receivedBy": "richa@badava.onmicrosoft.com",
        "sender": "MicrosoftExchange329e71ec88ae4615bbc36ab6ce41109e@badava.onmicrosoft.com",
        "size": 190296,
        "subject": "Undeliverable: Message from Cortex XSOAR Security Operations Server",
        "textBody": "[http://products.office.com/en-us/CMSImages/Office365Logo_Orange.png?version=b8d100a9-0a8b-8e6a-88e1-ef488fee0470]\r\nYour message to admin@company.com couldn't be delivered.\r\nadmin wasn't found at company.com.\r\nricha   Office 365      admin\r\nAction Required                 Recipient\r\nUnknown To address\r\n\r\nHow to Fix It\r\nThe address may be misspelled or may not exist. Try one or more of the following:\r\n\r\n  *   Send the message again following these steps: In Outlook, open this non-delivery report (NDR) and choose Send Again from the Report ribbon. In Outlook on the web, select this NDR, then select the link \"To send this message again, click here.\" Then delete and retype the entire recipient address. If prompted with an Auto-Complete List suggestion don't select it. After typing the complete address, click Send.\r\n  *   Contact the recipient (by phone, for example) to check that the address exists and is correct.\r\n  *   The recipient may have set up email forwarding to an incorrect address. Ask them to check that any forwarding they've set up is working correctly.\r\n  *   Clear the recipient Auto-Complete List in Outlook or Outlook on the web by following the steps in this article: Fix email delivery issues for error code 5.1.1 in Office 365\u003chttps://go.microsoft.com/fwlink/?LinkId=389363\u003e, and then send the message again. Retype the entire recipient address before selecting Send.\r\n\r\nIf the problem continues, forward this message to your email admin. If you're an email admin, refer to the More Info for Email Admins section below.\r\n\r\nWas this helpful? Send feedback to Microsoft\u003chttps://go.microsoft.com/fwlink/?LinkId=525920\u003e.\r\n________________________________\r\n\r\nMore Info for Email Admins\r\nStatus code: 550 5.1.1\r\n\r\nThis error occurs because the sender sent a message to an email address outside of Office 365, but the address is incorrect or doesn't exist at the destination domain. The error is reported by the recipient domain's email server, but most often it must be fixed by the person who sent the message. If the steps in the How to Fix It section above don't fix the problem, and you're the email admin for the recipient, try one or more of the following:\r\n\r\nThe email address exists and is correct - Confirm that the recipient address exists, is correct, and is accepting messages.\r\n\r\nSynchronize your directories - If you have a hybrid environment and are using directory synchronization make sure the recipient's email address is synced correctly in both Office 365 and in your on-premises directory.\r\n\r\nErrant forwarding rule - Check for forwarding rules that aren't behaving as expected. Forwarding can be set up by an admin via mail flow rules or mailbox forwarding address settings, or by the recipient via the Inbox Rules feature.\r\n\r\nMail flow settings and MX records are not correct - Misconfigured mail flow or MX record settings can cause this error. Check your Office 365 mail flow settings to make sure your domain and any mail flow connectors are set up correctly. Also, work with your domain registrar to make sure the MX records for your domain are configured correctly.\r\n\r\nFor more information and additional tips to fix this issue, see Fix email delivery issues for error code 550 5.1.1 in Office 365\u003chttps://go.microsoft.com/fwlink/?LinkId=389363\u003e.\r\n\r\nOriginal Message Details\r\nCreated Date:   5/21/2020 7:27:23 AM\r\nSender Address: richa@badava.onmicrosoft.com\r\nRecipient Address:      admin@company.com\r\nSubject:        Message from Cortex XSOAR Security Operations Server\r\n\r\nError Details\r\nReported error: 550 5.1.1 \u003cadmin@company.com\u003e: Email address could not be found, or was misspelled (G8)\r\nDSN generated by:       BMXPR01MB2294.INDPRD01.PROD.OUTLOOK.COM\r\nRemote server:  smtp29.gate.ord1d.rsapps.net\r\n\r\nMessage Hops\r\nHOP     TIME (UTC)      FROM    TO      WITH    RELAY TIME\r\n1       5/21/2020\r\n7:27:23 AM      BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM mapi    *\r\n2       5/21/2020\r\n7:27:23 AM      BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM BMXPR01MB2294.INDPRD01.PROD.OUTLOOK.COM Microsoft SMTP Server (version=TLS1_2, cipher=TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384)    *\r\n\r\nOriginal Message Headers\r\n\r\nARC-Seal: i=1; a=rsa-sha256; s=arcselector9901; d=microsoft.com; cv=none;\r\n b=mm01JMheOi8KX97nZKrC7LSWoBCCoRtiVcHaoM+e+IMmOEvFrrR9kQ3KqVkIlKYv/5z/7p7jBQ440vWJTrqEpqyCVEh9EGpEW5PFD3p+5oUVEKh2aYZgvAYs1QTj6dO5wmF5A/vgRQVRJeug6tRMWSgzp8eDaDcwxQsGGsvUMBHeJVn/p3geM7ls7BKoxgeNJvfZ7VRL7O51p06nPoBoxcBTON8cQQMRdBG6bTqObIfgCAZMA1UzmzXoDRznZ578RPtYAdmtqi7cf3GyxAFDCWWNGtVDQ5uKnxllbOMTmC+SN7CqMkw3COedqEbVSiMC0mfVuLLMZ5FdUa9Xl7Q1sA==\r\nARC-Message-Signature: i=1; a=rsa-sha256; c=relaxed/relaxed; d=microsoft.com;\r\n s=arcselector9901;\r\n h=From:Date:Subject:Message-ID:Content-Type:MIME-Version:X-MS-Exchange-SenderADCheck;\r\n bh=qIWvkA3bhacvdckysZVE3GPD/jiqEZ+nmgqdAOmGW/k=;\r\n b=h+Em2Qm9dm0ji53SoAtEIBFAVUv0TXvexqozjBKUVItIPmw0J/Kh2n8Il53O/wsAbeRcRDete0tFq0swp84XEYj2q8dGXeluJ6UAI3rdEQrIVv09uv1P7edtQ/GcFF/p2bltpOHywM4zrwgf1/nIL3aTzpr19MQYzUyYfnj/LBoHu0BMyAIOmltSurPNgjyVF2oQmlLPiXXSfyhXRJvm2KrVFc9H33Lwz8JK6ha9EZrpgWOamOhu2xuyFBConFglroLvr/sUCi8mRBPxHE4s2/E5cfkTAdtxtNwEYVnooOQSIHLCeQbxifU7jdHTRLVB6XJ0dfx904HJwq5c9VcfIQ==\r\nARC-Authentication-Results: i=1; mx.microsoft.com 1; spf=pass\r\n smtp.mailfrom=badava.onmicrosoft.com; dmarc=pass action=none\r\n header.from=badava.onmicrosoft.com; dkim=pass\r\n header.d=badava.onmicrosoft.com; arc=none\r\nDKIM-Signature: v=1; a=rsa-sha256; c=relaxed/relaxed;\r\n d=badava.onmicrosoft.com; s=selector1-badava-onmicrosoft-com;\r\n h=From:Date:Subject:Message-ID:Content-Type:MIME-Version:X-MS-Exchange-SenderADCheck;\r\n bh=qIWvkA3bhacvdckysZVE3GPD/jiqEZ+nmgqdAOmGW/k=;\r\n b=SERUGWIKaKKBUp6zaUh4JT86PcxD6ZHNklLeC8q3wJIdquQy0zFahELQLfA0aDJf8tUqMDJY1qW7g/YGAdqpDPungdTj3qbREwf+5ULcgYLu995FMFWYKL1MYm9B9ShaA/Qq0MtxjzhlUOlAxak9qhi/Li4kBYW8uLnmO9BjzLg=\r\nReceived: from BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM (2603:1096:b00:59::12)\r\n by BMXPR01MB2294.INDPRD01.PROD.OUTLOOK.COM (2603:1096:b00:39::13) with\r\n Microsoft SMTP Server (version=TLS1_2,\r\n cipher=TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384) id 15.20.3000.27; Thu, 21 May\r\n 2020 07:27:23 +0000\r\nReceived: from BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\r\n ([fe80::1d03:43d1:9bf:ce0d]) by BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\r\n ([fe80::1d03:43d1:9bf:ce0d%7]) with mapi id 15.20.3000.034; Thu, 21 May 2020\r\n 07:27:23 +0000\r\nFrom: richa priyanka \u003cricha@badava.onmicrosoft.com\u003e\r\nTo: \"admin@company.com\" \u003cadmin@company.com\u003e\r\nSubject: Message from Cortex XSOAR Security Operations Server\r\nThread-Topic: Message from Cortex XSOAR Security Operations Server\r\nThread-Index: AQHWL0FFDwMfzdk/4kGnOqHwe6CQKg==\r\nDate: Thu, 21 May 2020 07:27:23 +0000\r\nMessage-ID: \u003cBMXPR01MB37679C23EA9212F31C0C51FD8EB70@BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003e\r\nAccept-Language: en-US\r\nContent-Language: en-US\r\nX-MS-Has-Attach:\r\nX-MS-TNEF-Correlator:\r\nauthentication-results: company.com; dkim=none (message not signed)\r\n header.d=none;company.com; dmarc=none action=none\r\n header.from=badava.onmicrosoft.com;\r\nx-originating-ip: [54.176.61.115]\r\nx-ms-publictraffictype: Email\r\nx-ms-office365-filtering-correlation-id: b59d174c-10cf-45e4-fc57-08d7fd586791\r\nx-ms-traffictypediagnostic: BMXPR01MB2294:\r\nx-microsoft-antispam-prvs: \u003cBMXPR01MB22944B7225140130590A9DFC8EB70@BMXPR01MB2294.INDPRD01.PROD.OUTLOOK.COM\u003e\r\nx-ms-oob-tlc-oobclassifiers: OLM:4303;\r\nx-forefront-prvs: 041032FF37\r\nx-ms-exchange-senderadcheck: 1\r\nx-microsoft-antispam: BCL:0;\r\nx-microsoft-antispam-message-info: 42hxfQVw09yJJH1RWTKsas5Mg0hDJTdlLSWWOIwV4KNpcbU6dhKaENpgSZB97UsG7FJoU6LtQlSHVUMmlh4EKQiMBfAdDos1OcpkfNL/ZsV3hMQIE3AVp7TsA3apXd2MQQwNBoFZLTnASq7wR5J8da+paVEBo4TbfQQEc2h3ATW0+WKXyCziJH1jdQFTwV8GnUEcWRgfRstMafIJdBrytVRj4BISGE1GE/cGuxYD1a4LUiZfDFMBjm+EfxyCEKpckX6L8G/t6pbcqjuIT4cX1xmQ1WGwCuo718HsJaYAZEzKucuyg7b+aM3lRorKzKssGZh7yUkbEse1t4qiBTWABgikMhCQNNeztJ0G36XcMirnIFYgvLxnrmC4Ubg5tH261IYq5N67rq2srysmrp4/VsGiPnxL8CEDdxBYH3WuhS7Yybw7dhym3ptsz0KMaNYrpqsB+QLi/xn628/k55TLABHPCR8Fetj0RCzXTIXRIWA=\r\nx-forefront-antispam-report: CIP:255.255.255.255;CTRY:;LANG:en;SCL:1;SRV:;IPV:NLI;SFV:NSPM;H:BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM;PTR:;CAT:NONE;SFTY:;SFS:(346002)(366004)(34036004)(136003)(39830400003)(376002)(396003)(55236004)(558084003)(33656002)(966005)(8676002)(2906002)(316002)(55016002)(6916009)(86362001)(66476007)(8936002)(52536014)(186003)(91956017)(76116006)(5660300002)(15650500001)(7696005)(71200400001)(508600001)(64756008)(66946007)(66556008)(66446008)(26005)(6506007)(9686003);DIR:OUT;SFP:1101;\r\nx-ms-exchange-antispam-messagedata: NzllT6WzmxCvLzE87e5JhWnXLgTf/laR5mKoityqSSMGM9ccASdtJa2BWSv0upoEEZJJYUmQyd6JjjEesGA7pieEybIcKA/9R4X0QjveSwVMenROIHItXZW1+TxMwG+Vum8zAo7PSI40sfudmnZJChDHYcv84AP40aCrg/C9BSN1T+XXiBFH+oeADOX/4vJoht1qX5jdbj0K5LShNYDaHI7Jc42Pd7QS3dVvBv+oWRFBX5g8kGE6A9myzhxTu46lwXLHSTI7zCWsX4ibFCguN2e6PlglE857cxAtwVLPeBcZGHmAgTgB6vsmd4H/eoRAE8llbXSlBzxHA5O0CvNOOY1kfxX3bdSz2Zhcl5ZZLi01Alilr8Mj/lQ/B59DXmdaL3E87xhkDtYbSaRgrd48kJ8dJyPKK7foB3RVPL7ErmBr0B/tqVnr9Xq0Ri5prKMr0xnqCycwksRMASkyTbf5fDOCaD478IvMtzx6mWQfHgs=\r\nx-ms-exchange-transport-forked: True\r\nContent-Type: text/plain; charset=\"us-ascii\"\r\nContent-Transfer-Encoding: quoted-printable\r\nMIME-Version: 1.0\r\nX-OriginatorOrg: badava.onmicrosoft.com\r\nX-MS-Exchange-CrossTenant-Network-Message-Id: b59d174c-10cf-45e4-fc57-08d7fd586791\r\nX-MS-Exchange-CrossTenant-originalarrivaltime: 21 May 2020 07:27:23.1665\r\n (UTC)\r\nX-MS-Exchange-CrossTenant-fromentityheader: Hosted\r\nX-MS-Exchange-CrossTenant-id: a3da2674-d726-4da3-9d8e-2b65566ef88a\r\nX-MS-Exchange-CrossTenant-mailboxtype: HOSTED\r\nX-MS-Exchange-CrossTenant-userprincipalname: j3Shi4SvePAUNr9jgIztLf1Ns7mvs21Y4EIV3aIyY/OUgTlzr6p3jg/rcm+UaG4ijVc+7kj8esv8sDDv3I59UzXIQBDS0q0Dsrw3pE8y+Xo=\r\nX-MS-Exchange-Transport-CrossTenantHeadersStamped: BMXPR01MB2294\r\n\r\n",
        "toRecipients": [
            "admin@company.com"
        ]
    },
    {
        "ItemAttachments": [
            {
                "attachmentContentId": "33EA66608D8EC54BAA5D4E4CCF5DB0EE@INDPRD01.PROD.OUTLOOK.COM",
                "attachmentContentLocation": null,
                "attachmentContentType": "message/rfc822",
                "attachmentId": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkARgAAA8UvpdPLfBBFk4yzLjFjo38HAKGgXpWqlGBOsYqBLmshp1EAAAIBDAAAAKGgXpWqlGBOsYqBLmshp1EAAAIFgwAAAAESABAAZ8WLqZYwA0WXoJfP16oRSg==",
                "attachmentIsInline": false,
                "attachmentLastModifiedTime": "2020-05-21T07:24:37+00:00",
                "attachmentName": "Message from Cortex XSOAR Security Operations Server",
                "attachmentSHA256": "71a075e86b9b134bc265b50d29117f22d42d4bce6ef77c7c18c3e04eaa243efe",
                "attachmentSize": 27232,
                "attachmentType": "ItemAttachment",
                "originalItemId": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkARgAAA8UvpdPLfBBFk4yzLjFjo38HAKGgXpWqlGBOsYqBLmshp1EAAAIBDAAAAKGgXpWqlGBOsYqBLmshp1EAAAIFgwAAAA=="
            }
        ],
        "author": "MicrosoftExchange329e71ec88ae4615bbc36ab6ce41109e@badava.onmicrosoft.com",
        "body": "\u003chtml\u003e\u003chead\u003e\r\n\u003cmeta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"\u003e\u003cmeta name=\"viewport\" content=\"width=device-width, initial-scale=1\"\u003e\u003ctitle\u003eDSN\u003c/title\u003e\u003c/head\u003e\u003cbody style=\"        background-color: white;      \"\u003e\u003ctable style=\"        background-color: white;         max-width: 548px;         color: black;         border-spacing: 0px 0px;         padding-top: 0px;         padding-bottom: 0px;        border-collapse: collapse;      \" width=\"548\" cellspacing=\"0\" cellpadding=\"0\"\u003e\u003ctbody\u003e\u003ctr\u003e\u003ctd style=\"        text-align: left;        padding-bottom: 20px;      \"\u003e\u003cimg height=\"28\" width=\"126\" style=\"        max-width: 100%;      \" src=\"http://products.office.com/en-us/CMSImages/Office365Logo_Orange.png?version=b8d100a9-0a8b-8e6a-88e1-ef488fee0470\"\u003e \u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 16px;         padding-bottom: 10px;         -ms-text-size-adjust: 100%;        text-align: left;      \"\u003eYour message to \u003cspan style=\"        color: #0072c6;      \"\u003eadmin@company.com\u003c/span\u003e couldn't be delivered.\u003cbr\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;         font-size: 24px;         padding-top: 0px;         padding-bottom: 20px;         text-align: center;         -ms-text-size-adjust: 100%;      \"\u003e\u003cspan style=\"        color: #0072c6;      \"\u003eadmin\u003c/span\u003e wasn't found at \u003cspan style=\"        color: #0072c6;      \"\u003ecompany.com\u003c/span\u003e.\u003cbr\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        padding-bottom: 15px;         padding-left: 0px;         padding-right: 0px;         border-spacing: 0px 0px;      \"\u003e\u003ctable style=\"        max-width: 548px;         font-weight: 600;        border-spacing: 0px 0px;         padding-top: 0px;         padding-bottom: 0px;        border-collapse: collapse;      \"\u003e\u003ctbody\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 15px;        font-weight: 600;        text-align: left;        width: 181px;        -ms-text-size-adjust: 100%;        vertical-align: bottom;      \"\u003e\u003cfont color=\"#ffffff\"\u003e\u003cspan style=\"color:#000000\"\u003ericha\u003c/span\u003e \u003c/font\u003e\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 15px;        font-weight: 600;        text-align: center;        width: 186px;        -ms-text-size-adjust: 100%;        vertical-align: bottom;      \"\u003e\u003cfont color=\"#ffffff\"\u003e\u003cspan style=\"color:#000000\"\u003eOffice 365\u003c/span\u003e \u003c/font\u003e\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;         -ms-text-size-adjust: 100%;         font-size: 15px;         font-weight: 600;        text-align: right;         width: 181px;         vertical-align: bottom;      \"\u003e\u003cfont color=\"#ffffff\"\u003e\u003cspan style=\"color:#000000\"\u003eadmin\u003c/span\u003e \u003c/font\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;        text-align: left;        padding-top: 0px;        padding-bottom: 0px;        vertical-align: middle;        width: 181px;      \"\u003e\u003cfont color=\"#ffffff\"\u003e\u003cspan style=\"        color: #c00000;      \"\u003e\u003cb\u003eAction Required\u003c/b\u003e \u003c/span\u003e\u003c/font\u003e\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;        text-align: center;        padding-top: 0px;        padding-bottom: 0px;        vertical-align: middle;        width: 186px;      \"\u003e\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;        text-align: right;        padding-top: 0px;        padding-bottom: 0px;        vertical-align: middle;        width: 181px;      \"\u003e\u003cfont color=\"#ffffff\"\u003e\u003cspan style=\"color:#000000\"\u003eRecipient\u003c/span\u003e \u003c/font\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd colspan=\"3\" style=\"        padding-top:0;        padding-bottom:0;        padding-left:0;        padding-right:0      \"\u003e\u003ctable cellspacing=\"0\" cellpadding=\"0\" style=\"        border-spacing: 0px 0px;        padding-top: 0px;        padding-bottom: 0px;        padding-left: 0px;        padding-right: 0px;        border-collapse: collapse;      \"\u003e\u003ctbody\u003e\u003ctr height=\"10\"\u003e\u003ctd width=\"180\" height=\"10\" bgcolor=\"#c00000\" style=\"        width: 180px;        line-height: 10px;        height: 10px;        font-size: 6px;        padding-top: 0;        padding-bottom: 0;        padding-left: 0;        padding-right: 0;      \"\u003e\u003c!--[if gte mso 15]\u003e\u0026nbsp;\u003c![endif]--\u003e\u003c/td\u003e\u003ctd width=\"4\" height=\"10\" bgcolor=\"#ffffff\" style=\"        width: 4px;        line-height: 10px;        height: 10px;        font-size: 6px;        padding-top: 0;        padding-bottom: 0;        padding-left: 0;        padding-right: 0;      \"\u003e\u003c!--[if gte mso 15]\u003e\u0026nbsp;\u003c![endif]--\u003e\u003c/td\u003e\u003ctd width=\"180\" height=\"10\" bgcolor=\"#cccccc\" style=\"        width: 180px;        line-height: 10px;        height: 10px;        font-size: 6px;        padding-top: 0;        padding-bottom: 0;        padding-left: 0;        padding-right: 0;      \"\u003e\u003c!--[if gte mso 15]\u003e\u0026nbsp;\u003c![endif]--\u003e\u003c/td\u003e\u003ctd width=\"4\" height=\"10\" bgcolor=\"#ffffff\" style=\"        width: 4px;        line-height: 10px;        height: 10px;        font-size: 6px;        padding-top: 0;        padding-bottom: 0;        padding-left: 0;        padding-right: 0;      \"\u003e\u003c!--[if gte mso 15]\u003e\u0026nbsp;\u003c![endif]--\u003e\u003c/td\u003e\u003ctd width=\"180\" height=\"10\" bgcolor=\"#cccccc\" style=\"        width: 180px;        line-height: 10px;        height: 10px;        font-size: 6px;        padding-top: 0;        padding-bottom: 0;        padding-left: 0;        padding-right: 0;      \"\u003e\u003c!--[if gte mso 15]\u003e\u0026nbsp;\u003c![endif]--\u003e\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        text-align: left;        width: 181px;        line-height: 20px;        font-weight: 400;        padding-top: 0px;        padding-left: 0px;        padding-right: 0px;        padding-bottom: 0px;      \"\u003e\u003cfont color=\"#ffffff\"\u003e\u003cspan style=\"        color: #c00000;      \"\u003eUnknown To address\u003c/span\u003e \u003c/font\u003e\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        text-align: center;        width: 186px;        line-height: 20px;        font-weight: 400;        padding-top: 0px;        padding-left: 0px;        padding-right: 0px;        padding-bottom: 0px;      \"\u003e\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        text-align: right;        width: 181px;        line-height: 20px;        font-weight: 400;        padding-top: 0px;        padding-left: 0px;        padding-right: 0px;        padding-bottom: 0px;      \"\u003e\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        width: 100%;        padding-top: 0px;        padding-right: 10px;        padding-left: 10px;      \"\u003e\u003cbr\u003e\u003ctable style=\"        width: 100%;        padding-right: 0px;        padding-left: 0px;        padding-top: 0px;        padding-bottom: 0px;        background-color: #f2f5fa;        margin-left: 0px;      \"\u003e\u003ctbody\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 21px;        font-weight: 500;        background-color: #f2f5fa;        padding-top: 0px;        padding-bottom: 0px;        padding-left: 10px;        padding-right: 10px;      \"\u003eHow to Fix It\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 16px;        font-weight: 400;        padding-top: 0px;        padding-bottom: 6px;        padding-left: 10px;        padding-right: 10px;        background-color: #f2f5fa;      \"\u003eThe address may be misspelled or may not exist. Try one or more of the following:\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"         padding-top: 0px;         padding-bottom: 0px;         padding-left: 0px;         padding-right: 0px;        border-spacing: 0px 0px;      \"\u003e\u003cul style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 16px;        font-weight: 400;        margin-left: 40px;        margin-bottom: 5px;        background-color: #f2f5fa;        padding-top: 0px;        padding-bottom: 0px;        padding-left: 6px;        padding-right: 6px;      \"\u003e\u003cli\u003eSend the message again following these steps: In Outlook, open this non-delivery report (NDR) and choose \u003cb\u003eSend Again\u003c/b\u003e from the Report ribbon. In Outlook on the web, select this NDR, then select the link \u0026quot;\u003cb\u003eTo send this message again, click here.\u003c/b\u003e\u0026quot; Then delete and retype the entire recipient address. If prompted with an Auto-Complete List suggestion don't select it. After typing the complete address, click \u003cb\u003eSend\u003c/b\u003e.\u003c/li\u003e\u003cli\u003eContact the recipient (by phone, for example) to check that the address exists and is correct.\u003c/li\u003e\u003cli\u003eThe recipient may have set up email forwarding to an incorrect address. Ask them to check that any forwarding they've set up is working correctly.\u003c/li\u003e\u003cli\u003eClear the recipient Auto-Complete List in Outlook or Outlook on the web by following the steps in this article: \u003ca href=\"https://go.microsoft.com/fwlink/?LinkId=389363\"\u003eFix email delivery issues for error code 5.1.1 in Office 365\u003c/a\u003e, and then send the message again. Retype the entire recipient address before selecting \u003cb\u003eSend\u003c/b\u003e.\u003c/li\u003e\u003c/ul\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 16px;        font-weight: 400;        padding-top: 0px;        padding-bottom: 6px;        padding-left: 10px;        padding-right: 10px;        background-color: #f2f5fa;      \"\u003eIf the problem continues, forward this message to your email admin. If you're an email admin, refer to the \u003cb\u003eMore Info for Email Admins\u003c/b\u003e section below.\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;        padding-top: 10px;        padding-bottom: 0px;        padding-bottom: 4px;      \"\u003e\u003cbr\u003e\u003cem\u003eWas this helpful? \u003ca href=\"https://go.microsoft.com/fwlink/?LinkId=525920\"\u003eSend feedback to Microsoft\u003c/a\u003e.\u003c/em\u003e \u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        -ms-text-size-adjust: 100%;        font-size: 0px;        line-height: 0px;        padding-top: 0px;        padding-bottom: 0px;      \"\u003e\u003chr\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 21px;        font-weight: 500;      \"\u003e\u003cbr\u003eMore Info for Email Admins\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;      \"\u003e\u003cem\u003eStatus code: 550 5.1.1\u003c/em\u003e \u003cbr\u003e\u003cbr\u003eThis error occurs because the sender sent a message to an email address outside of Office 365, but the address is incorrect or doesn't exist at the destination domain. The error is reported by the recipient domain's email server, but most often it must be fixed by the person who sent the message. If the steps in the \u003cb\u003eHow to Fix It\u003c/b\u003e section above don't fix the problem, and you're the email admin for the recipient, try one or more of the following:\u003cbr\u003e\u003cbr\u003e\u003cb\u003eThe email address exists and is correct\u003c/b\u003e - Confirm that the recipient address exists, is correct, and is accepting messages.\u003cbr\u003e\u003cbr\u003e\u003cb\u003eSynchronize your directories\u003c/b\u003e - If you have a hybrid environment and are using directory synchronization make sure the recipient's email address is synced correctly in both Office 365 and in your on-premises directory.\u003cbr\u003e\u003cbr\u003e\u003cb\u003eErrant forwarding rule\u003c/b\u003e - Check for forwarding rules that aren't behaving as expected. Forwarding can be set up by an admin via mail flow rules or mailbox forwarding address settings, or by the recipient via the Inbox Rules feature.\u003cbr\u003e\u003cbr\u003e\u003cb\u003eMail flow settings and MX records are not correct\u003c/b\u003e - Misconfigured mail flow or MX record settings can cause this error. Check your Office 365 mail flow settings to make sure your domain and any mail flow connectors are set up correctly. Also, work with your domain registrar to make sure the MX records for your domain are configured correctly.\u003cbr\u003e\u003cbr\u003eFor more information and additional tips to fix this issue, see \u003ca href=\"https://go.microsoft.com/fwlink/?LinkId=389363\"\u003eFix email delivery issues for error code 550 5.1.1 in Office 365\u003c/a\u003e.\u003cbr\u003e\u003cbr\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 17px;        font-weight: 500;      \"\u003eOriginal Message Details\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-size: 14px;        line-height: 20px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;      \"\u003e\u003ctable style=\"        width: 100%;        border-collapse: collapse;        margin-left: 10px;      \"\u003e\u003ctbody\u003e\u003ctr\u003e\u003ctd valign=\"top\" style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eCreated Date:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003e5/21/2020 7:24:33 AM\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd valign=\"top\" style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eSender Address:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003ericha@badava.onmicrosoft.com\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eRecipient Address:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003eadmin@company.com\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eSubject:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003eMessage from Cortex XSOAR Security Operations Server\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 17px;        font-weight: 500;      \"\u003e\u003cbr\u003eError Details\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-size: 14px;        line-height: 20px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;      \"\u003e\u003ctable style=\"        width: 100%;        border-collapse: collapse;        margin-left: 10px;      \"\u003e\u003ctbody\u003e\u003ctr\u003e\u003ctd valign=\"top\" style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eReported error:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003e\u003cem\u003e550 5.1.1 \u0026lt;admin@company.com\u0026gt;: Email address could not be found, or was misspelled (G8)\u003c/em\u003e \u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eDSN generated by:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003eBMXPR01MB3016.INDPRD01.PROD.OUTLOOK.COM\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eRemote server:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003esmtp26.gate.ord1d.rsapps.net\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003cbr\u003e\u003ctable style=\"width: 880px;\" cellspacing=\"0\"\u003e\u003ctbody\u003e\u003ctr\u003e\u003ctd colspan=\"6\" style=\"        padding-top: 4px;        border-bottom: 1px solid #999999;        padding-bottom: 4px;        line-height: 120%;        font-size: 17px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;      \"\u003eMessage Hops\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        background-color: #f2f5fa;        border-bottom: 1px solid #999999;        white-space: nowrap;        padding: 8px;      \"\u003eHOP\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        background-color: #f2f5fa;        border-bottom: 1px solid #999999;        white-space: nowrap;        padding: 8px;        width: 80px;      \"\u003eTIME (UTC)\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        background-color: #f2f5fa;        border-bottom: 1px solid #999999;        white-space: nowrap;        padding: 8px;      \"\u003eFROM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        background-color: #f2f5fa;        border-bottom: 1px solid #999999;        white-space: nowrap;        padding: 8px;      \"\u003eTO\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        background-color: #f2f5fa;        border-bottom: 1px solid #999999;        white-space: nowrap;        padding: 8px;      \"\u003eWITH\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        background-color: #f2f5fa;        border-bottom: 1px solid #999999;        white-space: nowrap;        padding: 8px;      \"\u003eRELAY TIME\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: center;      \"\u003e1\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;        width: 80px;      \"\u003e5/21/2020\u003cbr\u003e7:24:33 AM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003eBMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003eBMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003emapi\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003e*\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: center;      \"\u003e2\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;        width: 80px;      \"\u003e5/21/2020\u003cbr\u003e7:24:33 AM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003eBMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003eBMXPR01MB3016.INDPRD01.PROD.OUTLOOK.COM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003eMicrosoft SMTP Server (version=TLS1_2, cipher=TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384)\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003e*\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003cp style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 17px;        font-weight: 500;        padding-top: 4px;        padding-bottom: 0;        margin-top: 19px;        margin-bottom: 5px;      \"\u003eOriginal Message Headers\u003c/p\u003e\u003cpre style=\"        color: gray;        white-space: pre;        padding-top: 0;        margin-top: 5px;      \"\u003eARC-Seal: i=1; a=rsa-sha256; s=arcselector9901; d=microsoft.com; cv=none;\r\n b=JyX5XArSl9S76dJlQy/dM1BlKhPVhQWdwsc7tu\u0026#43;udKznUi5jbzguD0wdiV6sjZnEsrZcl1r5sSgqIutnRz03ND/fG0MqzvBR2J9732AlY4CT3GdNTt3buXmEhzkY7FC74bg24owGlZ7jzVZfhyB53wfqEs/lL1scd/DZQXLWvXv1c6YG8u3jsW572lk/8I7CJsXcjGgtYhq4AW7n5B8k3LPBOG8gfKGghhA/4To2QxyB3wlAODONehjfrhGLoZkc1K6XKfufTaB8AzDUw3kgWB8111nsZTsJs8IxT0fRtbntJOQtziH1ESS6QyQ66wN6jeX4gQb6s4KZjscMONCm7Q==\r\nARC-Message-Signature: i=1; a=rsa-sha256; c=relaxed/relaxed; d=microsoft.com;\r\n s=arcselector9901;\r\n h=From:Date:Subject:Message-ID:Content-Type:MIME-Version:X-MS-Exchange-SenderADCheck;\r\n bh=qIWvkA3bhacvdckysZVE3GPD/jiqEZ\u0026#43;nmgqdAOmGW/k=;\r\n b=g/dkhu0N6J7emnSXs3Fp85mEZAFYaqQr4MrI9KGDA89BRsbZxRNLz5MSWPDbIXnMRPhglqvZWfncHVxY2TZjK1WhhkoxBUqhtL2CqSh0a4xOW\u0026#43;Klm9/XClOiz6Amw4V5\u0026#43;TQrp\u0026#43;Tt/vqETby4uQDwImsePZRb62bHf86toiqCjRlDG6tMMo7xbuh0EBweqAYuiRGVoX1RA4\u0026#43;xi5yLei2wE8nAkTGION46Ol\u0026#43;IS9RBNeKGKZGrtCqBuWlKSafBzj6ENDzyyIQEP7UcrX6OzHEWldM0H2Zhuy/k2Dc\u0026#43;bnpn8aVhFoM\u0026#43;u\u0026#43;jQFX3LLiYfMhdoX/cnqkdOIlH/1nl75Apo6w==\r\nARC-Authentication-Results: i=1; mx.microsoft.com 1; spf=pass\r\n smtp.mailfrom=badava.onmicrosoft.com; dmarc=pass action=none\r\n header.from=badava.onmicrosoft.com; dkim=pass\r\n header.d=badava.onmicrosoft.com; arc=none\r\nDKIM-Signature: v=1; a=rsa-sha256; c=relaxed/relaxed;\r\n d=badava.onmicrosoft.com; s=selector1-badava-onmicrosoft-com;\r\n h=From:Date:Subject:Message-ID:Content-Type:MIME-Version:X-MS-Exchange-SenderADCheck;\r\n bh=qIWvkA3bhacvdckysZVE3GPD/jiqEZ\u0026#43;nmgqdAOmGW/k=;\r\n b=FRmcf\u0026#43;nObkuGU\u0026#43;Z3MBL6Xr/1Ah2jka4YmKZ1/SwbSQCYum6m3E3Is2J\u0026#43;QPPq739UBz342GjCSoSecUU9XRXKY\u0026#43;8t\u0026#43;sJ2IfJ\u0026#43;qj6DWblLNyh4qe4KbuDQo8NC5MKfsiF\u0026#43;RY6fXkcySV1mTB1aNv7ILydAbQ6iqJ0eSdT/gILUryY=\r\nReceived: from BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM (2603:1096:b00:59::12)\r\n by BMXPR01MB3016.INDPRD01.PROD.OUTLOOK.COM (2603:1096:b00:31::23) with\r\n Microsoft SMTP Server (version=TLS1_2,\r\n cipher=TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384) id 15.20.3000.27; Thu, 21 May\r\n 2020 07:24:33 \u0026#43;0000\r\nReceived: from BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\r\n ([fe80::1d03:43d1:9bf:ce0d]) by BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\r\n ([fe80::1d03:43d1:9bf:ce0d%7]) with mapi id 15.20.3000.034; Thu, 21 May 2020\r\n 07:24:33 \u0026#43;0000\r\nFrom: richa priyanka \u0026lt;richa@badava.onmicrosoft.com\u0026gt;\r\nTo: \u0026quot;admin@company.com\u0026quot; \u0026lt;admin@company.com\u0026gt;\r\nSubject: Message from Cortex XSOAR Security Operations Server\r\nThread-Topic: Message from Cortex XSOAR Security Operations Server\r\nThread-Index: AQHWL0Df3e4nwozNVkC8rGRWr\u0026#43;e5hw==\r\nDate: Thu, 21 May 2020 07:24:33 \u0026#43;0000\r\nMessage-ID: \u0026lt;BMXPR01MB37675498D0CC700DB94763958EB70@BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u0026gt;\r\nAccept-Language: en-US\r\nContent-Language: en-US\r\nX-MS-Has-Attach:\r\nX-MS-TNEF-Correlator:\r\nauthentication-results: company.com; dkim=none (message not signed)\r\n header.d=none;company.com; dmarc=none action=none\r\n header.from=badava.onmicrosoft.com;\r\nx-originating-ip: [54.176.61.115]\r\nx-ms-publictraffictype: Email\r\nx-ms-office365-filtering-correlation-id: a0ed91b6-ed93-4a5e-8435-08d7fd58025f\r\nx-ms-traffictypediagnostic: BMXPR01MB3016:\r\nx-microsoft-antispam-prvs: \u0026lt;BMXPR01MB3016FA051891C75B360C3BE28EB70@BMXPR01MB3016.INDPRD01.PROD.OUTLOOK.COM\u0026gt;\r\nx-ms-oob-tlc-oobclassifiers: OLM:4303;\r\nx-forefront-prvs: 041032FF37\r\nx-ms-exchange-senderadcheck: 1\r\nx-microsoft-antispam: BCL:0;\r\nx-microsoft-antispam-message-info: lX3IMO4DiN3iZddnJ3H9GvWZcdGF7O8XmUpohk0J5O1tKemT00RfxDWp3L9ifZlPfKiKOFSuy8HXHsVlXmMyE5gCgVQJQao/H6c8wVPmiF7ieMHOJ4btZ03xvNfUjP22CHPz9cTbE1DYM680vQqKrG6N4tS4e\u0026#43;szl0l8dMxTH55IecvD31\u0026#43;paqIiqXe4DJwm4rmL3vsm8aCB1fgdTRuOP4WEuKuJ2VtoXC1C2Ti\u0026#43;KFfRSmS3Q80edeKo7xit\u0026#43;3eC3VFFyRojgGz\u0026#43;gGUreh01IwhtzedirZy8kMcLt8a3zYSAhOjbZkFej4SXw421vSDPVYM4pul7uyJgWh7S9rpp3tr69gIXGfMsJVDFKYBjbPB/wlnoF6G366Nk0CV4wZe5A8P3bSzAU\u0026#43;3ajNeGs/aViZCejDwVwegnVaN12A4M2s7JlxRqvoiL7\u0026#43;7TqowiljwVbq10hMGBMKSXcfBDgnq90yuplNnkRcheeYQ\u0026#43;sSDrhU8=\r\nx-forefront-antispam-report: CIP:255.255.255.255;CTRY:;LANG:en;SCL:1;SRV:;IPV:NLI;SFV:NSPM;H:BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM;PTR:;CAT:NONE;SFTY:;SFS:(136003)(396003)(366004)(346002)(376002)(39830400003)(34036004)(66556008)(66476007)(64756008)(66446008)(6506007)(558084003)(2906002)(91956017)(33656002)(7696005)(8676002)(86362001)(15650500001)(52536014)(8936002)(76116006)(55236004)(9686003)(6916009)(71200400001)(66946007)(508600001)(5660300002)(186003)(316002)(966005)(55016002)(26005);DIR:OUT;SFP:1101;\r\nx-ms-exchange-antispam-messagedata: TxVovgghazUtJBHPhzPtBDIboqypdJDLkl0\u0026#43;NfcSY4to6qcDdF5Xcxw0W82QM04xjbmMrpsaOeLJBy3NYxmc1gBR2fKCBohuUFllmzAKO6T7zVcYkx2SMlJB/XxP0iWQD4pfwaMmR2w5MiuEFeCcDcAyP0DkHd\u0026#43;vV4OCtgNKd/w5X2lmU4xwWjAr8ApTr/v\u0026#43;hxNJyYz17cWlIW4v1Of1UayrutWSfJDlXeeMdsmjQVY6Y344k8C4j47MJm4fAzdvZ0E6PbHYbMvT\u0026#43;95LAT\u0026#43;feVzDvrXBEbksknyNZbYQOa1BacHn/sQq0Z4Pkq89j6IsbIVrX40lmd4jUqa/A9SzDKOJFbzQ7G9rLpyMvLNJaERlDoU1ffYS0bUMcKZK2415xDxtY3fwgcDK7rYbYZ1haElEUO9xvDjLiDAJfP46PDaI81owtQjT/X3U0DRKHSL9ehy3GB2mJArV9bhMhL\u0026#43;BUW6sSI7F7fi0EjHmuhAHeW4=\r\nx-ms-exchange-transport-forked: True\r\nContent-Type: text/plain; charset=\u0026quot;us-ascii\u0026quot;\r\nContent-Transfer-Encoding: quoted-printable\r\nMIME-Version: 1.0\r\nX-OriginatorOrg: badava.onmicrosoft.com\r\nX-MS-Exchange-CrossTenant-Network-Message-Id: a0ed91b6-ed93-4a5e-8435-08d7fd58025f\r\nX-MS-Exchange-CrossTenant-originalarrivaltime: 21 May 2020 07:24:33.3928\r\n (UTC)\r\nX-MS-Exchange-CrossTenant-fromentityheader: Hosted\r\nX-MS-Exchange-CrossTenant-id: a3da2674-d726-4da3-9d8e-2b65566ef88a\r\nX-MS-Exchange-CrossTenant-mailboxtype: HOSTED\r\nX-MS-Exchange-CrossTenant-userprincipalname: HvLZPetZnCqpo9c8vkkLh0FjbskEry5iJ\u0026#43;DMDPn58FZdse47hLCLO6\u0026#43;pNmC7IXda3zoNEG3BzH0/MfwT89hbm4R1HlJpYINsMk74eagTxLg=\r\nX-MS-Exchange-Transport-CrossTenantHeadersStamped: BMXPR01MB3016\r\n\u003c/pre\u003e\u003c/body\u003e\u003c/html\u003e",
        "datetimeCreated": "2020-05-21T07:24:37Z",
        "datetimeReceived": "2020-05-21T07:24:37Z",
        "datetimeSent": "2020-05-21T07:24:36Z",
        "hasAttachments": true,
        "headers": [
            {
                "name": "Received",
                "value": "from BMXPR01MB3016.INDPRD01.PROD.OUTLOOK.COM (2603:1096:b00:1::28) by BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM with HTTPS via BM1PR01CA0088.INDPRD01.PROD.OUTLOOK.COM; Thu, 21 May 2020 07:24:36 +0000"
            },
            {
                "name": "MIME-Version",
                "value": "1.0"
            },
            {
                "name": "Date",
                "value": "Thu, 21 May 2020 07:24:36 +0000"
            },
            {
                "name": "Content-Type",
                "value": "multipart/report"
            },
            {
                "name": "X-MS-Exchange-Organization-SCL",
                "value": "-1"
            },
            {
                "name": "Content-Language",
                "value": "en-US"
            },
            {
                "name": "Message-ID",
                "value": "\u003c3305080d-e83d-4d8f-8447-7f424ed34191@BMXPR01MB3016.INDPRD01.PROD.OUTLOOK.COM\u003e"
            },
            {
                "name": "In-Reply-To",
                "value": "\u003cBMXPR01MB37675498D0CC700DB94763958EB70@BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003e"
            },
            {
                "name": "References",
                "value": "\u003cBMXPR01MB37675498D0CC700DB94763958EB70@BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003e"
            },
            {
                "name": "Thread-Topic",
                "value": "Message from Cortex XSOAR Security Operations Server"
            },
            {
                "name": "Thread-Index",
                "value": "AQHWL0Df3e4nwozNVkC8rGRWr+e5h6iyI0Ek"
            },
            {
                "name": "Subject",
                "value": "Undeliverable: Message from Cortex XSOAR Security Operations Server"
            },
            {
                "name": "Auto-Submitted",
                "value": "auto-replied"
            },
            {
                "name": "X-MS-PublicTrafficType",
                "value": "Email"
            },
            {
                "name": "X-MS-Exchange-Organization-AuthSource",
                "value": "BMXPR01MB3016.INDPRD01.PROD.OUTLOOK.COM"
            },
            {
                "name": "X-MS-Exchange-Organization-AuthAs",
                "value": "Internal"
            },
            {
                "name": "X-MS-Exchange-Organization-AuthMechanism",
                "value": "05"
            },
            {
                "name": "X-MS-Exchange-Organization-Network-Message-Id",
                "value": "e9aa9df3-2c55-44b6-e7ca-08d7fd580455"
            },
            {
                "name": "X-MS-TrafficTypeDiagnostic",
                "value": "BMXPR01MB3016:"
            },
            {
                "name": "X-MS-Exchange-Organization-ExpirationStartTime",
                "value": "21 May 2020 07:24:36.7842 (UTC)"
            },
            {
                "name": "X-MS-Exchange-Organization-ExpirationStartTimeReason",
                "value": "SideEffectMessage"
            },
            {
                "name": "X-MS-Exchange-Organization-ExpirationInterval",
                "value": "1:00:00:00.0000000"
            },
            {
                "name": "X-MS-Exchange-Organization-ExpirationIntervalReason",
                "value": "SideEffectMessage"
            },
            {
                "name": "X-MS-Oob-TLC-OOBClassifiers",
                "value": "OLM:449;"
            },
            {
                "name": "X-Microsoft-Antispam",
                "value": "BCL:0;"
            },
            {
                "name": "X-Forefront-Antispam-Report",
                "value": "CIP:255.255.255.255;CTRY:;LANG:en;SCL:-1;SRV:;IPV:NLI;SFV:SKI;H:;PTR:;CAT:NONE;SFTY:;SFS:;DIR:INB;SFP:;"
            },
            {
                "name": "X-MS-Exchange-CrossTenant-OriginalArrivalTime",
                "value": "21 May 2020 07:24:36.7872 (UTC)"
            },
            {
                "name": "X-MS-Exchange-CrossTenant-FromEntityHeader",
                "value": "Hosted"
            },
            {
                "name": "X-MS-Exchange-CrossTenant-Network-Message-Id",
                "value": "e9aa9df3-2c55-44b6-e7ca-08d7fd580455"
            },
            {
                "name": "X-MS-Exchange-Transport-CrossTenantHeadersStamped",
                "value": "BMXPR01MB3016"
            },
            {
                "name": "X-MS-Exchange-Organization-MessageDirectionality",
                "value": "Originating"
            },
            {
                "name": "X-MS-Exchange-Transport-EndToEndLatency",
                "value": "00:00:00.1875980"
            },
            {
                "name": "X-MS-Exchange-Processed-By-BccFoldering",
                "value": "15.20.3000.034"
            },
            {
                "name": "X-Microsoft-Antispam-Mailbox-Delivery",
                "value": "ucf:0;jmr:0;auth:0;dest:I;ENG:(750128)(520011016)(706158)(944506383)(944626604);"
            },
            {
                "name": "X-Microsoft-Antispam-Message-Info",
                "value": "ZEmlBFfByDGs+dHIOEc9O3KQi5YQX92VYPr7Vfd9zYsKcYQx6l24bn0rYMly4eM6/3xkpxyy3d+SNAtCScC3oGD7AoNbguk5OGficbi2DY6MNh0/H92dt2s/CRMTr+C4JmxHlICqojAJUnN6VcNMXwxe5adm5ugGgmD8fNN+Ijf7bqcS48Lb1aaE3kWrmPPPziAWPS4rP61epHp30/92tfU5zXOS+U6meTEcMY/s6clBOe9/JO4CoGoFMcq0Uy3OZypIeWzNFpdBBYAfYeMlOwLIDeRmNXEJjOZD2/MY8RvOeqZ8h0mFoH/tFn5kb1FsPULl6eUh4WK7GcdzQ0+Dzro98qCTbxHrRczDJUn7JrvN0R23XsuN60iEp+Ezs88yvD7AshVtx0Yju0tCmrYcjnFx8bkcWCb6pqBPmGz3tZYtJn7h1UEbYBr9RfND5pC4OXtKm0dk/t65n1B7wklNd6ykqUxnDHdukB9OYuJnjJejXx/qtQP5FqrOqMfZyrmsRyGR0L/dwXakre2q3DQvMg7jVzyQGHNpaTHMllAYB3OG6VteEWpAgcpnxZ2ua32IOSw6cKoXj9Gucn5/+Zj/F69lm605ouhjUi5QkjpaVQt5y8BD7BtnqMvuKXu9kSeR6kumd3Tt1Z2ohn6L2kxCCA=="
            }
        ],
        "importance": "Normal",
        "isRead": false,
        "itemId": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkARgAAA8UvpdPLfBBFk4yzLjFjo38HAKGgXpWqlGBOsYqBLmshp1EAAAIBDAAAAKGgXpWqlGBOsYqBLmshp1EAAAIFgwAAAA==",
        "lastModifiedTime": "2020-05-21T07:24:38Z",
        "mailbox": "richa@badava.onmicrosoft.com",
        "messageId": "\u003c3305080d-e83d-4d8f-8447-7f424ed34191@BMXPR01MB3016.INDPRD01.PROD.OUTLOOK.COM\u003e",
        "receivedBy": "richa@badava.onmicrosoft.com",
        "sender": "MicrosoftExchange329e71ec88ae4615bbc36ab6ce41109e@badava.onmicrosoft.com",
        "size": 190348,
        "subject": "Undeliverable: Message from Cortex XSOAR Security Operations Server",
        "textBody": "[http://products.office.com/en-us/CMSImages/Office365Logo_Orange.png?version=b8d100a9-0a8b-8e6a-88e1-ef488fee0470]\r\nYour message to admin@company.com couldn't be delivered.\r\nadmin wasn't found at company.com.\r\nricha   Office 365      admin\r\nAction Required                 Recipient\r\nUnknown To address\r\n\r\nHow to Fix It\r\nThe address may be misspelled or may not exist. Try one or more of the following:\r\n\r\n  *   Send the message again following these steps: In Outlook, open this non-delivery report (NDR) and choose Send Again from the Report ribbon. In Outlook on the web, select this NDR, then select the link \"To send this message again, click here.\" Then delete and retype the entire recipient address. If prompted with an Auto-Complete List suggestion don't select it. After typing the complete address, click Send.\r\n  *   Contact the recipient (by phone, for example) to check that the address exists and is correct.\r\n  *   The recipient may have set up email forwarding to an incorrect address. Ask them to check that any forwarding they've set up is working correctly.\r\n  *   Clear the recipient Auto-Complete List in Outlook or Outlook on the web by following the steps in this article: Fix email delivery issues for error code 5.1.1 in Office 365\u003chttps://go.microsoft.com/fwlink/?LinkId=389363\u003e, and then send the message again. Retype the entire recipient address before selecting Send.\r\n\r\nIf the problem continues, forward this message to your email admin. If you're an email admin, refer to the More Info for Email Admins section below.\r\n\r\nWas this helpful? Send feedback to Microsoft\u003chttps://go.microsoft.com/fwlink/?LinkId=525920\u003e.\r\n________________________________\r\n\r\nMore Info for Email Admins\r\nStatus code: 550 5.1.1\r\n\r\nThis error occurs because the sender sent a message to an email address outside of Office 365, but the address is incorrect or doesn't exist at the destination domain. The error is reported by the recipient domain's email server, but most often it must be fixed by the person who sent the message. If the steps in the How to Fix It section above don't fix the problem, and you're the email admin for the recipient, try one or more of the following:\r\n\r\nThe email address exists and is correct - Confirm that the recipient address exists, is correct, and is accepting messages.\r\n\r\nSynchronize your directories - If you have a hybrid environment and are using directory synchronization make sure the recipient's email address is synced correctly in both Office 365 and in your on-premises directory.\r\n\r\nErrant forwarding rule - Check for forwarding rules that aren't behaving as expected. Forwarding can be set up by an admin via mail flow rules or mailbox forwarding address settings, or by the recipient via the Inbox Rules feature.\r\n\r\nMail flow settings and MX records are not correct - Misconfigured mail flow or MX record settings can cause this error. Check your Office 365 mail flow settings to make sure your domain and any mail flow connectors are set up correctly. Also, work with your domain registrar to make sure the MX records for your domain are configured correctly.\r\n\r\nFor more information and additional tips to fix this issue, see Fix email delivery issues for error code 550 5.1.1 in Office 365\u003chttps://go.microsoft.com/fwlink/?LinkId=389363\u003e.\r\n\r\nOriginal Message Details\r\nCreated Date:   5/21/2020 7:24:33 AM\r\nSender Address: richa@badava.onmicrosoft.com\r\nRecipient Address:      admin@company.com\r\nSubject:        Message from Cortex XSOAR Security Operations Server\r\n\r\nError Details\r\nReported error: 550 5.1.1 \u003cadmin@company.com\u003e: Email address could not be found, or was misspelled (G8)\r\nDSN generated by:       BMXPR01MB3016.INDPRD01.PROD.OUTLOOK.COM\r\nRemote server:  smtp26.gate.ord1d.rsapps.net\r\n\r\nMessage Hops\r\nHOP     TIME (UTC)      FROM    TO      WITH    RELAY TIME\r\n1       5/21/2020\r\n7:24:33 AM      BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM mapi    *\r\n2       5/21/2020\r\n7:24:33 AM      BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM BMXPR01MB3016.INDPRD01.PROD.OUTLOOK.COM Microsoft SMTP Server (version=TLS1_2, cipher=TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384)    *\r\n\r\nOriginal Message Headers\r\n\r\nARC-Seal: i=1; a=rsa-sha256; s=arcselector9901; d=microsoft.com; cv=none;\r\n b=JyX5XArSl9S76dJlQy/dM1BlKhPVhQWdwsc7tu+udKznUi5jbzguD0wdiV6sjZnEsrZcl1r5sSgqIutnRz03ND/fG0MqzvBR2J9732AlY4CT3GdNTt3buXmEhzkY7FC74bg24owGlZ7jzVZfhyB53wfqEs/lL1scd/DZQXLWvXv1c6YG8u3jsW572lk/8I7CJsXcjGgtYhq4AW7n5B8k3LPBOG8gfKGghhA/4To2QxyB3wlAODONehjfrhGLoZkc1K6XKfufTaB8AzDUw3kgWB8111nsZTsJs8IxT0fRtbntJOQtziH1ESS6QyQ66wN6jeX4gQb6s4KZjscMONCm7Q==\r\nARC-Message-Signature: i=1; a=rsa-sha256; c=relaxed/relaxed; d=microsoft.com;\r\n s=arcselector9901;\r\n h=From:Date:Subject:Message-ID:Content-Type:MIME-Version:X-MS-Exchange-SenderADCheck;\r\n bh=qIWvkA3bhacvdckysZVE3GPD/jiqEZ+nmgqdAOmGW/k=;\r\n b=g/dkhu0N6J7emnSXs3Fp85mEZAFYaqQr4MrI9KGDA89BRsbZxRNLz5MSWPDbIXnMRPhglqvZWfncHVxY2TZjK1WhhkoxBUqhtL2CqSh0a4xOW+Klm9/XClOiz6Amw4V5+TQrp+Tt/vqETby4uQDwImsePZRb62bHf86toiqCjRlDG6tMMo7xbuh0EBweqAYuiRGVoX1RA4+xi5yLei2wE8nAkTGION46Ol+IS9RBNeKGKZGrtCqBuWlKSafBzj6ENDzyyIQEP7UcrX6OzHEWldM0H2Zhuy/k2Dc+bnpn8aVhFoM+u+jQFX3LLiYfMhdoX/cnqkdOIlH/1nl75Apo6w==\r\nARC-Authentication-Results: i=1; mx.microsoft.com 1; spf=pass\r\n smtp.mailfrom=badava.onmicrosoft.com; dmarc=pass action=none\r\n header.from=badava.onmicrosoft.com; dkim=pass\r\n header.d=badava.onmicrosoft.com; arc=none\r\nDKIM-Signature: v=1; a=rsa-sha256; c=relaxed/relaxed;\r\n d=badava.onmicrosoft.com; s=selector1-badava-onmicrosoft-com;\r\n h=From:Date:Subject:Message-ID:Content-Type:MIME-Version:X-MS-Exchange-SenderADCheck;\r\n bh=qIWvkA3bhacvdckysZVE3GPD/jiqEZ+nmgqdAOmGW/k=;\r\n b=FRmcf+nObkuGU+Z3MBL6Xr/1Ah2jka4YmKZ1/SwbSQCYum6m3E3Is2J+QPPq739UBz342GjCSoSecUU9XRXKY+8t+sJ2IfJ+qj6DWblLNyh4qe4KbuDQo8NC5MKfsiF+RY6fXkcySV1mTB1aNv7ILydAbQ6iqJ0eSdT/gILUryY=\r\nReceived: from BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM (2603:1096:b00:59::12)\r\n by BMXPR01MB3016.INDPRD01.PROD.OUTLOOK.COM (2603:1096:b00:31::23) with\r\n Microsoft SMTP Server (version=TLS1_2,\r\n cipher=TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384) id 15.20.3000.27; Thu, 21 May\r\n 2020 07:24:33 +0000\r\nReceived: from BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\r\n ([fe80::1d03:43d1:9bf:ce0d]) by BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\r\n ([fe80::1d03:43d1:9bf:ce0d%7]) with mapi id 15.20.3000.034; Thu, 21 May 2020\r\n 07:24:33 +0000\r\nFrom: richa priyanka \u003cricha@badava.onmicrosoft.com\u003e\r\nTo: \"admin@company.com\" \u003cadmin@company.com\u003e\r\nSubject: Message from Cortex XSOAR Security Operations Server\r\nThread-Topic: Message from Cortex XSOAR Security Operations Server\r\nThread-Index: AQHWL0Df3e4nwozNVkC8rGRWr+e5hw==\r\nDate: Thu, 21 May 2020 07:24:33 +0000\r\nMessage-ID: \u003cBMXPR01MB37675498D0CC700DB94763958EB70@BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003e\r\nAccept-Language: en-US\r\nContent-Language: en-US\r\nX-MS-Has-Attach:\r\nX-MS-TNEF-Correlator:\r\nauthentication-results: company.com; dkim=none (message not signed)\r\n header.d=none;company.com; dmarc=none action=none\r\n header.from=badava.onmicrosoft.com;\r\nx-originating-ip: [54.176.61.115]\r\nx-ms-publictraffictype: Email\r\nx-ms-office365-filtering-correlation-id: a0ed91b6-ed93-4a5e-8435-08d7fd58025f\r\nx-ms-traffictypediagnostic: BMXPR01MB3016:\r\nx-microsoft-antispam-prvs: \u003cBMXPR01MB3016FA051891C75B360C3BE28EB70@BMXPR01MB3016.INDPRD01.PROD.OUTLOOK.COM\u003e\r\nx-ms-oob-tlc-oobclassifiers: OLM:4303;\r\nx-forefront-prvs: 041032FF37\r\nx-ms-exchange-senderadcheck: 1\r\nx-microsoft-antispam: BCL:0;\r\nx-microsoft-antispam-message-info: lX3IMO4DiN3iZddnJ3H9GvWZcdGF7O8XmUpohk0J5O1tKemT00RfxDWp3L9ifZlPfKiKOFSuy8HXHsVlXmMyE5gCgVQJQao/H6c8wVPmiF7ieMHOJ4btZ03xvNfUjP22CHPz9cTbE1DYM680vQqKrG6N4tS4e+szl0l8dMxTH55IecvD31+paqIiqXe4DJwm4rmL3vsm8aCB1fgdTRuOP4WEuKuJ2VtoXC1C2Ti+KFfRSmS3Q80edeKo7xit+3eC3VFFyRojgGz+gGUreh01IwhtzedirZy8kMcLt8a3zYSAhOjbZkFej4SXw421vSDPVYM4pul7uyJgWh7S9rpp3tr69gIXGfMsJVDFKYBjbPB/wlnoF6G366Nk0CV4wZe5A8P3bSzAU+3ajNeGs/aViZCejDwVwegnVaN12A4M2s7JlxRqvoiL7+7TqowiljwVbq10hMGBMKSXcfBDgnq90yuplNnkRcheeYQ+sSDrhU8=\r\nx-forefront-antispam-report: CIP:255.255.255.255;CTRY:;LANG:en;SCL:1;SRV:;IPV:NLI;SFV:NSPM;H:BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM;PTR:;CAT:NONE;SFTY:;SFS:(136003)(396003)(366004)(346002)(376002)(39830400003)(34036004)(66556008)(66476007)(64756008)(66446008)(6506007)(558084003)(2906002)(91956017)(33656002)(7696005)(8676002)(86362001)(15650500001)(52536014)(8936002)(76116006)(55236004)(9686003)(6916009)(71200400001)(66946007)(508600001)(5660300002)(186003)(316002)(966005)(55016002)(26005);DIR:OUT;SFP:1101;\r\nx-ms-exchange-antispam-messagedata: TxVovgghazUtJBHPhzPtBDIboqypdJDLkl0+NfcSY4to6qcDdF5Xcxw0W82QM04xjbmMrpsaOeLJBy3NYxmc1gBR2fKCBohuUFllmzAKO6T7zVcYkx2SMlJB/XxP0iWQD4pfwaMmR2w5MiuEFeCcDcAyP0DkHd+vV4OCtgNKd/w5X2lmU4xwWjAr8ApTr/v+hxNJyYz17cWlIW4v1Of1UayrutWSfJDlXeeMdsmjQVY6Y344k8C4j47MJm4fAzdvZ0E6PbHYbMvT+95LAT+feVzDvrXBEbksknyNZbYQOa1BacHn/sQq0Z4Pkq89j6IsbIVrX40lmd4jUqa/A9SzDKOJFbzQ7G9rLpyMvLNJaERlDoU1ffYS0bUMcKZK2415xDxtY3fwgcDK7rYbYZ1haElEUO9xvDjLiDAJfP46PDaI81owtQjT/X3U0DRKHSL9ehy3GB2mJArV9bhMhL+BUW6sSI7F7fi0EjHmuhAHeW4=\r\nx-ms-exchange-transport-forked: True\r\nContent-Type: text/plain; charset=\"us-ascii\"\r\nContent-Transfer-Encoding: quoted-printable\r\nMIME-Version: 1.0\r\nX-OriginatorOrg: badava.onmicrosoft.com\r\nX-MS-Exchange-CrossTenant-Network-Message-Id: a0ed91b6-ed93-4a5e-8435-08d7fd58025f\r\nX-MS-Exchange-CrossTenant-originalarrivaltime: 21 May 2020 07:24:33.3928\r\n (UTC)\r\nX-MS-Exchange-CrossTenant-fromentityheader: Hosted\r\nX-MS-Exchange-CrossTenant-id: a3da2674-d726-4da3-9d8e-2b65566ef88a\r\nX-MS-Exchange-CrossTenant-mailboxtype: HOSTED\r\nX-MS-Exchange-CrossTenant-userprincipalname: HvLZPetZnCqpo9c8vkkLh0FjbskEry5iJ+DMDPn58FZdse47hLCLO6+pNmC7IXda3zoNEG3BzH0/MfwT89hbm4R1HlJpYINsMk74eagTxLg=\r\nX-MS-Exchange-Transport-CrossTenantHeadersStamped: BMXPR01MB3016\r\n\r\n",
        "toRecipients": [
            "admin@company.com"
        ]
    },
    {
        "ItemAttachments": [
            {
                "attachmentContentId": "C4ADB61033EE914781B2FFC8C3047783@INDPRD01.PROD.OUTLOOK.COM",
                "attachmentContentLocation": null,
                "attachmentContentType": "message/rfc822",
                "attachmentId": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkARgAAA8UvpdPLfBBFk4yzLjFjo38HAKGgXpWqlGBOsYqBLmshp1EAAAIBDAAAAKGgXpWqlGBOsYqBLmshp1EAAAIFggAAAAESABAAlOvQPX/umE6pab/wn6yTFQ==",
                "attachmentIsInline": false,
                "attachmentLastModifiedTime": "2020-05-21T07:21:55+00:00",
                "attachmentName": "Playbook has stopped on error for Incident created from API at 2020-04-22 14:51:23.461941605 +0000 UTC m=+1196833.293197140 (#268)",
                "attachmentSHA256": "9a261bfb93a78cf321c9781c642d33f55b9e04665b6a0bf8cfee4867d9dfa3ab",
                "attachmentSize": 28559,
                "attachmentType": "ItemAttachment",
                "originalItemId": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkARgAAA8UvpdPLfBBFk4yzLjFjo38HAKGgXpWqlGBOsYqBLmshp1EAAAIBDAAAAKGgXpWqlGBOsYqBLmshp1EAAAIFggAAAA=="
            }
        ],
        "author": "MicrosoftExchange329e71ec88ae4615bbc36ab6ce41109e@badava.onmicrosoft.com",
        "body": "\u003chtml\u003e\u003chead\u003e\r\n\u003cmeta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"\u003e\u003cmeta name=\"viewport\" content=\"width=device-width, initial-scale=1\"\u003e\u003ctitle\u003eDSN\u003c/title\u003e\u003c/head\u003e\u003cbody style=\"        background-color: white;      \"\u003e\u003ctable style=\"        background-color: white;         max-width: 548px;         color: black;         border-spacing: 0px 0px;         padding-top: 0px;         padding-bottom: 0px;        border-collapse: collapse;      \" width=\"548\" cellspacing=\"0\" cellpadding=\"0\"\u003e\u003ctbody\u003e\u003ctr\u003e\u003ctd style=\"        text-align: left;        padding-bottom: 20px;      \"\u003e\u003cimg height=\"28\" width=\"126\" style=\"        max-width: 100%;      \" src=\"http://products.office.com/en-us/CMSImages/Office365Logo_Orange.png?version=b8d100a9-0a8b-8e6a-88e1-ef488fee0470\"\u003e \u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 16px;         padding-bottom: 10px;         -ms-text-size-adjust: 100%;        text-align: left;      \"\u003eYour message to \u003cspan style=\"        color: #0072c6;      \"\u003eadmin@company.com\u003c/span\u003e couldn't be delivered.\u003cbr\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;         font-size: 24px;         padding-top: 0px;         padding-bottom: 20px;         text-align: center;         -ms-text-size-adjust: 100%;      \"\u003e\u003cspan style=\"        color: #0072c6;      \"\u003eadmin\u003c/span\u003e wasn't found at \u003cspan style=\"        color: #0072c6;      \"\u003ecompany.com\u003c/span\u003e.\u003cbr\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        padding-bottom: 15px;         padding-left: 0px;         padding-right: 0px;         border-spacing: 0px 0px;      \"\u003e\u003ctable style=\"        max-width: 548px;         font-weight: 600;        border-spacing: 0px 0px;         padding-top: 0px;         padding-bottom: 0px;        border-collapse: collapse;      \"\u003e\u003ctbody\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 15px;        font-weight: 600;        text-align: left;        width: 181px;        -ms-text-size-adjust: 100%;        vertical-align: bottom;      \"\u003e\u003cfont color=\"#ffffff\"\u003e\u003cspan style=\"color:#000000\"\u003ericha\u003c/span\u003e \u003c/font\u003e\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 15px;        font-weight: 600;        text-align: center;        width: 186px;        -ms-text-size-adjust: 100%;        vertical-align: bottom;      \"\u003e\u003cfont color=\"#ffffff\"\u003e\u003cspan style=\"color:#000000\"\u003eOffice 365\u003c/span\u003e \u003c/font\u003e\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;         -ms-text-size-adjust: 100%;         font-size: 15px;         font-weight: 600;        text-align: right;         width: 181px;         vertical-align: bottom;      \"\u003e\u003cfont color=\"#ffffff\"\u003e\u003cspan style=\"color:#000000\"\u003eadmin\u003c/span\u003e \u003c/font\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;        text-align: left;        padding-top: 0px;        padding-bottom: 0px;        vertical-align: middle;        width: 181px;      \"\u003e\u003cfont color=\"#ffffff\"\u003e\u003cspan style=\"        color: #c00000;      \"\u003e\u003cb\u003eAction Required\u003c/b\u003e \u003c/span\u003e\u003c/font\u003e\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;        text-align: center;        padding-top: 0px;        padding-bottom: 0px;        vertical-align: middle;        width: 186px;      \"\u003e\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;        text-align: right;        padding-top: 0px;        padding-bottom: 0px;        vertical-align: middle;        width: 181px;      \"\u003e\u003cfont color=\"#ffffff\"\u003e\u003cspan style=\"color:#000000\"\u003eRecipient\u003c/span\u003e \u003c/font\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd colspan=\"3\" style=\"        padding-top:0;        padding-bottom:0;        padding-left:0;        padding-right:0      \"\u003e\u003ctable cellspacing=\"0\" cellpadding=\"0\" style=\"        border-spacing: 0px 0px;        padding-top: 0px;        padding-bottom: 0px;        padding-left: 0px;        padding-right: 0px;        border-collapse: collapse;      \"\u003e\u003ctbody\u003e\u003ctr height=\"10\"\u003e\u003ctd width=\"180\" height=\"10\" bgcolor=\"#c00000\" style=\"        width: 180px;        line-height: 10px;        height: 10px;        font-size: 6px;        padding-top: 0;        padding-bottom: 0;        padding-left: 0;        padding-right: 0;      \"\u003e\u003c!--[if gte mso 15]\u003e\u0026nbsp;\u003c![endif]--\u003e\u003c/td\u003e\u003ctd width=\"4\" height=\"10\" bgcolor=\"#ffffff\" style=\"        width: 4px;        line-height: 10px;        height: 10px;        font-size: 6px;        padding-top: 0;        padding-bottom: 0;        padding-left: 0;        padding-right: 0;      \"\u003e\u003c!--[if gte mso 15]\u003e\u0026nbsp;\u003c![endif]--\u003e\u003c/td\u003e\u003ctd width=\"180\" height=\"10\" bgcolor=\"#cccccc\" style=\"        width: 180px;        line-height: 10px;        height: 10px;        font-size: 6px;        padding-top: 0;        padding-bottom: 0;        padding-left: 0;        padding-right: 0;      \"\u003e\u003c!--[if gte mso 15]\u003e\u0026nbsp;\u003c![endif]--\u003e\u003c/td\u003e\u003ctd width=\"4\" height=\"10\" bgcolor=\"#ffffff\" style=\"        width: 4px;        line-height: 10px;        height: 10px;        font-size: 6px;        padding-top: 0;        padding-bottom: 0;        padding-left: 0;        padding-right: 0;      \"\u003e\u003c!--[if gte mso 15]\u003e\u0026nbsp;\u003c![endif]--\u003e\u003c/td\u003e\u003ctd width=\"180\" height=\"10\" bgcolor=\"#cccccc\" style=\"        width: 180px;        line-height: 10px;        height: 10px;        font-size: 6px;        padding-top: 0;        padding-bottom: 0;        padding-left: 0;        padding-right: 0;      \"\u003e\u003c!--[if gte mso 15]\u003e\u0026nbsp;\u003c![endif]--\u003e\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        text-align: left;        width: 181px;        line-height: 20px;        font-weight: 400;        padding-top: 0px;        padding-left: 0px;        padding-right: 0px;        padding-bottom: 0px;      \"\u003e\u003cfont color=\"#ffffff\"\u003e\u003cspan style=\"        color: #c00000;      \"\u003eUnknown To address\u003c/span\u003e \u003c/font\u003e\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        text-align: center;        width: 186px;        line-height: 20px;        font-weight: 400;        padding-top: 0px;        padding-left: 0px;        padding-right: 0px;        padding-bottom: 0px;      \"\u003e\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        text-align: right;        width: 181px;        line-height: 20px;        font-weight: 400;        padding-top: 0px;        padding-left: 0px;        padding-right: 0px;        padding-bottom: 0px;      \"\u003e\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        width: 100%;        padding-top: 0px;        padding-right: 10px;        padding-left: 10px;      \"\u003e\u003cbr\u003e\u003ctable style=\"        width: 100%;        padding-right: 0px;        padding-left: 0px;        padding-top: 0px;        padding-bottom: 0px;        background-color: #f2f5fa;        margin-left: 0px;      \"\u003e\u003ctbody\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 21px;        font-weight: 500;        background-color: #f2f5fa;        padding-top: 0px;        padding-bottom: 0px;        padding-left: 10px;        padding-right: 10px;      \"\u003eHow to Fix It\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 16px;        font-weight: 400;        padding-top: 0px;        padding-bottom: 6px;        padding-left: 10px;        padding-right: 10px;        background-color: #f2f5fa;      \"\u003eThe address may be misspelled or may not exist. Try one or more of the following:\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"         padding-top: 0px;         padding-bottom: 0px;         padding-left: 0px;         padding-right: 0px;        border-spacing: 0px 0px;      \"\u003e\u003cul style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 16px;        font-weight: 400;        margin-left: 40px;        margin-bottom: 5px;        background-color: #f2f5fa;        padding-top: 0px;        padding-bottom: 0px;        padding-left: 6px;        padding-right: 6px;      \"\u003e\u003cli\u003eSend the message again following these steps: In Outlook, open this non-delivery report (NDR) and choose \u003cb\u003eSend Again\u003c/b\u003e from the Report ribbon. In Outlook on the web, select this NDR, then select the link \u0026quot;\u003cb\u003eTo send this message again, click here.\u003c/b\u003e\u0026quot; Then delete and retype the entire recipient address. If prompted with an Auto-Complete List suggestion don't select it. After typing the complete address, click \u003cb\u003eSend\u003c/b\u003e.\u003c/li\u003e\u003cli\u003eContact the recipient (by phone, for example) to check that the address exists and is correct.\u003c/li\u003e\u003cli\u003eThe recipient may have set up email forwarding to an incorrect address. Ask them to check that any forwarding they've set up is working correctly.\u003c/li\u003e\u003cli\u003eClear the recipient Auto-Complete List in Outlook or Outlook on the web by following the steps in this article: \u003ca href=\"https://go.microsoft.com/fwlink/?LinkId=389363\"\u003eFix email delivery issues for error code 5.1.1 in Office 365\u003c/a\u003e, and then send the message again. Retype the entire recipient address before selecting \u003cb\u003eSend\u003c/b\u003e.\u003c/li\u003e\u003c/ul\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 16px;        font-weight: 400;        padding-top: 0px;        padding-bottom: 6px;        padding-left: 10px;        padding-right: 10px;        background-color: #f2f5fa;      \"\u003eIf the problem continues, forward this message to your email admin. If you're an email admin, refer to the \u003cb\u003eMore Info for Email Admins\u003c/b\u003e section below.\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;        padding-top: 10px;        padding-bottom: 0px;        padding-bottom: 4px;      \"\u003e\u003cbr\u003e\u003cem\u003eWas this helpful? \u003ca href=\"https://go.microsoft.com/fwlink/?LinkId=525920\"\u003eSend feedback to Microsoft\u003c/a\u003e.\u003c/em\u003e \u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        -ms-text-size-adjust: 100%;        font-size: 0px;        line-height: 0px;        padding-top: 0px;        padding-bottom: 0px;      \"\u003e\u003chr\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 21px;        font-weight: 500;      \"\u003e\u003cbr\u003eMore Info for Email Admins\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;      \"\u003e\u003cem\u003eStatus code: 550 5.1.1\u003c/em\u003e \u003cbr\u003e\u003cbr\u003eThis error occurs because the sender sent a message to an email address outside of Office 365, but the address is incorrect or doesn't exist at the destination domain. The error is reported by the recipient domain's email server, but most often it must be fixed by the person who sent the message. If the steps in the \u003cb\u003eHow to Fix It\u003c/b\u003e section above don't fix the problem, and you're the email admin for the recipient, try one or more of the following:\u003cbr\u003e\u003cbr\u003e\u003cb\u003eThe email address exists and is correct\u003c/b\u003e - Confirm that the recipient address exists, is correct, and is accepting messages.\u003cbr\u003e\u003cbr\u003e\u003cb\u003eSynchronize your directories\u003c/b\u003e - If you have a hybrid environment and are using directory synchronization make sure the recipient's email address is synced correctly in both Office 365 and in your on-premises directory.\u003cbr\u003e\u003cbr\u003e\u003cb\u003eErrant forwarding rule\u003c/b\u003e - Check for forwarding rules that aren't behaving as expected. Forwarding can be set up by an admin via mail flow rules or mailbox forwarding address settings, or by the recipient via the Inbox Rules feature.\u003cbr\u003e\u003cbr\u003e\u003cb\u003eMail flow settings and MX records are not correct\u003c/b\u003e - Misconfigured mail flow or MX record settings can cause this error. Check your Office 365 mail flow settings to make sure your domain and any mail flow connectors are set up correctly. Also, work with your domain registrar to make sure the MX records for your domain are configured correctly.\u003cbr\u003e\u003cbr\u003eFor more information and additional tips to fix this issue, see \u003ca href=\"https://go.microsoft.com/fwlink/?LinkId=389363\"\u003eFix email delivery issues for error code 550 5.1.1 in Office 365\u003c/a\u003e.\u003cbr\u003e\u003cbr\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 17px;        font-weight: 500;      \"\u003eOriginal Message Details\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-size: 14px;        line-height: 20px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;      \"\u003e\u003ctable style=\"        width: 100%;        border-collapse: collapse;        margin-left: 10px;      \"\u003e\u003ctbody\u003e\u003ctr\u003e\u003ctd valign=\"top\" style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eCreated Date:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003e5/21/2020 7:21:52 AM\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd valign=\"top\" style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eSender Address:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003ericha@badava.onmicrosoft.com\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eRecipient Address:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003eadmin@company.com\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eSubject:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003ePlaybook has stopped on error for Incident created from API at 2020-04-22 14:51:23.461941605 \u0026#43;0000 UTC m=\u0026#43;1196833.293197140 (#268)\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 17px;        font-weight: 500;      \"\u003e\u003cbr\u003eError Details\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-size: 14px;        line-height: 20px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;      \"\u003e\u003ctable style=\"        width: 100%;        border-collapse: collapse;        margin-left: 10px;      \"\u003e\u003ctbody\u003e\u003ctr\u003e\u003ctd valign=\"top\" style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eReported error:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003e\u003cem\u003e550 5.1.1 \u0026lt;admin@company.com\u0026gt;: Email address could not be found, or was misspelled (G8)\u003c/em\u003e \u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eDSN generated by:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003eBMXPR01MB2294.INDPRD01.PROD.OUTLOOK.COM\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eRemote server:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003esmtp34.gate.iad3a.rsapps.net\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003cbr\u003e\u003ctable style=\"width: 880px;\" cellspacing=\"0\"\u003e\u003ctbody\u003e\u003ctr\u003e\u003ctd colspan=\"6\" style=\"        padding-top: 4px;        border-bottom: 1px solid #999999;        padding-bottom: 4px;        line-height: 120%;        font-size: 17px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;      \"\u003eMessage Hops\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        background-color: #f2f5fa;        border-bottom: 1px solid #999999;        white-space: nowrap;        padding: 8px;      \"\u003eHOP\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        background-color: #f2f5fa;        border-bottom: 1px solid #999999;        white-space: nowrap;        padding: 8px;        width: 80px;      \"\u003eTIME (UTC)\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        background-color: #f2f5fa;        border-bottom: 1px solid #999999;        white-space: nowrap;        padding: 8px;      \"\u003eFROM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        background-color: #f2f5fa;        border-bottom: 1px solid #999999;        white-space: nowrap;        padding: 8px;      \"\u003eTO\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        background-color: #f2f5fa;        border-bottom: 1px solid #999999;        white-space: nowrap;        padding: 8px;      \"\u003eWITH\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        background-color: #f2f5fa;        border-bottom: 1px solid #999999;        white-space: nowrap;        padding: 8px;      \"\u003eRELAY TIME\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: center;      \"\u003e1\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;        width: 80px;      \"\u003e5/21/2020\u003cbr\u003e7:21:52 AM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003eBMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003eBMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003emapi\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003e*\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: center;      \"\u003e2\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;        width: 80px;      \"\u003e5/21/2020\u003cbr\u003e7:21:52 AM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003eBMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003eBMXPR01MB2294.INDPRD01.PROD.OUTLOOK.COM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003eMicrosoft SMTP Server (version=TLS1_2, cipher=TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384)\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003e*\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003cp style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 17px;        font-weight: 500;        padding-top: 4px;        padding-bottom: 0;        margin-top: 19px;        margin-bottom: 5px;      \"\u003eOriginal Message Headers\u003c/p\u003e\u003cpre style=\"        color: gray;        white-space: pre;        padding-top: 0;        margin-top: 5px;      \"\u003eARC-Seal: i=1; a=rsa-sha256; s=arcselector9901; d=microsoft.com; cv=none;\r\n b=CzGFvJV0zC6gJggHvV4lC7M54Gq4gMVXTJTZt2nqMuRZnVEab/5a3qKj1OhGeXc5udTbmlkMJJMvcUHCaYPYQT719ZTJ4tqAL0DY7QLu2\u0026#43;izgzq\u0026#43;pdxIypy9UApqOuWOwb5OiT9u321uSOFoggw\u0026#43;KM6XWH36NDU8PPDb1pIHjE79eGffOY8ZiLT1RULU5J/cG2JFKbn2xsSccZXrVChJhfhZgdgmSAiRmdle\u0026#43;XsB2mEesLM5awuCyZOdhL\u0026#43;pozj4\u0026#43;nIofCgsHo53AxEiM6vxmV9IgQpL/bEgXMW2d7BrZ\u0026#43;GqMZITU70RZY6\u0026#43;Zpq6YnsuC7sONW30ODhDx8V0h/E36g==\r\nARC-Message-Signature: i=1; a=rsa-sha256; c=relaxed/relaxed; d=microsoft.com;\r\n s=arcselector9901;\r\n h=From:Date:Subject:Message-ID:Content-Type:MIME-Version:X-MS-Exchange-SenderADCheck;\r\n bh=pbEBPo63JbZVBDgmaZYE7ds6FbOMGo41LrMesmx2320=;\r\n b=J1QswUxh7trJUMRqENQfk/YHeeBATfDcD7B0aRMlSwSw3as3/4iODlHgPTtg8bg6OocjfrgHp5XkE3toWbfwrFZ3s0/OJ1sK5ZnJj2iXCoEfVqQ\u0026#43;G09K7vZJcBrec857pRpn/WXkvrprJlg2D//6Pmx95yKnGkwHx/jbHtV5gn/n3iSJ0Im5Noyd3j2fAsmV2p5wh4yAge6Aj9aIASPMNBh/UiP4Vr4ISv7T6eZYTBiTIFlIIFdNWQ6xYpahJ6rpRgvhU0UTNfJ32ota0bSH\u0026#43;cbbIp2zFDm6MEePT1J0ifwev76Hp9n\u0026#43;JJM\u0026#43;W9Bs378nE0ifVz5yjNb9STly\u0026#43;R03OA==\r\nARC-Authentication-Results: i=1; mx.microsoft.com 1; spf=pass\r\n smtp.mailfrom=badava.onmicrosoft.com; dmarc=pass action=none\r\n header.from=badava.onmicrosoft.com; dkim=pass\r\n header.d=badava.onmicrosoft.com; arc=none\r\nDKIM-Signature: v=1; a=rsa-sha256; c=relaxed/relaxed;\r\n d=badava.onmicrosoft.com; s=selector1-badava-onmicrosoft-com;\r\n h=From:Date:Subject:Message-ID:Content-Type:MIME-Version:X-MS-Exchange-SenderADCheck;\r\n bh=pbEBPo63JbZVBDgmaZYE7ds6FbOMGo41LrMesmx2320=;\r\n b=CbMbBViM3wu/\u0026#43;fezYIMQDmMN5Qqs1os1xKjTQSQrYlbsQme0USRaOkFNAK0YmwyZ085sUYz9ns8uWEK9Fno\u0026#43;HFIjnU0I7NSXmMHHaJ6NUgSBSANv5yVbtfz20C0tgYnm4qcoXj1vc6K3ILah4gtPHmb83kinm\u0026#43;pb42yPWyuCRS4=\r\nReceived: from BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM (2603:1096:b00:59::12)\r\n by BMXPR01MB2294.INDPRD01.PROD.OUTLOOK.COM (2603:1096:b00:39::13) with\r\n Microsoft SMTP Server (version=TLS1_2,\r\n cipher=TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384) id 15.20.3000.27; Thu, 21 May\r\n 2020 07:21:52 \u0026#43;0000\r\nReceived: from BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\r\n ([fe80::1d03:43d1:9bf:ce0d]) by BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\r\n ([fe80::1d03:43d1:9bf:ce0d%7]) with mapi id 15.20.3000.034; Thu, 21 May 2020\r\n 07:21:52 \u0026#43;0000\r\nFrom: richa priyanka \u0026lt;richa@badava.onmicrosoft.com\u0026gt;\r\nTo: \u0026quot;admin@company.com\u0026quot; \u0026lt;admin@company.com\u0026gt;\r\nSubject: Playbook has stopped on error for Incident created from API at\r\n 2020-04-22 14:51:23.461941605 \u0026#43;0000 UTC m=\u0026#43;1196833.293197140 (#268)\r\nThread-Topic: Playbook has stopped on error for Incident created from API at\r\n 2020-04-22 14:51:23.461941605 \u0026#43;0000 UTC m=\u0026#43;1196833.293197140 (#268)\r\nThread-Index: AQHWL0CAvYxGZBLvEk\u0026#43;LUeAg02HUMA==\r\nDate: Thu, 21 May 2020 07:21:52 \u0026#43;0000\r\nMessage-ID: \u0026lt;BMXPR01MB3767E711DA78E4CD3055FBAC8EB70@BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u0026gt;\r\nAccept-Language: en-US\r\nContent-Language: en-US\r\nX-MS-Has-Attach:\r\nX-MS-TNEF-Correlator:\r\nauthentication-results: company.com; dkim=none (message not signed)\r\n header.d=none;company.com; dmarc=none action=none\r\n header.from=badava.onmicrosoft.com;\r\nx-originating-ip: [54.176.61.115]\r\nx-ms-publictraffictype: Email\r\nx-ms-office365-filtering-correlation-id: f3d3690c-5d8f-427f-b210-08d7fd57a299\r\nx-ms-traffictypediagnostic: BMXPR01MB2294:\r\nx-microsoft-antispam-prvs: \u0026lt;BMXPR01MB22949002FC7DC4144D983B2F8EB70@BMXPR01MB2294.INDPRD01.PROD.OUTLOOK.COM\u0026gt;\r\nx-ms-oob-tlc-oobclassifiers: OLM:2512;\r\nx-forefront-prvs: 041032FF37\r\nx-ms-exchange-senderadcheck: 1\r\nx-microsoft-antispam: BCL:0;\r\nx-microsoft-antispam-message-info: NCkZPV6GjXJBfSzDJd1KOHN7hvk4KMTSvceziixrh8oB\u0026#43;YpxrJgd/pMhUSQgtdf0gzVLEmULGCc/4Jm/0G\u0026#43;4mtloo7UDQnEVAA6mpWdiL4alphIpU9\u0026#43;Gf0SFq6jtllTdNb54ZNYoENF90qWwV7V3KcqskVYylolJduzU3bWc6LgtHYktB4Hvch7D3ElxwQFIfErDEcQnMIiW944hjnlQpAgSsu9/P04cEVbRsumMi9CoxvE7Yn8\u0026#43;mid/9xl7AZxsyp5jnrQHgpEGKaTN4MMCup0cFejpxsBqx818QkPUKvrgTsY2aVceybpPsAEZlIP/cp878nCzhxjjlgBr18kdDqGqmgaCHKLSQshsHx3lHG5oMs0MpCy5wz\u0026#43;VUZAOIiBWBIvvbJrAcfrmoHJDyhMo80eU9wy0uAuW24LGpx2X6l0KLHPfNjTX7FhlLTH4T2UodESRVZ\u0026#43;zSHA6tNnroDg8ogLWSBvUEwwIKL5zuHpqEPo=\r\nx-forefront-antispam-report: CIP:255.255.255.255;CTRY:;LANG:en;SCL:1;SRV:;IPV:NLI;SFV:NSPM;H:BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM;PTR:;CAT:NONE;SFTY:;SFS:(346002)(366004)(34036004)(136003)(39830400003)(376002)(396003)(55236004)(33656002)(966005)(8676002)(2906002)(316002)(55016002)(6916009)(86362001)(66476007)(8936002)(52536014)(186003)(91956017)(4744005)(76116006)(5660300002)(7696005)(71200400001)(508600001)(64756008)(66946007)(66556008)(66446008)(26005)(6506007)(9686003);DIR:OUT;SFP:1101;\r\nx-ms-exchange-antispam-messagedata: kCAtMUewDsbjqpiWFhNtvBrNPiHIZ4Kj2Y72Ac\u0026#43;6tdiy9td9B4T6PJSQ\u0026#43;qXenoqRpFLYD5PIJ6GR0/en5upPgmdHVJU2A5oyfByTM9duavoa1Ps7SDsVY6WMRg7ICJUiib/hSPciigYOL8RZiNR8yFQ9h7ySmf9o9aB2i6KbOZ6wN4aWLsa4zvALdnsxlXia9ynuQmWL/AuGvrfEMYFGSJhjNZDDsPcq2nGVwKaDVMlJTbLyWC9RPboHi40OCPVU16Mwrsr54ssHRu06jGejD\u0026#43;KQD1dDbK6l6HigL/\u0026#43;VZWIBBCUKf5BryVei1qmk/rhAX7Yf6/5msr2HVi0aHFQD9ifP40nujJ5K2aVdrbqYk/G3csdP7bsq/E1L0W9yyH4FHiYnXCjsd1beVRGhcJfe/YAnL62EOld7rNu942oxH6yhSvxyR/iJLrG8ilFfA\u0026#43;RfHxbyvftLMBSar6G/u0EpoHCTOmhzPJXdqbSoTx\u0026#43;HU\u0026#43;o=\r\nx-ms-exchange-transport-forked: True\r\nContent-Type: text/plain; charset=\u0026quot;us-ascii\u0026quot;\r\nContent-Transfer-Encoding: quoted-printable\r\nMIME-Version: 1.0\r\nX-OriginatorOrg: badava.onmicrosoft.com\r\nX-MS-Exchange-CrossTenant-Network-Message-Id: f3d3690c-5d8f-427f-b210-08d7fd57a299\r\nX-MS-Exchange-CrossTenant-originalarrivaltime: 21 May 2020 07:21:52.7788\r\n (UTC)\r\nX-MS-Exchange-CrossTenant-fromentityheader: Hosted\r\nX-MS-Exchange-CrossTenant-id: a3da2674-d726-4da3-9d8e-2b65566ef88a\r\nX-MS-Exchange-CrossTenant-mailboxtype: HOSTED\r\nX-MS-Exchange-CrossTenant-userprincipalname: iLMoJBrmr\u0026#43;hN0WebPkzMJXYPUbsl5yw9Ksf\u0026#43;78GOcMZSMfJBQ2Yzn376BHCObWuhvsqIn4jMc6MTvWL9fmMXNLZFMngN9Fg5aJImai\u0026#43;S\u0026#43;RU=\r\nX-MS-Exchange-Transport-CrossTenantHeadersStamped: BMXPR01MB2294\r\n\u003c/pre\u003e\u003c/body\u003e\u003c/html\u003e",
        "datetimeCreated": "2020-05-21T07:21:55Z",
        "datetimeReceived": "2020-05-21T07:21:56Z",
        "datetimeSent": "2020-05-21T07:21:55Z",
        "hasAttachments": true,
        "headers": [
            {
                "name": "Received",
                "value": "from BMXPR01MB2294.INDPRD01.PROD.OUTLOOK.COM (2603:1096:b00::18) by BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM with HTTPS via BM1PR01CA0102.INDPRD01.PROD.OUTLOOK.COM; Thu, 21 May 2020 07:21:55 +0000"
            },
            {
                "name": "MIME-Version",
                "value": "1.0"
            },
            {
                "name": "Date",
                "value": "Thu, 21 May 2020 07:21:55 +0000"
            },
            {
                "name": "Content-Type",
                "value": "multipart/report"
            },
            {
                "name": "X-MS-Exchange-Organization-SCL",
                "value": "-1"
            },
            {
                "name": "Content-Language",
                "value": "en-US"
            },
            {
                "name": "Message-ID",
                "value": "\u003c2baeef66-4fcb-4d57-a37c-aa13b21d73d0@BMXPR01MB2294.INDPRD01.PROD.OUTLOOK.COM\u003e"
            },
            {
                "name": "In-Reply-To",
                "value": "\u003cBMXPR01MB3767E711DA78E4CD3055FBAC8EB70@BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003e"
            },
            {
                "name": "References",
                "value": "\u003cBMXPR01MB3767E711DA78E4CD3055FBAC8EB70@BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003e"
            },
            {
                "name": "Thread-Topic",
                "value": "Playbook has stopped on error for Incident created from API at 2020-04-22 14:51:23.461941605 +0000 UTC m=+1196833.293197140 (#268)"
            },
            {
                "name": "Thread-Index",
                "value": "AQHWL0CAvYxGZBLvEk+LUeAg02HUMKiyIoJC"
            },
            {
                "name": "Subject",
                "value": "Undeliverable: Playbook has stopped on error for Incident created from API at 2020-04-22 14:51:23.461941605 +0000 UTC m=+1196833.293197140 (#268)"
            },
            {
                "name": "Auto-Submitted",
                "value": "auto-replied"
            },
            {
                "name": "X-MS-PublicTrafficType",
                "value": "Email"
            },
            {
                "name": "X-MS-Exchange-Organization-AuthSource",
                "value": "BMXPR01MB2294.INDPRD01.PROD.OUTLOOK.COM"
            },
            {
                "name": "X-MS-Exchange-Organization-AuthAs",
                "value": "Internal"
            },
            {
                "name": "X-MS-Exchange-Organization-AuthMechanism",
                "value": "05"
            },
            {
                "name": "X-MS-Exchange-Organization-Network-Message-Id",
                "value": "565a1635-e85b-4517-64ab-08d7fd57a43c"
            },
            {
                "name": "X-MS-TrafficTypeDiagnostic",
                "value": "BMXPR01MB2294:"
            },
            {
                "name": "X-MS-Exchange-Organization-ExpirationStartTime",
                "value": "21 May 2020 07:21:55.5557 (UTC)"
            },
            {
                "name": "X-MS-Exchange-Organization-ExpirationStartTimeReason",
                "value": "SideEffectMessage"
            },
            {
                "name": "X-MS-Exchange-Organization-ExpirationInterval",
                "value": "1:00:00:00.0000000"
            },
            {
                "name": "X-MS-Exchange-Organization-ExpirationIntervalReason",
                "value": "SideEffectMessage"
            },
            {
                "name": "X-MS-Oob-TLC-OOBClassifiers",
                "value": "OLM:923;"
            },
            {
                "name": "X-Microsoft-Antispam",
                "value": "BCL:0;"
            },
            {
                "name": "X-Forefront-Antispam-Report",
                "value": "CIP:255.255.255.255;CTRY:;LANG:en;SCL:-1;SRV:;IPV:NLI;SFV:SKI;H:;PTR:;CAT:NONE;SFTY:;SFS:;DIR:INB;SFP:;"
            },
            {
                "name": "X-MS-Exchange-CrossTenant-OriginalArrivalTime",
                "value": "21 May 2020 07:21:55.5587 (UTC)"
            },
            {
                "name": "X-MS-Exchange-CrossTenant-FromEntityHeader",
                "value": "Hosted"
            },
            {
                "name": "X-MS-Exchange-CrossTenant-Network-Message-Id",
                "value": "565a1635-e85b-4517-64ab-08d7fd57a43c"
            },
            {
                "name": "X-MS-Exchange-Transport-CrossTenantHeadersStamped",
                "value": "BMXPR01MB2294"
            },
            {
                "name": "X-MS-Exchange-Organization-MessageDirectionality",
                "value": "Originating"
            },
            {
                "name": "X-MS-Exchange-Transport-EndToEndLatency",
                "value": "00:00:00.1874243"
            },
            {
                "name": "X-MS-Exchange-Processed-By-BccFoldering",
                "value": "15.20.3000.034"
            },
            {
                "name": "X-Microsoft-Antispam-Mailbox-Delivery",
                "value": "ucf:0;jmr:0;auth:0;dest:I;ENG:(750128)(520011016)(706158)(944506383)(944626604);"
            },
            {
                "name": "X-Microsoft-Antispam-Message-Info",
                "value": "cQuvZiUahyW4RBsV6N5pOnraCMFF5bC03+OZwy6+WqHzT6Wn/DLaGRJLq4QLm/lVcrtWQb9t+zsj955uL+9RdLH9MgkmT4f68dUCRQ2jvpX91M1c8PMtMNMrkkutmDf4bWQOKIy5vR5+op0gMeeBJAfHeCJJnfCJ68FyPSkXRjRGo+MGMXJp2J6KGeABFELs3L3tNl+g0gE+0gmTfVtk5Hx3CB+uqqWTpNdAy3VRJ7XLgrBjxdcoHNOg7GYmy6qyv8Bq202i5W7Ex4VRXLKkcDeuDn2o98FByjbU338pXkSoq4EMtDtVKbo2ehvqDKYgE8nr9Ve57NCCSjCpfraa0YkEABZFH9X6vBOuOmgbLwS/JW+z99NaOG+cb1pGmDPuZG9l3t8cETk/Q3aUMYnn7MHwq4IhKoemOIjz2TMsugrY4XMwGw2X7X7+HGzj3iPZpzyXVmdPwsHnemKb5+DoIGILi1T4K7tCaQ7Q5oj5z/Zocz57qq9eX8JtmJjDnPTfGgeuIsiQ6eCMIOlLUAvren+LjW0RfbwwOOv8byoQSkiqb87MYDnU727eIwYgqmsPakbhrBlK13+IJrLqsLJV8iDxJGo0zWktvRyrpcq18iz2EmHGZ42g+kDiKCwI5El+FF/HNjWqA+K+t+OFK823sg=="
            }
        ],
        "importance": "Normal",
        "isRead": false,
        "itemId": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkARgAAA8UvpdPLfBBFk4yzLjFjo38HAKGgXpWqlGBOsYqBLmshp1EAAAIBDAAAAKGgXpWqlGBOsYqBLmshp1EAAAIFggAAAA==",
        "lastModifiedTime": "2020-05-21T07:21:56Z",
        "mailbox": "richa@badava.onmicrosoft.com",
        "messageId": "\u003c2baeef66-4fcb-4d57-a37c-aa13b21d73d0@BMXPR01MB2294.INDPRD01.PROD.OUTLOOK.COM\u003e",
        "receivedBy": "richa@badava.onmicrosoft.com",
        "sender": "MicrosoftExchange329e71ec88ae4615bbc36ab6ce41109e@badava.onmicrosoft.com",
        "size": 194187,
        "subject": "Undeliverable: Playbook has stopped on error for Incident created from API at 2020-04-22 14:51:23.461941605 +0000 UTC m=+1196833.293197140 (#268)",
        "textBody": "[http://products.office.com/en-us/CMSImages/Office365Logo_Orange.png?version=b8d100a9-0a8b-8e6a-88e1-ef488fee0470]\r\nYour message to admin@company.com couldn't be delivered.\r\nadmin wasn't found at company.com.\r\nricha   Office 365      admin\r\nAction Required                 Recipient\r\nUnknown To address\r\n\r\nHow to Fix It\r\nThe address may be misspelled or may not exist. Try one or more of the following:\r\n\r\n  *   Send the message again following these steps: In Outlook, open this non-delivery report (NDR) and choose Send Again from the Report ribbon. In Outlook on the web, select this NDR, then select the link \"To send this message again, click here.\" Then delete and retype the entire recipient address. If prompted with an Auto-Complete List suggestion don't select it. After typing the complete address, click Send.\r\n  *   Contact the recipient (by phone, for example) to check that the address exists and is correct.\r\n  *   The recipient may have set up email forwarding to an incorrect address. Ask them to check that any forwarding they've set up is working correctly.\r\n  *   Clear the recipient Auto-Complete List in Outlook or Outlook on the web by following the steps in this article: Fix email delivery issues for error code 5.1.1 in Office 365\u003chttps://go.microsoft.com/fwlink/?LinkId=389363\u003e, and then send the message again. Retype the entire recipient address before selecting Send.\r\n\r\nIf the problem continues, forward this message to your email admin. If you're an email admin, refer to the More Info for Email Admins section below.\r\n\r\nWas this helpful? Send feedback to Microsoft\u003chttps://go.microsoft.com/fwlink/?LinkId=525920\u003e.\r\n________________________________\r\n\r\nMore Info for Email Admins\r\nStatus code: 550 5.1.1\r\n\r\nThis error occurs because the sender sent a message to an email address outside of Office 365, but the address is incorrect or doesn't exist at the destination domain. The error is reported by the recipient domain's email server, but most often it must be fixed by the person who sent the message. If the steps in the How to Fix It section above don't fix the problem, and you're the email admin for the recipient, try one or more of the following:\r\n\r\nThe email address exists and is correct - Confirm that the recipient address exists, is correct, and is accepting messages.\r\n\r\nSynchronize your directories - If you have a hybrid environment and are using directory synchronization make sure the recipient's email address is synced correctly in both Office 365 and in your on-premises directory.\r\n\r\nErrant forwarding rule - Check for forwarding rules that aren't behaving as expected. Forwarding can be set up by an admin via mail flow rules or mailbox forwarding address settings, or by the recipient via the Inbox Rules feature.\r\n\r\nMail flow settings and MX records are not correct - Misconfigured mail flow or MX record settings can cause this error. Check your Office 365 mail flow settings to make sure your domain and any mail flow connectors are set up correctly. Also, work with your domain registrar to make sure the MX records for your domain are configured correctly.\r\n\r\nFor more information and additional tips to fix this issue, see Fix email delivery issues for error code 550 5.1.1 in Office 365\u003chttps://go.microsoft.com/fwlink/?LinkId=389363\u003e.\r\n\r\nOriginal Message Details\r\nCreated Date:   5/21/2020 7:21:52 AM\r\nSender Address: richa@badava.onmicrosoft.com\r\nRecipient Address:      admin@company.com\r\nSubject:        Playbook has stopped on error for Incident created from API at 2020-04-22 14:51:23.461941605 +0000 UTC m=+1196833.293197140 (#268)\r\n\r\nError Details\r\nReported error: 550 5.1.1 \u003cadmin@company.com\u003e: Email address could not be found, or was misspelled (G8)\r\nDSN generated by:       BMXPR01MB2294.INDPRD01.PROD.OUTLOOK.COM\r\nRemote server:  smtp34.gate.iad3a.rsapps.net\r\n\r\nMessage Hops\r\nHOP     TIME (UTC)      FROM    TO      WITH    RELAY TIME\r\n1       5/21/2020\r\n7:21:52 AM      BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM mapi    *\r\n2       5/21/2020\r\n7:21:52 AM      BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM BMXPR01MB2294.INDPRD01.PROD.OUTLOOK.COM Microsoft SMTP Server (version=TLS1_2, cipher=TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384)    *\r\n\r\nOriginal Message Headers\r\n\r\nARC-Seal: i=1; a=rsa-sha256; s=arcselector9901; d=microsoft.com; cv=none;\r\n b=CzGFvJV0zC6gJggHvV4lC7M54Gq4gMVXTJTZt2nqMuRZnVEab/5a3qKj1OhGeXc5udTbmlkMJJMvcUHCaYPYQT719ZTJ4tqAL0DY7QLu2+izgzq+pdxIypy9UApqOuWOwb5OiT9u321uSOFoggw+KM6XWH36NDU8PPDb1pIHjE79eGffOY8ZiLT1RULU5J/cG2JFKbn2xsSccZXrVChJhfhZgdgmSAiRmdle+XsB2mEesLM5awuCyZOdhL+pozj4+nIofCgsHo53AxEiM6vxmV9IgQpL/bEgXMW2d7BrZ+GqMZITU70RZY6+Zpq6YnsuC7sONW30ODhDx8V0h/E36g==\r\nARC-Message-Signature: i=1; a=rsa-sha256; c=relaxed/relaxed; d=microsoft.com;\r\n s=arcselector9901;\r\n h=From:Date:Subject:Message-ID:Content-Type:MIME-Version:X-MS-Exchange-SenderADCheck;\r\n bh=pbEBPo63JbZVBDgmaZYE7ds6FbOMGo41LrMesmx2320=;\r\n b=J1QswUxh7trJUMRqENQfk/YHeeBATfDcD7B0aRMlSwSw3as3/4iODlHgPTtg8bg6OocjfrgHp5XkE3toWbfwrFZ3s0/OJ1sK5ZnJj2iXCoEfVqQ+G09K7vZJcBrec857pRpn/WXkvrprJlg2D//6Pmx95yKnGkwHx/jbHtV5gn/n3iSJ0Im5Noyd3j2fAsmV2p5wh4yAge6Aj9aIASPMNBh/UiP4Vr4ISv7T6eZYTBiTIFlIIFdNWQ6xYpahJ6rpRgvhU0UTNfJ32ota0bSH+cbbIp2zFDm6MEePT1J0ifwev76Hp9n+JJM+W9Bs378nE0ifVz5yjNb9STly+R03OA==\r\nARC-Authentication-Results: i=1; mx.microsoft.com 1; spf=pass\r\n smtp.mailfrom=badava.onmicrosoft.com; dmarc=pass action=none\r\n header.from=badava.onmicrosoft.com; dkim=pass\r\n header.d=badava.onmicrosoft.com; arc=none\r\nDKIM-Signature: v=1; a=rsa-sha256; c=relaxed/relaxed;\r\n d=badava.onmicrosoft.com; s=selector1-badava-onmicrosoft-com;\r\n h=From:Date:Subject:Message-ID:Content-Type:MIME-Version:X-MS-Exchange-SenderADCheck;\r\n bh=pbEBPo63JbZVBDgmaZYE7ds6FbOMGo41LrMesmx2320=;\r\n b=CbMbBViM3wu/+fezYIMQDmMN5Qqs1os1xKjTQSQrYlbsQme0USRaOkFNAK0YmwyZ085sUYz9ns8uWEK9Fno+HFIjnU0I7NSXmMHHaJ6NUgSBSANv5yVbtfz20C0tgYnm4qcoXj1vc6K3ILah4gtPHmb83kinm+pb42yPWyuCRS4=\r\nReceived: from BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM (2603:1096:b00:59::12)\r\n by BMXPR01MB2294.INDPRD01.PROD.OUTLOOK.COM (2603:1096:b00:39::13) with\r\n Microsoft SMTP Server (version=TLS1_2,\r\n cipher=TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384) id 15.20.3000.27; Thu, 21 May\r\n 2020 07:21:52 +0000\r\nReceived: from BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\r\n ([fe80::1d03:43d1:9bf:ce0d]) by BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\r\n ([fe80::1d03:43d1:9bf:ce0d%7]) with mapi id 15.20.3000.034; Thu, 21 May 2020\r\n 07:21:52 +0000\r\nFrom: richa priyanka \u003cricha@badava.onmicrosoft.com\u003e\r\nTo: \"admin@company.com\" \u003cadmin@company.com\u003e\r\nSubject: Playbook has stopped on error for Incident created from API at\r\n 2020-04-22 14:51:23.461941605 +0000 UTC m=+1196833.293197140 (#268)\r\nThread-Topic: Playbook has stopped on error for Incident created from API at\r\n 2020-04-22 14:51:23.461941605 +0000 UTC m=+1196833.293197140 (#268)\r\nThread-Index: AQHWL0CAvYxGZBLvEk+LUeAg02HUMA==\r\nDate: Thu, 21 May 2020 07:21:52 +0000\r\nMessage-ID: \u003cBMXPR01MB3767E711DA78E4CD3055FBAC8EB70@BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003e\r\nAccept-Language: en-US\r\nContent-Language: en-US\r\nX-MS-Has-Attach:\r\nX-MS-TNEF-Correlator:\r\nauthentication-results: company.com; dkim=none (message not signed)\r\n header.d=none;company.com; dmarc=none action=none\r\n header.from=badava.onmicrosoft.com;\r\nx-originating-ip: [54.176.61.115]\r\nx-ms-publictraffictype: Email\r\nx-ms-office365-filtering-correlation-id: f3d3690c-5d8f-427f-b210-08d7fd57a299\r\nx-ms-traffictypediagnostic: BMXPR01MB2294:\r\nx-microsoft-antispam-prvs: \u003cBMXPR01MB22949002FC7DC4144D983B2F8EB70@BMXPR01MB2294.INDPRD01.PROD.OUTLOOK.COM\u003e\r\nx-ms-oob-tlc-oobclassifiers: OLM:2512;\r\nx-forefront-prvs: 041032FF37\r\nx-ms-exchange-senderadcheck: 1\r\nx-microsoft-antispam: BCL:0;\r\nx-microsoft-antispam-message-info: NCkZPV6GjXJBfSzDJd1KOHN7hvk4KMTSvceziixrh8oB+YpxrJgd/pMhUSQgtdf0gzVLEmULGCc/4Jm/0G+4mtloo7UDQnEVAA6mpWdiL4alphIpU9+Gf0SFq6jtllTdNb54ZNYoENF90qWwV7V3KcqskVYylolJduzU3bWc6LgtHYktB4Hvch7D3ElxwQFIfErDEcQnMIiW944hjnlQpAgSsu9/P04cEVbRsumMi9CoxvE7Yn8+mid/9xl7AZxsyp5jnrQHgpEGKaTN4MMCup0cFejpxsBqx818QkPUKvrgTsY2aVceybpPsAEZlIP/cp878nCzhxjjlgBr18kdDqGqmgaCHKLSQshsHx3lHG5oMs0MpCy5wz+VUZAOIiBWBIvvbJrAcfrmoHJDyhMo80eU9wy0uAuW24LGpx2X6l0KLHPfNjTX7FhlLTH4T2UodESRVZ+zSHA6tNnroDg8ogLWSBvUEwwIKL5zuHpqEPo=\r\nx-forefront-antispam-report: CIP:255.255.255.255;CTRY:;LANG:en;SCL:1;SRV:;IPV:NLI;SFV:NSPM;H:BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM;PTR:;CAT:NONE;SFTY:;SFS:(346002)(366004)(34036004)(136003)(39830400003)(376002)(396003)(55236004)(33656002)(966005)(8676002)(2906002)(316002)(55016002)(6916009)(86362001)(66476007)(8936002)(52536014)(186003)(91956017)(4744005)(76116006)(5660300002)(7696005)(71200400001)(508600001)(64756008)(66946007)(66556008)(66446008)(26005)(6506007)(9686003);DIR:OUT;SFP:1101;\r\nx-ms-exchange-antispam-messagedata: kCAtMUewDsbjqpiWFhNtvBrNPiHIZ4Kj2Y72Ac+6tdiy9td9B4T6PJSQ+qXenoqRpFLYD5PIJ6GR0/en5upPgmdHVJU2A5oyfByTM9duavoa1Ps7SDsVY6WMRg7ICJUiib/hSPciigYOL8RZiNR8yFQ9h7ySmf9o9aB2i6KbOZ6wN4aWLsa4zvALdnsxlXia9ynuQmWL/AuGvrfEMYFGSJhjNZDDsPcq2nGVwKaDVMlJTbLyWC9RPboHi40OCPVU16Mwrsr54ssHRu06jGejD+KQD1dDbK6l6HigL/+VZWIBBCUKf5BryVei1qmk/rhAX7Yf6/5msr2HVi0aHFQD9ifP40nujJ5K2aVdrbqYk/G3csdP7bsq/E1L0W9yyH4FHiYnXCjsd1beVRGhcJfe/YAnL62EOld7rNu942oxH6yhSvxyR/iJLrG8ilFfA+RfHxbyvftLMBSar6G/u0EpoHCTOmhzPJXdqbSoTx+HU+o=\r\nx-ms-exchange-transport-forked: True\r\nContent-Type: text/plain; charset=\"us-ascii\"\r\nContent-Transfer-Encoding: quoted-printable\r\nMIME-Version: 1.0\r\nX-OriginatorOrg: badava.onmicrosoft.com\r\nX-MS-Exchange-CrossTenant-Network-Message-Id: f3d3690c-5d8f-427f-b210-08d7fd57a299\r\nX-MS-Exchange-CrossTenant-originalarrivaltime: 21 May 2020 07:21:52.7788\r\n (UTC)\r\nX-MS-Exchange-CrossTenant-fromentityheader: Hosted\r\nX-MS-Exchange-CrossTenant-id: a3da2674-d726-4da3-9d8e-2b65566ef88a\r\nX-MS-Exchange-CrossTenant-mailboxtype: HOSTED\r\nX-MS-Exchange-CrossTenant-userprincipalname: iLMoJBrmr+hN0WebPkzMJXYPUbsl5yw9Ksf+78GOcMZSMfJBQ2Yzn376BHCObWuhvsqIn4jMc6MTvWL9fmMXNLZFMngN9Fg5aJImai+S+RU=\r\nX-MS-Exchange-Transport-CrossTenantHeadersStamped: BMXPR01MB2294\r\n\r\n",
        "toRecipients": [
            "admin@company.com"
        ]
    },
    {
        "ItemAttachments": [
            {
                "attachmentContentId": "EA4F7EFBFF38564DA07D731AF193DB2D@INDPRD01.PROD.OUTLOOK.COM",
                "attachmentContentLocation": null,
                "attachmentContentType": "message/rfc822",
                "attachmentId": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkARgAAA8UvpdPLfBBFk4yzLjFjo38HAKGgXpWqlGBOsYqBLmshp1EAAAIBDAAAAKGgXpWqlGBOsYqBLmshp1EAAAIFgQAAAAESABAACUnWHuVtUEWy3V5C6TBNqQ==",
                "attachmentIsInline": false,
                "attachmentLastModifiedTime": "2020-05-21T07:21:53+00:00",
                "attachmentName": "Message from Cortex XSOAR Security Operations Server",
                "attachmentSHA256": "798bd2bc884d06d29211649a9322bbcb7201d9149935ba03c6834de0bbee88d9",
                "attachmentSize": 26912,
                "attachmentType": "ItemAttachment",
                "originalItemId": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkARgAAA8UvpdPLfBBFk4yzLjFjo38HAKGgXpWqlGBOsYqBLmshp1EAAAIBDAAAAKGgXpWqlGBOsYqBLmshp1EAAAIFgQAAAA=="
            }
        ],
        "author": "MicrosoftExchange329e71ec88ae4615bbc36ab6ce41109e@badava.onmicrosoft.com",
        "body": "\u003chtml\u003e\u003chead\u003e\r\n\u003cmeta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"\u003e\u003cmeta name=\"viewport\" content=\"width=device-width, initial-scale=1\"\u003e\u003ctitle\u003eDSN\u003c/title\u003e\u003c/head\u003e\u003cbody style=\"        background-color: white;      \"\u003e\u003ctable style=\"        background-color: white;         max-width: 548px;         color: black;         border-spacing: 0px 0px;         padding-top: 0px;         padding-bottom: 0px;        border-collapse: collapse;      \" width=\"548\" cellspacing=\"0\" cellpadding=\"0\"\u003e\u003ctbody\u003e\u003ctr\u003e\u003ctd style=\"        text-align: left;        padding-bottom: 20px;      \"\u003e\u003cimg height=\"28\" width=\"126\" style=\"        max-width: 100%;      \" src=\"http://products.office.com/en-us/CMSImages/Office365Logo_Orange.png?version=b8d100a9-0a8b-8e6a-88e1-ef488fee0470\"\u003e \u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 16px;         padding-bottom: 10px;         -ms-text-size-adjust: 100%;        text-align: left;      \"\u003eYour message to \u003cspan style=\"        color: #0072c6;      \"\u003eadmin@company.com\u003c/span\u003e couldn't be delivered.\u003cbr\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;         font-size: 24px;         padding-top: 0px;         padding-bottom: 20px;         text-align: center;         -ms-text-size-adjust: 100%;      \"\u003e\u003cspan style=\"        color: #0072c6;      \"\u003eadmin\u003c/span\u003e wasn't found at \u003cspan style=\"        color: #0072c6;      \"\u003ecompany.com\u003c/span\u003e.\u003cbr\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        padding-bottom: 15px;         padding-left: 0px;         padding-right: 0px;         border-spacing: 0px 0px;      \"\u003e\u003ctable style=\"        max-width: 548px;         font-weight: 600;        border-spacing: 0px 0px;         padding-top: 0px;         padding-bottom: 0px;        border-collapse: collapse;      \"\u003e\u003ctbody\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 15px;        font-weight: 600;        text-align: left;        width: 181px;        -ms-text-size-adjust: 100%;        vertical-align: bottom;      \"\u003e\u003cfont color=\"#ffffff\"\u003e\u003cspan style=\"color:#000000\"\u003ericha\u003c/span\u003e \u003c/font\u003e\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 15px;        font-weight: 600;        text-align: center;        width: 186px;        -ms-text-size-adjust: 100%;        vertical-align: bottom;      \"\u003e\u003cfont color=\"#ffffff\"\u003e\u003cspan style=\"color:#000000\"\u003eOffice 365\u003c/span\u003e \u003c/font\u003e\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;         -ms-text-size-adjust: 100%;         font-size: 15px;         font-weight: 600;        text-align: right;         width: 181px;         vertical-align: bottom;      \"\u003e\u003cfont color=\"#ffffff\"\u003e\u003cspan style=\"color:#000000\"\u003eadmin\u003c/span\u003e \u003c/font\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;        text-align: left;        padding-top: 0px;        padding-bottom: 0px;        vertical-align: middle;        width: 181px;      \"\u003e\u003cfont color=\"#ffffff\"\u003e\u003cspan style=\"        color: #c00000;      \"\u003e\u003cb\u003eAction Required\u003c/b\u003e \u003c/span\u003e\u003c/font\u003e\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;        text-align: center;        padding-top: 0px;        padding-bottom: 0px;        vertical-align: middle;        width: 186px;      \"\u003e\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;        text-align: right;        padding-top: 0px;        padding-bottom: 0px;        vertical-align: middle;        width: 181px;      \"\u003e\u003cfont color=\"#ffffff\"\u003e\u003cspan style=\"color:#000000\"\u003eRecipient\u003c/span\u003e \u003c/font\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd colspan=\"3\" style=\"        padding-top:0;        padding-bottom:0;        padding-left:0;        padding-right:0      \"\u003e\u003ctable cellspacing=\"0\" cellpadding=\"0\" style=\"        border-spacing: 0px 0px;        padding-top: 0px;        padding-bottom: 0px;        padding-left: 0px;        padding-right: 0px;        border-collapse: collapse;      \"\u003e\u003ctbody\u003e\u003ctr height=\"10\"\u003e\u003ctd width=\"180\" height=\"10\" bgcolor=\"#c00000\" style=\"        width: 180px;        line-height: 10px;        height: 10px;        font-size: 6px;        padding-top: 0;        padding-bottom: 0;        padding-left: 0;        padding-right: 0;      \"\u003e\u003c!--[if gte mso 15]\u003e\u0026nbsp;\u003c![endif]--\u003e\u003c/td\u003e\u003ctd width=\"4\" height=\"10\" bgcolor=\"#ffffff\" style=\"        width: 4px;        line-height: 10px;        height: 10px;        font-size: 6px;        padding-top: 0;        padding-bottom: 0;        padding-left: 0;        padding-right: 0;      \"\u003e\u003c!--[if gte mso 15]\u003e\u0026nbsp;\u003c![endif]--\u003e\u003c/td\u003e\u003ctd width=\"180\" height=\"10\" bgcolor=\"#cccccc\" style=\"        width: 180px;        line-height: 10px;        height: 10px;        font-size: 6px;        padding-top: 0;        padding-bottom: 0;        padding-left: 0;        padding-right: 0;      \"\u003e\u003c!--[if gte mso 15]\u003e\u0026nbsp;\u003c![endif]--\u003e\u003c/td\u003e\u003ctd width=\"4\" height=\"10\" bgcolor=\"#ffffff\" style=\"        width: 4px;        line-height: 10px;        height: 10px;        font-size: 6px;        padding-top: 0;        padding-bottom: 0;        padding-left: 0;        padding-right: 0;      \"\u003e\u003c!--[if gte mso 15]\u003e\u0026nbsp;\u003c![endif]--\u003e\u003c/td\u003e\u003ctd width=\"180\" height=\"10\" bgcolor=\"#cccccc\" style=\"        width: 180px;        line-height: 10px;        height: 10px;        font-size: 6px;        padding-top: 0;        padding-bottom: 0;        padding-left: 0;        padding-right: 0;      \"\u003e\u003c!--[if gte mso 15]\u003e\u0026nbsp;\u003c![endif]--\u003e\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        text-align: left;        width: 181px;        line-height: 20px;        font-weight: 400;        padding-top: 0px;        padding-left: 0px;        padding-right: 0px;        padding-bottom: 0px;      \"\u003e\u003cfont color=\"#ffffff\"\u003e\u003cspan style=\"        color: #c00000;      \"\u003eUnknown To address\u003c/span\u003e \u003c/font\u003e\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        text-align: center;        width: 186px;        line-height: 20px;        font-weight: 400;        padding-top: 0px;        padding-left: 0px;        padding-right: 0px;        padding-bottom: 0px;      \"\u003e\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        text-align: right;        width: 181px;        line-height: 20px;        font-weight: 400;        padding-top: 0px;        padding-left: 0px;        padding-right: 0px;        padding-bottom: 0px;      \"\u003e\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        width: 100%;        padding-top: 0px;        padding-right: 10px;        padding-left: 10px;      \"\u003e\u003cbr\u003e\u003ctable style=\"        width: 100%;        padding-right: 0px;        padding-left: 0px;        padding-top: 0px;        padding-bottom: 0px;        background-color: #f2f5fa;        margin-left: 0px;      \"\u003e\u003ctbody\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 21px;        font-weight: 500;        background-color: #f2f5fa;        padding-top: 0px;        padding-bottom: 0px;        padding-left: 10px;        padding-right: 10px;      \"\u003eHow to Fix It\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 16px;        font-weight: 400;        padding-top: 0px;        padding-bottom: 6px;        padding-left: 10px;        padding-right: 10px;        background-color: #f2f5fa;      \"\u003eThe address may be misspelled or may not exist. Try one or more of the following:\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"         padding-top: 0px;         padding-bottom: 0px;         padding-left: 0px;         padding-right: 0px;        border-spacing: 0px 0px;      \"\u003e\u003cul style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 16px;        font-weight: 400;        margin-left: 40px;        margin-bottom: 5px;        background-color: #f2f5fa;        padding-top: 0px;        padding-bottom: 0px;        padding-left: 6px;        padding-right: 6px;      \"\u003e\u003cli\u003eSend the message again following these steps: In Outlook, open this non-delivery report (NDR) and choose \u003cb\u003eSend Again\u003c/b\u003e from the Report ribbon. In Outlook on the web, select this NDR, then select the link \u0026quot;\u003cb\u003eTo send this message again, click here.\u003c/b\u003e\u0026quot; Then delete and retype the entire recipient address. If prompted with an Auto-Complete List suggestion don't select it. After typing the complete address, click \u003cb\u003eSend\u003c/b\u003e.\u003c/li\u003e\u003cli\u003eContact the recipient (by phone, for example) to check that the address exists and is correct.\u003c/li\u003e\u003cli\u003eThe recipient may have set up email forwarding to an incorrect address. Ask them to check that any forwarding they've set up is working correctly.\u003c/li\u003e\u003cli\u003eClear the recipient Auto-Complete List in Outlook or Outlook on the web by following the steps in this article: \u003ca href=\"https://go.microsoft.com/fwlink/?LinkId=389363\"\u003eFix email delivery issues for error code 5.1.1 in Office 365\u003c/a\u003e, and then send the message again. Retype the entire recipient address before selecting \u003cb\u003eSend\u003c/b\u003e.\u003c/li\u003e\u003c/ul\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 16px;        font-weight: 400;        padding-top: 0px;        padding-bottom: 6px;        padding-left: 10px;        padding-right: 10px;        background-color: #f2f5fa;      \"\u003eIf the problem continues, forward this message to your email admin. If you're an email admin, refer to the \u003cb\u003eMore Info for Email Admins\u003c/b\u003e section below.\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;        padding-top: 10px;        padding-bottom: 0px;        padding-bottom: 4px;      \"\u003e\u003cbr\u003e\u003cem\u003eWas this helpful? \u003ca href=\"https://go.microsoft.com/fwlink/?LinkId=525920\"\u003eSend feedback to Microsoft\u003c/a\u003e.\u003c/em\u003e \u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        -ms-text-size-adjust: 100%;        font-size: 0px;        line-height: 0px;        padding-top: 0px;        padding-bottom: 0px;      \"\u003e\u003chr\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 21px;        font-weight: 500;      \"\u003e\u003cbr\u003eMore Info for Email Admins\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;      \"\u003e\u003cem\u003eStatus code: 550 5.1.1\u003c/em\u003e \u003cbr\u003e\u003cbr\u003eThis error occurs because the sender sent a message to an email address outside of Office 365, but the address is incorrect or doesn't exist at the destination domain. The error is reported by the recipient domain's email server, but most often it must be fixed by the person who sent the message. If the steps in the \u003cb\u003eHow to Fix It\u003c/b\u003e section above don't fix the problem, and you're the email admin for the recipient, try one or more of the following:\u003cbr\u003e\u003cbr\u003e\u003cb\u003eThe email address exists and is correct\u003c/b\u003e - Confirm that the recipient address exists, is correct, and is accepting messages.\u003cbr\u003e\u003cbr\u003e\u003cb\u003eSynchronize your directories\u003c/b\u003e - If you have a hybrid environment and are using directory synchronization make sure the recipient's email address is synced correctly in both Office 365 and in your on-premises directory.\u003cbr\u003e\u003cbr\u003e\u003cb\u003eErrant forwarding rule\u003c/b\u003e - Check for forwarding rules that aren't behaving as expected. Forwarding can be set up by an admin via mail flow rules or mailbox forwarding address settings, or by the recipient via the Inbox Rules feature.\u003cbr\u003e\u003cbr\u003e\u003cb\u003eMail flow settings and MX records are not correct\u003c/b\u003e - Misconfigured mail flow or MX record settings can cause this error. Check your Office 365 mail flow settings to make sure your domain and any mail flow connectors are set up correctly. Also, work with your domain registrar to make sure the MX records for your domain are configured correctly.\u003cbr\u003e\u003cbr\u003eFor more information and additional tips to fix this issue, see \u003ca href=\"https://go.microsoft.com/fwlink/?LinkId=389363\"\u003eFix email delivery issues for error code 550 5.1.1 in Office 365\u003c/a\u003e.\u003cbr\u003e\u003cbr\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 17px;        font-weight: 500;      \"\u003eOriginal Message Details\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-size: 14px;        line-height: 20px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;      \"\u003e\u003ctable style=\"        width: 100%;        border-collapse: collapse;        margin-left: 10px;      \"\u003e\u003ctbody\u003e\u003ctr\u003e\u003ctd valign=\"top\" style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eCreated Date:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003e5/21/2020 7:21:49 AM\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd valign=\"top\" style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eSender Address:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003ericha@badava.onmicrosoft.com\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eRecipient Address:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003eadmin@company.com\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eSubject:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003eMessage from Cortex XSOAR Security Operations Server\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 17px;        font-weight: 500;      \"\u003e\u003cbr\u003eError Details\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-size: 14px;        line-height: 20px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;      \"\u003e\u003ctable style=\"        width: 100%;        border-collapse: collapse;        margin-left: 10px;      \"\u003e\u003ctbody\u003e\u003ctr\u003e\u003ctd valign=\"top\" style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eReported error:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003e\u003cem\u003e550 5.1.1 \u0026lt;admin@company.com\u0026gt;: Email address could not be found, or was misspelled (G8)\u003c/em\u003e \u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eDSN generated by:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003eBMXPR01MB3848.INDPRD01.PROD.OUTLOOK.COM\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        font-size: 14px;        -ms-text-size-adjust: 100%;        white-space: nowrap;        font-weight: 500;        width: 140px;      \"\u003eRemote server:\u003c/td\u003e\u003ctd style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 14px;        font-weight: 400;      \"\u003esmtp32.gate.iad3b.rsapps.net\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003cbr\u003e\u003ctable style=\"width: 880px;\" cellspacing=\"0\"\u003e\u003ctbody\u003e\u003ctr\u003e\u003ctd colspan=\"6\" style=\"        padding-top: 4px;        border-bottom: 1px solid #999999;        padding-bottom: 4px;        line-height: 120%;        font-size: 17px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;      \"\u003eMessage Hops\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        background-color: #f2f5fa;        border-bottom: 1px solid #999999;        white-space: nowrap;        padding: 8px;      \"\u003eHOP\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        background-color: #f2f5fa;        border-bottom: 1px solid #999999;        white-space: nowrap;        padding: 8px;        width: 80px;      \"\u003eTIME (UTC)\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        background-color: #f2f5fa;        border-bottom: 1px solid #999999;        white-space: nowrap;        padding: 8px;      \"\u003eFROM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        background-color: #f2f5fa;        border-bottom: 1px solid #999999;        white-space: nowrap;        padding: 8px;      \"\u003eTO\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        background-color: #f2f5fa;        border-bottom: 1px solid #999999;        white-space: nowrap;        padding: 8px;      \"\u003eWITH\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        background-color: #f2f5fa;        border-bottom: 1px solid #999999;        white-space: nowrap;        padding: 8px;      \"\u003eRELAY TIME\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: center;      \"\u003e1\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;        width: 80px;      \"\u003e5/21/2020\u003cbr\u003e7:21:50 AM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003eBMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003eBMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003emapi\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003e1\u0026nbsp;sec\u003c/td\u003e\u003c/tr\u003e\u003ctr\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: center;      \"\u003e2\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;        width: 80px;      \"\u003e5/21/2020\u003cbr\u003e7:21:50 AM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003eBMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003eBMXPR01MB3848.INDPRD01.PROD.OUTLOOK.COM\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003eMicrosoft SMTP Server (version=TLS1_2, cipher=TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384)\u003c/td\u003e\u003ctd style=\"        font-size: 12px;        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-weight: 500;        border-bottom: 1px solid #999999;        padding: 8px;        text-align: left;      \"\u003e*\u003c/td\u003e\u003c/tr\u003e\u003c/tbody\u003e\u003c/table\u003e\u003cp style=\"        font-family: 'Segoe UI', Frutiger, Arial, sans-serif;        -ms-text-size-adjust: 100%;        font-size: 17px;        font-weight: 500;        padding-top: 4px;        padding-bottom: 0;        margin-top: 19px;        margin-bottom: 5px;      \"\u003eOriginal Message Headers\u003c/p\u003e\u003cpre style=\"        color: gray;        white-space: pre;        padding-top: 0;        margin-top: 5px;      \"\u003eARC-Seal: i=1; a=rsa-sha256; s=arcselector9901; d=microsoft.com; cv=none;\r\n b=GMzcrzBNLsH3YXI9MTKcivhq1Ti9ip5LeAm3HVLelP4HgOQzWqtFrmJcVnKkmmk0sS7xAK523dwQMQ2Vp/h0J/cYtTf1v3am1b\u0026#43;iE6BCje8rP\u0026#43;vkGcmrmGof7PO0Qw/v59JQlFvUsGUyEOdEuTsFRBo7W5wHtkq2ej9pZtMo8XvXEvq8MmY/u/YWJhBKB8FJ6VDrili4FSqxxljPIoVHRDOVcj6wNnnqamjugpFSv7QV7nCauQVRq5T9Zm6Qpnj4/WDFSQh7WTo4gGXBLSicu9CuDClsAhx9lx749w34HiUW7At1Kzc0YIxVAwPv6fTKd9PCcO2K/hca6Qh1cUrcmg==\r\nARC-Message-Signature: i=1; a=rsa-sha256; c=relaxed/relaxed; d=microsoft.com;\r\n s=arcselector9901;\r\n h=From:Date:Subject:Message-ID:Content-Type:MIME-Version:X-MS-Exchange-SenderADCheck;\r\n bh=qIWvkA3bhacvdckysZVE3GPD/jiqEZ\u0026#43;nmgqdAOmGW/k=;\r\n b=lKvEzQ/MPqxEgSBpo8xSMTqj\u0026#43;kSzxwNFoLZIQRqAK72pDX1gNwsLBBOJCcJ22kFsc6lgUOSISonY8WatSAnQtFQ8zvkSDOqAwFMlQ2Y9utOezVj00yM6D1lQKZvK\u0026#43;QDY2VTfbVviY80AYD17xNOCBNXFm\u0026#43;GNxmZ07RM1VZU3p\u0026#43;bS3tMaVz6wj6HBWz1khw328lam54vnqD\u0026#43;KONl7GCqQhPUX3RSdLfU8m5DBs8QaKObEzBd3QFadunTWJWlAQpRC5jPn61T3WqmTExY5ncGswNh3BCY53Cv7fakSTryr6kBYPPWwIDViyvRP5LdKBvW8X2FtrQPCAk9dsaFp9NYZ7w==\r\nARC-Authentication-Results: i=1; mx.microsoft.com 1; spf=pass\r\n smtp.mailfrom=badava.onmicrosoft.com; dmarc=pass action=none\r\n header.from=badava.onmicrosoft.com; dkim=pass\r\n header.d=badava.onmicrosoft.com; arc=none\r\nDKIM-Signature: v=1; a=rsa-sha256; c=relaxed/relaxed;\r\n d=badava.onmicrosoft.com; s=selector1-badava-onmicrosoft-com;\r\n h=From:Date:Subject:Message-ID:Content-Type:MIME-Version:X-MS-Exchange-SenderADCheck;\r\n bh=qIWvkA3bhacvdckysZVE3GPD/jiqEZ\u0026#43;nmgqdAOmGW/k=;\r\n b=pCzIWsdkwV7no4RgfJ03jMdTK/n7\u0026#43;/tUIM1XDCked3EDCgGKtCL9fA6yvPw15IuF2QM8VnvnSPBR0CSzMROlzYnU/FPiY63ToU7DMkZAYE9p1JimQb\u0026#43;ix9Gsy9Y29a4dUyIQr96SIOZbiYxhFPTPTNQHrG49MFiu3BdE0Cdt7eA=\r\nReceived: from BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM (2603:1096:b00:59::12)\r\n by BMXPR01MB3848.INDPRD01.PROD.OUTLOOK.COM (2603:1096:b00:62::17) with\r\n Microsoft SMTP Server (version=TLS1_2,\r\n cipher=TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384) id 15.20.3000.26; Thu, 21 May\r\n 2020 07:21:50 \u0026#43;0000\r\nReceived: from BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\r\n ([fe80::1d03:43d1:9bf:ce0d]) by BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\r\n ([fe80::1d03:43d1:9bf:ce0d%7]) with mapi id 15.20.3000.034; Thu, 21 May 2020\r\n 07:21:50 \u0026#43;0000\r\nFrom: richa priyanka \u0026lt;richa@badava.onmicrosoft.com\u0026gt;\r\nTo: \u0026quot;admin@company.com\u0026quot; \u0026lt;admin@company.com\u0026gt;\r\nSubject: Message from Cortex XSOAR Security Operations Server\r\nThread-Topic: Message from Cortex XSOAR Security Operations Server\r\nThread-Index: AQHWL0B\u0026#43;PsjUzt3PQUiexFCPsm5/yw==\r\nDate: Thu, 21 May 2020 07:21:49 \u0026#43;0000\r\nMessage-ID: \u0026lt;BMXPR01MB376742ED0FCF07D06C4873268EB70@BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u0026gt;\r\nAccept-Language: en-US\r\nContent-Language: en-US\r\nX-MS-Has-Attach:\r\nX-MS-TNEF-Correlator:\r\nauthentication-results: company.com; dkim=none (message not signed)\r\n header.d=none;company.com; dmarc=none action=none\r\n header.from=badava.onmicrosoft.com;\r\nx-originating-ip: [54.176.61.115]\r\nx-ms-publictraffictype: Email\r\nx-ms-office365-filtering-correlation-id: f497fd2b-fbfe-4b7e-08bf-08d7fd57a0f4\r\nx-ms-traffictypediagnostic: BMXPR01MB3848:\r\nx-microsoft-antispam-prvs: \u0026lt;BMXPR01MB3848E84495C2E12F15DC92CE8EB70@BMXPR01MB3848.INDPRD01.PROD.OUTLOOK.COM\u0026gt;\r\nx-ms-oob-tlc-oobclassifiers: OLM:4303;\r\nx-forefront-prvs: 041032FF37\r\nx-ms-exchange-senderadcheck: 1\r\nx-microsoft-antispam: BCL:0;\r\nx-microsoft-antispam-message-info: aCZ2QGtijt672BIVyGt1Ap3iHYmoXv/edQwq0fBfOvDW\u0026#43;Jx4Lxp8ussoIPIhYKRH1rln4vx97bvLPY8oIEjoN2iTJGCT33hpo8QRpuhyO1RNoW492wx11AWnWrODu7W8SbwkawOXEKHWxzEfzyyBySLslUNOPl40IiTlQlVOA5n3SPpeQrPgM2ACpLaIDVMGigmHaSZIm67fiN9RCRQhhwh2bl6C\u0026#43;zVxzcKg9h7BfAAqtYy1WhD0PfgrNpeUo2FnScPdee0ZQlg0auec3fRsjuwhfsWQJGVOqtgz2MSXe64gelsG7P9r\u0026#43;fGTrqecXhNe5C8aWoBLpCNrbTqZRafD\u0026#43;uegKHZxlGMPT\u0026#43;7C7EX29eljgNDAz9rAfXhnLFACFO8uWWjSG8sAzl5fxv4elANGBgftCIfRoL7PTs0ecZJE2E903kJW2EQ4ruGGi7Er\u0026#43;rC78XADia0fWp1Oovf9yAiPkP7xwSOva2dVZKocWN/xBoQ=\r\nx-forefront-antispam-report: CIP:255.255.255.255;CTRY:;LANG:en;SCL:1;SRV:;IPV:NLI;SFV:NSPM;H:BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM;PTR:;CAT:NONE;SFTY:;SFS:(396003)(34036004)(136003)(346002)(39830400003)(376002)(366004)(55016002)(26005)(86362001)(55236004)(5660300002)(6506007)(966005)(33656002)(186003)(316002)(15650500001)(508600001)(6916009)(558084003)(71200400001)(2906002)(9686003)(7696005)(66446008)(8676002)(8936002)(66476007)(64756008)(76116006)(91956017)(52536014)(66556008)(66946007);DIR:OUT;SFP:1101;\r\nx-ms-exchange-antispam-messagedata: 4uZnE2\u0026#43;NjQbwp\u0026#43;WseAwhbNu2uJeD8vbFX0jvzYOg5k0JwYX9BVUsb75RadF6UrlPGpIR917/VHkb2KuFyOBichYSDtkRZzs1iQhNGvrdAoKHUZsgIzE6x98\u0026#43;UAHkOKa/2zwUxndYGwF1YdDB26X5dn0pWOP94xNnnDdzamgj\u0026#43;li/T6IjUzzUc6iGF66Jj6HtHsHlWiaR5/OCcRbJD4Wh3mxjnwq2ZDnb0J\u0026#43;Q97HrdKrG3clmWsUgRykhXdBlbRAgVWqnbuTwJaB3m74buwRYd4pxhcRM32Uv477X/OiNj9cQZJWoEKe8LwTlcze7HSy2FZMGKlTSLtjNNWnWSHvGKvOiCB/har7Tmzv6prSa9wuog4TVLI3AbjEvxotio/tLCsgNa1dbDtMZ/aBhwKrCZyM1vZjwGh7nPZxBPjTKkZs=\r\nx-ms-exchange-transport-forked: True\r\nContent-Type: text/plain; charset=\u0026quot;us-ascii\u0026quot;\r\nContent-Transfer-Encoding: quoted-printable\r\nMIME-Version: 1.0\r\nX-OriginatorOrg: badava.onmicrosoft.com\r\nX-MS-Exchange-CrossTenant-Network-Message-Id: f497fd2b-fbfe-4b7e-08bf-08d7fd57a0f4\r\nX-MS-Exchange-CrossTenant-originalarrivaltime: 21 May 2020 07:21:49.9744\r\n (UTC)\r\nX-MS-Exchange-CrossTenant-fromentityheader: Hosted\r\nX-MS-Exchange-CrossTenant-id: a3da2674-d726-4da3-9d8e-2b65566ef88a\r\nX-MS-Exchange-CrossTenant-mailboxtype: HOSTED\r\nX-MS-Exchange-CrossTenant-userprincipalname: Pxja6wRAA64WEkZmkre6H2H3E338MLPPKhOoVoxYOGVKZpftv\u0026#43;jwv6T/X75VwUY9zXj3RSJoG/mL2NU0gyydW85dN6kXkjXBZvq/fVzGsMQ=\r\nX-MS-Exchange-Transport-CrossTenantHeadersStamped: BMXPR01MB3848\r\n\u003c/pre\u003e\u003c/body\u003e\u003c/html\u003e",
        "datetimeCreated": "2020-05-21T07:21:53Z",
        "datetimeReceived": "2020-05-21T07:21:54Z",
        "datetimeSent": "2020-05-21T07:21:53Z",
        "hasAttachments": true,
        "headers": [
            {
                "name": "Received",
                "value": "from BMXPR01MB3848.INDPRD01.PROD.OUTLOOK.COM (2603:1096:b00:40::14) by BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM with HTTPS via BM1PR01CA0120.INDPRD01.PROD.OUTLOOK.COM; Thu, 21 May 2020 07:21:53 +0000"
            },
            {
                "name": "MIME-Version",
                "value": "1.0"
            },
            {
                "name": "Date",
                "value": "Thu, 21 May 2020 07:21:53 +0000"
            },
            {
                "name": "Content-Type",
                "value": "multipart/report"
            },
            {
                "name": "X-MS-Exchange-Organization-SCL",
                "value": "-1"
            },
            {
                "name": "Content-Language",
                "value": "en-US"
            },
            {
                "name": "Message-ID",
                "value": "\u003c2550c507-8de2-4a14-8333-2e591260a1d0@BMXPR01MB3848.INDPRD01.PROD.OUTLOOK.COM\u003e"
            },
            {
                "name": "In-Reply-To",
                "value": "\u003cBMXPR01MB376742ED0FCF07D06C4873268EB70@BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003e"
            },
            {
                "name": "References",
                "value": "\u003cBMXPR01MB376742ED0FCF07D06C4873268EB70@BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003e"
            },
            {
                "name": "Thread-Topic",
                "value": "Message from Cortex XSOAR Security Operations Server"
            },
            {
                "name": "Thread-Index",
                "value": "AQHWL0B+PsjUzt3PQUiexFCPsm5/y6iyIn8f"
            },
            {
                "name": "Subject",
                "value": "Undeliverable: Message from Cortex XSOAR Security Operations Server"
            },
            {
                "name": "Auto-Submitted",
                "value": "auto-replied"
            },
            {
                "name": "X-MS-PublicTrafficType",
                "value": "Email"
            },
            {
                "name": "X-MS-Exchange-Organization-AuthSource",
                "value": "BMXPR01MB3848.INDPRD01.PROD.OUTLOOK.COM"
            },
            {
                "name": "X-MS-Exchange-Organization-AuthAs",
                "value": "Internal"
            },
            {
                "name": "X-MS-Exchange-Organization-AuthMechanism",
                "value": "05"
            },
            {
                "name": "X-MS-Exchange-Organization-Network-Message-Id",
                "value": "ab651f59-5e70-4d3b-73b4-08d7fd57a2e3"
            },
            {
                "name": "X-MS-TrafficTypeDiagnostic",
                "value": "BMXPR01MB3848:"
            },
            {
                "name": "X-MS-Exchange-Organization-ExpirationStartTime",
                "value": "21 May 2020 07:21:53.2961 (UTC)"
            },
            {
                "name": "X-MS-Exchange-Organization-ExpirationStartTimeReason",
                "value": "SideEffectMessage"
            },
            {
                "name": "X-MS-Exchange-Organization-ExpirationInterval",
                "value": "1:00:00:00.0000000"
            },
            {
                "name": "X-MS-Exchange-Organization-ExpirationIntervalReason",
                "value": "SideEffectMessage"
            },
            {
                "name": "X-MS-Oob-TLC-OOBClassifiers",
                "value": "OLM:449;"
            },
            {
                "name": "X-Microsoft-Antispam",
                "value": "BCL:0;"
            },
            {
                "name": "X-Forefront-Antispam-Report",
                "value": "CIP:255.255.255.255;CTRY:;LANG:en;SCL:-1;SRV:;IPV:NLI;SFV:SKI;H:;PTR:;CAT:NONE;SFTY:;SFS:;DIR:INB;SFP:;"
            },
            {
                "name": "X-MS-Exchange-CrossTenant-OriginalArrivalTime",
                "value": "21 May 2020 07:21:53.2991 (UTC)"
            },
            {
                "name": "X-MS-Exchange-CrossTenant-FromEntityHeader",
                "value": "Hosted"
            },
            {
                "name": "X-MS-Exchange-CrossTenant-Network-Message-Id",
                "value": "ab651f59-5e70-4d3b-73b4-08d7fd57a2e3"
            },
            {
                "name": "X-MS-Exchange-Transport-CrossTenantHeadersStamped",
                "value": "BMXPR01MB3848"
            },
            {
                "name": "X-MS-Exchange-Organization-MessageDirectionality",
                "value": "Originating"
            },
            {
                "name": "X-MS-Exchange-Transport-EndToEndLatency",
                "value": "00:00:00.2173152"
            },
            {
                "name": "X-MS-Exchange-Processed-By-BccFoldering",
                "value": "15.20.3000.034"
            },
            {
                "name": "X-Microsoft-Antispam-Mailbox-Delivery",
                "value": "ucf:0;jmr:0;auth:0;dest:I;ENG:(750128)(520011016)(706158)(944506383)(944626604);"
            },
            {
                "name": "X-Microsoft-Antispam-Message-Info",
                "value": "05GfBuXJeEdDRFw2/XbgSL49faX1t7P7UKc4H2dapI+Et468Wyw1FELuD8IZmuNgcaEEwSALRwUNO2v9+ncNv3gnfpgF0GbvxyV6uBLVmaXTyF479WivaJg77cFJy+JxMSs+Gj1thlB0d5udNwY7bB/4rKPYUkDy06VvvbiI77VCfDKDtrSMvWQGmxCEZhbNrXP3c6o67CAvyx8cyNv7eBYE8FPha5qbpHLZfz/RgMUC3+cil4FyDpl2WOJr0vq2mxwHy1TY6cvFgBg29KuFfgUx//Nk5vA3GbeJ28vSfqqitEh94pBrUEznkgMFNlmbln+MwQWRBS4Vp8E5xanGupXL5/jW6Y02BnWpyNdk7BdjEHUigFUl/V8KmNYXVt7D7KDzu05n5i8sBQIVJ1GqScdg5chvzTsylYX3gkT5ctx0m2v8mVM9xjTRAY73cYNMldFIibqJgymCWebaIve/fd9Lok6SAK70g9malGcZLLvwxjCfYDwNkOm+3Fw6hH21qz2+qMYHDM7baisvPPn1M+3ZamKLmIDUDvBOm6CtaSNul+/KoMM2KToDBRF85DFKqaQgvjwnFdTFAPfKhpiYr9cc+vnaqgoR7hwvVxtlNZr9pjrsIDWn7IdxZISqonNdi81TxDGFIFx62n0AJYrnlQ=="
            }
        ],
        "importance": "Normal",
        "isRead": false,
        "itemId": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkARgAAA8UvpdPLfBBFk4yzLjFjo38HAKGgXpWqlGBOsYqBLmshp1EAAAIBDAAAAKGgXpWqlGBOsYqBLmshp1EAAAIFgQAAAA==",
        "lastModifiedTime": "2020-05-21T07:21:55Z",
        "mailbox": "richa@badava.onmicrosoft.com",
        "messageId": "\u003c2550c507-8de2-4a14-8333-2e591260a1d0@BMXPR01MB3848.INDPRD01.PROD.OUTLOOK.COM\u003e",
        "receivedBy": "richa@badava.onmicrosoft.com",
        "sender": "MicrosoftExchange329e71ec88ae4615bbc36ab6ce41109e@badava.onmicrosoft.com",
        "size": 190004,
        "subject": "Undeliverable: Message from Cortex XSOAR Security Operations Server",
        "textBody": "[http://products.office.com/en-us/CMSImages/Office365Logo_Orange.png?version=b8d100a9-0a8b-8e6a-88e1-ef488fee0470]\r\nYour message to admin@company.com couldn't be delivered.\r\nadmin wasn't found at company.com.\r\nricha   Office 365      admin\r\nAction Required                 Recipient\r\nUnknown To address\r\n\r\nHow to Fix It\r\nThe address may be misspelled or may not exist. Try one or more of the following:\r\n\r\n  *   Send the message again following these steps: In Outlook, open this non-delivery report (NDR) and choose Send Again from the Report ribbon. In Outlook on the web, select this NDR, then select the link \"To send this message again, click here.\" Then delete and retype the entire recipient address. If prompted with an Auto-Complete List suggestion don't select it. After typing the complete address, click Send.\r\n  *   Contact the recipient (by phone, for example) to check that the address exists and is correct.\r\n  *   The recipient may have set up email forwarding to an incorrect address. Ask them to check that any forwarding they've set up is working correctly.\r\n  *   Clear the recipient Auto-Complete List in Outlook or Outlook on the web by following the steps in this article: Fix email delivery issues for error code 5.1.1 in Office 365\u003chttps://go.microsoft.com/fwlink/?LinkId=389363\u003e, and then send the message again. Retype the entire recipient address before selecting Send.\r\n\r\nIf the problem continues, forward this message to your email admin. If you're an email admin, refer to the More Info for Email Admins section below.\r\n\r\nWas this helpful? Send feedback to Microsoft\u003chttps://go.microsoft.com/fwlink/?LinkId=525920\u003e.\r\n________________________________\r\n\r\nMore Info for Email Admins\r\nStatus code: 550 5.1.1\r\n\r\nThis error occurs because the sender sent a message to an email address outside of Office 365, but the address is incorrect or doesn't exist at the destination domain. The error is reported by the recipient domain's email server, but most often it must be fixed by the person who sent the message. If the steps in the How to Fix It section above don't fix the problem, and you're the email admin for the recipient, try one or more of the following:\r\n\r\nThe email address exists and is correct - Confirm that the recipient address exists, is correct, and is accepting messages.\r\n\r\nSynchronize your directories - If you have a hybrid environment and are using directory synchronization make sure the recipient's email address is synced correctly in both Office 365 and in your on-premises directory.\r\n\r\nErrant forwarding rule - Check for forwarding rules that aren't behaving as expected. Forwarding can be set up by an admin via mail flow rules or mailbox forwarding address settings, or by the recipient via the Inbox Rules feature.\r\n\r\nMail flow settings and MX records are not correct - Misconfigured mail flow or MX record settings can cause this error. Check your Office 365 mail flow settings to make sure your domain and any mail flow connectors are set up correctly. Also, work with your domain registrar to make sure the MX records for your domain are configured correctly.\r\n\r\nFor more information and additional tips to fix this issue, see Fix email delivery issues for error code 550 5.1.1 in Office 365\u003chttps://go.microsoft.com/fwlink/?LinkId=389363\u003e.\r\n\r\nOriginal Message Details\r\nCreated Date:   5/21/2020 7:21:49 AM\r\nSender Address: richa@badava.onmicrosoft.com\r\nRecipient Address:      admin@company.com\r\nSubject:        Message from Cortex XSOAR Security Operations Server\r\n\r\nError Details\r\nReported error: 550 5.1.1 \u003cadmin@company.com\u003e: Email address could not be found, or was misspelled (G8)\r\nDSN generated by:       BMXPR01MB3848.INDPRD01.PROD.OUTLOOK.COM\r\nRemote server:  smtp32.gate.iad3b.rsapps.net\r\n\r\nMessage Hops\r\nHOP     TIME (UTC)      FROM    TO      WITH    RELAY TIME\r\n1       5/21/2020\r\n7:21:50 AM      BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM mapi    1 sec\r\n2       5/21/2020\r\n7:21:50 AM      BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM BMXPR01MB3848.INDPRD01.PROD.OUTLOOK.COM Microsoft SMTP Server (version=TLS1_2, cipher=TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384)    *\r\n\r\nOriginal Message Headers\r\n\r\nARC-Seal: i=1; a=rsa-sha256; s=arcselector9901; d=microsoft.com; cv=none;\r\n b=GMzcrzBNLsH3YXI9MTKcivhq1Ti9ip5LeAm3HVLelP4HgOQzWqtFrmJcVnKkmmk0sS7xAK523dwQMQ2Vp/h0J/cYtTf1v3am1b+iE6BCje8rP+vkGcmrmGof7PO0Qw/v59JQlFvUsGUyEOdEuTsFRBo7W5wHtkq2ej9pZtMo8XvXEvq8MmY/u/YWJhBKB8FJ6VDrili4FSqxxljPIoVHRDOVcj6wNnnqamjugpFSv7QV7nCauQVRq5T9Zm6Qpnj4/WDFSQh7WTo4gGXBLSicu9CuDClsAhx9lx749w34HiUW7At1Kzc0YIxVAwPv6fTKd9PCcO2K/hca6Qh1cUrcmg==\r\nARC-Message-Signature: i=1; a=rsa-sha256; c=relaxed/relaxed; d=microsoft.com;\r\n s=arcselector9901;\r\n h=From:Date:Subject:Message-ID:Content-Type:MIME-Version:X-MS-Exchange-SenderADCheck;\r\n bh=qIWvkA3bhacvdckysZVE3GPD/jiqEZ+nmgqdAOmGW/k=;\r\n b=lKvEzQ/MPqxEgSBpo8xSMTqj+kSzxwNFoLZIQRqAK72pDX1gNwsLBBOJCcJ22kFsc6lgUOSISonY8WatSAnQtFQ8zvkSDOqAwFMlQ2Y9utOezVj00yM6D1lQKZvK+QDY2VTfbVviY80AYD17xNOCBNXFm+GNxmZ07RM1VZU3p+bS3tMaVz6wj6HBWz1khw328lam54vnqD+KONl7GCqQhPUX3RSdLfU8m5DBs8QaKObEzBd3QFadunTWJWlAQpRC5jPn61T3WqmTExY5ncGswNh3BCY53Cv7fakSTryr6kBYPPWwIDViyvRP5LdKBvW8X2FtrQPCAk9dsaFp9NYZ7w==\r\nARC-Authentication-Results: i=1; mx.microsoft.com 1; spf=pass\r\n smtp.mailfrom=badava.onmicrosoft.com; dmarc=pass action=none\r\n header.from=badava.onmicrosoft.com; dkim=pass\r\n header.d=badava.onmicrosoft.com; arc=none\r\nDKIM-Signature: v=1; a=rsa-sha256; c=relaxed/relaxed;\r\n d=badava.onmicrosoft.com; s=selector1-badava-onmicrosoft-com;\r\n h=From:Date:Subject:Message-ID:Content-Type:MIME-Version:X-MS-Exchange-SenderADCheck;\r\n bh=qIWvkA3bhacvdckysZVE3GPD/jiqEZ+nmgqdAOmGW/k=;\r\n b=pCzIWsdkwV7no4RgfJ03jMdTK/n7+/tUIM1XDCked3EDCgGKtCL9fA6yvPw15IuF2QM8VnvnSPBR0CSzMROlzYnU/FPiY63ToU7DMkZAYE9p1JimQb+ix9Gsy9Y29a4dUyIQr96SIOZbiYxhFPTPTNQHrG49MFiu3BdE0Cdt7eA=\r\nReceived: from BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM (2603:1096:b00:59::12)\r\n by BMXPR01MB3848.INDPRD01.PROD.OUTLOOK.COM (2603:1096:b00:62::17) with\r\n Microsoft SMTP Server (version=TLS1_2,\r\n cipher=TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384) id 15.20.3000.26; Thu, 21 May\r\n 2020 07:21:50 +0000\r\nReceived: from BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\r\n ([fe80::1d03:43d1:9bf:ce0d]) by BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\r\n ([fe80::1d03:43d1:9bf:ce0d%7]) with mapi id 15.20.3000.034; Thu, 21 May 2020\r\n 07:21:50 +0000\r\nFrom: richa priyanka \u003cricha@badava.onmicrosoft.com\u003e\r\nTo: \"admin@company.com\" \u003cadmin@company.com\u003e\r\nSubject: Message from Cortex XSOAR Security Operations Server\r\nThread-Topic: Message from Cortex XSOAR Security Operations Server\r\nThread-Index: AQHWL0B+PsjUzt3PQUiexFCPsm5/yw==\r\nDate: Thu, 21 May 2020 07:21:49 +0000\r\nMessage-ID: \u003cBMXPR01MB376742ED0FCF07D06C4873268EB70@BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003e\r\nAccept-Language: en-US\r\nContent-Language: en-US\r\nX-MS-Has-Attach:\r\nX-MS-TNEF-Correlator:\r\nauthentication-results: company.com; dkim=none (message not signed)\r\n header.d=none;company.com; dmarc=none action=none\r\n header.from=badava.onmicrosoft.com;\r\nx-originating-ip: [54.176.61.115]\r\nx-ms-publictraffictype: Email\r\nx-ms-office365-filtering-correlation-id: f497fd2b-fbfe-4b7e-08bf-08d7fd57a0f4\r\nx-ms-traffictypediagnostic: BMXPR01MB3848:\r\nx-microsoft-antispam-prvs: \u003cBMXPR01MB3848E84495C2E12F15DC92CE8EB70@BMXPR01MB3848.INDPRD01.PROD.OUTLOOK.COM\u003e\r\nx-ms-oob-tlc-oobclassifiers: OLM:4303;\r\nx-forefront-prvs: 041032FF37\r\nx-ms-exchange-senderadcheck: 1\r\nx-microsoft-antispam: BCL:0;\r\nx-microsoft-antispam-message-info: aCZ2QGtijt672BIVyGt1Ap3iHYmoXv/edQwq0fBfOvDW+Jx4Lxp8ussoIPIhYKRH1rln4vx97bvLPY8oIEjoN2iTJGCT33hpo8QRpuhyO1RNoW492wx11AWnWrODu7W8SbwkawOXEKHWxzEfzyyBySLslUNOPl40IiTlQlVOA5n3SPpeQrPgM2ACpLaIDVMGigmHaSZIm67fiN9RCRQhhwh2bl6C+zVxzcKg9h7BfAAqtYy1WhD0PfgrNpeUo2FnScPdee0ZQlg0auec3fRsjuwhfsWQJGVOqtgz2MSXe64gelsG7P9r+fGTrqecXhNe5C8aWoBLpCNrbTqZRafD+uegKHZxlGMPT+7C7EX29eljgNDAz9rAfXhnLFACFO8uWWjSG8sAzl5fxv4elANGBgftCIfRoL7PTs0ecZJE2E903kJW2EQ4ruGGi7Er+rC78XADia0fWp1Oovf9yAiPkP7xwSOva2dVZKocWN/xBoQ=\r\nx-forefront-antispam-report: CIP:255.255.255.255;CTRY:;LANG:en;SCL:1;SRV:;IPV:NLI;SFV:NSPM;H:BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM;PTR:;CAT:NONE;SFTY:;SFS:(396003)(34036004)(136003)(346002)(39830400003)(376002)(366004)(55016002)(26005)(86362001)(55236004)(5660300002)(6506007)(966005)(33656002)(186003)(316002)(15650500001)(508600001)(6916009)(558084003)(71200400001)(2906002)(9686003)(7696005)(66446008)(8676002)(8936002)(66476007)(64756008)(76116006)(91956017)(52536014)(66556008)(66946007);DIR:OUT;SFP:1101;\r\nx-ms-exchange-antispam-messagedata: 4uZnE2+NjQbwp+WseAwhbNu2uJeD8vbFX0jvzYOg5k0JwYX9BVUsb75RadF6UrlPGpIR917/VHkb2KuFyOBichYSDtkRZzs1iQhNGvrdAoKHUZsgIzE6x98+UAHkOKa/2zwUxndYGwF1YdDB26X5dn0pWOP94xNnnDdzamgj+li/T6IjUzzUc6iGF66Jj6HtHsHlWiaR5/OCcRbJD4Wh3mxjnwq2ZDnb0J+Q97HrdKrG3clmWsUgRykhXdBlbRAgVWqnbuTwJaB3m74buwRYd4pxhcRM32Uv477X/OiNj9cQZJWoEKe8LwTlcze7HSy2FZMGKlTSLtjNNWnWSHvGKvOiCB/har7Tmzv6prSa9wuog4TVLI3AbjEvxotio/tLCsgNa1dbDtMZ/aBhwKrCZyM1vZjwGh7nPZxBPjTKkZs=\r\nx-ms-exchange-transport-forked: True\r\nContent-Type: text/plain; charset=\"us-ascii\"\r\nContent-Transfer-Encoding: quoted-printable\r\nMIME-Version: 1.0\r\nX-OriginatorOrg: badava.onmicrosoft.com\r\nX-MS-Exchange-CrossTenant-Network-Message-Id: f497fd2b-fbfe-4b7e-08bf-08d7fd57a0f4\r\nX-MS-Exchange-CrossTenant-originalarrivaltime: 21 May 2020 07:21:49.9744\r\n (UTC)\r\nX-MS-Exchange-CrossTenant-fromentityheader: Hosted\r\nX-MS-Exchange-CrossTenant-id: a3da2674-d726-4da3-9d8e-2b65566ef88a\r\nX-MS-Exchange-CrossTenant-mailboxtype: HOSTED\r\nX-MS-Exchange-CrossTenant-userprincipalname: Pxja6wRAA64WEkZmkre6H2H3E338MLPPKhOoVoxYOGVKZpftv+jwv6T/X75VwUY9zXj3RSJoG/mL2NU0gyydW85dN6kXkjXBZvq/fVzGsMQ=\r\nX-MS-Exchange-Transport-CrossTenantHeadersStamped: BMXPR01MB3848\r\n\r\n",
        "toRecipients": [
            "admin@company.com"
        ]
    }
]'''
    return json.dumps({"results": get_items_from_folder_response}) 

@ews_api.route(f'/{BASE_URL}/get-attachment')
def get_attachment():
    get_attachment_response = r'''{
    "attachmentContentId": "9E9814D2BFFCAA4CBE931EDB2835DBB5@INDPRD01.PROD.OUTLOOK.COM",
    "attachmentContentType": "message/rfc822",
    "attachmentId": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkARgAAA8UvpdPLfBBFk4yzLjFjo38HAKGgXpWqlGBOsYqBLmshp1EAAAIBDAAAAKGgXpWqlGBOsYqBLmshp1EAAAIFhQAAAAESABAAFoD0cLCL9Ey7HWZfKiylbA==",
    "attachmentIsInline": false,
    "attachmentLastModifiedTime": "2020-05-21T07:46:13+00:00",
    "attachmentName": "Message from Cortex XSOAR Security Operations Server",
    "attachmentSHA256": "593f44935f5a2def6bac6051405d45a397019196e24e96efe425f7c527c93cff",
    "attachmentSize": 26592,
    "attachmentType": "ItemAttachment",
    "author": "richa@badava.onmicrosoft.com",
    "body": "DBot has updated an incident Incident created from API at 2020-04-22 14:51:23.461941605 +0000 UTC m=+1196833.293197140.\nView it on https://ip-172-31-11-183.us-west-1.compute.internal:443#/WarRoom/268",
    "datetimeCreated": "2020-05-21T07:46:13Z",
    "datetimeReceived": "2020-05-21T07:46:09Z",
    "datetimeSent": "2020-05-21T07:46:09Z",
    "hasAttachments": false,
    "headers": [
        {
            "name": "ARC-Seal",
            "value": "i=1; a=rsa-sha256; s=arcselector9901; d=microsoft.com; cv=none; b=ZCd/6UGIYyL8ichvpiAlOcSG6YIR+YnQkKqF174fmH1PvIP+MiQSMb6Tx0mzMJc3GazmJkPABrd6W9n1saUjW0eNjrqg2+tmOFzHe1zhs10Om39mV5MYTUwyT1xtU5w/EY8IL6+ovGjNZZmzhXANPmxjAmLzO0sQPD4Tf+W0jrYs9EZyWmntf7ELc2O3QtFlZxFh4hOhce9XPkqzNTFeEzXMYM/HVo8cxTLcZUz+/KE0kixgwn2Ca6ZT0h1Zp8GqwOtSuvqHFH3VAsFMkTpmMElj71hwB4z+Kr/gj3w7bgyaNTbOB+G/TWbQsU41ZriM2GvPKaybbG+Jw2HLMu/xGQ=="
        },
        {
            "name": "ARC-Message-Signature",
            "value": "i=1; a=rsa-sha256; c=relaxed/relaxed; d=microsoft.com; s=arcselector9901; h=From:Date:Subject:Message-ID:Content-Type:MIME-Version:X-MS-Exchange-SenderADCheck; bh=qIWvkA3bhacvdckysZVE3GPD/jiqEZ+nmgqdAOmGW/k=; b=IFEb/cJFmy5dWshqDYzxiuFmqAK9ZceHmKqxw4FFSHOROFGXqe2PKHHc5EBsznOvma5eKg3zakonZm4eVo0v5++3Axg4cPCOwA/Y5BAj2XzJEWSk4R7AgbpdhWqOogd7MIZzyjAzDnRCl6h0dO8uggX8R7rtNZWWvX843E0jqo5QfgTnBNaqy90mMlbQ0WIampZyNrneRbSZwjRN1NMGSRFcAj1M4PW4z+bmWtiQ4UYuaZiu4YXwRlre8L/L+BPwIrQhm3d2THCAX57P1RHxukIaKTUa8t8CNuTMYxIvJrttbNB2A0OAbD8wrT/+aCnXpuiXbfZ/QLPk+XKzN0n3lw=="
        },
        {
            "name": "ARC-Authentication-Results",
            "value": "i=1; mx.microsoft.com 1; spf=pass smtp.mailfrom=badava.onmicrosoft.com; dmarc=pass action=none header.from=badava.onmicrosoft.com; dkim=pass header.d=badava.onmicrosoft.com; arc=none"
        },
        {
            "name": "DKIM-Signature",
            "value": "v=1; a=rsa-sha256; c=relaxed/relaxed; d=badava.onmicrosoft.com; s=selector1-badava-onmicrosoft-com; h=From:Date:Subject:Message-ID:Content-Type:MIME-Version:X-MS-Exchange-SenderADCheck; bh=qIWvkA3bhacvdckysZVE3GPD/jiqEZ+nmgqdAOmGW/k=; b=c8CalLXQJY3COuq+JOflwXBgv4iUr88u4TUlN2dkdFzFRtZXAsxeg+noESYwLVKUN36CREFpqmMS0fE9FhX267SYtMUU8prgApeah/wvw98GYyU3wfPf7HLmoyIOgIibbd8rMrwR23RRq+DU4gEot2yeBdHDtlK4cCsnnuuBxlA="
        },
        {
            "name": "Received",
            "value": "from BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM (2603:1096:b00:59::12) by BMXPR01MB4101.INDPRD01.PROD.OUTLOOK.COM (2603:1096:b00:5b::10) with Microsoft SMTP Server (version=TLS1_2, cipher=TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384) id 15.20.3021.25; Thu, 21 May 2020 07:46:09 +0000"
        },
        {
            "name": "Received",
            "value": "from BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM ([fe80::1d03:43d1:9bf:ce0d]) by BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM ([fe80::1d03:43d1:9bf:ce0d%7]) with mapi id 15.20.3000.034; Thu, 21 May 2020 07:46:09 +0000"
        },
        {
            "name": "Subject",
            "value": "Message from Cortex XSOAR Security Operations Server"
        },
        {
            "name": "Thread-Topic",
            "value": "Message from Cortex XSOAR Security Operations Server"
        },
        {
            "name": "Thread-Index",
            "value": "AQHWL0Pk8vBDxq2wYUCqRgfhK1FjKg=="
        },
        {
            "name": "Date",
            "value": "Thu, 21 May 2020 07:46:09 +0000"
        },
        {
            "name": "Message-ID",
            "value": "\u003cBMXPR01MB3767F19E1B1D8D3E94D8B0DA8EB70@BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003e"
        },
        {
            "name": "Accept-Language",
            "value": "en-US"
        },
        {
            "name": "Content-Language",
            "value": "en-US"
        },
        {
            "name": "authentication-results",
            "value": "company.com; dkim=none (message not signed) header.d=none;company.com; dmarc=none action=none header.from=badava.onmicrosoft.com;"
        },
        {
            "name": "x-originating-ip",
            "value": "[54.176.61.115]"
        },
        {
            "name": "x-ms-publictraffictype",
            "value": "Email"
        },
        {
            "name": "x-ms-office365-filtering-correlation-id",
            "value": "8f372d9c-e814-449c-7aba-08d7fd5b06f6"
        },
        {
            "name": "x-ms-traffictypediagnostic",
            "value": "BMXPR01MB4101:"
        },
        {
            "name": "x-microsoft-antispam-prvs",
            "value": "\u003cBMXPR01MB41013D5627E9E28823D06CAE8EB70@BMXPR01MB4101.INDPRD01.PROD.OUTLOOK.COM\u003e"
        },
        {
            "name": "x-ms-oob-tlc-oobclassifiers",
            "value": "OLM:4303;"
        },
        {
            "name": "x-forefront-prvs",
            "value": "041032FF37"
        },
        {
            "name": "x-ms-exchange-senderadcheck",
            "value": "1"
        },
        {
            "name": "x-microsoft-antispam",
            "value": "BCL:0;"
        },
        {
            "name": "x-microsoft-antispam-message-info",
            "value": "tfAMtifaKFUYVOp5ydeBeJ1pQLP4pVXdCTeFTd7HtWr5NDHz7pHSdjL+3lGo0xwieEvZZeKRt2URYd4w3mPUzpKqj3QtTOZm+r6TT4CZFnSV8hFMNprW0eCUl4p9clZrWF+vOPKAaiZg44mVaeeF7sVDutwLfYjS/eNJbXY0NAl/TFZ6FEg4foiGEFIbe/f3B78bKhIWuN7dunrNTC1oaxwmBe9EqRqVZ32/Sv63qNcqYAAeRnQlZnXNcOxgiHkv5OcvA4PhR4dZq8jNuJZYWd3aZoH4UT9zQ2lHmXqpM47YE878fOfRj7F6BKSRjgSwFv0an1JTb8KKlDDAEus7Oz/7lb7ga65DX5CKSel+HX8="
        },
        {
            "name": "x-forefront-antispam-report",
            "value": "CIP:255.255.255.255;CTRY:;LANG:en;SCL:1;SRV:;IPV:NLI;SFV:NSPM;H:BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM;PTR:;CAT:NONE;SFTY:;SFS:(34036004)(136003)(366004)(396003)(346002)(39830400003)(376002)(26005)(186003)(558084003)(9686003)(508600001)(86362001)(966005)(8676002)(2906002)(6916009)(5660300002)(71200400001)(52536014)(7696005)(55236004)(6506007)(66446008)(66476007)(64756008)(66556008)(66946007)(55016002)(33656002)(15650500001)(91956017)(8936002)(316002)(76116006);DIR:OUT;SFP:1101;"
        },
        {
            "name": "x-ms-exchange-antispam-messagedata",
            "value": "reX2X2StahPOTjGnBUVhcORncp/8tp+uz+XY4pednPkQRY4JDnvlxo0NtvvbTPUjBTu03PbCT0bjMSVwEw27x8g5SYn7sbibs1bp2OYyWxmEC/gQAhg6wBguGlLyscRyADZStyfpqPF/VAjEgRKUybOnmEa+qqiq+1DP8T6gn5w4eH5fSWAYcL7EFIKX8m6RnIWuQmDJS0ufH1/1IzlrlkbEXy6LIStcI0p6RPHiRgFhWrw531DaoUne6j7HCUERWI3x4vExDQOfd2U+/KLCAeAIdPkXCZf4m08PFltIJG/svWzelkjUgGkYdfjWyzJnyrcnx3L5DuhndpgpuI/dh7PV7UchvHv1+Hq2rn9wxrIsivhW1qeb7sMjkXwz6YbK91BuSuUSjZz/O5caEUhV1sbB6rKXPo2Br08uuDrGlSgSO/F5eOQRcxnpydoI1eOiFP4iKRs+vqipCBjuxwODNR4nDhhbxY7haHn8mduByV4="
        },
        {
            "name": "x-ms-exchange-transport-forked",
            "value": "True"
        },
        {
            "name": "Content-Type",
            "value": "text/plain"
        },
        {
            "name": "Content-Transfer-Encoding",
            "value": "quoted-printable"
        },
        {
            "name": "MIME-Version",
            "value": "1.0"
        },
        {
            "name": "X-OriginatorOrg",
            "value": "badava.onmicrosoft.com"
        },
        {
            "name": "X-MS-Exchange-CrossTenant-Network-Message-Id",
            "value": "8f372d9c-e814-449c-7aba-08d7fd5b06f6"
        },
        {
            "name": "X-MS-Exchange-CrossTenant-originalarrivaltime",
            "value": "21 May 2020 07:46:09.5723 (UTC)"
        },
        {
            "name": "X-MS-Exchange-CrossTenant-fromentityheader",
            "value": "Hosted"
        },
        {
            "name": "X-MS-Exchange-CrossTenant-id",
            "value": "a3da2674-d726-4da3-9d8e-2b65566ef88a"
        },
        {
            "name": "X-MS-Exchange-CrossTenant-mailboxtype",
            "value": "HOSTED"
        },
        {
            "name": "X-MS-Exchange-CrossTenant-userprincipalname",
            "value": "9EkulCQ+CVphdRLj8I9sa4xrwvnzs9WhHDVzbtmGKeBMdTpXxKWf5gvY8tuxrnf28ldaAjI7sCUBZb6EmYWkrzQIVWwRiRMYAIclZv85E4I="
        },
        {
            "name": "X-MS-Exchange-Transport-CrossTenantHeadersStamped",
            "value": "BMXPR01MB4101"
        }
    ],
    "importance": "Normal",
    "isRead": true,
    "lastModifiedTime": "2020-05-21T07:46:13Z",
    "mailbox": "richa@badava.onmicrosoft.com",
    "messageId": "\u003cBMXPR01MB3767F19E1B1D8D3E94D8B0DA8EB70@BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM\u003e",
    "originalItemId": "AQMkADNkNTc0ODYxLWVjZmYALTQyZGMtOWFmNi1mN2Q1YjU3ZjBjODkARgAAA8UvpdPLfBBFk4yzLjFjo38HAKGgXpWqlGBOsYqBLmshp1EAAAIBDAAAAKGgXpWqlGBOsYqBLmshp1EAAAIFhQAAAA==",
    "sender": "richa@badava.onmicrosoft.com",
    "size": 26261,
    "subject": "Message from Cortex XSOAR Security Operations Server",
    "toRecipients": [
        "admin@company.com"
    ]
}'''
    return get_attachment_response

@ews_api.route(f'/{BASE_URL}/get-autodiscovery-config')
def get_autodiscovery_config():
    get_autodiscovery_config_response = '''
    {
    "api_version": "Exchange2016",
    "auth_type": "basic",
    "build": "15.20.3000.34",
    "service_endpoint": "https://outlook.office365.com/EWS/Exchange.asmx"
}'''
    return get_autodiscovery_config_response

@ews_api.route(f'/{BASE_URL}/get-ooo')
def get_ooo():
    get_ooo_response = '''{
    "end": "2020-05-28T07:00:00Z",
    "externalAudience": "All",
    "mailbox": "richa@badava.onmicrosoft.com",
    "start": "2020-05-27T07:00:00Z",
    "state": "Disabled",
    "internal_reply": "Hi, thanks for reaching out! I am out of office, and will get back to your email with a delay.",
    "external_reply": "Hi, thanks for reaching out! I am out of office, kindly write to mikescott@sabre.com for urgent issues."
}'''
    return get_ooo_response

@ews_api.route(f'/{BASE_URL}/expand-group')
def expand_group():
    expand_group_response = r'''{
    "members": [
        {
            "displayName": "Angela Kinsey",
            "mailbox": "akinsey@sabre.onmicrosoft.com",
            "mailboxType": "Mailbox"
        },
        {
            "displayName": "Pam Besley",
            "mailbox": "pbeesley@sabre.onmicrosoft.com",
            "mailboxType": "Mailbox"
        }
    ],
    "name": "threathunters@badava.onmicrosoft.com"
}'''
    return expand_group_response

@ews_api.route(f'/{BASE_URL}/get-contacts')
def get_contacts():
    get_contacts_response = r'''{"results":[
    {
        "changekey": "EQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAFMNPC",
        "companyName": "Sabre",
        "culture": "en-US",
        "datetimeCreated": "2020-05-28T12:19:32Z",
        "datetimeReceived": "2020-05-28T12:19:32Z",
        "datetimeSent": "2020-05-28T12:19:32Z",
        "displayName": "Pam Beesley",
        "emailAddresses": [
            "akinsey@sabre.com"
        ],
        "fileAs": "Kinsey, Angela",
        "fileAsMapping": "LastCommaFirst",
        "givenName": "Pam",
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQBGAAAAAADFL6XTy3wQRZOMsy4xY6N/BwChoF6VqpRgTrGKgS5rIadRAAAAAAEOAAChoF6VqpRgTrGKgS5rIadRAAAFMyyvAAA=",
        "importance": "Normal",
        "itemClass": "IPM.Contact",
        "lastModifiedName": "Pam Beesley",
        "lastModifiedTime": "2020-05-28T12:19:32Z",
        "phoneNumbers": [
            {
                "label": "MobilePhone",
                "phoneNumber": "+91-8473020934"
            }
        ],
        "postalAddressIndex": "None",
        "sensitivity": "Normal",
        "subject": "Angela Kinsey - Sabre",
        "surname": "Kinsey",
        "uniqueBody": "\u003chtml\u003e\u003cbody\u003e\u003c/body\u003e\u003c/html\u003e",
        "webClientReadFormQueryString": "https://outlook.office365.com/owa/?ItemID=AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQBGAAAAAADFL6XTy3wQRZOMsy4xY6N%2FBwChoF6VqpRgTrGKgS5rIadRAAAAAAEOAAChoF6VqpRgTrGKgS5rIadRAAAFMyyvAAA%3D\u0026exvsurl=1\u0026viewmodel=PersonaCardViewModelFactory"
    },
    {
        "changekey": "EQAAABYAAAChoF6VqpRgTrGKgS5rIadRAAAFMNOl",
        "culture": "en-US",
        "datetimeCreated": "2020-05-28T12:17:18Z",
        "datetimeReceived": "2020-05-28T12:17:18Z",
        "datetimeSent": "2020-05-28T12:17:18Z",
        "displayName": "Kelly Kapoor",
        "emailAddresses": [
            "kellyk@sabre.onmicrosoft.com"
        ],
        "fileAs": "kepoor, kelly",
        "fileAsMapping": "LastCommaFirst",
        "givenName": "Kelly",
        "id": "AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQBGAAAAAADFL6XTy3wQRZOMsy4xY6N/BwChoF6VqpRgTrGKgS5rIadRAAAAAAEOAAChoF6VqpRgTrGKgS5rIadRAAAFMyyuAAA=",
        "importance": "Normal",
        "itemClass": "IPM.Contact",
        "lastModifiedName": "Pam Beesley",
        "lastModifiedTime": "2020-05-28T12:17:18Z",
        "phoneNumbers": [
            {
                "label": "BusinessPhone",
                "phoneNumber": "4250000000"
            }
        ],
        "physicalAddresses": [
            {
                "city": null,
                "country": "India",
                "label": "Business",
                "state": null,
                "street": null,
                "zipcode": null
            }
        ],
        "postalAddressIndex": "None",
        "sensitivity": "Normal",
        "subject": "Kelly Kapoor",
        "surname": "kelly",
        "uniqueBody": "\u003chtml\u003e\u003cbody\u003e\u003c/body\u003e\u003c/html\u003e",
        "webClientReadFormQueryString": "https://outlook.office365.com/owa/?ItemID=AAMkADNkNTc0ODYxLWVjZmYtNDJkYy05YWY2LWY3ZDViNTdmMGM4OQBGAAAAAADFL6XTy3wQRZOMsy4xY6N%2FBwChoF6VqpRgTrGKgS5rIadRAAAAAAEOAAChoF6VqpRgTrGKgS5rIadRAAAFMyyuAAA%3D\u0026exvsurl=1\u0026viewmodel=PersonaCardViewModelFactory"
    }
]}'''
    return get_contacts_response

@ews_api.route(f'/{BASE_URL}/get-file')
def get_file():
    get_file_response = r'''From nobody Thu May 28 13:46:37 2020
Received: from MA1PR01MB2937.INDPRD01.PROD.OUTLOOK.COM (2603:1096:b00:c::29)
 by BMXPR01MB3767.INDPRD01.PROD.OUTLOOK.COM with HTTPS via
 BMXPR01CA0043.INDPRD01.PROD.OUTLOOK.COM; Thu, 28 May 2020 13:42:11 +0000
Received: from BM1PR01CA0099.INDPRD01.PROD.OUTLOOK.COM (2603:1096:b00::15) by
 MA1PR01MB2937.INDPRD01.PROD.OUTLOOK.COM (2603:1096:a00:3d::19) with
 Microsoft
 SMTP Server (version=TLS1_2, cipher=TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384) id
 15.20.3021.23; Thu, 28 May 2020 13:42:09 +0000
Received: from BO1IND01FT008.eop-IND01.prod.protection.outlook.com
 (2603:1096:b00::4) by BM1PR01CA0099.outlook.office365.com (2603:1096:b00::15)
 with Microsoft SMTP Server (version=TLS1_2,
 cipher=TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384) id 15.20.3045.19 via Frontend
 Transport; Thu, 28 May 2020 13:42:09 +0000
Authentication-Results: spf=pass (sender IP is 209.85.167.53)
 smtp.mailfrom=gmail.com; badava.onmicrosoft.com; dkim=pass (signature was
 verified) header.d=gmail.com;badava.onmicrosoft.com; dmarc=pass action=none
 header.from=gmail.com;compauth=pass reason=100
Received-SPF: Pass (protection.outlook.com: domain of gmail.com designates
 209.85.167.53 as permitted sender) receiver=protection.outlook.com;
 client-ip=209.85.167.53; helo=mail-lf1-f53.google.com;
Received: from mail-lf1-f53.google.com (209.85.167.53) by
 BO1IND01FT008.mail.protection.outlook.com (10.152.202.71) with Microsoft SMTP
 Server (version=TLS1_2, cipher=TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384) id
 15.20.3045.17 via Frontend Transport; Thu, 28 May 2020 13:42:08 +0000
Received: by mail-lf1-f53.google.com with SMTP id u16so14835212lfl.8
 for <richa@badava.onmicrosoft.com>; Thu, 28 May 2020 06:42:08 -0700 (PDT)
DKIM-Signature: v=1; a=rsa-sha256; c=relaxed/relaxed; d=gmail.com; s=20161025;
 h=mime-version:references:in-reply-to:from:date:message-id:subject:to;
 bh=n/5RmzyYXlzLDkqkIDi78YHR+zoO0FszBIeg6PN7IYw=;
 b=PXHvdTYp5TrBpwFm/o0lTkXB6gul56RVRL8xuaUS33hrz5pQUHrw1m+1pN4jK7iDFP
 sgcf3b9gAoJtiuRDo3crQukuwb+b1ikyygNhXn9YCyYrtDR/wLXrk+D1kYeTa4YcmABj
 BSWYin7la1+sU6RgHvNnVD3WXzbBPwSBlmZxz1Wz81N4HxSv8KrdCuN60aow+8H0ebBm
 jfxyUSftn3myhtMCkHHezz3/UoEV9T30goWXmjJWX+UPvTyJGS2e9TIZDDl5DZ2KG57i
 9VNwj17tjMryHZu6nBOHw265sgC6GBnHVWF0RKW4eBVST+x9JovSZze+kl2au7VKV6JA
 zSpA==
X-Google-DKIM-Signature: v=1; a=rsa-sha256; c=relaxed/relaxed;
 d=1e100.net; s=20161025;
 h=x-gm-message-state:mime-version:references:in-reply-to:from:date
 :message-id:subject:to;
 bh=n/5RmzyYXlzLDkqkIDi78YHR+zoO0FszBIeg6PN7IYw=;
 b=AqYK4091RS2ROjJzA5ybTk3/5ROqVqR1JPHpMuE7+vSxKPpU8arM9ZCkEMgJGx2g55
 zmko3nCaIYJf57gMmIHo9NukcVqOReJjzM0c+LzYoEVTyhqH3AJ7uK2QMz9p8pF00aZq
 sAubAbgVC+vJQm/8uEr8V4CkllPsP0cwAGwiAixu3mxbfIk2zODHiRwZ9rn86t4BE/zL
 /+ihIxOSybenhMFnX6phagdeHpKME218Lre/TRUn+YU4G2GAsukAdEgr9J+Yk8Wv1Zp6
 lvj7BEgVwO+NZIYyNuQBivc9G5SepgHFWb5bNXWv1ez7zhK5Akb9czU/GYASVTd7JS5x
 v4Og==
X-Gm-Message-State: AOAM5321d3n5E7gUkKmVWliBEgO7MJGDCqWfEwdfqno46qke+NByFtg7
 lstSG+GT4iI3L5XhNpPzo0ipK9ga/M9z0enuvec+cBYP
X-Google-Smtp-Source: ABdhPJwMufv5JeQDm/aE2iAlWHuCHfnxNCeRO56ekmlgYHG/2e1myRWvwAoKRtypBAiZnVC2vCVp+phFCwhnzuHLq6E=
X-Received: by 2002:a19:987:: with SMTP id 129mr1732586lfj.8.1590673325749;
 Thu, 28 May 2020 06:42:05 -0700 (PDT)
References: <CAFZmXLsVri==hnPOvH7La09LM5LWVXJf_DvP=_vKZS=NVRtqTw@mail.gmail.com>
In-Reply-To: <CAFZmXLsVri==hnPOvH7La09LM5LWVXJf_DvP=_vKZS=NVRtqTw@mail.gmail.com>
From: richa priyanka <itsrichap@gmail.com>
Date: Thu, 28 May 2020 19:11:54 +0530
Message-ID: <CAFZmXLt5pZVYnC=Hay3+-xvQGEa2QUA=DsbdLrRkyi+C=eorLA@mail.gmail.com>
Subject: Quantum String Reports
To: richa@badava.onmicrosoft.com
Content-Type: multipart/alternative; boundary="00000000000088fa8205a6b57e97"
Return-Path: itsrichap@gmail.com
X-MS-Exchange-Organization-ExpirationStartTime: 28 May 2020 13:42:09.0029 (UTC)
X-MS-Exchange-Organization-ExpirationStartTimeReason: OriginalSubmit
X-MS-Exchange-Organization-ExpirationInterval: 1:00:00:00.0000000
X-MS-Exchange-Organization-ExpirationIntervalReason: OriginalSubmit
X-MS-Exchange-Organization-Network-Message-Id: 18752b48-ed8c-44a3-8033-08d8030ceaff
X-EOPAttributedMessage: 0
X-EOPTenantAttributedMessage: a3da2674-d726-4da3-9d8e-2b65566ef88a:0
X-MS-Exchange-Organization-MessageDirectionality: Incoming
X-Forefront-Antispam-Report: CIP:209.85.167.53; CTRY:US; LANG:en; SCL:6; SRV:;
 IPV:NLI; SFV:BLK; H:mail-lf1-f53.google.com; PTR:mail-lf1-f53.google.com;
 CAT:SPM; SFTY:; SFS:; DIR:INB; SFP:;
X-MS-PublicTrafficType: Email
X-MS-Exchange-Organization-AuthSource: BO1IND01FT008.eop-IND01.prod.protection.outlook.com
X-MS-Exchange-Organization-AuthAs: Anonymous
X-MS-Office365-Filtering-Correlation-Id: 18752b48-ed8c-44a3-8033-08d8030ceaff
X-MS-TrafficTypeDiagnostic: MA1PR01MB2937:
X-MS-Oob-TLC-OOBClassifiers: OLM:1091;
X-MS-Exchange-Organization-SCL: 6
X-Microsoft-Antispam: BCL:0;
X-MS-Exchange-CrossTenant-OriginalArrivalTime: 28 May 2020 13:42:08.7470 (UTC)
X-MS-Exchange-CrossTenant-Network-Message-Id: 18752b48-ed8c-44a3-8033-08d8030ceaff
X-MS-Exchange-CrossTenant-Id: a3da2674-d726-4da3-9d8e-2b65566ef88a
X-MS-Exchange-CrossTenant-FromEntityHeader: Internet
X-MS-Exchange-Transport-CrossTenantHeadersStamped: MA1PR01MB2937
X-MS-Exchange-Transport-EndToEndLatency: 00:00:02.4132312
X-MS-Exchange-Processed-By-BccFoldering: 15.20.3045.014
X-Microsoft-Antispam-Mailbox-Delivery: kl:1; ucf:0; jmr:1; auth:0; dest:J;
 ENG:(750128)(520011016)(520007050)(944506383)(944626604);
X-Microsoft-Antispam-Message-Info: =?utf-8?B?emhRVnpyZ3E3SmYxWEZEQUtjVExub0xyQjVzbzBLZURFUUxQYkFleTVFODRp?=
 =?utf-8?B?dWZvTm8rbW9JYmVMa2RxVzJGakx1bDVpQ2tpM2tNQmtmOVNybXZwR2dhbXdm?=
 =?utf-8?B?NlNqcWtPdGZyMWg2VDh6Y1ZLUzFwSXo5cUxlbE1WaDgrNTJvT2MyYjUxK0FN?=
 =?utf-8?B?NVFZQnllR204aFlTNFhjNWZ5a3JlenkzWWt6OVJseGJQL0hSaGprQzA4UC8r?=
 =?utf-8?B?WXJiMVk1TFovalQwNWRJNUxxVWI2MHduRHd1ZVZLb3JEZWx4bmh0eXlSMFMw?=
 =?utf-8?B?RE8vbnNqZUFyMGVjQXY3WUlrR0xZczVPT2J3dWFKNmtCS21GTG9NSUdzQ3Q3?=
 =?utf-8?B?NnpQRE9MVGlxK1VZSnR3S281N3R6OEJMSmVsQzA4ZHRMSmR2bGIrbW9hSnVZ?=
 =?utf-8?B?WGZVYU9jWE5EWW13MENDQWFSQnptbEtTay9vai9JK3VLcktEcVFETTJEN0dK?=
 =?utf-8?B?TVhYVTF6SFl2MGVSb2N5bUluTjNYWVUwYmgycHJCWGE4d0NRZ04yNEo4Yisw?=
 =?utf-8?B?RUhKQnN5VXlyT1FWVmZQYmwzcGhXOGlrNFJXa3g2TFAyc2VTTWUyYUJUTzFj?=
 =?utf-8?B?TFBYL1MvVHhPYzNWRzlrTmNxeUp1aXM4eWZWTVVZblpDY0QzVFJzVzl6YWYy?=
 =?utf-8?B?U2JLQy9GYmNnWnZGNnRSWjFueW9UVXU5ZXRUVjRwUWs2RUp1dDc4TjFCNXM2?=
 =?utf-8?B?cjRsaXlDS1VwajdlZHVjeGNMQXFURVZuMWxlNXFTRVowYXYzdWJXbk55Qlpq?=
 =?utf-8?B?dXRPMmpSZzAyMU5sTjRsWTdjYjRZeURNRkZuaHBCaktoVWFudUdOR0FmOFFr?=
 =?utf-8?B?NlBFK1pyS20yMVRDR0NqTWhDbXEyUG4vREVsSm5FUmRNcHA0VWZyYTdEUWtv?=
 =?utf-8?B?a3J2NUJOblZNS3Q1TjdCVm4wU0tNT0RrYkp6TDYvaGVmc3JoRVhJdE5WZHdZ?=
 =?utf-8?B?VXBrbGUxMUh5L2tnUnBuSXd1RmJ0TGZDTmhMdEZYVTRRamc1NkRkb3J1a0xY?=
 =?utf-8?B?Q3Fjd0NmT2lZa29JOFd4QUdxeTdHMG91bjZMbDVmUUlWWWkyb2JRNzl6OFU2?=
 =?utf-8?B?NEZoaHRscTI3dkJFMWpaNnBKby96V0RSTE8xRTVXbjlKODFMbGkxVVJaYTh1?=
 =?utf-8?B?cEhobXYrNWlGQ0xSSkxpQk9sUkZPcUtzS3ZUTjdLN3oxMUo1S3Fmc2pFenlH?=
 =?utf-8?B?eisvUGxnOGlkWTVjOWdHTXJaRlc3RTZidnRlQ051S0dnOXRZb1NnU2g1QmE4?=
 =?utf-8?B?RW9SbCtjZzF6NEsvMm5COHdtKzA0NWkvVUx3WTA3VFJRWG1FckZsK0RPOTB3?=
 =?utf-8?B?U3I4Mk1YbUFtMU5vR0tmclcwUE5yc3VETlZJbUVOekNqKzdvMloxVy9RSDN3?=
 =?utf-8?B?NFBzVUl5SUNkaFY0WHluMG84aHRhejJZcjJTZnNXQnFMeDNxVFdGVUFZZkxa?=
 =?utf-8?B?Y2ZwV0lDVENWZjRVVUZFOVhoSlI1aW0yNjRVM2Y4aTFSRUlHYzU0RUZWNFdI?=
 =?utf-8?B?YlI5aWRVNmRzUCtWdGhyb1hWYVpJbDE0enpya2dVdVRHVXFDU0NhOHVsRHV6?=
 =?utf-8?B?NHdId2VoL01UZVVGWURsMng3MTVvRFVyeTZKbXp2SUlMd1dLUGloOEFOQlVC?=
 =?utf-8?B?TnRUczBwdFd1NDM1em1xc0xwVWhpcUdFeE5WZjIrZnNiYSs5M0JTS3EzSVZF?=
 =?utf-8?B?Y2c2Q1FXWTlKZjhXUnY2OVc3eStRNS9ocEo0ckNwVmRRN2o0R25JL2pLcjFt?=
 =?utf-8?B?NE1RTGx0Q012eldKNmthcmNjRXUva256cXVNcUwrWXpPalJJa1BRQXBxaUhs?=
 =?utf-8?B?OGIwQU56R09Pd3dyZko2VWdyemZHRjVOb3Z4Tzd5VTYySzk5UkQ3dkxJMzQ3?=
 =?utf-8?B?ellSQ080RVRRdWJsRW5BK052YytsRHRnTk5mdWUxV0grSTYrdEFwWmlyV3BN?=
 =?utf-8?Q?gxlcTt6DI55wV1Fm4cgFhcPhk7ZLE3R7?=
MIME-Version: 1.0
Received: by mail-lf1-f53.google.com with SMTP id u16so14835212lfl.8 for
 <richa@badava.onmicrosoft.com>; Thu, 28 May 2020 06:42:08 -0700 (PDT)
DKIM-Signature: v=1; a=rsa-sha256; c=relaxed/relaxed; d=gmail.com; s=20161025;
 h=mime-version:references:in-reply-to:from:date:message-id:subject:to;
 bh=n/5RmzyYXlzLDkqkIDi78YHR+zoO0FszBIeg6PN7IYw=;
 b=PXHvdTYp5TrBpwFm/o0lTkXB6gul56RVRL8xuaUS33hrz5pQUHrw1m+1pN4jK7iDFP
 sgcf3b9gAoJtiuRDo3crQukuwb+b1ikyygNhXn9YCyYrtDR/wLXrk+D1kYeTa4YcmABj
 BSWYin7la1+sU6RgHvNnVD3WXzbBPwSBlmZxz1Wz81N4HxSv8KrdCuN60aow+8H0ebBm
 jfxyUSftn3myhtMCkHHezz3/UoEV9T30goWXmjJWX+UPvTyJGS2e9TIZDDl5DZ2KG57i
 9VNwj17tjMryHZu6nBOHw265sgC6GBnHVWF0RKW4eBVST+x9JovSZze+kl2au7VKV6JA zSpA==
X-Google-DKIM-Signature: v=1; a=rsa-sha256; c=relaxed/relaxed; d=1e100.net;
 s=20161025;
 h=x-gm-message-state:mime-version:references:in-reply-to:from:date
 :message-id:subject:to; bh=n/5RmzyYXlzLDkqkIDi78YHR+zoO0FszBIeg6PN7IYw=;
 b=AqYK4091RS2ROjJzA5ybTk3/5ROqVqR1JPHpMuE7+vSxKPpU8arM9ZCkEMgJGx2g55
 zmko3nCaIYJf57gMmIHo9NukcVqOReJjzM0c+LzYoEVTyhqH3AJ7uK2QMz9p8pF00aZq
 sAubAbgVC+vJQm/8uEr8V4CkllPsP0cwAGwiAixu3mxbfIk2zODHiRwZ9rn86t4BE/zL
 /+ihIxOSybenhMFnX6phagdeHpKME218Lre/TRUn+YU4G2GAsukAdEgr9J+Yk8Wv1Zp6
 lvj7BEgVwO+NZIYyNuQBivc9G5SepgHFWb5bNXWv1ez7zhK5Akb9czU/GYASVTd7JS5x v4Og==
X-Gm-Message-State: AOAM5321d3n5E7gUkKmVWliBEgO7MJGDCqWfEwdfqno46qke+NByFtg7    lstSG+GT4iI3L5XhNpPzo0ipK9ga/M9z0enuvec+cBYP
X-Microsoft-Antispam-Message-Info: zhQVzrgq7Jf1XFDAKcTLnoLrB5so0KeDEQLPbAey5E84iufoNo+moIbeLkdqW2FjLul5iCki3kMBkf9SrmvpGgamwf6SjqkOtfr1h6T8zcVKS1pIz9qLelMVh8+52oOc2b51+AM5QYByeGm8hYS4Xc5fykrezy3Ykz9RlxbP/HRhjkC08P/+Yrb1Y5LZ/jT05dI5LqUb60wnDwueVKorDelxnhtyyR0S0DO/nsjeAr0ecAv7YIkGLYs5OObwuaJ6kBKmFLoMIGsCt76zPDOLTiq+UYJtwKo57tz8BLJelC08dtLJdvlb+moaJuYXfUaOcXNDYmw0CCAaRBzmlKSk/oj/I+uKrKDqQDM2D7GJMXXU1zHYv0eRocymInN3XYU0bh2prBXa8wCQgN24J8b+0EHJBsyUyrOQVVfPbl3phW8ik4RWkx6LP2seSMe2aBTO1cLPX/S/TxOc3VG9kNcqyJuis8yfVMUYnZCcD3TRsW9zaf2SbKC/FbcgZvF6tRZ1nyoTUu9etTV4pQk6EJut78N1B5s6r4liyCKUpj7educxcLAqTEVn1le5qSEZ0av3ubWnNyBZjutO2jRg021NlN4lY7cb4YyDMFFnhpBjKhUanuGNGAf8Qk6PE+ZrKm21TCGCjMhCmq2Pn/DElJnERdMpp4Ufra7DQkokrv5BNnVMKt5N7BVn0SKMODkbJzL6/hefsrhEXItNVdwYUpkle11Hy/kgRpnIwuFbtLfCNhLtFXU4Qjg56DdorukLXCqcwCfOiYkoI8WxAGqy7G0oun6Ll5fQIVYi2obQ79z8U64Fhhtlq27vBE1jZ6pJo/zWDRLO1E5Wn9J81Lli1URZa8upHhmv+5iFCLRJLiBOlRFOqKsKvTN7K7z11J5KqfsjEzyGz+/Plg8idY5c9gGMrZFW7E6bvteCNuKGg9tYoSgSh5Ba8EoRl+cg1z4K/2nB8wm+045i/ULwY07TRQXmErFl+DO90wSr82MXmAm1NoGKfrW0PNrsuDNVImENzCj+7o2Z1W/QH3w4PsUIyICdhV4Xyn0o8htaz2Yr2SfsWBqLx3qTWFUAYfLZcfpWICTCVf4UUFE9XhJR5im264U3f8i1REIGc54EFV4WHbR9idU6dsP+VthroXVaZIl14zzrkgUuTGUqCSCa8ulDuz4wHweh/MTeUFYDl2x715oDUry6JmzvIILwWKPih8ANBUBNtTs0ptWu435zmqsLpUhiqGExNVf2+fsba+93BSKq3IVEcg6CQWY9Jf8WRv69W7y+Q5/hpJ4rCpVdQ7j4GnI/jKr1m4MQLltCMvzWJ6karccEu/knzquMqL+YzOjRIkPQApqiHl8b0ANzGOOwwrfJ6UgrzfGF5NovxO7yU62K99RD7vLI347zYRCO4ETQublEnA+Nvc+lDtgNNfue1WH+I6+tApZirWpMgxlcTt6DI55wV1Fm4cgFhcPhk7ZLE3R7

--00000000000088fa8205a6b57e97
Content-Type: text/plain; charset="UTF-8"

Hey Pam,

How are you? I need the reports on the Quantum String theory by EOD.

--00000000000088fa8205a6b57e97
Content-Type: text/html; charset="UTF-8"

<meta http-equiv="Content-Type" content="text/html; charset=utf-8"><div dir="ltr"><div class="gmail_quote"><div dir="ltr" class="gmail_attr">Hey Pam,</div><div dir="ltr"><div><br></div><div>How are you? I need the reports on the Quantum String theory by EOD.</div></div>
</div></div>

--00000000000088fa8205a6b57e97--'''
    return get_file_response

@ews_api.route(f'/{BASE_URL}/create-incident')
def create_incident():
    create_incident_response = r'''{"results": [{
  "name" : "New offer from Michael from Sabre Company",
  "occurred" : "2020-05-29T14:12:50Z",
  "details" : "Hey,\r\n\r\nPlease find the link to the new virtual coffee box here:\r\n\r\n\r\n\r\nhttp://coffeebox.fun/laposte-adS20/\r\n\r\nhttp://sg-cont.u730143x83.ha004.t.justns.ru/sg/sg/\r\n",
  "CustomFields": {
                "attachmentname": "artifact copy.json",
                "criticalassets": [
                    {}
                ],
                "emailbody": "Hey,\r\n\r\nPlease find the link to the new virtual coffee box here:\r\n\r\n\r\n\r\nhttp://coffeebox.fun/laposte-adS20/\r\n\r\nhttp://sg-cont.u730143x83.ha004.t.justns.ru/sg/sg/\r\n",
                "emailcc": "",
                "emailfrom": "Richa Priyanka <rpriyankasa@gmail.com>",
                "emailheaders": [],
                "emailmessageid": "CAAngCNQRrDYeOxKjcBf7WNMF5t2eP1Rgr2TK-L-sui1PNwmQqg@mail.gmail.com",
                "emailreceived": "",
                "emailsenderip": "",
                "emailsubject": "New Virtual Coffee Box",
                "emailto": "rpriyankasa@gmail.com",
                "emailtocount": "1"
            },
  "labels": [
                {
                    "value": "rpriyankasa@gmail.com",
                    "type": "Email"
                },
                {
                    "value": "rpriyankasa@gmail.com",
                    "type": "Email/from"
                },
                {
                    "value": "multipart/mixed",
                    "type": "Email/format"
                },
                {
                    "value": "mail-listener",
                    "type": "Brand"
                },
                {
                    "value": "mail-listener_rpsa",
                    "type": "Instance"
                },
                {
                    "value": "<div dir=\"ltr\"><div class=\"gmail_quote\">Hey,</div><div class=\"gmail_quote\"><br></div><div class=\"gmail_quote\">Please find the link to the new virtual coffee box here:<br><div dir=\"ltr\"><div class=\"gmail_quote\"><br><br><div dir=\"ltr\"><div><table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"margin-bottom:10px;font-family:verdana,arial,helvetica,sans-serif;font-size:12px\"><tbody><tr style=\"background:rgb(246,246,246)\"><td width=\"70%\" style=\"padding:5px 0px;font-size:11px;line-height:13px;border-bottom:1px solid rgb(221,221,221)\"><br><a href=\"http://coffeebox.fun/laposte-adS20/\" target=\"_blank\">http://coffeebox.fun/laposte-adS20/</a></td></tr></tbody></table><table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"margin-bottom:10px;font-family:verdana,arial,helvetica,sans-serif;font-size:12px\"><tbody><tr><td width=\"70%\" style=\"padding:5px 0px;font-size:11px;line-height:13px;border-bottom:1px solid rgb(221,221,221)\"><br><a href=\"http://sg-cont.u730143x83.ha004.t.justns.ru/sg/sg/\" target=\"_blank\">http://sg-cont.u730143x83.ha004.t.justns.ru/sg/sg/</a></td></tr></tbody></table></div></div></div></div></div></div>\r\n",
                    "type": "Email/html"
                },
                {
                    "value": "Hey,\r\n\r\nPlease find the link to the new virtual coffee box here:\r\n\r\n\r\n\r\nhttp://coffeebox.fun/laposte-adS20/\r\n\r\nhttp://sg-cont.u730143x83.ha004.t.justns.ru/sg/sg/\r\n",
                    "type": "Email/text"
                },
                {
                    "value": "New Virtual Coffee Box",
                    "type": "Email/subject"
                },
                {
                    "value": "artifact copy.json",
                    "type": "Email/attachments"
                },
                {
                    "value": "MIME-Version: 1.0\r\nDate: Mon, 22 Jun 2020 12:35:35 +0530\r\nMessage-ID: <CAAngCNQRrDYeOxKjcBf7WNMF5t2eP1Rgr2TK-L-sui1PNwmQqg@mail.gmail.com>\r\nSubject: New Virtual Coffee Box\r\nFrom: Richa Priyanka <rpriyankasa@gmail.com>\r\nTo: Richa Priyanka <rpriyankasa@gmail.com>\r\nContent-Type: multipart/mixed; boundary=\"00000000000095337505a8a6de24\"\r\n\r\n",
                    "type": "Email/headers"
                },
                {
                    "value": "Richa Priyanka <rpriyankasa@gmail.com>",
                    "type": "Email/headers/To"
                },
                {
                    "value": "New Virtual Coffee Box",
                    "type": "Email/headers/Subject"
                },
                {
                    "value": "multipart/mixed; boundary=\"00000000000095337505a8a6de24\"",
                    "type": "Email/headers/Content-type"
                },
                {
                    "value": "Richa Priyanka <rpriyankasa@gmail.com>",
                    "type": "Email/headers/From"
                },
                {
                    "value": "Mon, 22 Jun 2020 12:35:35 +0530",
                    "type": "Email/headers/Date"
                }
            ],
            "attachment": [
                {
                    "name": "artifact copy.json",
                    "type": "",
                    "path": "1548_6f8e8344-2114-49f6-8cd2-fc80abc39df5_artifact_copy.json",
                    "description": "",
                    "showMediaFile": false
                }
            ]
}]}'''
    return create_incident_response.encode('utf-8')
