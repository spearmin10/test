from flask import Blueprint, request
from datetime import datetime, timezone, timedelta
import json

BASE_URL = "/api/now/mirror/".strip("/")
INTEGRATION = "mirror_demo_api"
mirror_demo_api = Blueprint(f"{INTEGRATION}", __name__)

FETCH = False


def set_time():
    now = datetime.now(timezone.utc) - timedelta(seconds=10)
    updated = now.strftime("%Y-%m-%d %H:%M:%S")
    return updated


mock_incident = {
    "active": "true",
    "activity_due": "",
    "additional_assignee_list": "",
    "approval": "not requested",
    "approval_history": "",
    "approval_set": "",
    "assigned_to": "",
    "assignment_group": "",
    "business_duration": "",
    "business_service": "",
    "business_stc": "",
    "calendar_duration": "",
    "calendar_stc": "",
    "caller_id": {
        "link": "https://dev62495.service-now.com/api/now/table/sys_user/62826bf03710200044e0bfc8bcbe5df1",
        "value": "02826bf03710200044e0bfc8bcbe5d3f",
    },
    "category": "inquiry",
    "caused_by": "",
    "child_incidents": "0",
    "close_code": "",
    "close_notes": "",
    "closed_at": "",
    "closed_by": "",
    "cmdb_ci": "",
    "comments": "",
    "comments_and_work_notes": "",
    "company": {
        "link": "https://dev62495.service-now.com/api/now/table/core_company/227cdfb03710200044e0bfc8bcbe5d6b",
        "value": "227cdfb03710200044e0bfc8bcbe5d6b",
    },
    "contact_type": "",
    "correlation_display": "",
    "correlation_id": "",
    "delivery_plan": "",
    "delivery_task": "",
    "description": "",
    "due_date": "",
    "escalation": "0",
    "expected_start": "",
    "follow_up": "",
    "group_list": "",
    "hold_reason": "",
    "impact": "3",
    "incident_state": "1",
    "knowledge": "false",
    "location": "",
    "made_sla": "true",
    "notify": "1",
    "number": "INC0010002",
    "opened_at": "2020-05-06 09:34:04",
    "opened_by": {
        "link": "https://dev62495.service-now.com/api/now/table/sys_user/6816f79cc0a8016401c5a33be04be441",
        "value": "6816f79cc0a8016401c5a33be04be441",
    },
    "order": "",
    "parent": "",
    "parent_incident": "",
    "priority": "5",
    "problem_id": "",
    "reassignment_count": "0",
    "reopen_count": "0",
    "reopened_by": "",
    "reopened_time": "",
    "resolved_at": "",
    "resolved_by": "",
    "rfc": "",
    "severity": "3",
    "short_description": "Suspicious activity on my laptop",
    "sla_due": "",
    "state": "1",
    "subcategory": "",
    "sys_class_name": "incident",
    "sys_created_by": "admin",
    "sys_created_on": "2020-05-06 09:34:04",
    "sys_domain": {"link": "https://dev62495.service-now.com/api/now/table/sys_user_group/global", "value": "global",},
    "sys_domain_path": "/",
    "sys_id": "ba0d1622dbe01010cc3c112039961987",
    "sys_mod_count": "1",
    "sys_tags": "",
    "sys_updated_by": "admin",
    "sys_updated_on": "2020-05-05 22:17:48",
    "time_worked": "",
    "upon_approval": "proceed",
    "upon_reject": "cancel",
    "urgency": "1",
    "user_input": "",
    "watch_list": "",
    "work_end": "",
    "work_notes": "",
    "work_notes_list": "",
    "work_start": "",
}
notes = [
    {
        "sys_id": "ba0d1622dbe01010cc3c112039961987",
        "sys_created_on": "2020-05-05 22:17:48",
        "name": "incident",
        "element_id": "a79d926cdb234010e6e80d53ca9619fe",
        "sys_tags": "",
        "value": "The issue seems to be between the screen and the chair",
        "sys_created_by": "admin",
        "element": "comments",
    },
    {
        "sys_id": "ba0d1622dbe01010cc3c112039961987",
        "sys_created_on": "2020-05-05 22:17:48",
        "name": "incident",
        "element_id": "a79d926cdb234010e6e80d53ca9619fe",
        "sys_tags": "",
        "value": "This is a test",
        "sys_created_by": "admin",
        "element": "comments",
    },
]


def set_fetch(fetch):
    global FETCH
    FETCH = True if fetch == "true" else False


def set_close(close):
    if "true" in close:
        mock_incident.update({"resolved_by": "Admin"})
    else:
        mock_incident.update({"resolved_by": ""})


def set_note(note):
    updated = set_time()
    notes[1]["sys_created_on"] = updated
    notes[1]["value"] = note


@mirror_demo_api.route(f"/{BASE_URL}/set")
def set_params():
    updated = set_time()
    args = request.args
    name = args.get("name")
    fetch = args.get("fetch")
    close = args.get("close")
    severity = args.get("severity")
    note = args.get("note")
    if name:
        mock_incident["short_description"] = name
    if severity:
        mock_incident["urgency"] = severity
    if fetch:
        set_fetch(fetch)
    if close:
        set_close(close)
    if note:
        set_note(note)
    mock_incident["sys_updated_on"] = updated

    return {
        "name": name,
        "fetch": fetch,
        "close": close,
        "severity": severity,
        "note": note,
        "updated": f"{updated} UTC",
    }


@mirror_demo_api.route(f"/{BASE_URL}/table/incident", methods=["GET", "POST"])
def fetch_incidents():
    updated = set_time()
    global FETCH
    method = request.method
    if method in ["GET", "POST"] and FETCH:
        mock_incident["opened_at"] = updated
        return json.dumps({"result": [mock_incident]})
    else:
        return json.dumps({"result": []})


@mirror_demo_api.route(f"/{BASE_URL}/table/incident/<sys_id>", methods=["GET"])
def get_incident(sys_id):
    return json.dumps({"result": mock_incident})


@mirror_demo_api.route(f"/{BASE_URL}/table/sys_journal_field")
def get_notes():
    return json.dumps({"result": notes})


@mirror_demo_api.route(f"/{BASE_URL}/table/incident/<sys_id>", methods=["PATCH", "DELETE"])
def patch_note(sys_id):
    updated = set_time()
    data = request.get_json()
    if data.get("comments"):
        note = data["comments"]
        notes[1]["sys_created_on"] = updated
        notes[1]["value"] = note
    return json.dumps({"result": [mock_incident]})


@mirror_demo_api.route(f"/{BASE_URL}/set/get/note")
def get_mirrored_note():
    return json.dumps({"result": [notes[-1]]})
