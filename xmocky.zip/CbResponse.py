from flask import Blueprint, request
from flask import json
import logging
from datetime import datetime, timedelta, timezone

mock_sensors = [
    {       
        "systemvolume_total_size": "42939584512",
        "os_environment_display_string": "Windows XP Professional Service Pack 3",
        "sensor_uptime": "638",
        "physical_memory_size": "536330240",
        "build_id": 1,
        "uptime": "666",
        "computer_dns_name": "j-8205a0c27a0c4",
        "id": 1,
        "systemvolume_free_size": "40167079936",
        "sensor_health_message": "Healthy",
        "build_version_string": "003.002.000.30829",
        "computer_sid": "S-1-5-21-1715567821-507921405-682003330",
        "event_log_flush_time": "",
        "computer_name": "J-8205A0C27A0C4",
        "last_checkin_time": "2013-09-10 07:08:37.378860-07:00",
        "license_expiration": "1990-01-01 00:00:00-08:00",
        "network_adapters": "192.168.206.157,000c298a3614|",
        "sensor_health_status": 100,
        "registration_time": "2013-09-10 06:49:21.261157-07:00",
        "next_checkin_time": "2013-09-10 07:09:07.368285-07:00",
        "notes": "",
        "os_environment_id": 1,
        "boot_id": "5",
        "cookie": 1291426991,
        "group_id": 1,
        "display": True,
        "uninstall": False,
        "network_isolation_enabled": False,
        "is_isolating": False
    },
    {
        "systemvolume_total_size": "22939584512",
        "os_environment_display_string": "Windows XP Professional Service Pack 2",
        "sensor_uptime": "638",
        "physical_memory_size": "236330240",
        "build_id": 2,
        "uptime": "523",
        "computer_dns_name": "CEO-PC",
        "id": 2,
        "systemvolume_free_size": "20167079936",
        "sensor_health_message": "Healthy",
        "build_version_string": "003.002.000.30829",
        "computer_sid": "S-1-5-21-1715567821-507921405-683003330",
        "event_log_flush_time": "",
        "computer_name": "CEO-PC",
        "last_checkin_time": "2019-09-10 01:08:31.3711160-07:00",
        "license_expiration": "1990-01-01 00:00:00-08:00",
        "network_adapters": "192.168.206.156,000c298a3613|",
        "sensor_health_status": 100,
        "registration_time": "2019-09-10 06:49:21.261157-07:00",
        "next_checkin_time": "2019-09-10 07:09:07.368285-07:00",
        "notes": "",
        "os_environment_id": 1,
        "boot_id": "5",
        "cookie": 1291426991,
        "group_id": 1,
        "display": True,
        "uninstall": False,
        "network_isolation_enabled": False,
        "is_isolating": False
    }
    ]

mock_alerts = {
    "terms": [],
    "results": [
        {
            "username": "SYSTEM",
            "alert_type": "watchlist.hit.ingress.process",
            "sensor_criticality": 3,
            "modload_count": 58,
            "report_score": 1,
            "watchlist_id": "Binary_0545A3EB959QQQ4790D267BFB8C1ACA4",
            "sensor_id": 2,
            "feed_name": "virustotalconnector",
            "created_time": "2017-10-11T14:16:06.074Z",
            "report_ignored": False,
            "ioc_type": "md5",
            "watchlist_name": "Binary_0545A3EB959QQQ4790D267BFB8C1ACA4",
            "ioc_confidence": 0.5,
            "alert_severity": 0.675,
            "crossproc_count": 2,
            "group": "default group",
            "hostname": "CEO-PC",
            "filemod_count": 0,
            "comms_ip": "192.119.22.22",
            "netconn_count": 0,
            "interface_ip": "192.168.206.156",
            "status": "Unresolved",
            "process_path": "c:\\program files (x86)\\google\\update\\googleupdate.exe",
            "description": "[1 / 66] VirusTotal report for 0545A3EB959CFA4790D267BFB8C1ACA4",
            "process_name": "googleupdate.exe",
            "process_unique_id": "00000002-0000-0cdc-01d3-429b633fda36-015f0bcadb87",
            "process_id": "00000002-0000-0cdc-01d3-429b633fda36",
            "link": "https://www.virustotal.com/file/69061e33acb7587d773d05000390f9101f71dfd6eed7973b551594eaf3f04193/analysis/1507720618/",
            "_version_": 1580970924950159360,
            "regmod_count": 7,
            "md5": "0545a3eb959cfa4790d267bfb8c1aca4",
            "segment_id": 197843847,
            "total_hosts": "0",
            "feed_id": 24,
            "ioc_value": "0545a3eb959cfa4790d267bfb8c1aca4",
            "os_type": "windows",
            "childproc_count": 4,
            "unique_id": "611b825e-f555-4841-91fe-39cb15e05106",
            "feed_rating": 3
        }
    ],
    "elapsed": 0.007166147232055664,
    "comprehensive_search": True,
    "all_segments": True,
    "total_results": 350,
    "highlights": [],
    "facets": {},
    "start": 0,
    "incomplete_results": False,
    "filtered": {}
    }

mock_blacklist = [  
    {
        "username": "cb",
        "audit": [
        {
            "username": "cb",
            "timestamp": "2015-10-21 00:10:10.369349-07:00",
            "text": "Auto-Blacklist From Watchlist",
            "enabled": True,
            "user_id": 1
        }
        ],
        "text": "Auto-Blacklist From Watchlist",
        "md5hash": "35e664e41174ce70e910b85bcd685136",
        "block_count": 0,
        "user_id": 1,
        "last_block_sensor_id": None,
        "enabled": True,
        "last_block_time": None,
        "timestamp": "2015-10-21 00:10:10.369349-07:00",
        "last_block_hostname": None
    }
    ]

now = datetime.now(timezone.utc)

BASE_URL = '/api/'.strip('/')
INTEGRATION = 'cbresponse_api'

cbresponse_api = Blueprint(f'{INTEGRATION}', __name__)
logger = logging.getLogger(__name__)


@cbresponse_api.route(f'/{BASE_URL}/v1/license')
def testModule():
    return {'result': 'it works'}


@cbresponse_api.route(f'/{BASE_URL}/v1/sensor/', defaults={'sensor_id': None})
@cbresponse_api.route(f'/{BASE_URL}/v1/sensor/<int:sensor_id>',  methods=['PUT', 'GET'])
def getSensorByIdRequest(sensor_id):

    if request.method == 'PUT':
        return {'error': 'modifying sensor is not supported in this environment'}

    if sensor_id:
        if sensor_id in [1,2]:        
            return mock_sensors[sensor_id-1]
        else:
            return {'error': 'sensor ID not found. Try ID 1 or 2.'}
    else:
        return json.dumps(mock_sensors)


@cbresponse_api.route(f'/{BASE_URL}/v1/binary')
def getBinaryData():
    query = request.args.get('q')
    binary = query.strip("()")

    return {
         "total_results": 1,
         "facets": {},
         "elapsed": 0.046832799911499023,
         "start": 0,
         "results": [
             {
             "md5": "F2C7BB8ACC97F92E987B2D4087D021B1",
             "digsig_result": "Signed",
             "observed_filename": [
                 "c:\\windows\\system32\\"+binary
             ],
             "product_version": "6.1.7600.16385",
             "signed": "Signed",
             "digsig_sign_time": "2009-07-14T10:17:00Z",
             "orig_mod_len": 193536,
             "is_executable_image": True,
             "is_64bit": True,
             "digsig_publisher": "Microsoft Corporation",
             "file_version": "6.1.7600.16385 (win7_rtm.090713-1255)",
             "company_name": "Microsoft Corporation",
             "internal_name": "Internal Name",
             "product_name": "Microsoft Windows Operating System",
             "digsig_result_code": "0",
             "timestamp": "2013-08-16T11:26:48.321Z",
             "copied_mod_len": 193536,
             "server_added_timestamp": "2013-08-16T11:26:48.321Z",
             "legal_copyright": "Microsoft Corporation. All rights reserved.",
             "original_filename": binary,
             "file_desc": "file",
             "os_type": "windows"
             }
         ],
         "terms": [
             binary
         ],
         "highlights": [
             {
             "name": "PREPREPREFILE.EXEPOSTPOSTPOST",
             "ids": [
                 "F2C7BB8ACC97F92E987B2D4087D021B1"
             ]
             },
             {
             "name": "c:\\windows\\system32\\PREPREPRE{}POSTPOSTPOST".format(binary),
             "ids": [
                 "F2C7BB8ACC97F92E987B2D4087D021B1"
             ]
             }
         ]
         }


@cbresponse_api.route(f'/{BASE_URL}/v2/alert')
def showAlerts():
    return mock_alerts


@cbresponse_api.route(f'/{BASE_URL}/v1/banning/blacklist',  methods=['POST', 'GET'])
def getHashBlacklist():
    if request.method == 'GET':
        return json.dumps(mock_blacklist)
    elif request.method == 'POST':
        return {
            "md5hash": "f41d8cd98f00b214e9800998ecf8427e",
            "text": "autoban from watchlist",
            "last_ban_time": "0",
            "ban_count": "0",
            "last_ban_host": "0",
            "enabled": "True"
            }

@cbresponse_api.route(f'/{BASE_URL}/v1/alerts',  methods=['POST'])
def updateAlert():
    alert_ids = request.args.get('alert_ids')
    status    = request.args.get('requested_status')
    set_ignored = request.args.get('set_ignored')

    return {
        "result": "success",
        "alert_ids": alert_ids,
        "requested_status": status,
        "assigned_to": "ahnold"
        }

@cbresponse_api.route(f'/{BASE_URL}/v1/watchlist',methods=['POST','GET'])
def getWatchlist():
    if request.method == 'GET':
        return {
            'alliance_id': None,
            'date_added': '2013-12-11 11:36:38.476886-08:00',
            'from_alliance': False,
            'id': 4,
            'index_type': 'modules',
            'last_hit': '2013-12-11 15:05:04.964374-08:00',
            'last_hit_count': 22,
            'name': 'Newly Loaded Modules',
            'search_query': 'q=is_executable_image:false&cb.urlver=1&sort=server_added_timestamp desc'
        }
    elif request.method == 'POST':
        data=json.loads(request.data)
        return {
            'alliance_id': None,
            'date_added': now,
            'from_alliance': False,
            'id': 7,
            'name': data["name"],
            'search_query': data["search_query"]
        }

@cbresponse_api.route(f'/{BASE_URL}/v1/watchlist/<int:watchlist_id>',  methods=['PUT','DELETE','GET'])
def createWatchlist(watchlist_id): 
    if request.method == 'DELETE':
        return {'result' : 'success'}
    elif request.method in ['PUT','GET']:
        return {
            'result' : 'success',
            'alliance_id': None,
            'date_added': '2013-12-11 11:36:38.476886-08:00',
            'from_alliance': False,
            'id': watchlist_id,
            'index_type': 'modules',
            'last_hit': '2013-12-11 15:05:04.964374-08:00',
            'last_hit_count': 22,
            'name': 'Newly Loaded Modules',
            'search_query': 'q=is_executable_image:false&cb.urlver=1&sort=server_added_timestamp desc'
        }


@cbresponse_api.route(f'/{BASE_URL}/v1/process')
def getProcess():
    pass


""" Available Commands in XSOAR
    testModule();               [Done]
    version();                  [!sample data not in API doc]
    fetchIncidents();           [Done : fetching same alert every time]
    showAlerts();               [Done : 1 alert]
    updateAlert();              [Done]
    quarantineDevice(true);     []
    quarantineDevice(false);    []
    getProcesses();             []
    getProcess();               []
    getProcessEvents();         []
    getBinaries();              [Done]
    getBinary();                [Done]
    getSensors();               [Done]
    blockHash(true);            []
    blockHash(false);           []
    getHashBlacklist();         [Done] 
    getWatchlist();             [Done]
    createWatchlist();          [Done]
    setWatchlist();             [Done]
    deleteWatch();              [Done]
    getBinaryZip();             []
"""