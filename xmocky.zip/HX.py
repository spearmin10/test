import os, shutil 
from flask import Blueprint, request, make_response
from random import randint

hx_api = Blueprint('hx_api', __name__, static_folder='files')

AGENT_ID = 'AAABBBAAABBBAA'

null = None
false = False
true = True

@hx_api.route('/hx/api/v3/token', methods=['GET', 'DELETE'])
def login():
    resp = make_response("")
    resp.headers['X-FeApi-Token'] = 'abracadabra'
    return resp

@hx_api.route('/hx/api/v3/hosts/<agent_id>/live', methods=['POST', 'GET'])
def request_acq(agent_id):
    id = randint(1,10)
    return {
            "details": [],
            "route": "/hx/api/v3/hosts/id/live",
            "data": {
                "_id": id,
                "_revision": "20150902162440979636157490",
                "errormessage": None,
                "comment": None,
                "state": "NEW",
                "name": "MyScript",
                "md5": None,
                "request_time": "2015-09-02T16:24:40.000Z",
                "request_actor": {
                    "_id": 1002,
                    "username": "user1"
                },
                "zip_passphrase": None,
                "external_id": None,
                "finishtime": None,
                "url": f"/hx/api/v3/acqs/live/{agent_id}",
                "download": f"/hx/api/v3/acqs/live/{agent_id}.mans",
                "host": {
                    "id": "2fmP4LULrw6dHmPTq5vJFU",
                    "url": "/hx/api/v3/hosts/2fmP4LULrw6dHmPTq5vJFU"
                },
                "script": {
                    "_id": "1b96b88353619a0ceb781c80b0fa15504c68ab3d",
                    "url": "/hx/api/v3/scripts/1b96b88353619a0ceb781c80b0fa15504c68ab3d",
                    "download": "/hx/api/v3/scripts/1b96b88353619a0ceb781c80b0fa15504c68ab3d.xml"
                }
            },
            "message": "Created"
        }

@hx_api.route('/hx/api/v3/acqs/live/<mans:filename>', methods=['GET', 'DELETE'])
def download_acq(filename):
    shutil.copy('files/1.mans', 'files/'+filename)
    return hx_api.send_static_file(filename)
    
@hx_api.route('/hx/api/v3/acqs/live/<int:agent_id>', methods=['POST', 'GET'])
def request_start_acq(agent_id):
    return {
            "details": [],
            "route": f"/hx/api/v3/acqs/live/{agent_id}",
            "data": {
            "_id": agent_id,
            "_revision": "20150902162454464463157492",
            "comment": None,
            "state": "COMPLETE",
            "name": "MyScript",
            "md5": None,
            "request_time": "2015-09-02T16:24:40.000Z",
            "request_actor": {
                "_id": 1002,
                "username": "user1"
            },
            "zip_passphrase": None,
            "external_id": None,
            "finish_time": "2015-09-02T16:24:54.463Z",
            "url": f"/hx/api/v3/acqs/{agent_id}",
            "download": f"/hx/api/v3/acqs/live/{agent_id}",
            "host": {
                "_id": "2fmP4LULrw6dHmPTq5vJFU",
                "url": "/hx/api/v3/hosts/2fmP4LULrw6dHmPTq5vJFU"
            },
            "script":{
                "_id": "1b96b88353619a0ceb781c80b0fa15504c68ab3d",
                "url": "/hx/api/v3/scripts/1b96b88353619a0ceb781c80b0fa15504c68ab3d",
                "download": "/hx/api/v3/scripts/1b96b88353619a0ceb781c80b0fa15504c68ab3d.xml"
            }
            },
            "message": "OK"
        }   

@hx_api.route('/hx/api/v3/hosts/<string:agent_id>')
def get_endpoint_info(agent_id):
    global AGENT_ID
    AGENT_ID = agent_id
    domain = "ACME"
    hostname = "CEO-PC"
    return {
                "details": [],
                "route": "/hx/api/v3/hosts/agent_id",
                "data": {
                "_id": agent_id,
                "agent_version": "20.40.4",
                "excluded_from_containment": "false",
                "containment_missing_software": "true",
                "containment_queued": "false",
                "containment_state": "normal",
                "containment_not_supported_linux": "false",
                "high_value_host_bit": "false",
                "app_config_hash": None,
                "domain": domain,
                "litmus_script_id": "",
                "normalized_app_version": "#A20.#A40.#4-|",
                "server_time": "2019-02-19T04:29:02.000Z",
                "stats": {
                    "acqs": 0,
                    "malware_cleaned_count": 0,
                    "malware_quarantined_count": 0,
                    "execution_hits_count": 0,
                    "presence_hits_count": 0,
                    "last_hit": "2019-02-05T20:13:51.542313+00:00",
                    "has_execution_hits": "false",
                    "has_presence_hits": "false",
                    "alerting_conditions": 0,
                    "alerts": 1,
                    "exploit_alerts": 0,
                    "exploit_blocks": 0,
                    "malware_alerts": 0,
                    "generic_alerts": 1,
                    "false_positive_alerts": 0,
                    "false_positive_alerts_by_source": {},
                    "malware_false_positive_alerts": 0
                },
                "hostname": hostname,
                "sysinfo": {
                    "malware": {
                        "content": {
                            "updated": "2019-02-19T04:29:02Z",
                            "version": "9.4603"
                        },
                        "engine": {
                            "version": "11.0.1.2"
                        },
                        "version": "None"
                    },
                    "containmentState": "normal",
                    "appCreated": "2019-02-18T09:07:28Z",
                    "stateAgentStatus": "ok",
                    "intelHash": "dummy_intelHash",
                    "appStarted": "2019-02-19T04:29:02Z",
                    "configId": "dummy_configId",
                    "appVersion": "20.40.4",
                    "configChannel": "default",
                    "MalwareProtectionStatus": "disabled",
                    "exdStatus": "indeterminate",
                    "configETag": "dummy_configETag",
                    "intelKeyHash": "dummy_intelKeyHash",
                    "intelETag": "dummy_intelETag",
                    "domain": domain,
                    "regOwner": "ENGINEERING",
                    "timezone": "Eastern Standard Time",
                    "patchLevel": "Service Pack 2",
                    "productID": "89580-379-1410483-71824",
                    "totalphysical": "25165824",
                    "loggedOnUser": "GIC\\CIO",
                    "uptime": "PT838667S",
                    "installDate": "2019-02-18T09:07:28Z",
                    "hostname": "",
                    "procConfigInfo": {
                        "lpcDevice": "Intel (8C4E)",
                        "virtualization": "Enabled",
                        "vmGuest": "No"
                    },
                    "machine": "WIN-XJR05A",
                    "platform": "win",
                    "lastMsgMarker": "",
                    "biosInfo": {
                        "biosVersion": "Xen - 0",
                        "biosDate": "08/12/07"
                    },
                    "networkArray": {
                        "networkInfo": [
                            {
                                "dhcpLeaseObtained": "2012-04-11T14:57:17Z",
                                "ipGatewayArray": {
                                    "ipGateway": [
                                        "31.176.38.21"
                                    ]
                                },
                                "description": "Citrix PV Ethernet Adapter",
                                "adapter": "{584D834A-E4A2-4E03-999C-C210B321D5B1}",
                                "MAC": "74-EE-2E-7E-32-4E",
                                "dhcpServerArray": {
                                    "dhcpServer": [
                                        "80.123.225.97"
                                    ]
                                },
                                "dhcpLeaseExpires": "2012-04-13T14:57:17Z",
                                "ipArray": {
                                    "ipInfo": [
                                        {
                                            "subnetMask": "255.255.255.0",
                                            "ipAddress": "162.96.86.57"
                                        }
                                    ]    
                                }
                            }
                        ]
                    },
                    "drives": "C:",
                    "productName": "Windows XP Professional x64 ",
                    "buildNumber": "3790",
                    "FIPS": "disabled",
                    "user": "SYSTEM",
                    "date": "2019-02-19T04:24:17Z",
                    "gmtoffset": "-PT5H",
                    "regOrg": "ENGINEERING",
                    "OSbitness": "64-bit",
                    "procType": "Multiprocessor Free",
                    "primaryIpv4Address": "202.142.135.5",
                    "litmusScriptID": "",
                    "timezoneDST": "Eastern Standard Time",
                    "MAC": "77-65-0E-8D-F2-F1",
                    "availphysical": "12582912",
                    "timezoneStandard": "Eastern Standard Time",
                    "directory": "C:\\Windows\\system32",
                    "OS": "Windows XP Professional x64 Service Pack 2",
                    "processor": "Intel(R) Xeon(R) CPU X5670 @ 2.93GHz",
                    "clockSkew": "-PT285S",
                    "@created": "2019-02-19T04:24:17Z",
                    "computed": {
                        "normalizedAgentVersion": "#A20.#A40.#4-|",
                        "gmtoffsetSeconds": -18000,
                        "serverTime": "2019-02-19T04:29:02.000Z",
                        "skewSeconds": -285,
                        "hostHashes": [
                            "6bc99b3be6e5bbf3bda49b3ae2e2f659",
                            "fab54cac621774013df631d459edbd36",
                            "787f8a0d85848bdb52478576bc174cea",
                            "e5932c1a1f53fa2ac6d62f9e1d5fd7a4",
                            "755dee37dd7b3e4ec9d2f283d7bf5c87",
                            "bdc08f82a376938d7971fc1936a6c795",
                            "387d9f7b9511de5464590cc16cff43b6",
                            "0bc3d09b76c8ca1e217592cd02c25f31"
                        ],
                        "ips": [
                            "0000:0000:0000:0000:0000:ffff:a260:5639",
                            "0000:0000:0000:0000:0000:ffff:35cd:95c6",
                            "0000:0000:0000:0000:0000:ffff:e094:2643",
                            "0000:0000:0000:0000:0000:ffff:c29c:a053",
                            "0000:0000:0000:0000:0000:ffff:3e97:d349",
                            "0000:0000:0000:0000:0000:ffff:ca8e:8705"
                        ],
                        "displayIps": [
                            "162.96.86.57",
                            "53.205.149.198",
                            "224.148.38.67",
                            "194.156.160.83",
                            "62.151.211.73",
                            "202.142.135.5"
                        ],
                        "normalizedHostname": "win-gw65tc",
                        "normalizedDomain": "qanet",
                        "normalizedOS": "windows xp professional x64",
                        "normalizedPatchLevel": "service pack 2", 
                        "normalizedTimezone": "eastern standard time"
                    },
                    "url": "/hx/api/v3/hosts/1XVSmoRORuhhCqjDB3iwin/sysinfo"
                },
                "gmt_offset_seconds": -18000,
                "timezone": "Eastern Standard Time",
                "primary_ip_address": "202.142.135.5",
                "last_audit_timestamp": "2019-02-19T04:29:02.000Z",
                "last_poll_timestamp": "2019-02-19T04:43:28.000Z",
                "last_poll_ip": "202.142.135.5",
                "reported_clone": "false",
                "initial_agent_checkin": "2019-02-18T09:09:23.000Z",
                "url": "/hx/api/v3/hosts/1XVSmoRORuhhCqjDB3iwin",
                "triages": {
                    "recent_triage_action": None,
                    "recent_triage_id": None,
                    "recent_triage_state": None
                },
                "last_alert": {
                    "_id": 3,
                    "url": "/hx/api/v3/alerts/3"
                },
                "last_exploit_block": None,
                "last_alert_timestamp": "2019-02-05T20:13:51.542313+00:00",
                "last_exploit_block_timestamp": None,
                "os": {
                    "product_name": "Windows XP Professional x64 ",
                    "patch_level": "Service Pack 2",
                    "bitness": "64-bit",
                    "platform": "win",
                    "kernel_version": None
                },
                "primary_mac": "77-65-0E-8D-F2-F1"
            },
            "message": "OK"
        }

@hx_api.route('/hx/api/v3/alerts/<int:alert_id>', methods=['POST', 'GET', 'DELETE'])
def get_alert_details(alert_id):
    return {
            "details": [],
            "route": "/hx/api/v3/alerts/id",
            "data": {
                "_id": alert_id,
                "agent": {
                    "_id": AGENT_ID,
                    "url": "/hx/api/v3/hosts/XCFwFkoKbF9c4AnGJIQKVd",
                    "containment_state": "normal"
                },
                "appliance": {
                    "_id": "865393E9C9ED"
                },
                "condition": {
                    "_id": "4oGWnPCBPcLHbmcyF7i50g==",
                    "url": "/hx/api/v3/conditions/4oGWnPCBPcLHbmcyF7i50g=="
                },
                "event_at": "2019-12-29T17:26:25.652Z",
                "matched_at": "2019-12-29T17:27:21.000Z",
                "reported_at": "2019-12-29T17:27:29.985Z",
                "source": "IOC",
                "matched_source_alerts": [],
                "resolution": "ALERT",
                "url": "/hx/api/v3/alerts/1",
                "event_id": 1892,
                "event_type": "regKeyEvent",
                "event_values": {
                    "regKeyEvent/timestamp": "2019-12-29T17:26:25.652Z",
                    "regKeyEvent/hive": "HKEY_USERS\\S-1-5-21-588215685-4172047043-1146767439-1000",
                    "regKeyEvent/keyPath": "Software\\Microsoft\\Windows\\CurrentVersion\\Run",
                    "regKeyEvent/path": "HKEY_USERS\\S-1-5-21-588215685-4172047043-1146767439-1000\\Software\\Microsoft\\Windows\\CurrentVersion\\Run\\Goodness",
                    "regKeyEvent/eventType": 1,
                    "regKeyEvent/pid": 3640,
                    "regKeyEvent/process": "goodness.exe",
                    "regKeyEvent/processPath": "C:\\temp\\Benign Malware\\ioc benign samples",
                    "regKeyEvent/valueName": "Goodness",
                    "regKeyEvent/valueType": "REG_SZ",
                    "regKeyEvent/value": "QwA6AFwAVQBzAGUAcgBzAFwAcQBhAHUAcwBlAHIAXABBAHAAcABE",
                    "regKeyEvent/text": "C:\\Users\\gooduser\\AppData\\Roaming\\Goodness\\Goodness.exe",
                    "regKeyEvent/username": "ACME\\gooduser"
                }
            },
            "message": "OK"
        }

@hx_api.route('/hx/api/v3/hosts/<agent_id>/containment', methods=['POST', 'GET', 'DELETE'])
def contain_endpoint(agent_id):
    return {
        "details": [],
        "route": "/hx/api/v3/hosts/agent_id/containment", "message": "Accepted"
        }

@hx_api.route('/hx/api/v3/indicators', methods=['POST', 'GET', 'DELETE'])
def get_indicators():
    if request.args.get('offset'):
        offset = request.args.get('offset')
    else:
        offset = 0
        offset += 1
    if int(offset) > 2:
        return {
            "data": {
                    "total": 0, 
                    "query": {}, 
                    "sort": "test",
                    "offset": 0, 
                    "limit": 0, 
                    "entries": []
            }
        }
    return {
            "data": {
                    "total": 6, 
                    "query": {}, 
                    "sort": "test",
                    "offset": 0, 
                    "limit": 50, 
                    "entries": [ 
                        {
                            "uri_name": "B",
                            "_id": "05c9d68f-4934-47f9-b7d7-d7a395613833", 
                            "name": "B",
                            "_revision": "20170505202805948578101110", 
                            "display_name": null,
                            "description": null,
                            "category": {
                                        "_id": 1014,
                                        "uri_name": "IndicatorTests",
                                        "url": "/hx/api/v3/indicator_categories/indicatortests", "name": "IndicatorTests",
                                        "share_mode": "unrestricted"
                                    },
                            "created_by": "api_analyst", 
                            "create_actor": {
                                            "_id": 1073,
                                            "username": "api_analyst" 
                                        },
                            "update_actor": { "_id": 1073,
                            "username": "api_analyst" },
                            "create_text": null,
                            "signature": null,
                            "active_since": "2017-05-05T20:28:05.777Z", "meta": {
                            "g": "h" },
                            "url": "/hx/api/v3/indicators/indicatortests/b", "stats": {
                            "source_alerts": 0, "active_conditions": 0, "alerted_agents": 0
                            }, "platforms": [
                                                "win",
                                                "osx" 
                                            ],
                            }]}
            }


@hx_api.route('/hx/api/v3/alerts')
def get_alerts():
    offset = request.args.get('offset')
    if int(offset) < 5:
        return {
                    "data": {
                        "total": 5,
                        "query": {},
                        "sort": {},
                        "offset": 0,
                        "limit": 50,
                        "entries": [
                            {
                                "_id": 1,
                                "agent": {
                                    "_id": "F747371460563427011B11",
                                    "url": "/hx/api/v3/hosts/F747371460563427011B11",
                                    "containment_state": "normal"
                                },
                                "condition": {
                                    "_id": "MMlFLVI86z8fOQ4gp8ubNg==",
                                    "url": "/hx/api/v3/conditions/MMlFLVI86z8fOQ4gp8ubNg=="
                                },
                                "event_at": "2016-04-13T16:03:48.023Z",
                                "matched_at": "2016-04-13T16:03:48.023Z",
                                "reported_at": "2016-04-13T16:03:48.020Z",
                                "source": "IOC",
                                "matched_source_alerts": [
                                    {
                                        "_id": 6,
                                        "url": "https://www.fireeye.com/event_stream/events_for_bot?ma_id=1898",
                                        "appliance_id": "cfd3:89ea:52dd:af36:bf08:dfd2:f316:b9ed",
                                        "meta": null,
                                        "indicator_revision": "20160413160347195319100050",
                                        "indicator_id": "d9892f3c-6947-4d3a-9188-0bb89f995214",
                                        "row": 1
                                    }
                                ],
                                "resolution": "ALERT",
                                "url": "/hx/api/v3/alerts/1",
                                "event_id": 35525,
                                "event_type": "fileWriteEvent",
                                "event_values": {
                                    "fileWriteEvent/drive": "C",
                                    "fileWriteEvent/id": 235966399,
                                    "fileWriteEvent/pid": 71077,
                                    "fileWriteEvent/lowestFileOffsetSeen": 2187,
                                    "fileWriteEvent/closed": 0,
                                    "fileWriteEvent/md5": "a8fcb009fdaddcff893f808fd1b056be",
                                    "fileWriteEvent/process": "winlogon.exe",
                                    "fileWriteEvent/filePath": "Users\\dave\\ApplicationData",
                                    "fileWriteEvent/size": 1855,
                                    "fileWriteEvent/dataAtLowestOffset": "",
                                    "fileWriteEvent/fileExtension": "",
                                    "fileWriteEvent/writes": 49,
                                    "fileWriteEvent/fullPath": "E:\\Program Files\\Internet Explorer\\ssss",
                                    "fileWriteEvent/textAtLowestOffset": "",
                                    "fileWriteEvent/timestamp": "1995-04-20T06:55:30.484Z",
                                    "fileWriteEvent/numBytesSeenWritten": 91,
                                    "fileWriteEvent/fileName": "a.exe"
                                }
                            },
                            {
                                "_id": 2,
                                "agent": {
                                    "_id": "B56A3D71460563427005B6",
                                    "url": "/hx/api/v3/hosts/B56A3D71460563427005B6",
                                    "containment_state": "normal"
                                },
                                "condition": {
                                    "_id": "6RSq+67NCXEH9WrMfQwqlg==",
                                    "url": "/hx/api/v3/conditions/6RSq+67NCXEH9WrMfQwqlg=="
                                },
                                "event_at": "2016-04-13T16:03:48.044Z",
                                "matched_at": "2016-04-13T16:03:48.044Z",
                                "reported_at": "2016-04-13T16:03:48.041Z",
                                "source": "IOC",
                                "matched_source_alerts": [
                                    {
                                        "_id": 6,
                                        "url": "https://www.fireeye.com/event_stream/events_for_bot?ma_id=1898",
                                        "appliance_id": "cfd3:89ea:52dd:af36:bf08:dfd2:f316:b9ed",
                                        "meta": null,
                                        "indicator_revision": "20160413160347195319100050",
                                        "indicator_id": "d9892f3c-6947-4d3a-9188-0bb89f995214",
                                        "row": 1
                                    }
                                ],
                                "resolution": "ALERT",
                                "url": "/hx/api/v3/alerts/2",
                                "event_id": 18081,
                                "event_type": "fileWriteEvent",
                                "event_values": {
                                    "fileWriteEvent/drive": "D",
                                    "fileWriteEvent/id": 700942240,
                                    "fileWriteEvent/pid": 22635,
                                    "fileWriteEvent/lowestFileOffsetSeen": 1628,
                                    "fileWriteEvent/closed": 1,
                                    "fileWriteEvent/md5": "273c2eb718cafc02720424c34dc70ad5",
                                    "fileWriteEvent/process": "winlogon.exe",
                                    "fileWriteEvent/filePath": "Program Files\\Internet Explorer",
                                    "fileWriteEvent/size": 1300,
                                    "fileWriteEvent/dataAtLowestOffset": "",
                                    "fileWriteEvent/fileExtension": "dll",
                                    "fileWriteEvent/writes": 76,
                                    "fileWriteEvent/fullPath": "E:\\Program Files\\Internet Explorer\\ssss",
                                    "fileWriteEvent/textAtLowestOffset": "",
                                    "fileWriteEvent/timestamp": "1999-02-07T02:44:49.266Z",
                                    "fileWriteEvent/numBytesSeenWritten": 56,
                                    "fileWriteEvent/fileName": "s.dll"
                                }
                            },
                            {
                                "_id": 3,
                                "agent": {
                                    "_id": "3865B61460563427008B10",
                                    "url": "/hx/api/v3/hosts/3865B61460563427008B10",
                                    "containment_state": "normal"
                                },
                                "condition": {
                                    "_id": "frBwW5JL9DX_RPruNGR7Sg==",
                                    "url": "/hx/api/v3/conditions/frBwW5JL9DX_RPruNGR7Sg=="
                                },
                                "event_at": "2016-04-13T16:03:48.068Z",
                                "matched_at": "2016-04-13T16:03:48.068Z",
                                "reported_at": "2016-04-13T16:03:48.065Z",
                                "source": "IOC",
                                "matched_source_alerts": [
                                    {
                                        "_id": 3,
                                        "url": "https://www.fireeye.com/event_stream/events_for_bot?ma_id=1898",
                                        "appliance_id": "cfd3:89ea:52dd:af36:bf08:dfd2:f316:b9ed",
                                        "meta": null,
                                        "indicator_revision": "20160413160347195319100050",
                                        "indicator_id": "d9892f3c-6947-4d3a-9188-0bb89f995214",
                                        "row": 1
                                    }
                                ],
                                "url": "/hx/api/v3/alerts/3",
                                "event_id": 30458,
                                "event_type": "fileWriteEvent",
                                "event_values": {
                                    "fileWriteEvent/drive": "D",
                                    "fileWriteEvent/id": 498432242,
                                    "fileWriteEvent/pid": 96643,
                                    "fileWriteEvent/lowestFileOffsetSeen": 4681,
                                    "fileWriteEvent/closed": 1,
                                    "fileWriteEvent/md5": "a316a56c47f69ddedffcc19f1d94047f",
                                    "fileWriteEvent/process": "Explorer.EXE",
                                    "fileWriteEvent/filePath": "WINDOWS\\system32",
                                    "fileWriteEvent/size": 1970,
                                    "fileWriteEvent/dataAtLowestOffset": "",
                                    "fileWriteEvent/fileExtension": "dll",
                                    "fileWriteEvent/writes": 70,
                                    "fileWriteEvent/fullPath": "D:\\Users\\dave\\ApplicationData\\abcdefghijklmonpqrstuvsxyz\\00000000000000 0000000dfdfddfd000000dffdfdd00000dfdfd00000000fdfd0\\a.exe",
                                    "fileWriteEvent/textAtLowestOffset": "",
                                    "fileWriteEvent/timestamp": "2008-05-19T19:16:51.085Z",
                                    "fileWriteEvent/numBytesSeenWritten": 99,
                                    "fileWriteEvent/fileName": "a.exe"
                                }
                            },
                            {
                                "_id": 4,
                                "agent": {
                                    "_id": "2D19B171460563427005B5",
                                    "url": "/hx/api/v3/hosts/2D19B171460563427005B5",
                                    "containment_state": "normal"
                                },
                                "condition": {
                                    "_id": "WvyXeB8AqosXbJ7P3p08Qg==",
                                    "url": "/hx/api/v3/conditions/WvyXeB8AqosXbJ7P3p08Qg=="
                                },
                                "event_at": "2016-04-13T16:03:48.092Z",
                                "matched_at": "2016-04-13T16:03:48.092Z",
                                "reported_at": "2016-04-13T16:03:48.091Z",
                                "source": "IOC",
                                "matched_source_alerts": [
                                    {
                                        "_id": 8,
                                        "url": "https://www.fireeye.com/event_stream/events_for_bot?ma_id=1898",
                                        "appliance_id": "cfd3:89ea:52dd:af36:bf08:dfd2:f316:b9ed",
                                        "meta": null,
                                        "indicator_revision": "20160413160347195319100050",
                                        "indicator_id": "d9892f3c-6947-4d3a-9188-0bb89f995214",
                                        "row": 1
                                    }
                                ],
                                "resolution": "ALERT",
                                "url": "/hx/api/v3/alerts/4",
                                "event_id": 23369,
                                "event_type": "fileWriteEvent",
                                "event_values": {
                                    "fileWriteEvent/drive": "E",
                                    "fileWriteEvent/id": 70266581,
                                    "fileWriteEvent/pid": 99357,
                                    "fileWriteEvent/lowestFileOffsetSeen": 2801,
                                    "fileWriteEvent/closed": 1,
                                    "fileWriteEvent/md5": "df6cb25cca48a5576ab7712e9e171913",
                                    "fileWriteEvent/process": "Explorer.EXE",
                                    "fileWriteEvent/filePath": "Program Files\\Internet Explorer",
                                    "fileWriteEvent/size": 1542,
                                    "fileWriteEvent/dataAtLowestOffset": "",
                                    "fileWriteEvent/fileExtension": "",
                                    "fileWriteEvent/writes": 51,
                                    "fileWriteEvent/fullPath": "D:\\Users\\dave\\ApplicationData\\abcdefghijklmonpqrstuvsxyz\\00000000000000 0000000dfdfddfd000000dffdfdd00000dfdfd00000000fdfd0\\a.exe",
                                    "fileWriteEvent/textAtLowestOffset": "",
                                    "fileWriteEvent/timestamp": "2011-02-21T01:05:34.793Z",
                                    "fileWriteEvent/numBytesSeenWritten": 73,
                                    "fileWriteEvent/fileName": "a.exe"
                                }
                            },
                            {
                                "_id": 5,
                                "agent": {
                                    "_id": "3865B61460563427008B10",
                                    "url": "/hx/api/v3/hosts/3865B61460563427008B10",
                                    "containment_state": "normal"
                                },
                                "condition": {
                                    "_id": "7Un0vrQlKgQHY1xGt8Stvw==",
                                    "url": "/hx/api/v3/conditions/7Un0vrQlKgQHY1xGt8Stvw=="
                                },
                                "event_at": "2016-04-13T16:03:48.107Z",
                                "matched_at": "2016-04-13T16:03:48.107Z",
                                "reported_at": "2016-04-13T16:03:48.105Z",
                                "source": "IOC",
                                "matched_source_alerts": [
                                    {
                                        "_id": 1,
                                        "url": "https://www.fireeye.com/event_stream/events_for_bot?ma_id=1676",
                                        "appliance_id": "3dd4:3d09:da84:71a9:16d6:38ce:d848:3b21",
                                        "meta": null,
                                        "indicator_revision": "20160413160347404326100054",
                                        "indicator_id": "bebd4e8e-b352-43b6-9733-3e3e05d030dd",
                                        "row": 1
                                    },
                                    {
                                        "_id": 2,
                                        "url": "https://www.fireeye.com/event_stream/events_for_bot?ma_id=1676",
                                        "appliance_id": "3dd4:3d09:da84:71a9:16d6:38ce:d848:3b21",
                                        "meta": null,
                                        "indicator_revision": "20160413160347404326100054",
                                        "indicator_id": "bebd4e8e-b352-43b6-9733-3e3e05d030dd",
                                        "row": 1
                                    },
                                    {
                                        "_id": 3,
                                        "url": "https://www.fireeye.com/event_stream/events_for_bot?ma_id=1066",
                                        "appliance_id": "75c1:7a89:9b4b:34bc:4a89:e7ed:cce8:4d37",
                                        "meta": null,
                                        "indicator_revision": "20160413160347499728100056",
                                        "indicator_id": "0e116ea3-6708-43f0-8491-c515e9fdacb9",
                                        "row": 1
                                    },
                                    {
                                        "_id": 4,
                                        "url": "https://www.fireeye.com/event_stream/events_for_bot?ma_id=1066",
                                        "appliance_id": "75c1:7a89:9b4b:34bc:4a89:e7ed:cce8:4d37",
                                        "meta": null,
                                        "indicator_revision": "20160413160347499728100056",
                                        "indicator_id": "0e116ea3-6708-43f0-8491-c515e9fdacb9",
                                        "row": 1
                                    },
                                    {
                                        "_id": 5,
                                        "url": "https://www.fireeye.com/event_stream/events_for_bot?ma_id=1686",
                                        "appliance_id": "aa02:82b9:8680:f742:6383:a385:afda:5a23",
                                        "meta": null,
                                        "indicator_revision": "20160413160347573698100058",
                                        "indicator_id": "356a9140-ed9a-4a4a-a072-16afdcfbed6f",
                                        "row": 1
                                    },
                                    {
                                        "_id": 7,
                                        "url": "https://www.fireeye.com/event_stream/events_for_bot?ma_id=1685",
                                        "appliance_id": "4f2:93f1:b442:4a6d:608f:f041:c9f2:25b1",
                                        "meta": null,
                                        "indicator_revision": "20160413160347651174100060",
                                        "indicator_id": "ddbed919-38a9-40d4-b75e-25e2552393d9",
                                        "row": 1
                                    },
                                    {
                                        "_id": 8,
                                        "url": "https://www.fireeye.com/event_stream/events_for_bot?ma_id=1685",
                                        "appliance_id": "4f2:93f1:b442:4a6d:608f:f041:c9f2:25b1",
                                        "meta": null,
                                        "indicator_revision": "20160413160347651174100060",
                                        "indicator_id": "ddbed919-38a9-40d4-b75e-25e2552393d9",
                                        "row": 1
                                    },
                                    {
                                        "_id": 8,
                                        "url": "https://www.fireeye.com/event_stream/events_for_bot?ma_id=1314",
                                        "appliance_id": "4130:bfa6:e0da:d6ab:48ac:2d5d:395d:5e5a",
                                        "meta": null,
                                        "indicator_revision": "20160413160347749192100062",
                                        "indicator_id": "efa9d72d-e9ca-43da-a782-0c34c929eebc",
                                        "row": 1
                                    },
                                    {
                                        "_id": 9,
                                        "url": "https://www.fireeye.com/event_stream/events_for_bot?ma_id=1515",
                                        "appliance_id": "45fb:934e:acd8:c78b:e66b:e46f:a7f2:1554",
                                        "meta": null,
                                        "indicator_revision": "20160413160347846211100064",
                                        "indicator_id": "d0ef43fb-7339-4f2c-8968-aadedaaf50f5",
                                        "row": 1
                                    }
                                ],
                                "resolution": "ALERT",
                                "url": "/hx/api/v3/alerts/5",
                                "event_id": 19528,
                                "event_type": "ipv4NetworkEvent",
                                "event_values": {
                                    "ipv4NetworkEvent/localIP": "xxx.xxx.xxx.xxx",
                                    "ipv4NetworkEvent/localPort": 3764,
                                    "ipv4NetworkEvent/remoteIP": "xxx.xxx.xxx.xxx",
                                    "ipv4NetworkEvent/remotePort": 5069,
                                    "ipv4NetworkEvent/protocol": "tcp",
                                    "ipv4NetworkEvent/pid": 6680,
                                    "ipv4NetworkEvent/process": "explorer.exe",
                                    "ipv4NetworkEvent/timestamp": "2016-04-13T16:03:48.106Z",
                                    "ipv4NetworkEvent/id": 12036
                                }
                            } 
                        ]
                    },
                    "message": "OK",
                    "details": [],
                    "route": "/hx/api/v3/alerts"
                }
    return {
            "data": {
                "total": 6,
                "query": {},
                "sort": {},
                "offset": 0,
                "limit": 50,
                "entries": []
            }
        }
    