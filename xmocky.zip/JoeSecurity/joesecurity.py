from flask import Blueprint, request
import json
import logging
from datetime import datetime
from base64 import b64decode
from JoeSecurity.joesecurity_reports_json import json_report
from JoeSecurity.joesecurity_reports_html import html_report
from JoeSecurity.joesecurity_reports_pcap import pcap_report
from JoeSecurity.joesecurity_reports_pdf import pdf_report
from JoeSecurity.joesecurity_reports_xml import xml_report
from JoeSecurity.joesecurity_reports_sample_file import sample_file

BASE_URL = '/api/v2'.strip('/')
INTEGRATION = 'joesecurity_api'

mock_online = {
    'data': {
        'online': True
    }
}

mock_analysis = {
    "file": {
                'data':
                    {
                        'webid': '123',
                        'filename': 'malicious.pdf',
                        'status': 'finished',
                        'comments': 'This file will always can back malicious!',
                        'time': 'time',
                        'md5': 'e7c098adba278310a3de2f57335df7e3',
                        'sha1': '29b009e3688a221c175bb215285e15c343f6d2ba',
                        'sha256': '9c3eccc9c4ff45d564c86b774fd623480971243c6b3b5b5e41b4bbe2d630e0bf',
                        'runs': [
                            {
                                'detection': 'malicious',
                                'error': None,
                                'sigma': False,
                                'yara': False,
                                'system': 'w7_1'
                            },
                            {
                                'detection': 'malicious',
                                'error': None,
                                'sigma': False,
                                'yara': False,
                                'system': 'wxp_1'
                            }
                        ]
                    }
            },
    "url": {
                'data':
                    {
                        'webid': '456',
                        'filename': 'www.net.com',
                        'status': 'finished',
                        'comments': 'This URL will always come back malicious!',
                        'time': 'time',
                        'md5': None,
                        'sha1': None,
                        'sha256': None,
                        'runs': [
                            {
                                'detection': 'malicious',
                                'error': None,
                                'sigma': False,
                                'yara': False,
                                'system': 'w7_1'
                            },
                            {
                                'detection': 'malicious',
                                'error': None,
                                'sigma': False,
                                'yara': False,
                                'system': 'wxp_1'
                            }
                        ]
                    }
            },
    "error": {
                "errors": [
                    {
                        'message': 'webid not found'
                    }
                ]
            }
}

mock_analysis_list = {
    'data': [
        {
            'webid': '123'
        },
        {
            'webid': '456'
        }
    ]
}

mock_sample = {
    'reports': {
        'pdf': pdf_report,
        'xml': xml_report,
        'json': json_report,
        'html': html_report,
        'pcap': pcap_report,
        'sample': sample_file
    },
    'file': '',
    'error': {
                "errors": [
                    {
                        'message': 'analysis not found'
                    }
                ]
            }
}

joesecurity_api = Blueprint(f'{INTEGRATION}', __name__)
logger = logging.getLogger(__name__)

@joesecurity_api.route(f'/{BASE_URL}/server/online', methods=['GET', 'POST'])
def online():
    return json.dumps(mock_online)


@joesecurity_api.route(f'/{BASE_URL}/analysis/submit', methods=['POST'])
def analysis_submit():
    if request.method == 'POST':
        url = request.form.get('url')
        sample = request.files.get('sample')
        if url:
            mock_analysis['url']['data']['filename'] = url
        if sample:
            return_data = {
                'data': {
                    'webids': [
                        "123"
                    ]
                }
            }
        else:
            return_data = {
                'data': {
                    'webids': [
                        "456"
                    ]
                }
            }
        return json.dumps(return_data)


@joesecurity_api.route(f'/{BASE_URL}/analysis/info', methods=['POST'])
def analysis_info():
    now = datetime.now()
    if request.method == 'POST':
        webID = request.form.get('webid')
        if webID == '123':
            return_data = mock_analysis['file']
        elif webID == '456':
            return_data = mock_analysis['url']
        else:
            return_data = mock_analysis['error']
            return return_data, 404
        return_data['data']['time'] = now.isoformat()
        return_data['data']['webid'] = webID
        return json.dumps(return_data)


@joesecurity_api.route(f'/{BASE_URL}/analysis/download', methods=['POST'])
def analysis_download():
    if request.method == 'POST':
        report_type = request.form.get('type')
        webID = request.form.get('webid')
        if (webID in ['123', '456'] and report_type != 'sample') or (webID == '123' and report_type == 'sample'):
            return_data = mock_sample['reports'][report_type]
        else:
            return_data = mock_sample['error']
            return json.dumps(return_data), 404
        return b64decode(return_data)


@joesecurity_api.route(f'/{BASE_URL}/analysis/list', methods=['POST'])
def analysis_list():
    if request.method == 'POST':
        return json.dumps(mock_analysis_list)


@joesecurity_api.route(f'/{BASE_URL}/analysis/search', methods=['POST'])
def analysis_search():
    if request.method == 'POST':
        return json.dumps(mock_analysis_list)