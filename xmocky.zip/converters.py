from werkzeug.routing import BaseConverter, ValidationError
import re
 
class MansConverter(BaseConverter):
    def to_python(self, value):
        match = re.search(r'\.mans', value)
        if not match:
            raise ValidationError()
        return value
        