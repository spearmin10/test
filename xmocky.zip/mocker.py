import argparse
import shutil
import yaml

parser = argparse.ArgumentParser()
parser.add_argument("yaml_config_file", help="provide yaml file with config")
args = parser.parse_args()

with open(args.yaml_config_file) as f:
    data = yaml.safe_load(f)
    mock_name = data['name']
    uri = data['endpoint']
    blueprint = mock_name.lower() + '_api'
    commands = data['commands']

shutil.copyfile('Template.py', mock_name + '.py')
filename = mock_name + '.py'

with open(filename) as in_file:
    s = in_file.read()
    result = s.replace('[endpoint_url]', uri)
    result = result.replace('[template_api]', blueprint)
 
with open(filename, 'w') as out_file:
    out_file.write(result)
    integration = '{BASE_URL}'
    for command in commands:
        if not command['params']:
            out_file.write(f"\n@{blueprint}.route(f'/{integration}{command['uri']}')\ndef {command['command']}():\n")
            if not command['response'].startswith('['):
                out_file.write(f"\treturn {command['response']}\n")
            else:
                out_file.write(f"\tresult = {command['response']}\n\treturn json.dumps(result)\n")
        else:
            out_file.write(f"\n@{blueprint}.route(f'/{integration}{command['uri']}<{command['param']}>')\ndef {command['command']}({command['param']}):\n")
            if not command['response'].startswith('['):
                out_file.write(f"\treturn {command['response']}\n")
            else:
                out_file.write(f"\tresult = {command['response']}\n\treturn json.dumps(result)\n")
        
with open ('XMocky.py') as xrfile:
    content = xrfile.readlines()
    for index, line in enumerate(content):
        if line.startswith('# Int'):
            location = index + 1
        if line.startswith('# Blue'):
            location2 = index + 2

with open ('XMocky.py', 'w') as xwfile:   
    content.insert(location, f'from {mock_name} import {blueprint}\n')
    content.insert(location2, f'app.register_blueprint({blueprint})\n')
    xwfile.writelines(content)
