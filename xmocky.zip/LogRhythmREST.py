from flask import Blueprint, request, Response
import json
import logging

BASE_URL = '/'.strip('/')
INTEGRATION = 'logrhythm_rest_api'

logrhythm_rest_api = Blueprint(f'{INTEGRATION}', __name__)
logger = logging.getLogger(__name__)

query_xml = (
    """
    <?xml version="1.0" encoding="UTF-8"?>
    <aie>
    </aie>
    """
).strip()

log_message_xml = ( #Xs Required at start and beginning. Integration performs a slice.
    """
XXX<?xml version="1.0"?>
<Event xmlns:x="http://schemas.microsoft.com/win/2004/08/events/event">
<x:EventID>34</x:EventID>
<x:Level>Lev</x:Level>
<x:Task>Task</x:Task>
<x:Opcode>OpCode</x:Opcode>
<x:Keywords>Keywords</x:Keywords>
<x:Channel>Channel</x:Channel>
<x:Computer>Computer</x:Computer>
<x:EventData>EvData</x:EventData>
</Event>XX
    """
).strip()




@logrhythm_rest_api.route(f'/{BASE_URL}/lr-admin-api/hosts', methods = ["GET"],defaults={'id': None})
@logrhythm_rest_api.route(f'/{BASE_URL}/lr-admin-api/hosts/<id>', methods = ["GET"])
def test(id):
    result =[
        {
        "id": -1,
        "entity": {
            "id": 12345,
            "name": "XMOCKY_NAME"
        },
        "name": "XMOCKY_NAME",
        "shortDesc": "Short Description",
        "longDesc": "Long Description",
        "riskLevel": "High-High",
        "threatLevel": "None",
        "threatLevelComments": "TL Comments Here",
        "recordStatusName": "Retired",
        "hostZone": "Unknown",
        "os": "Win10",
        "useEventlogCredentials": True,
        "osType": "Windows",
        "location" : "US"
        }
    ]
    
    if id : result = result[0]

    r = Response(response=json.dumps(result), status=200, mimetype="application/json")
    r.headers["Content-Type"] = "application/json"
    return r


@logrhythm_rest_api.route(f'/{BASE_URL}/lr-admin-api/hosts/', methods = ["POST"])
def hosts():
    result ={
        "id": -1,
        "entity": {
            "id": 12345,
            "name": "XMOCKY_NAME"
        },
        "name": "XMOCKY_NAME",
        "shortDesc": "Short Description",
        "longDesc": "Long Description",
        "riskLevel": "High-High",
        "threatLevel": "None",
        "threatLevelComments": "TL Comments Here",
        "recordStatusName": "Retired",
        "hostZone": "Unknown",
        "os": "Win10",
        "useEventlogCredentials": True,
        "osType": "Windows",
        "location" : "US"
    }
    
    r = Response(response=json.dumps(result), status=200, mimetype="application/json")
    r.headers["Content-Type"] = "application/json"
    return r

@logrhythm_rest_api.route(f'/{BASE_URL}/lr-admin-api/hosts/status', methods = ["PUT"])
def change_status():
    result ={
        "id": -1,
        "entity": {
            "id": 12345,
            "name": "XMOCKY_NAME"
        },
        "name": "XMOCKY_NAME",
        "shortDesc": "Short Description",
        "longDesc": "Long Description",
        "riskLevel": "High-High",
        "threatLevel": "None",
        "threatLevelComments": "TL Comments Here",
        "recordStatusName": "Retired",
        "hostZone": "Unknown",
        "os": "Win10",
        "useEventlogCredentials": True,
        "osType": "Windows",
        "location" : "US"
    }
    
    r = Response(response=json.dumps(result), status=200, mimetype="application/json")
    r.headers["Content-Type"] = "application/json"
    return r

@logrhythm_rest_api.route(f'/{BASE_URL}/lr-admin-api/persons', methods = ["GET"], defaults={'x': None})
@logrhythm_rest_api.route(f'/{BASE_URL}/lr-admin-api/persons/<x>', methods = ["GET"])
def persons(x):
    result =[{
        "id" :5432,
        "dateUpdated": "2019-08-22",
        "recordStatusName" : "Retired",
        "lastName" : "Smith",
        "firstName" : "John",
        "isAPIPerson" : True,
        "user" : {
            "id": 1234,
            "login" : "jsmith"
        }

    }]
    
    if x : result = result[0]

    r = Response(response=json.dumps(result), status=200, mimetype="application/json")
    r.headers["Content-Type"] = "application/json"
    return r

@logrhythm_rest_api.route(f'/{BASE_URL}/lr-admin-api/networks', methods = ["GET"], defaults={'x': None})
@logrhythm_rest_api.route(f'/{BASE_URL}/lr-admin-api/networks/<x>', methods = ["GET"])
def networks(x):
    result =[{
        "id" :5432,
        "eip": "8.8.4.4",
        "bip": "8.8.4.5",
        "hostZone" : "dmz",
        "recordStatusName" : "Retired",
        "isAPIPerson" : True,
        "name": "XMOCKY_NAME",
        "riskLevel": "High-High",
        "threatLevel": "None",
        "location": "US",
        "dateUpdated" : "2019-08-22",
        "entity" : {
            "id": 1234,
            "name" : "mock_network"
        }

    }]
    
    if x : result = result[0]

    r = Response(response=json.dumps(result), status=200, mimetype="application/json")
    r.headers["Content-Type"] = "application/json"
    return r


@logrhythm_rest_api.route(f'/{BASE_URL}/lr-drilldown-cache-api/drilldown/<id>', methods = ["GET","POST"])
def logqueryservice(id):
    result = {
        "Data" : {
            "DrillDownResults": {
                "RuleBlocks": [
                    {
                        "DrillDownLogs": json.dumps( [
                            {
                                "ID" : 1234,
                                "Name" :"Log Entry",
                                "logMessage": "MOCK Log Message"
                            }
                        ]),
                        "DDSummaries" : [

                        ]

                    }
                ],
                "AIEMsgXml" : query_xml,
                "Status" : 1,
                "AlarmID" : 23478
            }
        }
    }
    
    r = Response(response=json.dumps(result), status=200, mimetype="application/json")
    r.headers["Content-Type"] = "application/json"
    return r

@logrhythm_rest_api.route(f'/{BASE_URL}/lr-legacy-search-api/esquery', methods = ["POST"])
def query():
    result = {
        "hits" : {
            "hits": [
                {
                    "fields": {
                    "logMessage" : log_message_xml
                    }
                }

            ]
        }

        }
    r = Response(response=json.dumps(result), status=200, mimetype="application/json")
    r.headers["Content-Type"] = "application/json"
    return r 


"""lr-add-alarm-comments
lr-get-alarm-by-id 
lr-get-alarm-events-by-id 
lr-get-alarm-history-by-id 
lr-update-alarm-status 
lr-get-alarms 
lr-get-hosts-by-entity-id 
lr-add-host 
lr-execute-query"""
