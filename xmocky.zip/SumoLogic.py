from flask import Blueprint, request
import json
import logging

BASE_URL = '/v1/'.strip('/')
INTEGRATION = 'sumologic_api'

sumologic_api = Blueprint(f'{INTEGRATION}', __name__)
logger = logging.getLogger(__name__)

@sumologic_api.route(f'/{BASE_URL}/collectors')
def test():
    return {  
   "collectors":[  
      {  
         "id":2,
         "name":"OtherCollector",
         "collectorType":"Installable",
         "alive":True,
         "links":[  
            {  
               "rel":"sources",
               "href":"/v1/collectors/2/sources"
            }
         ],
         "collectorVersion":"19.33-28",
         "ephemeral":False,
         "description":"Local Windows Collection",
         "osName":"Windows 7",
         "osArch":"amd64",
         "osVersion":"6.1",
         "category":"local"
      },
   ]
}

@sumologic_api.route(f'/{BASE_URL}/search/jobs', methods=['GET', 'POST'])
def searchjobs():
    return {  
   "collectors":[  
      {  
         "id":2,
         "name":"OtherCollector",
         "collectorType":"Installable",
         "alive":True,
         "links":[  
            {  
               "rel":"sources",
               "href":"/v1/collectors/2/sources"
            }
         ],
         "collectorVersion":"19.33-28",
         "ephemeral":False,
         "description":"Local Windows Collection",
         "osName":"Windows 7",
         "osArch":"amd64",
         "osVersion":"6.1",
         "category":"local"
      },
   ]
}

@sumologic_api.route(f'/{BASE_URL}/search/jobs/undefined', methods=['GET', 'DELETE'])
def getlogstatus():
    return {
   "state":"DONE GATHERING RESULTS",
   "messageCount":90,
   "histogramBuckets":[
      {
         "length":60000,
         "count":1,
         "startTimestamp":1359404820000
      },
      {
         "length":60000,
         "count":1,
         "startTimestamp":1359405480000
      },
      {
         "length":60000,
         "count":1,
         "startTimestamp":1359404340000
      }
   ],
   "pendingErrors":[

   ],
   "pendingWarnings":[

   ],
   "recordCount":1
}

@sumologic_api.route(f'/{BASE_URL}/search/jobs/undefined/messages', methods=['GET'])
def getmessages():
	return {
   "fields":[
      {
         "name":"_messageid",
         "fieldType":"long",
         "keyField":False
      },
      {
         "name":"_sourceid",
         "fieldType":"long",
         "keyField":False
      },
      {
         "name":"_sourcename",
         "fieldType":"string",
         "keyField":False
      },
      {
         "name":"_sourcehost",
         "fieldType":"string",
         "keyField":False
      },
      {
         "name":"_sourcecategory",
         "fieldType":"string",
         "keyField":False
      },
      {
         "name":"_format",
         "fieldType":"string",
         "keyField":False
      },
      {
         "name":"_size",
         "fieldType":"long",
         "keyField":False
      },
      {
         "name":"_messagetime",
         "fieldType":"long",
         "keyField":False
      },
      {
         "name":"_receipttime",
         "fieldType":"long",
         "keyField":False
      },
      {
         "name":"_messagecount",
         "fieldType":"int",
         "keyField":False
      },
      {
         "name":"_raw",
         "fieldType":"string",
         "keyField":False
      },
      {
         "name":"_source",
         "fieldType":"string",
         "keyField":False
      },
      {
         "name":"_collectorid",
         "fieldType":"long",
         "keyField":False
      },
      {
         "name":"_collector",
         "fieldType":"string",
         "keyField":False
      },
      {
         "name":"_blockid",
         "fieldType":"long",
         "keyField":False
      }
   ],
   "messages":[
      {
         "map":{
            "_receipttime":"1359407350899",
            "_source":"service",
            "_collector":"local",
            "_format":"plain:atp:o:0:l:29:p:yyyy-MM-dd HH:mm:ss,SSS ZZZZ",
            "_blockid":"-9223372036854775669",
            "_messageid":"-9223372036854773763",
            "_messagetime":"1359407350333",
            "_collectorid":"1579",
            "_sourcename":"/Users/christian/Development/sumo/ops/assemblies/latest/service-20.1-SNAPSHOT/logs/service.log",
            "_sourcehost":"Chiapet.local",
            "_raw":"2013-01-28 13:09:10,333 -0800 INFO  [module=SERVICE] [logger=util.scala.zk.discovery.AWSServiceRegistry] [thread=pool-1-thread-1] FINISHED findRunningInstances(ListBuffer((Service: name: elasticache-1, defaultProps: Map()), (Service: name: userAndOrgCache, defaultProps: Map()), (Service: name: rds_cloudcollector, defaultProps: Map()))) returning Map((Service: name: elasticache-1, defaultProps: Map()) -> [], (Service: name: userAndOrgCache, defaultProps: Map()) -> [], (Service: name: rds_cloudcollector, defaultProps: Map()) -> []) after 1515 ms",
            "_size":"549",
            "_sourcecategory":"service",
            "_sourceid":"1640",
            "_messagecount":"2044"
         }
      },
      {
         "map":{
            "_receipttime":"1359407051885",
            "_source":"service",
            "_collector":"local",
            "_format":"plain:atp:o:0:l:29:p:yyyy-MM-dd HH:mm:ss,SSS ZZZZ",
            "_blockid":"-9223372036854775674",
            "_messageid":"-9223372036854773772",
            "_messagetime":"1359407049529",
            "_collectorid":"1579",
            "_sourcename":"/Users/christian/Development/sumo/ops/assemblies/latest/service-20.1-SNAPSHOT/logs/service.log",
            "_sourcehost":"Chiapet.local",
            "_raw":"2013-01-28 13:04:09,529 -0800 INFO  [module=SERVICE] [logger=com.netflix.config.sources.DynamoDbConfigurationSource] [thread=pollingConfigurationSource] Successfully polled Dynamo for a new configuration based on table:raychaser-chiapetProperties",
            "_size":"246",
            "_sourcecategory":"service",
            "_sourceid":"1640",
            "_messagecount":"2035"
         }
      }
   ]
}
@sumologic_api.route(f'/{BASE_URL}/search/jobs/undefined/records', methods=['GET'])
def getrecords():
	return {
   "fields":[
      {
         "name":"_sourcecategory",
         "fieldType":"string",
         "keyField":True
      },
      {
         "name":"_count",
         "fieldType":"int",
         "keyField":False
      }
   ],
   "records":[
      {
         "map":{
            "_count":"90",
            "_sourcecategory":"service"
         }
      }
   ]
}




