from flask import Blueprint, request, Response
import json
import logging

BASE_URL = ''.strip('/')
INTEGRATION = 'logrhythem_soap_api'

logrhythm_soap_api = Blueprint(f'{INTEGRATION}', __name__)
logger = logging.getLogger(__name__)



event_xml = (
 """
<?xml version="1.0"?>
<Envelope>
    <Body>
        <GetFirstPageAlarmsByAlarmStatusResponse>
            <GetFirstPageAlarmsByAlarmStatusResult>
                <Alarms>
                    <AlarmSummaryDataModel>
                        <AlarmDate>2018-03-27T09:18:04.41</AlarmDate>
                        <AlarmID>12</AlarmID>
                        <AlarmRuleID>677</AlarmRuleID>
                        <AlarmRuleName>LogRhythm AI Comm Manager Heartbeat Missed</AlarmRuleName>
                        <AlarmStatus>New</AlarmStatus>
                        <DateInserted>2018-03-27T09:18:04.72</DateInserted>
                        <DateUpdated>2018-04-09T08:50:47.027</DateUpdated>
                        <EntityID>1</EntityID>
                        <EntityName>Primary Site</EntityName>
                        <EventCount>1</EventCount>
                        <EventDateFirst>2018-03-27T09:18:02.873</EventDateFirst>
                        <EventDateLast>2018-03-27T09:18:02.873</EventDateLast>
                        <LastUpdatedID>3</LastUpdatedID>
                        <LastUpdatedName>api, lrapi</LastUpdatedName>
                        <RBPAvg>67</RBPAvg>
                        <RBPMax>67</RBPMax>
                    </AlarmSummaryDataModel>
                    <AlarmSummaryDataModel>
                        <AlarmDate>2018-03-27T09:18:04.42</AlarmDate>
                        <AlarmID>15</AlarmID>
                        <AlarmRuleID>677</AlarmRuleID>
                        <AlarmRuleName>Mock Alert</AlarmRuleName>
                        <AlarmStatus>New</AlarmStatus>
                        <DateInserted>2018-03-27T09:18:04.72</DateInserted>
                        <DateUpdated>2018-04-09T08:50:47.027</DateUpdated>
                        <EntityID>5</EntityID>
                        <EntityName>Primary Site</EntityName>
                        <EventCount>1</EventCount>
                        <EventDateFirst>2018-03-27T09:18:02.873</EventDateFirst>
                        <EventDateLast>2018-03-27T09:18:02.873</EventDateLast>
                        <LastUpdatedID>3</LastUpdatedID>
                        <LastUpdatedName>api, lrapi</LastUpdatedName>
                        <RBPAvg>57</RBPAvg>
                        <RBPMax>67</RBPMax>
                    </AlarmSummaryDataModel>
                    <AlarmSummaryDataModel>
                        <AlarmDate>2018-03-27T09:19:02.51</AlarmDate>
                        <AlarmID>17</AlarmID>
                        <AlarmRuleID>677</AlarmRuleID>
                        <AlarmRuleName>LogRhythm AI Comm Manager Heartbeat Missed</AlarmRuleName>
                        <AlarmStatus>New</AlarmStatus>
                        <DateInserted>2018-03-27T09:18:04.72</DateInserted>
                        <DateUpdated>2018-04-09T08:50:47.027</DateUpdated>
                        <EntityID>6</EntityID>
                        <EntityName>Primary Site</EntityName>
                        <EventCount>3</EventCount>
                        <EventDateFirst>2018-03-27T09:18:02.873</EventDateFirst>
                        <EventDateLast>2018-03-27T09:18:02.873</EventDateLast>
                        <LastUpdatedID>3</LastUpdatedID>
                        <LastUpdatedName>api, lrapi</LastUpdatedName>
                        <RBPAvg>67</RBPAvg>
                        <RBPMax>67</RBPMax>
                    </AlarmSummaryDataModel>
                     <AlarmSummaryDataModel>
                        <AlarmDate>2018-03-27T09:19:03.50</AlarmDate>
                        <AlarmID>14</AlarmID>
                        <AlarmRuleID>677</AlarmRuleID>
                        <AlarmRuleName>LogRhythm AI Comm Manager Heartbeat Missed</AlarmRuleName>
                        <AlarmStatus>New</AlarmStatus>
                        <DateInserted>2018-03-27T09:18:04.72</DateInserted>
                        <DateUpdated>2018-04-09T08:50:47.027</DateUpdated>
                        <EntityID>6</EntityID>
                        <EntityName>Primary Site</EntityName>
                        <EventCount>3</EventCount>
                        <EventDateFirst>2018-03-27T09:18:02.873</EventDateFirst>
                        <EventDateLast>2018-03-27T09:18:02.873</EventDateLast>
                        <LastUpdatedID>3</LastUpdatedID>
                        <LastUpdatedName>api, lrapi</LastUpdatedName>
                        <RBPAvg>67</RBPAvg>
                        <RBPMax>67</RBPMax>
                    </AlarmSummaryDataModel>
                </Alarms>
            </GetFirstPageAlarmsByAlarmStatusResult>
        </GetFirstPageAlarmsByAlarmStatusResponse>
    </Body>
</Envelope>
"""
).strip()

@logrhythm_soap_api.route(f'/{BASE_URL}/test')
def test():
    return {'result': 'it works'}




@logrhythm_soap_api.route(f'/{BASE_URL}/LogRhythm.API/Services/AlarmServiceBasicAuth.svc', methods=["POST","GET"])
def basicauth():

    return Response(event_xml, mimetype='text/xml')
