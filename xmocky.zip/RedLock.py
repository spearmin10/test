from flask import Blueprint, request, Response
import json
import logging

INTEGRATION = 'redlock_api'

redlock_api = Blueprint(f'{INTEGRATION}', __name__)
logger = logging.getLogger(__name__)

@redlock_api.route('/test')
def test():
    return {'result': 'it works'}

@redlock_api.route(f'/login',methods=['POST'])
def test_module():
    return {
            "token":"eyJhbGciOiJIUzI1NiJ9.eyJmaXJzdExvZ2luIjpmYWxzZSwicmVzdHJpY3QiOjAsImlzQWNjZXNzS2V5TG9naW4iOnRydWUsInV",
            "message":"login_successful"
    }

@redlock_api.route(f'/alert/<id>')
def redlock_alert_details(id):
    return {
        "alertRules": [
            {
                "alertAssociationTime": 1576014006878,
                "alertRuleNotificationConfig": [],
                "allowAutoRemediate": False,
                "deleted": False,
                "lastModifiedBy": "ankur@redlock.io",
                "lastModifiedOn": 1538669516320,
                "name": "Default Alert Rule",
                "notifyOnDismissed": False,
                "notifyOnOpen": True,
                "notifyOnResolved": False,
                "notifyOnSnoozed": False,
                "policyScanConfigId": "43178516-c63b-4dc1-8893-212de6b111f1"
            }
        ],
        "alertTime": 1588553089432,
        "firstSeen": 1576014006873,
        "id": id,
        "lastSeen": 1589387387237,
        "policy": {
            "policyId": "6c5091cc-2da3-42b3-877e-42fd7d9e85d6",
            "policyType": "config",
            "remediable": False,
            "systemDefault": True
        },
        "resource": {
            "account": "todd azure",
            "accountId": "c21d5724-78f1-4cd4-8197-da25a4088ead",
            "cloudType": "azure",
            "data": {
                "autoProvisioningSettings": [
                    {
                    "id": "/subscriptions/c21d5724-78f1-4cd4-8197-da25a4088ead/providers/Microsoft.Security/autoProvisioningSettings/default",
                    "name": "default",
                    "properties": {
                        "autoProvision": "Off"
                    },
                    "type": "Microsoft.Security/autoProvisioningSettings"
                    }
                ],
                "pricings": [
                    {
                    "id": "/subscriptions/c21d5724-78f1-4cd4-8197-da25a4088ead/providers/Microsoft.Security/pricings/default",
                    "name": "default",
                    "properties": {
                        "pricingTier": "Free"
                    },
                    "type": "Microsoft.Security/pricings"
                    }
                ],
                "securityContacts": []
            },
            "id": "default",
            "name": "default",
            "region": "global",
            "regionId": "",
            "resourceApiName": "azure-security-center-settings",
            "resourceType": "OTHER"
        },
        "riskDetail": {
            "policyScores": [
                {
                    "name": "Azure Security Center automatic provisioning of monitoring agent is set to Off",
                    "points": "10/10",
                    "policyId": "6c5091cc-2da3-42b3-877e-42fd7d9e85d6",
                    "remediable": False,
                    "riskScore": {
                    "maxScore": 10,
                    "score": 10
                    }
                },
                {
                    "name": "Azure Security Center 'Also send email notification to subscription owners' value is not set",
                    "points": "10/10",
                    "policyId": "fc914428-2c9a-4240-a3a7-769b85187278",
                    "remediable": False,
                    "riskScore": {
                    "maxScore": 10,
                    "score": 10
                    }
                },
                {
                    "name": "Azure Security Center contact phone number not set",
                    "points": "1/1",
                    "policyId": "e8799768-aeda-4d42-897a-29ede5798312",
                    "remediable": False,
                    "riskScore": {
                    "maxScore": 1,
                    "score": 1
                    }
                },
                {
                    "name": "Azure Security Center contact email not set",
                    "points": "10/10",
                    "policyId": "46e24e8c-945c-4048-91f2-800cccf54613",
                    "remediable": False,
                    "riskScore": {
                    "maxScore": 10,
                    "score": 10
                    }
                },
                {
                    "name": "Azure Security Center 'Standard pricing tier' is not selected",
                    "points": "10/10",
                    "policyId": "c221ce81-99df-487e-8c05-4329335e9f9a",
                    "remediable": False,
                    "riskScore": {
                    "maxScore": 10,
                    "score": 10
                    }
                },
                {
                    "name": "Azure Security Center send email notifications set to 'Off'",
                    "points": "10/10",
                    "policyId": "8d78bf42-4e80-4e25-89fa-5f8a7fe8ddb1",
                    "remediable": False,
                    "riskScore": {
                    "maxScore": 10,
                    "score": 10
                    }
                }
            ],
            "rating": "F",
            "riskScore": {
                "maxScore": 51,
                "score": 51
            },
            "score": "51/51"
        },
    "status": "open"
    }

@redlock_api.route(f'/alert/dismiss',methods=['POST'])
def redlock_alert_dismiss():
    return {}

@redlock_api.route(f'/alert/reopen',methods=['POST'])
def redlock_alert_reopen():
    return {}

@redlock_api.route(f'/filter/alert/suggest')
def redlock_list_filters():
    return {
        "account.group": {
            "options": [],
            "staticFilter": False
        },
        "alert.id": {
            "options": [],
            "staticFilter": False
        },
        "alert.status": {
            "options": [
                "dismissed",
                "snoozed",
                "open",
                "resolved"
            ],
            "staticFilter": True
        },
        "alertRule.name": {
            "options": [],
            "staticFilter": False
        },
        "cloud.account": {
            "options": [],
            "staticFilter": False
        },
        "cloud.accountId": {
            "options": [],
            "staticFilter": False
        },
        "cloud.region": {
            "options": [],
            "staticFilter": False
        },
        "cloud.service": {
            "options": [],
            "staticFilter": False
        },
        "cloud.type": {
            "options": [
                "alibaba_cloud",
                "aws",
                "azure",
                "gcp"
            ],
            "staticFilter": True
        },
        "policy.complianceRequirement": {
            "options": [],
            "staticFilter": False
        },
        "policy.complianceSection": {
            "options": [],
            "staticFilter": False
        },
        "policy.complianceStandard": {
            "options": [],
            "staticFilter": False
        },
        "policy.label": {
            "options": [],
            "staticFilter": False
        },
        "policy.name": {
            "options": [
                "CloudTrail trail is not integrated with CloudWatch Log",
                "GCP Kubernetes Engine Clusters have legacy compute engine metadata endpoints enabled",
                "AWS ACM Certificate with wildcard domain name",
                "AWS CloudTrail is not enabled in all regions",
                "AWS CloudTrail log validation is not enabled in all regions"
            ],
            "staticFilter": False
        },
        "policy.remediable": {
            "options": [
                "True",
                "False"
            ],
            "staticFilter": True
        },
        "policy.rule.type": {
            "options": [
                "cft",
                "k8s",
                "tf"
            ],
            "staticFilter": True
        },
        "policy.severity": {
            "options": [
                "high",
                "medium",
                "low"
            ],
            "staticFilter": True
        },
        "policy.subtype": {
            "options": [
                "build",
                "run"
            ],
            "staticFilter": True
        },
        "policy.type": {
            "options": [
                "anomaly",
                "audit_event",
                "config",
                "network"
            ],
            "staticFilter": True
        },
        "resource.id": {
            "options": [],
            "staticFilter": False
        },
        "resource.name": {
            "options": [],
            "staticFilter": False
        },
        "resource.type": {
            "options": [
                "AWS Resource Access Manager Principals",
                "IAM Password Policy",
                "IAM Policies",
                "S3 Bucket ACLs"
            ],
            "staticFilter": False
        },
        "risk.grade": {
            "options": [
                "A",
                "B",
                "C",
                "F"
            ],
            "staticFilter": True
        }
    }
@redlock_api.route(f'/alert', methods=['POST'])
def redlock_search_alert():
    results = [{
        "alertTime": 1589940343486,
        "firstSeen": 1589940343486,
        "id": "P-1030",
        "investigateOptions": {
            "alertId": "P-1030"
        },
        "lastSeen": 1589944678982,
        "policy": {
            "complianceMetadata": [
                {
                    "complianceId": "9acef5b4-04a7-4cf8-b78c-83a27601b8c5",
                    "customAssigned": False,
                    "requirementId": "3.13",
                    "requirementName": "SYSTEM AND COMMUNICATIONS PROTECTION",
                    "sectionDescription": "Monitor, control, and protect organizational communications (i.e., information transmitted or received by organizational information systems) at the external boundaries and key internal boundaries of the information systems.",
                    "sectionId": "3.13.1",
                    "sectionLabel": "3.13.1",
                    "standardDescription": "NIST 800-171 Rev1 Compliance Standard",
                    "standardName": "NIST 800-171 Rev1",
                    "systemDefault": False
                },
                {
                    "complianceId": "e431082b-ff3e-4bcb-b084-39e3aa43678f",
                    "customAssigned": False,
                    "requirementId": "3.13",
                    "requirementName": "SYSTEM AND COMMUNICATIONS PROTECTION",
                    "sectionDescription": "Employ architectural designs, software development techniques, and systems engineering principles that promote effective information security within organizational information systems.",
                    "sectionId": "3.13.2",
                    "sectionLabel": "3.13.2",
                    "standardDescription": "NIST 800-171 Rev1 Compliance Standard",
                    "standardName": "NIST 800-171 Rev1",
                    "systemDefault": False
                },
                {
                    "complianceId": "f9168f42-15c7-45d0-9347-c9a080fd8976",
                    "customAssigned": False,
                    "requirementId": "3.13",
                    "requirementName": "SYSTEM AND COMMUNICATIONS PROTECTION",
                    "sectionDescription": "Implement subnetworks for publicly accessible system components that are physically or logically separated from internal networks.",
                    "sectionId": "3.13.5",
                    "sectionLabel": "3.13.5",
                    "standardDescription": "NIST 800-171 Rev1 Compliance Standard",
                    "standardName": "NIST 800-171 Rev1",
                    "systemDefault": False
                },
                {
                    "complianceId": "d78391e4-1a20-4928-8367-b2fd0fc123c6",
                    "customAssigned": False,
                    "requirementId": "3.14",
                    "requirementName": "SYSTEM AND INFORMATION INTEGRITY",
                    "sectionDescription": "Monitor the information system including inbound and outbound communications traffic, to detect attacks and indicators of potential attacks.",
                    "sectionId": "3.14.6",
                    "sectionLabel": "3.14.6",
                    "standardDescription": "NIST 800-171 Rev1 Compliance Standard",
                    "standardName": "NIST 800-171 Rev1",
                    "systemDefault": False
                },
                {
                    "complianceId": "0022415a-00cb-4222-b1e1-1b0c35310ce5",
                    "customAssigned": False,
                    "requirementId": "DSI",
                    "requirementName": "Data Security & Information Lifecycle Management",
                    "sectionDescription": "Data Inventory / Flows : Policies and procedures shall be established, and supporting business processes and technical measures implemented, to inventory, document, and maintain data flows for data that is resident (permanently or temporarily) within the service's geographically distributed (physical and virtual) applications and infrastructure network and systems components and/or shared with other third parties to ascertain any regulatory, statutory, or supply chain agreement (SLA) compliance impact, and to address any other business risks associated with the data. Upon request, provider shall inform customer (tenant) of compliance impact and risk, especially if customer data is used as part of the services.",
                    "sectionId": "DSI-02",
                    "sectionLabel": "CSA CCM",
                    "standardDescription": "Cloud Security Alliance: Cloud Controls Matrix Version 3.0.1",
                    "standardName": "CSA CCM v3.0.1",
                    "systemDefault": False
                },
                {
                    "complianceId": "bd35c1ad-c76f-4135-8aab-16a0281848f1",
                    "customAssigned": False,
                    "requirementId": "IAM",
                    "requirementName": "Identity & Access Management",
                    "sectionDescription": "Third Party Access : The identification, assessment, and prioritization of risks posed by business processes requiring third-party access to the organization's information systems and data shall be followed by coordinated application of resources to minimize, monitor, and measure likelihood and impact of unauthorized or inappropriate access. Compensating controls derived from the risk analysis shall be implemented prior to provisioning access.",
                    "sectionId": "IAM-07",
                    "sectionLabel": "CSA CCM",
                    "standardDescription": "Cloud Security Alliance: Cloud Controls Matrix Version 3.0.1",
                    "standardName": "CSA CCM v3.0.1",
                    "systemDefault": False
                },
                {
                    "complianceId": "f4f029b1-2b02-4c9a-a7bb-6de6e2c5b453",
                    "customAssigned": False,
                    "requirementId": "IVS",
                    "requirementName": "Infrastructure & Virtualization Security",
                    "sectionDescription": "Network Security : Network environments and virtual instances shall be designed and configured to restrict and monitor traffic between trusted and untrusted connections. These configurations shall be reviewed at least annually, and supported by a documented justification for use for all allowed services, protocols, ports, and by compensating controls.",
                    "sectionId": "IVS-06",
                    "sectionLabel": "CSA CCM",
                    "standardDescription": "Cloud Security Alliance: Cloud Controls Matrix Version 3.0.1",
                    "standardName": "CSA CCM v3.0.1",
                    "systemDefault": False
                },
                {
                    "complianceId": "d4d51e32-fae7-44ef-b348-5aed7e8a62a4",
                    "customAssigned": False,
                    "requirementId": "IVS",
                    "requirementName": "Infrastructure & Virtualization Security",
                    "sectionDescription": "Production / Non-Production Environments : Production and non-production environments shall be separated to prevent unauthorized access or changes to information assets. Separation of the environments may include: stateful inspection firewalls, domain/realm authentication sources, and clear segregation of duties for personnel accessing these environments as part of their job duties.",
                    "sectionId": "IVS-08",
                    "sectionLabel": "CSA CCM",
                    "standardDescription": "Cloud Security Alliance: Cloud Controls Matrix Version 3.0.1",
                    "standardName": "CSA CCM v3.0.1",
                    "systemDefault": False
                },
                {
                    "complianceId": "694d6f8b-9f1b-40ad-bf7d-e6ceb0b5c072",
                    "customAssigned": False,
                    "requirementId": "1",
                    "requirementName": "Install and maintain a firewall configuration to protect cardholder data",
                    "sectionDescription": "Restrict inbound and outbound traffic to that which is necessary for the cardholder data environment, and specifically deny all other traffic.",
                    "sectionId": "1.2.1",
                    "sectionLabel": "2.1",
                    "standardDescription": "Payment Card Industry Data Security Standard version 3.2",
                    "standardName": "PCI DSS v3.2",
                    "systemDefault": False
                },
                {
                    "complianceId": "72bcd5c2-2a68-4364-a8ef-82eaf3f566f9",
                    "customAssigned": False,
                    "requirementId": "CC6",
                    "requirementName": "Logical and Physical Access Controls",
                    "sectionDescription": "The entity implements logical access security software, infrastructure, and architectures over protected information assets to protect them from security events to meet the entity's objectives. ",
                    "sectionId": "CC6.1",
                    "sectionLabel": "1",
                    "standardDescription": "SOC2 Compliance Standard",
                    "standardName": "SOC 2",
                    "systemDefault": False
                },
                {
                    "complianceId": "ccb75284-13a3-4587-a69d-edd4163807f0",
                    "customAssigned": False,
                    "requirementId": "CC6",
                    "requirementName": "Logical and Physical Access Controls",
                    "sectionDescription": "The entity implements logical access security measures to protect against threats from sources outside its system boundaries.  ",
                    "sectionId": "CC6.6",
                    "sectionLabel": "6",
                    "standardDescription": "SOC2 Compliance Standard",
                    "standardName": "SOC 2",
                    "systemDefault": False
                },
                {
                    "complianceId": "a497bcdb-66ec-4f91-aca2-0e2e0e9f0300",
                    "customAssigned": False,
                    "requirementId": "PR",
                    "requirementName": "Protect",
                    "sectionDescription": "Access Control : Network integrity is protected, incorporating network segregation where appropriate",
                    "sectionId": "PR.AC-5",
                    "sectionLabel": "AC-5",
                    "standardDescription": "NIST Cybersecurity Framework (CSF) version 1.1",
                    "standardName": "NIST CSF",
                    "systemDefault": False
                },
                {
                    "complianceId": "e681841b-7502-4cc2-a542-49ecf45abfb1",
                    "customAssigned": False,
                    "requirementId": "DE",
                    "requirementName": "Detect",
                    "sectionDescription": "Anomalies and Events : A baseline of network operations and expected data flows for users and systems is established and managed",
                    "sectionId": "DE.AE-1",
                    "sectionLabel": "AE-1",
                    "standardDescription": "NIST Cybersecurity Framework (CSF) version 1.1",
                    "standardName": "NIST CSF",
                    "systemDefault": False
                },
                {
                    "complianceId": "887199f3-c2fe-4677-b3df-ff6b7af7bd94",
                    "customAssigned": False,
                    "requirementId": "DE",
                    "requirementName": "Detect",
                    "sectionDescription": "Security Continuous Monitoring : Monitoring for unauthorized personnel, connections, devices, and software is performed",
                    "sectionId": "DE.CM-7",
                    "sectionLabel": "CM-7",
                    "standardDescription": "NIST Cybersecurity Framework (CSF) version 1.1",
                    "standardName": "NIST CSF",
                    "systemDefault": False
                },
                {
                    "complianceId": "29eec89e-398c-45c3-8d61-174c71356842",
                    "customAssigned": False,
                    "requirementId": "Chapter 5",
                    "requirementName": "Transfers of personal data to third countries or international organisations",
                    "sectionDescription": "Transfers subject to appropriate safeguards",
                    "sectionId": "Article 46",
                    "sectionLabel": "Article 46",
                    "standardDescription": "General Data Protection Regulation",
                    "standardName": "GDPR",
                    "systemDefault": False
                },
                {
                    "complianceId": "0f69af82-db28-40ad-ab0c-59cb7c3cfb33",
                    "customAssigned": False,
                    "requirementId": "SC-1",
                    "requirementName": "System And Communications Protection",
                    "sectionDescription": "The information system blocks both inbound and outbound communications traffic between [Assignment: organization-defined communication clients] that are independently configured by end users and external service providers.",
                    "sectionId": "SC-7 (19)",
                    "sectionLabel": "SC-7 (19)",
                    "standardDescription": "NIST 800-53 Rev4 Compliance Standard",
                    "standardName": "NIST 800-53 Rev4",
                    "systemDefault": False
                },
                {
                    "complianceId": "50edb59e-5ee5-4907-8ff4-af839ee5d9e5",
                    "customAssigned": False,
                    "requirementId": "SI-1",
                    "requirementName": "System And Information Integrity",
                    "sectionDescription": "The information system monitors inbound and outbound communications traffic [Assignment: organization-defined frequency] for unusual or unauthorized activities or conditions.",
                    "sectionId": "SI-4 (4)",
                    "sectionLabel": "SI-4 (4)",
                    "standardDescription": "NIST 800-53 Rev4 Compliance Standard",
                    "standardName": "NIST 800-53 Rev4",
                    "systemDefault": False
                },
                {
                    "complianceId": "b9b7622e-bef0-4a71-800a-8fd4ec99d2c3",
                    "customAssigned": False,
                    "requirementId": "A.6",
                    "requirementName": "Organization of Information Security",
                    "sectionDescription": "Teleworking; Control: A policy and supporting security measures shall be implemented to protect information accessed, processed or stored at teleworking sites.",
                    "sectionId": "A.6.2.2",
                    "sectionLabel": "A.6.2.2",
                    "standardDescription": "ISO 27001:2013 Compliance Standard",
                    "standardName": "ISO 27001:2013",
                    "systemDefault": False
                },
                {
                    "complianceId": "fbf2d83d-ff97-4fb8-8a34-de3853854ff2",
                    "customAssigned": False,
                    "requirementId": "Control Category: 09.0",
                    "requirementName": "Communications and Operations Management",
                    "sectionDescription": "Monitoring System Use",
                    "sectionId": "Control Reference:09.ab",
                    "sectionLabel": "HITRUST CSF",
                    "standardDescription": "HITRUST CSF v9.3",
                    "standardName": "HITRUST CSF v9.3",
                    "systemDefault": False
                },
                {
                    "complianceId": "a55108dd-9607-49ee-8d71-43ac59ae41b7",
                    "customAssigned": False,
                    "requirementId": "TA0007",
                    "requirementName": "Discovery",
                    "sectionDescription": "Network Service Scanning : Adversaries may attempt to get a listing of services running on remote hosts, including those that may be vulnerable to remote software exploitation. Methods to acquire this information include port scans and vulnerability scans using tools that are brought onto a system.",
                    "sectionId": "T1046",
                    "sectionLabel": "MITRE ATT&CK",
                    "standardDescription": "MITRE ATT&CK Cloud Matrix for Enterprise [Beta]",
                    "standardName": "MITRE ATT&CK [Beta]",
                    "systemDefault": False
                },
                {
                    "complianceId": "c9cff8ce-257a-4f5e-a6c1-1d0ca718c192",
                    "customAssigned": False,
                    "requirementId": "Chapter 4",
                    "requirementName": "Controller and processor",
                    "sectionDescription": "Security of processing",
                    "sectionId": "Article 32",
                    "sectionLabel": "Article 32",
                    "standardDescription": "General Data Protection Regulation",
                    "standardName": "GDPR",
                    "systemDefault": False
                },
                {
                    "complianceId": "dfcbc074-8e35-4ed8-8edb-5944cd2f7576",
                    "customAssigned": False,
                    "requirementId": "4.7",
                    "requirementName": "Principle 7 - Safeguards",
                    "sectionDescription": "The methods of protection should include\n\n(a) physical measures, for example, locked filing cabinets and restricted access to offices;\n\n(b) organizational measures, for example, security clearances and limiting access on a “need-to-know” basis; and\n\n(c) technological measures, for example, the use of passwords and encryption.",
                    "sectionId": "4.7.3",
                    "sectionLabel": "PIPEDA",
                    "standardDescription": "Personal Information Protection and Electronic Documents Act (PIPEDA)",
                    "standardName": "PIPEDA",
                    "systemDefault": False
                },
                {
                    "complianceId": "df3bfdf9-ef14-4bfd-9270-191e9ef6583f",
                    "customAssigned": False,
                    "requirementId": "1798.150",
                    "requirementName": "California Civil Code Section 1798.150",
                    "sectionDescription": "Any consumer whose nonencrypted and nonredacted personal information, as defined in subparagraph (A) of paragraph (1) of subdivision (d) of Section 1798.81.5, is subject to an unauthorized access and exfiltration, theft, or disclosure as a result of the business’s violation of the duty to implement and maintain reasonable security procedures and practices appropriate to the nature of the information to protect the personal information may institute a civil action for any of the following:\n(A) To recover damages in an amount not less than one  hundred dollars ($100) and not greater than seven hundred and fifty ($750) per consumer per incident or actual damages, whichever is greater.\n(B) Injunctive or declaratory relief.\n(C) Any other relief the court deems proper.",
                    "sectionId": "1798.150(a)(1)",
                    "sectionLabel": "CCPA 2018",
                    "standardDescription": "California Consumer Privacy Act of 2018 [1798.100 - 1798.199]",
                    "standardName": "CCPA 2018",
                    "systemDefault": False
                }
            ],
            "deleted": False,
            "description": "This policy identifies that Security Groups do not allow all traffic from internet. A Security Group acts as a virtual firewall that controls the traffic for one or more instances. Security groups should have restrictive ACLs to only allow incoming traffic from specific IPs to specific ports where the application is listening for connections.",
            "labels": [
                "CIS",
                "PCI DSS v3.2"
            ],
            "lastModifiedBy": "template@redlock.io",
            "lastModifiedOn": 1540593383000,
            "name": "AWS Security groups allow internet traffic",
            "policyId": "2dbda57f-33d4-459a-97ae-dec7e81f9ec4",
            "policyType": "config",
            "recommendation": "If the Security Groups reported indeed need to restrict all traffic, follow the instructions below:\n1. Log in to the AWS console\n2. In the console, select the specific region from region drop down on the top right corner, for which the alert is generated\n3. Navigate to the 'VPC' service\n4. Click on the 'Security Group' specific to the alert\n5. Click on 'Inbound Rules' and remove the row with the ip value as 0.0.0.0/0 or ::/0",
            "remediable": True,
            "remediation": {
                "cliScriptTemplate": "aws --region ${region} ec2 revoke-security-group-ingress --group-id ${resourceId} --ip-permissions '[{\"IpProtocol\": \"${protocol}\", \"FromPort\": ${fromPort}, \"ToPort\": ${toPort}, \"Ip${ipV4/6}Ranges\":[{\"CidrIp${ipV4/6}\":\"${cidr}\"}]}]'",
                "description": "\"This CLI command requires 'ec2:RevokeSecurityGroupIngress' permission. Successful execution will update the security group to revoke the ingress rule records open to internet either on IPv4 or on IPv6 protocol.\"}",
                "impact": "reject all traffic from internet"
            },
            "severity": "high",
            "systemDefault": True
        },
        "reason": "NEW_ALERT",
        "resource": {
		  "account": "aws-charlie",
		  "accountId": "081476508764",
		  "cloudAccountGroups": ["Default Account Group"],
		  "cloudType": "aws",
		  "data": {
			"description": "all-allow",
			"groupId": "sg-076123ae51e408ce0",
			"groupName": "all-allow",
			"ipPermissions": [{
				"fromPort": 24,
				"ipProtocol": "tcp",
				"ipRanges": ["0.0.0.0/0","::/0"],
				"ipv4Ranges": [{
					"cidrIp": "0.0.0.0/0",
					"description": "Same"
				  }
				],
				"ipv6Ranges":  [{
					"cidrIp": "::/0",
					"description": "Same"
				  }
				],
				"prefixListIds": [],
				"toPort": 24,
				"userIdGroupPairs": []
			  }
			],
			"ipPermissionsEgress": [{
				"ipProtocol": "-1",
				"ipRanges": ["0.0.0.0/0","::/0"],
				"ipv4Ranges": [{
					"cidrIp": "0.0.0.0/0",
					"description": "Same"
				  }
				],
				"ipv6Ranges":  [{
					"cidrIp": "::/0",
					"description": "Same"
				  }
				],
				"prefixListIds": [],
				"userIdGroupPairs": []
			  }
			],
			"ownerId": "081476508764",
			"tags": [],
			"vpcId": "vpc-cdec17ab"
		  },
		  "id": "sg-076123ae51e408ce0",
		  "name": "all-allow",
		  "region": "AWS California",
		  "regionId": "us-west-1",
		  "resourceApiName": "aws-ec2-describe-security-groups",
		  "resourceType": "SECURITY_GROUP",
		  "rrn": "rrn::securityGroup:us-west-1:081476508764:sg-076123ae51e408ce0",
		  "url": "https://console.aws.amazon.com/vpc/home?region=us-west-1#securityGroups:filter=sg-076123ae51e408ce0"
		},
        "riskDetail": {
            "rating": "C",
            "riskScore": {
                "maxScore": 200,
                "score": 40
            },
            "score": "40/200"
        },
        "status": "open"
    },
    {
    "alertTime": 1588553089432,
    "firstSeen": 1576014006873,
    "history": [
        {
            "modifiedBy": "Prasen Shelar",
            "modifiedOn": 1590043797145,
            "reason": "USER_DISMISSED",
            "status": "dismissed"
        },
        {
            "modifiedBy": "Prasen Shelar",
            "modifiedOn": 1590043728649,
            "status": "open"
        },
        {
            "modifiedBy": "Prasen Shelar",
            "modifiedOn": 1590043640481,
            "reason": "USER_DISMISSED",
            "status": "dismissed"
        },
        {
            "modifiedBy": "Prasen Shelar",
            "modifiedOn": 1590041680094,
            "status": "open"
        },
        {
            "modifiedBy": "Prasen Shelar",
            "modifiedOn": 1590041489233,
            "reason": "USER_DISMISSED",
            "status": "dismissed"
        },
        {
            "modifiedBy": "Prasen Shelar",
            "modifiedOn": 1590041454728,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1588553089433,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1588552417093,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1587633281027,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1587632634171,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1586699194636,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1586698614244,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1586645504916,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1586644868494,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1586341150929,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1586340509887,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1586225356453,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1586224716911,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1586045695740,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1586045312653,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1586029928432,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1586029120430,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1585903928390,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1585903316331,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1585894422877,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1585893983217,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1585808363284,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1585807851576,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1585657938260,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1585657229385,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1585548108193,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1585547203630,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1585520825139,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1585520441151,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1585497268555,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1585496626501,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1585404472783,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1585403768108,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1585392844166,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1585391819154,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1585324774367,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1585324261016,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1585127113737,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1585126663267,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1585099474700,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1585098897251,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1585008587963,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1585008202627,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1584855160528,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1584854586829,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1584848697365,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1584847988534,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1584364356044,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1584363667084,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1583474990434,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1583474236246,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1583042241146,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1583041985680,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1582502416907,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1582500916991,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1582443984801,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1582442486281,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1581947751734,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1581946976260,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1579769890757,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1579769036086,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1579333855954,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1579333389559,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1579126602819,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1579126287247,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1579017354238,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1579016962353,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1578535450003,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1578535064046,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1578534584193,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1578534196814,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1578458946176,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1578458754376,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1578381311708,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1578380918094,
            "status": "open"
        },
        {
            "modifiedBy": "Prisma Cloud System Admin",
            "modifiedOn": 1577909409259,
            "reason": "RESOURCE_UPDATED",
            "status": "resolved"
        },
        {
            "modifiedBy": "RedLock",
            "modifiedOn": 1577909027230,
            "status": "open"
        }
    ],
    "id": "P-945",
    "lastSeen": 1590043797160,
    "policy": {
        "complianceMetadata": [
            {
                "complianceId": "c18a5413-d6dd-40f1-a6ae-730ac7761cc0",
                "customAssigned": False,
                "requirementId": "164.312(b)",
                "requirementName": "Audit controls",
                "sectionDescription": "Standard: Audit controls. Implement hardware, software, and/or procedural mechanisms that record and examine activity in information systems that contain or use electronic protected health information.",
                "sectionId": "164.312(b)",
                "sectionLabel": "(b)",
                "standardDescription": "Health Insurance Portability and Accountability Standard",
                "standardName": "HIPAA",
                "systemDefault": False
            },
            {
                "complianceId": "cc53d960-8486-4d27-9e31-aeafecbf3c82",
                "customAssigned": False,
                "requirementId": "CA-1",
                "requirementName": "Security Assessment And Authorization",
                "sectionDescription": "The organization employs an independent penetration agent or penetration team to perform penetration testing on the information system or system components.",
                "sectionId": "CA-8 (1)",
                "sectionLabel": "CA-8 (1)",
                "standardDescription": "NIST 800-53 Rev4 Compliance Standard",
                "standardName": "NIST 800-53 Rev4",
                "systemDefault": False
            },
            {
                "complianceId": "0004ed53-cb6d-49d4-90ef-a97b1fd5806f",
                "customAssigned": False,
                "requirementId": "A.18",
                "requirementName": "Protection of Records",
                "sectionDescription": "Protection of Records; Control: Records shall be protected from loss, destruction, falsification, unauthorized access and unauthorized release, in accordance with legislative, regulatory, contractual and business requirements.",
                "sectionId": "A.18.1.3",
                "sectionLabel": "A.18.1.3",
                "standardDescription": "ISO 27001:2013 Compliance Standard",
                "standardName": "ISO 27001:2013",
                "systemDefault": False
            },
            {
                "complianceId": "533ac11d-8bd2-4d51-bcbb-586eb43b5ac0",
                "customAssigned": False,
                "requirementId": "A.8",
                "requirementName": "Asset Management",
                "sectionDescription": "Handling of Assets; Control: Procedures for handling assets shall be developed and implemented in accordance with the information classification scheme adopted by the organization.",
                "sectionId": "A.8.2.3",
                "sectionLabel": "A.8.2.3",
                "standardDescription": "ISO 27001:2013 Compliance Standard",
                "standardName": "ISO 27001:2013",
                "systemDefault": False
            },
            {
                "complianceId": "72eaf131-78e9-4b44-be61-c16f52449adc",
                "customAssigned": False,
                "requirementId": "A.14",
                "requirementName": "Security Requirements of Information Systems",
                "sectionDescription": "Protecting Application Services Transactions; Control: Information involved in application service transactions shall be protected to prevent incomplete transmission, mis-routing, unauthorized message alteration, unauthorized disclosure, unauthorized message duplication or replay.",
                "sectionId": "A.14.1.3",
                "sectionLabel": "A.14.1.3",
                "standardDescription": "ISO 27001:2013 Compliance Standard",
                "standardName": "ISO 27001:2013",
                "systemDefault": False
            },
            {
                "complianceId": "d2a1ae41-b871-42c1-8a20-76ea39bd8b13",
                "customAssigned": False,
                "requirementId": "A.16",
                "requirementName": "Management of Information Security Incidents and Improvements",
                "sectionDescription": "Assessment of and Decision on Information Security Events; Control: Information security events shall be assessed and it shall be decided if they are to be classified as information security incidents.",
                "sectionId": "A.16.1.4",
                "sectionLabel": "A.16.1",
                "standardDescription": "ISO 27001:2013 Compliance Standard",
                "standardName": "ISO 27001:2013",
                "systemDefault": False
            },
            {
                "complianceId": "99f384b6-eafe-455d-8b0d-69e20400cad6",
                "customAssigned": False,
                "requirementId": "A.9",
                "requirementName": "Access Control",
                "sectionDescription": "Review of user access rights; Control: Asset owners shall review users' access rights at regular intervals.",
                "sectionId": "A.9.2.5",
                "sectionLabel": "A.9.2.5",
                "standardDescription": "ISO 27001:2013 Compliance Standard",
                "standardName": "ISO 27001:2013",
                "systemDefault": False
            },
            {
                "complianceId": "dfcbc074-8e35-4ed8-8edb-5944cd2f7576",
                "customAssigned": False,
                "requirementId": "4.7",
                "requirementName": "Principle 7 - Safeguards",
                "sectionDescription": "The methods of protection should include\n\n(a) physical measures, for example, locked filing cabinets and restricted access to offices;\n\n(b) organizational measures, for example, security clearances and limiting access on a “need-to-know” basis; and\n\n(c) technological measures, for example, the use of passwords and encryption.",
                "sectionId": "4.7.3",
                "sectionLabel": "PIPEDA",
                "standardDescription": "Personal Information Protection and Electronic Documents Act (PIPEDA)",
                "standardName": "PIPEDA",
                "systemDefault": False
            },
            {
                "complianceId": "fa590f5e-7fdd-4330-953d-8e6d60f4c846",
                "customAssigned": False,
                "requirementId": "2",
                "requirementName": "Security Center",
                "sectionDescription": "Ensure that 'Automatic provisioning of monitoring agent' is set to 'On'",
                "sectionId": "2.2",
                "sectionLabel": "2",
                "standardDescription": "Center for Internet Security Benchmark for Azure v1.1.0",
                "standardName": "CIS v1.1 (Azure)",
                "systemDefault": False
            },
            {
                "complianceId": "df3bfdf9-ef14-4bfd-9270-191e9ef6583f",
                "customAssigned": False,
                "requirementId": "1798.150",
                "requirementName": "California Civil Code Section 1798.150",
                "sectionDescription": "Any consumer whose nonencrypted and nonredacted personal information, as defined in subparagraph (A) of paragraph (1) of subdivision (d) of Section 1798.81.5, is subject to an unauthorized access and exfiltration, theft, or disclosure as a result of the business’s violation of the duty to implement and maintain reasonable security procedures and practices appropriate to the nature of the information to protect the personal information may institute a civil action for any of the following:\n(A) To recover damages in an amount not less than one  hundred dollars ($100) and not greater than seven hundred and fifty ($750) per consumer per incident or actual damages, whichever is greater.\n(B) Injunctive or declaratory relief.\n(C) Any other relief the court deems proper.",
                "sectionId": "1798.150(a)(1)",
                "sectionLabel": "CCPA 2018",
                "standardDescription": "California Consumer Privacy Act of 2018 [1798.100 - 1798.199]",
                "standardName": "CCPA 2018",
                "systemDefault": False
            }
        ],
        "deleted": False,
        "description": "This policy identifies the Azure Security Center policies which have automatic provisioning of monitoring agent is set to Off. When Automatic provisioning of monitoring agent is turned on, Azure Security Center provisions the Microsoft Monitoring Agent on all existing supported Azure virtual machines and any new ones that are created. The Microsoft Monitoring agent scans for different security-related setups and events such as system updates, OS weaknesses and endpoint protection and provides alerts.",
        "labels": [
            "Security_Center"
        ],
        "lastModifiedBy": "hhutton@paloaltonetworks.com",
        "lastModifiedOn": 1563387981729,
        "name": "Azure Security Center automatic provisioning of monitoring agent is set to Off",
        "policyId": "6c5091cc-2da3-42b3-877e-42fd7d9e85d6",
        "policyType": "config",
        "recommendation": "1. Login to Azure Portal\n2. Go to Security Center (Left Panel)\n3. Click on Pricing & settings\n4. Choose the reported Subscription\n5. Click on Data Collection(Left Panel)\n6. Set 'Auto Provisioning' to On\n7. Click on Save",
        "remediable": True,
        "remediation": {
            "cliScriptTemplate": "az security auto-provisioning-setting update --name \"${resourceName}\" --auto-provision \"on\"",
            "description": "This CLI command requires 'Microsoft.Security/autoProvisioningSettings/*' permission. Successful execution will enable automatic provisioning of monitoring agent.",
            "impact": "enable automatic provisioning of monitoring agent"
        },
        "severity": "medium",
        "systemDefault": True
    },
    "reason": "USER_REOPENED",
    "resource": {
        "account": "todd azure",
        "accountId": "c21d5724-78f1-4cd4-8197-da25a4088ead",
        "cloudAccountGroups": [
            "Default Account Group"
        ],
        "cloudType": "azure",
        "data": {
            "autoProvisioningSettings": [
                {
                "id": "/subscriptions/c21d5724-78f1-4cd4-8197-da25a4088ead/providers/Microsoft.Security/autoProvisioningSettings/default",
                "name": "default",
                "properties": {
                    "autoProvision": "Off"
                },
                "type": "Microsoft.Security/autoProvisioningSettings"
                }
            ],
            "pricings": [
                {
                "id": "/subscriptions/c21d5724-78f1-4cd4-8197-da25a4088ead/providers/Microsoft.Security/pricings/default",
                "name": "default",
                "properties": {
                    "pricingTier": "Free"
                },
                "type": "Microsoft.Security/pricings"
                }
            ],
            "securityContacts": []
        },
        "id": "default",
        "name": "default",
        "region": "global",
        "regionId": "",
        "resourceApiName": "azure-security-center-settings",
        "resourceType": "OTHER",
        "rrn": "rrn::other::c21d5724-78f1-4cd4-8197-da25a4088ead:default",
        "url": "https://portal.azure.com/#blade/Microsoft_Azure_Security/SecurityMenuBlade/"
    },
    "riskDetail": {
        "rating": "F",
        "riskScore": {
            "maxScore": 51,
            "score": 51
        },
        "score": "51/51"
    },
    "status": "open"
    }]
    return json.dumps(results)