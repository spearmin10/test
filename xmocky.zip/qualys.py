from flask import Blueprint, request
import json
import logging
from datetime import datetime
from base64 import b64decode

BASE_URL = '/api/2.0/fo'.strip('/')
INTEGRATION = 'qualys_api'

qualys_api = Blueprint(f'{INTEGRATION}', __name__)
logger = logging.getLogger(__name__)

mock_reports = """<REPORT_LIST_OUTPUT>
 <RESPONSE>
 <DATETIME>2017-10-30T22:32:15Z</DATETIME>
 <REPORT_LIST>
 <REPORT>
 <ID>42703</ID>
 <TITLE><![CDATA[Test now]]></TITLE>
 <TYPE>Scan</TYPE>
 <USER_LOGIN>acme_aa</USER_LOGIN>
 <LAUNCH_DATETIME>2017-10-30T17:59:22Z</LAUNCH_DATETIME>
 <OUTPUT_FORMAT>PDF</OUTPUT_FORMAT>
 <SIZE>16.9 KB</SIZE>
 <STATUS>
 <STATE>Finished</STATE>
 </STATUS>
 <EXPIRATION_DATETIME>2017-11-06T17:59:24Z</EXPIRATION_DATETIME>
 </REPORT>
 <REPORT>
 <ID>42700</ID>
 <TYPE>Scorecard</TYPE>
 <USER_LOGIN>acme_ts2</USER_LOGIN>
 <LAUNCH_DATETIME>2017-10-29T22:12:42Z</LAUNCH_DATETIME>
 <OUTPUT_FORMAT>PDF</OUTPUT_FORMAT>
 <SIZE>16.9 KB</SIZE>
 <STATUS>
 <STATE>Finished</STATE>
 </STATUS>
 <EXPIRATION_DATETIME>2017-11-05T22:12:44Z</EXPIRATION_DATETIME>
 </REPORT>
 <REPORT>
 <ID>42699</ID>
 <TYPE>Scorecard</TYPE>
 <USER_LOGIN>quays_ts2</USER_LOGIN>
 <LAUNCH_DATETIME>2017-10-29T21:52:19Z</LAUNCH_DATETIME>
 <OUTPUT_FORMAT>XML</OUTPUT_FORMAT>
 <SIZE>16.9 KB</SIZE>
 <STATUS>
 <STATE>Finished</STATE>
 </STATUS>
 <EXPIRATION_DATETIME>2017-11-05T21:52:21Z</EXPIRATION_DATETIME>
 </REPORT>
 </REPORT_LIST>
 </RESPONSE>
</REPORT_LIST_OUTPUT>"""

mock_groups = """<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE ASSET_GROUP_LIST_OUTPUT SYSTEM
"https://qualysapi.qualys.com/api/2.0/fo/asset/group/asset_group_list_output.dtd">
<ASSET_GROUP_LIST_OUTPUT>
 <RESPONSE>
 <DATETIME>2018-03-17T09:52:59Z</DATETIME>
 <ASSET_GROUP_LIST>
 <ASSET_GROUP>
 <ID>246385</ID>
 <TITLE>user_john</TITLE>
 <OWNER_USER_ID>180603</OWNER_USER_ID>
 <LAST_UPDATE>2018-03-07T11:37:57Z</LAST_UPDATE>
 <BUSINESS_IMPACT>High</BUSINESS_IMPACT>
 <DEFAULT_APPLIANCE_ID>199673</DEFAULT_APPLIANCE_ID>
 <APPLIANCE_IDS>199673, 199674</APPLIANCE_IDS>
 <IP_SET>
 <IP_RANGE>10.10.10.10-10.10.10.11</IP_RANGE>
 <IP_RANGE>10.113.197.131-10.113.197.132</IP_RANGE>
 </IP_SET>
 <DNS_LIST>
 <DNS>qualsss1.com</DNS>
 </DNS_LIST>
 <NETBIOS_LIST>
 <NETBIOS>WIN2003-SRV-O</NETBIOS>
 </NETBIOS_LIST>
 <HOST_IDS>634744, 653133</HOST_IDS>
 <ASSIGNED_USER_IDS>198400, 198401</ASSIGNED_USER_IDS>
 <ASSIGNED_UNIT_IDS>202741</ASSIGNED_UNIT_IDS>
 <OWNER_USER_NAME>John Doe</OWNER_USER_NAME>
 </ASSET_GROUP>
 </ASSET_GROUP_LIST>
 </RESPONSE>
</ASSET_GROUP_LIST_OUTPUT>"""

mock_hosts = """<!DOCTYPE HOST_LIST_OUTPUT SYSTEM
"https://qualysapi.qualys.com/api/2.0/fo/asset/host/host_list_output.dtd">
<HOST_LIST_OUTPUT>
<RESPONSE>
<DATETIME>2017-04-15T09:50:46Z</DATETIME>
<HOST_LIST>
<HOST>
<ID>135151</ID>
<IP>10.97.5.247</IP>
<TRACKING_METHOD>EC2</TRACKING_METHOD>
<DNS><![CDATA[i-0bb87c3281243cdfd]]></DNS>
<EC2_INSTANCE_ID><![CDATA[i0bb87c3281243cdfd]]></EC2_INSTANCE_ID>
<OS><![CDATA[Amazon Linux 2016.09]]></OS>
<METADATA>
<EC2>
<ATTRIBUTE>
<NAME><![CDATA[latest/dynamic/instance-identity/document/region]]></NAME>
<LAST_STATUS>Success</LAST_STATUS>
<VALUE><![CDATA[us-east-1]]></VALUE>
<LAST_SUCCESS_DATE>2017-03-21T13:39:38Z</LAST_SUCCESS_DATE>
<LAST_ERROR_DATE></LAST_ERROR_DATE>
<LAST_ERROR><![CDATA[]]></LAST_ERROR>
</ATTRIBUTE>
<ATTRIBUTE>
<NAME><![CDATA[latest/dynamic/instance-identity/document/accountId]]></NAME>
<LAST_STATUS>Success</LAST_STATUS>
<VALUE><![CDATA[205767712438]]></VALUE>
<LAST_SUCCESS_DATE>2017-03-21T13:39:38Z</LAST_SUCCESS_DATE>
<LAST_ERROR_DATE></LAST_ERROR_DATE>
<LAST_ERROR><![CDATA[]]></LAST_ERROR>
</ATTRIBUTE>
</EC2>
</METADATA>
<LAST_VULN_SCAN_DATETIME>2017-03-21T13:39:38Z</LAST_VULN_SCAN_DATETIME>
<LAST_VM_SCANNED_DATE>2017-03-21T13:39:38Z</LAST_VM_SCANNED_DATE>
<LAST_VM_SCANNED_DURATION>229</LAST_VM_SCANNED_DURATION>
<LAST_VM_AUTH_SCANNED_DATE>2017-03-21T13:39:38Z</LAST_VM_AUTH_SCANNED_DATE>
<LAST_VM_AUTH_SCANNED_DURATION>229</LAST_VM_AUTH_SCANNED_DURATION>
<LAST_COMPLIANCE_SCAN_DATETIME>2017-03-21T13:21:51Z</LAST_COMPLIANCE_SCAN_DATETIME>
</HOST>
</HOST_LIST>
</RESPONSE>
</HOST_LIST_OUTPUT>"""

mock_vhosts = """<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE VIRTUAL_HOST_LIST_OUTPUT SYSTEM
"https://qualysapi.qualys.com/api/2.0/fo/asset/vhost/vhost_list_ou
tput.dtd">
<VIRTUAL_HOST_LIST_OUTPUT>
 <RESPONSE>
 <DATETIME>2018-04-26T11:20:42Z</DATETIME>
 <VIRTUAL_HOST_LIST>
 <VIRTUAL_HOST>
 <IP>10.11.65.3</IP>
 <PORT>255</PORT>
 <FQDN>asadfsadf-123.com</FQDN>
 </VIRTUAL_HOST>
 <VIRTUAL_HOST>
 <IP>10.11.65.5</IP>
 <PORT>246</PORT>
 <FQDN>asdfsahydk.com</FQDN>
 </VIRTUAL_HOST>
 </VIRTUAL_HOST_LIST>
 </RESPONSE>
</VIRTUAL_HOST_LIST_OUTPUT>"""

mock_excluded_ips = """<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE IP_LIST_OUTPUT SYSTEM
"https://qualysapi.qualys.com/api/2.0/fo/asset/excluded_ip/ip_list
_output.dtd">
<IP_LIST_OUTPUT>
 <RESPONSE>
 <DATETIME>2018-01-23T00:33:24Z</DATETIME>
 <IP_SET>
 <IP_RANGE network_id="0" expiration_date="2015-04-28T00:00:00Z">10.100.100.101-10.100.100.255</IP_RANGE>
 <IP network_id="14665885">10.10.10.1</IP>
 <IP network_id="0">10.100.100.100</IP>
 </IP_SET>
 </RESPONSE>
</IP_LIST_OUTPUT>"""

mock_modify_excluded_ips = """<!DOCTYPE SIMPLE_RETURN SYSTEM
"https://qualysapi.qualys.com/api/2.0/simple_return.dtd">
<SIMPLE_RETURN>
 <RESPONSE>
 <DATETIME>$DATE$</DATETIME>
 <TEXT>Adding IPs to Excluded IPs list.</TEXT>
 <ITEM_LIST>
 <ITEM>
 <KEY>Added IPs</KEY>
 <VALUE>10.0.0.1</VALUE>
 </ITEM>
 </ITEM_LIST>
 </RESPONSE>
</SIMPLE_RETURN>"""

mock_modify_ips = """<?xml version="1.0" encoding="UTF-8" ?>
 <!DOCTYPE SIMPLE_RETURN SYSTEM
"https://qualysapi.qualys.com/api/2.0/simple_return.dtd">
 <SIMPLE_RETURN>
 <RESPONSE>
 <DATETIME>$DATE$</DATETIME>
 <TEXT>IPs successfully added to Vulnerability
Management/Compliance Management</TEXT>
 </RESPONSE>
</SIMPLE_RETURN>"""

mock_modify_vhost = """<?xml version="1.0" encoding="UTF-8" ?>
 <!DOCTYPE SIMPLE_RETURN SYSTEM
"https://qualysapi.qualys.com/api/2.0/simple_return.dtd">
 <SIMPLE_RETURN>
 <RESPONSE>
 <DATETIME>$DATE$</DATETIME>
 <TEXT>$TEXT$</TEXT>
 </RESPONSE>
</SIMPLE_RETURN>"""

mock_ips = """<!DOCTYPE IP_LIST_OUTPUT SYSTEM
"https://qualysapi.qualys.com/api/2.0/fo/asset/ip/
ip_list_output.dtd">
<IP_LIST_OUTPUT>
 <RESPONSE>
 <DATETIME>$DATE$</DATETIME>
 <IP_SET>
 <IP>123.123.45.0</IP>
 <IP_RANGE>123.124.45.0-123.124.45.255</IP_RANGE>
 <IP_RANGE>123.124.46.0-123.124.46.255</IP_RANGE>
 <IP_RANGE>123.124.47.0-123.124.47.255</IP_RANGE>
 <IP_RANGE>123.124.48.0-123.124.48.255</IP_RANGE>
 </IP_SET>
 </RESPONSE>
</IP_LIST_OUTPUT>"""

mock_scan_data = """<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE COMPLIANCE_SCAN_RESULT_OUTPUT SYSTEM
"https://qualysapi.qualys.com/api/2.0/fo/scan/compliance/compliance_scan_result_output.dtd">
<COMPLIANCE_SCAN_RESULT_OUTPUT>
 <RESPONSE>
 <DATETIME>2018-06-17T10:23:53Z</DATETIME>
 <COMPLIANCE_SCAN>
 <HEADER>
 <NAME><![CDATA[Compliance Scan Results]]></NAME>
 <GENERATION_DATETIME>2012-09-17T10:23:53Z</GENERATION_DATETIME>
 <COMPANY_INFO>
 <NAME><![CDATA[Qualys]]></NAME>
 <ADDRESS><![CDATA[1600 Bridge Parkway]]></ADDRESS>
 <CITY><![CDATA[Redwood Shores]]></CITY>
 <STATE><![CDATA[California]]></STATE>
 <COUNTRY><![CDATA[United States]]></COUNTRY>
 <ZIP_CODE><![CDATA[94065]]></ZIP_CODE>
 </COMPANY_INFO>
 <USER_INFO>
 <NAME><![CDATA[NAME]]></NAME>
 <USERNAME>USERNAME</USERNAME>
 <ROLE>Manager</ROLE>
 </USER_INFO>
 <KEY value="USERNAME">USERNAME</KEY>
 <KEY value="COMPANY"><![CDATA[Qualys]]></KEY>
 <KEY value="DATE">2018-06-15T11:49:08Z</KEY>
 <KEY value="TITLE"><![CDATA[My PC Scan]]></KEY>
 <KEY value="TARGET">10.10.10.29</KEY>
 <KEY value="EXCLUDED_TARGET"><![CDATA[N/A]]></KEY>
 <KEY value="DURATION">00:01:00</KEY>
 <KEY value="SCAN_HOST">10.10.21.122 (Scanner 6.6.28-1, Vulnerability Signatures 2.2.215-2)</KEY>
 <KEY value="NBHOST_ALIVE">1</KEY>
 <KEY value="NBHOST_TOTAL">1</KEY>
 <KEY value="REPORT_TYPE">Scheduled</KEY>
 <KEY value="OPTIONS">File Integrity Monitoring: Enabled,
Scanned Ports: Standard Scan, Hosts to Scan in Parallel - External
Scanners: 15, Hosts to Scan in Parallel - Scanner Appliances: 30,
Total Processes to Run in Parallel: 10, HTTP Processes to Run in
Parallel: 10,
Packet (Burst) Delay: Medium, Intensity: Normal, Overall 
Performance: Normal, ICMP Host Discovery, Ignore RST packets: Off,
Ignore firewall-generated SYN-ACK packets: Off, Do not send ACK or
SYN-ACK packets during host discovery: Off</KEY>
 <KEY value="STATUS">FINISHED</KEY>
 <OPTION_PROFILE>
 <OPTION_PROFILE_TITLE option_profile_default="0"><![CDATA[11412]]></OPTION_PROFILE_TITLE>
 </OPTION_PROFILE>
 </HEADER>
 <APPENDIX>
 <TARGET_HOSTS>
 <HOSTS_SCANNED>10.10.10.29</HOSTS_SCANNED>
 </TARGET_HOSTS>
 <TARGET_DISTRIBUTION>
 <SCANNER>
 <NAME><![CDATA[iscan_sx]]></NAME>
 <HOSTS>10.10.10.29</HOSTS>
 </SCANNER>
 </TARGET_DISTRIBUTION>
 <AUTHENTICATION>
 <AUTH>
 <TYPE>Windows</TYPE>
 <SUCCESS>
 <IP>10.10.10.29</IP>
 </SUCCESS>
 </AUTH>
 </AUTHENTICATION>
 </APPENDIX>
 </COMPLIANCE_SCAN>
 </RESPONSE>
</COMPLIANCE_SCAN_RESULT_OUTPUT>"""

mock_scan_compliance_launch = """<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE SIMPLE_RETURN SYSTEM
"https://qualysapi.qualys.com/api/2.0/simple_return.dtd">
<SIMPLE_RETURN>
 <RESPONSE>
 <DATETIME>2018-06-15T21:55:36Z</DATETIME>
 <TEXT>New compliance scan launched</TEXT>
 <ITEM_LIST>
 <ITEM>
 <KEY>ID</KEY>
 <VALUE>18198</VALUE>
 </ITEM>
 <ITEM>
 <KEY>REFERENCE</KEY>
 <VALUE>compliance/1473976536.18198</VALUE>
 </ITEM>
 </ITEM_LIST>
 </RESPONSE>
</SIMPLE_RETURN>"""

mock_scan_vm_launch = """<SIMPLE_RETURN>
 <RESPONSE>
 <DATETIME>2013-01-15T21:32:40Z</DATETIME>
 <TEXT>New vm scan launched</TEXT>
 <ITEM_LIST>
 <ITEM>
 <KEY>ID</KEY>
 <VALUE>136992</VALUE>
 </ITEM>
 <ITEM>
 <KEY>REFERENCE</KEY>
 <VALUE>scan/1358285558.36992</VALUE>
 </ITEM>
 </ITEM_LIST>
 </RESPONSE>
</SIMPLE_RETURN>"""

mock_vm_scan_list = """<SCAN_LIST_OUTPUT>
 <REQUEST>
 <DATETIME>2018-05-25T12:28:29Z</DATETIME>
 <USER_LOGIN>acme_ab</USER_LOGIN>
 <RESOURCE>https://qualysapi.qualys.com/api/2.0/fo/scan/
 </RESOURCE>
 <PARAM_LIST>
 <PARAM>
 <KEY>action</KEY>
 <VALUE>list</VALUE>
 </PARAM>
 <PARAM>
 <KEY>echo_request</KEY>
 <VALUE>1</VALUE>
 </PARAM>
 <PARAM>
 <KEY>show_ags</KEY>
 <VALUE>1</VALUE>
 </PARAM>
 <PARAM>
 <KEY>show_op</KEY>
 <VALUE>1</VALUE>
 </PARAM>
 </PARAM_LIST>
 </REQUEST>
 <RESPONSE>
 <DATETIME>2018-05-25T12:28:29Z</DATETIME>
 <SCAN_LIST>
 <SCAN>
 <REF>scan/1187117392.587</REF>
 <TYPE>On-Demand</TYPE>
 <TITLE><![CDATA[Web Servers 09/25]]></TITLE>
 <USER_LOGIN>acme_ab</USER_LOGIN>
 <LAUNCH_DATETIME>2018-05-25-25T08:10:43Z</LAUNCH_DATETIME>
 <DURATION>00:05:16</DURATION>
 <PROCESSED>1</PROCESSED>
 <STATUS>
 <STATE>Finished</STATE>
 </STATUS>
 <TARGET><![CDATA[10.10.10.10-10.10.10.113]]></TARGET>
 <OPTION_PROFILE>
 <TITLE><![CDATA[Initial Options]]></TITLE>
 <DEFAULT_FLAG>1</DEFAULT_FLAG>
 </OPTION_PROFILE>
 </SCAN>
 <SCAN>
 <REF>scan/1169604974.6553</REF>
 <TYPE>Scheduled</TYPE>
 <TITLE><![CDATA[Web Servers]]></TITLE>
 <USER_LOGIN>acme_sb3</USER_LOGIN>
 <LAUNCH_DATETIME>2018-05-24T15:40:02Z</LAUNCH_DATETIME>
 <DURATION>00:05:16</DURATION>
 <PROCESSED>0</PROCESSED>
 <STATUS>
 <STATE>Finished</STATE>
 </STATUS>
 <TARGET><![CDATA[10.10.10.10-10.10.10.113]]></TARGET>
 <OPTION_PROFILE>
 <TITLE><![CDATA[Initial Options]]></TITLE>
 <DEFAULT_FLAG>1</DEFAULT_FLAG>
 </OPTION_PROFILE>
 </SCAN>
 </SCAN_LIST>
 </RESPONSE>
</SCAN_LIST_OUTPUT>"""

mock_knowledge_base_vulns = """   <KNOWLEDGE_BASE_VULN_LIST_OUTPUT>
      <RESPONSE>
         <DATETIME>2020-05-20T19:01:25Z</DATETIME>
         <VULN_LIST>
            <VULN>
               <BUGTRAQ_LIST>
                  <BUGTRAQ>
                     <ID>36299</ID>
                     <URL>http://www.securityfocus.com/bid/36299</URL>
                  </BUGTRAQ>
               </BUGTRAQ_LIST>
               <CATEGORY>Windows</CATEGORY>
               <CONSEQUENCE>Successful exploitation of this vulnerability could allow an attacker to take complete control of an affected system. Most attempts to exploit this vulnerability will cause an affected system to stop responding and restart.</CONSEQUENCE>
               <CORRELATION>
                  <EXPLOITS>
                     <EXPLT_SRC>
                        <element>
                           <EXPLT_LIST>
                              <EXPLT>
                                 <DESC>SMB2 Negotiate Pointer Dereference Vulnerability - Immunity Ref : smb2_negotiate_remote</DESC>
                                 <LINK>http://immunityinc.com</LINK>
                                 <REF>CVE-2009-3103</REF>
                              </EXPLT>
                           </EXPLT_LIST>
                           <SRC_NAME>Immunity</SRC_NAME>
                        </element>
                        <element>
                           <EXPLT_LIST>
                              <EXPLT>
                                 <DESC>Microsoft Windows SMB 2.0 Negotiate Protocol Request Remote Exploit - Core Security Category : Exploits/Remote</DESC>
                                 <REF>CVE-2009-3103</REF>
                              </EXPLT>
                           </EXPLT_LIST>
                           <SRC_NAME>Core Security</SRC_NAME>
                        </element>
                        <element>
                           <EXPLT_LIST>
                              <EXPLT>
                                 <element>
                                    <DESC>Microsoft Windows - 'srv2.sys' SMB Negotiate ProcessID Function Table Dereference (MS09-050) - The Exploit-DB Ref : 14674</DESC>
                                    <LINK>http://www.exploit-db.com/exploits/14674</LINK>
                                    <REF>CVE-2009-2526</REF>
                                 </element>
                                 <element>
                                    <DESC>Microsoft Windows - 'srv2.sys' SMB Negotiate ProcessID Function Table Dereference (MS09-050) - The Exploit-DB Ref : 14674</DESC>
                                    <LINK>http://www.exploit-db.com/exploits/14674</LINK>
                                    <REF>CVE-2009-2532</REF>
                                 </element>
                                 <element>
                                    <DESC>Microsoft Windows Vista/7 - SMB2.0 Negotiate Protocol Request Remote Blue Screen of Death (MS07-063) - The Exploit-DB Ref : 9594</DESC>
                                    <LINK>http://www.exploit-db.com/exploits/9594</LINK>
                                    <REF>CVE-2009-3103</REF>
                                 </element>
                                 <element>
                                    <DESC>Microsoft Windows - 'srv2.sys' SMB Negotiate ProcessID Function Table Dereference (MS09-050) (Metasploit) - The Exploit-DB Ref : 16363</DESC>
                                    <LINK>http://www.exploit-db.com/exploits/16363</LINK>
                                    <REF>CVE-2009-3103</REF>
                                 </element>
                                 <element>
                                    <DESC>Microsoft Windows 7/2008 R2 - Remote Kernel Crash - The Exploit-DB Ref : 10005</DESC>
                                    <LINK>http://www.exploit-db.com/exploits/10005</LINK>
                                    <REF>CVE-2009-3103</REF>
                                 </element>
                                 <element>
                                    <DESC>Microsoft Windows - SMB2 Negotiate Protocol '0x72' Response Denial of Service - The Exploit-DB Ref : 12524</DESC>
                                    <LINK>http://www.exploit-db.com/exploits/12524</LINK>
                                    <REF>CVE-2009-3103</REF>
                                 </element>
                                 <element>
                                    <DESC>Microsoft Windows - 'srv2.sys' SMB Negotiate ProcessID Function Table Dereference (MS09-050) - The Exploit-DB Ref : 14674</DESC>
                                    <LINK>http://www.exploit-db.com/exploits/14674</LINK>
                                    <REF>CVE-2009-3103</REF>
                                 </element>
                                 <element>
                                    <DESC>Microsoft Windows - 'srv2.sys' SMB Code Execution (Python) (MS09-050) - The Exploit-DB Ref : 40280</DESC>
                                    <LINK>http://www.exploit-db.com/exploits/40280</LINK>
                                    <REF>CVE-2009-3103</REF>
                                 </element>
                                 <element>
                                    <DESC>Microsoft Windows - 'srv2.sys' SMB Code Execution (Python) (MS09-050) - The Exploit-DB Ref : 40280</DESC>
                                    <LINK>http://www.exploit-db.com/exploits/40280</LINK>
                                    <REF>CVE-2009-2532</REF>
                                 </element>
                                 <element>
                                    <DESC>Microsoft Windows - 'srv2.sys' SMB Code Execution (Python) (MS09-050) - The Exploit-DB Ref : 40280</DESC>
                                    <LINK>http://www.exploit-db.com/exploits/40280</LINK>
                                    <REF>CVE-2009-2526</REF>
                                 </element>
                              </EXPLT>
                           </EXPLT_LIST>
                           <SRC_NAME>The Exploit-DB</SRC_NAME>
                        </element>
                        <element>
                           <EXPLT_LIST>
                              <EXPLT>
                                 <element>
                                    <DESC>Microsoft SRV2.SYS SMB Negotiate ProcessID Function Table Dereference - Metasploit Ref : /modules/auxiliary/dos/windows/smb/ms09_050_smb2_negotiate_pidhigh</DESC>
                                    <LINK>https://github.com/rapid7/metasploit-framework/blob/master//modules/auxiliary/dos/windows/smb/ms09_050_smb2_negotiate_pidhigh.rb</LINK>
                                    <REF>CVE-2009-3103</REF>
                                 </element>
                                 <element>
                                    <DESC>Microsoft SRV2.SYS SMB2 Logoff Remote Kernel NULL Pointer Dereference - Metasploit Ref : /modules/auxiliary/dos/windows/smb/ms09_050_smb2_session_logoff</DESC>
                                    <LINK>https://github.com/rapid7/metasploit-framework/blob/master//modules/auxiliary/dos/windows/smb/ms09_050_smb2_session_logoff.rb</LINK>
                                    <REF>CVE-2009-3103</REF>
                                 </element>
                                 <element>
                                    <DESC>MS09-050 Microsoft SRV2.SYS SMB Negotiate ProcessID Function Table Dereference - Metasploit Ref : /modules/exploit/windows/smb/ms09_050_smb2_negotiate_func_index</DESC>
                                    <LINK>https://github.com/rapid7/metasploit-framework/blob/master//modules/exploits/windows/smb/ms09_050_smb2_negotiate_func_index.rb</LINK>
                                    <REF>CVE-2009-3103</REF>
                                 </element>
                                 <element>
                                    <DESC>MS09-050 Microsoft SRV2.SYS SMB Negotiate ProcessID Function Table Dereference - Metasploit Ref : /modules/exploit/windows/fileformat/somplplayer_m3u</DESC>
                                    <LINK>https://github.com/rapid7/metasploit-framework/blob/master//modules/exploits/windows/smb/ms09_050_smb2_negotiate_func_index.rb</LINK>
                                    <REF>CVE-2009-3103</REF>
                                 </element>
                              </EXPLT>
                           </EXPLT_LIST>
                           <SRC_NAME>Metasploit</SRC_NAME>
                        </element>
                     </EXPLT_SRC>
                  </EXPLOITS>
               </CORRELATION>
               <CVE_LIST>
                  <CVE>
                     <element>
                        <ID>CVE-2009-2526</ID>
                        <URL>http://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2009-2526</URL>
                     </element>
                     <element>
                        <ID>CVE-2009-2532</ID>
                        <URL>http://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2009-2532</URL>
                     </element>
                     <element>
                        <ID>CVE-2009-3103</ID>
                        <URL>http://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2009-3103</URL>
                     </element>
                  </CVE>
               </CVE_LIST>
               <DIAGNOSIS>The Microsoft Server Message Block (SMBv2) Protocol is a network file sharing protocol used to provide shared access to files, printers, serial ports, and miscellaneous communications between nodes on a network. It is a client-server implementation and consists of a set of data packets, each containing a request sent by the client or a response sent by the server.
&lt;P&gt;
A remote code execution and denial of service vulnerability has been identified in the Microsoft SMB implementation because it does not appropriately parse SMB negotiation requests. An attacker can exploit this issue by sending specially crafted SMB packets.
&lt;P&gt;
Affected Software:&lt;BR&gt;
Windows Vista, Windows Vista Service Pack 1, and Windows Vista Service Pack 2&lt;BR&gt;
Windows Vista x64 Edition, Windows Vista x64 Edition Service Pack 1, and Windows Vista x64 Edition Service Pack 2&lt;BR&gt;
Windows Server 2008 for 32-bit Systems and Windows Server 2008 for 32-bit Systems Service Pack 2&lt;BR&gt;
Windows Server 2008 for x64-based Systems and Windows Server 2008 for x64-based Systems Service Pack 2&lt;BR&gt;
Windows Server 2008 for Itanium-based Systems and Windows Server 2008 for Itanium-based Systems Service Pack 2&lt;P&gt;

QID Detection Logic (Unauthenticated):&lt;BR&gt;
The sends a specially crafted non-invasive TCP request to check if the SMBv2 remote code execution vulnerability exists on the target based on the response received. &lt;P&gt;</DIAGNOSIS>
               <DISCOVERY>
                  <ADDITIONAL_INFO>Patch Available, Exploit Available</ADDITIONAL_INFO>
                  <REMOTE>1</REMOTE>
               </DISCOVERY>
               <LAST_SERVICE_MODIFICATION_DATETIME>2020-04-10T10:26:10Z</LAST_SERVICE_MODIFICATION_DATETIME>
               <PATCHABLE>1</PATCHABLE>
               <PCI_FLAG>1</PCI_FLAG>
               <PUBLISHED_DATETIME>2009-09-09T01:01:39Z</PUBLISHED_DATETIME>
               <QID>90527</QID>
               <SEVERITY_LEVEL>5</SEVERITY_LEVEL>
               <SOFTWARE_LIST>
                  <SOFTWARE>
                     <element>
                        <PRODUCT>windows_vista</PRODUCT>
                        <VENDOR>microsoft</VENDOR>
                     </element>
                     <element>
                        <PRODUCT>windows_server_2008</PRODUCT>
                        <VENDOR>microsoft</VENDOR>
                     </element>
                  </SOFTWARE>
               </SOFTWARE_LIST>
               <SOLUTION>Workaround:&lt;BR&gt;&lt;P&gt;
Microsoft has provided a capability of enabling and disabling the workarounds automatically. Refer to &lt;A HREF="http://support.microsoft.com/kb/975497" TARGET="_blank"&gt;Microsoft Knowledge Base Article 975497&lt;/A&gt; for further details.
&lt;P&gt;
The workarounds can also be applied manually. Details are listed below:
&lt;P&gt;
1) Disable SMB v2. To modify the registry key, perform the following steps:
&lt;P&gt;
- Click Start, click Run, type Regedit in the Open box, and then click OK.&lt;BR&gt;
- Locate and then click the following registry subkey: HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services&lt;BR&gt;
- Click LanmanServer.&lt;BR&gt;
- Click Parameters.&lt;BR&gt;
- Right-click to add a new DWORD (32 bit) Value.&lt;BR&gt;
- Enter smb2 in the Name data field, and change the Value data field to 0.&lt;BR&gt;
- Exit.&lt;BR&gt;
- Restart the &amp;quot;Server&amp;quot; service. This can be done in the following two ways:
&lt;P&gt;
1. Open up the computer management MMC, navigate to Services and Applications, click Services, right-click the Server service name and click Restart. &lt;BR&gt;
Answer Yes in the pop-up menu.&lt;BR&gt;
2. From a command prompt with administrator privileges, type net stop server and then net start server.&lt;BR&gt;
&lt;P&gt;
Impact of the workaround: The host will not be able to communicate using SMB2. Instead, the host will communicate using SMB 1.0. This should not impact basic services such as file and printer sharing. These will continue to function as normal.
&lt;P&gt;
Two TCP ports, 139 and 445, should be blocked at the firewall to protect systems behind the firewall from attempts to exploit this vulnerability. 
&lt;P&gt;
Impact of the workaround: Blocking the ports can cause several windows services or applications using those ports to stop functioning.
&lt;P&gt;
Also, refer to Security Bulletin MS09-050 and &lt;A HREF="http://www.microsoft.com/technet/security/advisory/975497.mspx" TARGET="_blank"&gt;Microsoft Security Advisory (975497)&lt;/A&gt; to obtain additional details on applying the workarounds.
&lt;P&gt;Patch:&lt;BR&gt;
Following are links for downloading patches to fix the vulnerabilities:
&lt;P&gt; &lt;A HREF="http://www.microsoft.com/download/details.aspx?familyid=29842c0c-8930-4b5f-83c6-1a718974b63f" TARGET="_blank"&gt;MS09-050: Windows Vista, Windows Vista Service Pack 1, and Windows Vista Service Pack 2&lt;/A&gt;&lt;P&gt; &lt;A HREF="http://www.microsoft.com/download/details.aspx?familyid=62ed5d0a-5ca6-4942-80c9-7808b14cb6b5" TARGET="_blank"&gt;MS09-050: Windows Vista x64 Edition, Windows Vista x64 Edition Service Pack 1, and Windows Vista x64 Edition Service Pack 2&lt;/A&gt;&lt;P&gt; &lt;A HREF="http://www.microsoft.com/download/details.aspx?familyid=ff6bfcf3-76c9-4c45-b57d-22f94458dd6e" TARGET="_blank"&gt;MS09-050: Windows Server 2008 for 32-bit Systems and Windows Server 2008 for 32-bit Systems Service Pack 2&lt;/A&gt;&lt;P&gt; &lt;A HREF="http://www.microsoft.com/download/details.aspx?familyid=aff6f9c7-4a72-48f2-b750-204d796c7daa" TARGET="_blank"&gt;MS09-050: Windows Server 2008 for x64-based Systems and Windows Server 2008 for x64-based Systems Service Pack 2&lt;/A&gt;&lt;P&gt; &lt;A HREF="http://www.microsoft.com/download/details.aspx?familyid=7b70108b-7f59-4898-ab4e-76be990de878" TARGET="_blank"&gt;MS09-050: Windows Server 2008 for Itanium-based Systems and Windows Server 2008 for Itanium-based Systems Service Pack 2&lt;/A&gt;

&lt;P&gt;Virtual Patches:&lt;BR&gt;
&lt;A HREF="http://www.trendmicro.com/vulnerabilitycontrols "TARGET="_blank"&gt;Trend Micro Virtual Patching&lt;/A&gt;&lt;BR&gt;
Virtual Patch #1003761: SMBv2 Infinite Loop Vulnerability&lt;BR&gt;
Virtual Patch #1003712: Windows Vista SMB2.0 Negotiate Protocol Request Remote Code Execution&lt;BR&gt;</SOLUTION>
               <TITLE>Microsoft Server Message Block (SMBv2) Remote Code Execution Vulnerability (MS09-050) and Shadow Brokers (EDUCATEDSCHOLAR)</TITLE>
               <VENDOR_REFERENCE_LIST>
                  <VENDOR_REFERENCE>
                     <ID>MS09-050</ID>
                     <URL>https://technet.microsoft.com/en-us/library/security/MS09-050</URL>
                  </VENDOR_REFERENCE>
               </VENDOR_REFERENCE_LIST>
               <VULN_TYPE>Vulnerability</VULN_TYPE>
            </VULN>
         </VULN_LIST>
      </RESPONSE>
   </KNOWLEDGE_BASE_VULN_LIST_OUTPUT>
"""

mock_scan_list = """<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE SCAN_LIST_OUTPUT SYSTEM
"https://qualysapi.qualys.com/api/2.0/fo/scan/scan_list_output.dtd">
<SCAN_LIST_OUTPUT>
 <RESPONSE>
 <DATETIME>2018-06-12T07:28:46Z</DATETIME>
 <SCAN_LIST>
 <SCAN>
 <ID>3332486</ID>
 <REF>compliance/1344842952.1340</REF>
 <TYPE>Scheduled</TYPE>
 <TITLE><![CDATA[MY PC Scan]]></TITLE>
 <USER_LOGIN>USERNAME</USER_LOGIN>
 <LAUNCH_DATETIME>2018-05-13T07:30:09Z</LAUNCH_DATETIME>
 <DURATION>00:06:29</DURATION>
 <PROCESSED>1</PROCESSED>
 <STATUS>
 <STATE>Finished</STATE>
 </STATUS>
 <TARGET><![CDATA[10.10.25.50]]></TARGET>
 </SCAN>
 </SCAN_LIST>
 </RESPONSE>
</SCAN_LIST_OUTPUT>"""

mock_scan_modify = """<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE SIMPLE_RETURN SYSTEM
"https://qualysapi.qualys.com/api/2.0/simple_return.dtd">
<SIMPLE_RETURN>
 <RESPONSE>
 <DATETIME>2018-06-15T21:55:36Z</DATETIME>
 <TEXT>New compliance scan launched</TEXT>
 <ITEM_LIST>
 <ITEM>
 <KEY>ID</KEY>
 <VALUE>18198</VALUE>
 </ITEM>
 <ITEM>
 <KEY>REFERENCE</KEY>
 <VALUE>compliance/1473976536.18198</VALUE>
 </ITEM>
 </ITEM_LIST>
 </RESPONSE>
</SIMPLE_RETURN>"""

mock_report_templates = """<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE REPORT_TEMPLATE_LIST SYSTEM
"https://qualysapi.qualys.com/report_template_list.dtd">
<REPORT_TEMPLATE_LIST>
 <REPORT_TEMPLATE>
 <ID>235288</ID>
 <TYPE>Auto</TYPE>
 <TEMPLATE_TYPE>Scan</TEMPLATE_TYPE>
 <TITLE><![CDATA[Windows Authentication QIDs]]></TITLE>
 <USER>
 <LOGIN><![CDATA[acme_jk]]></LOGIN>
 <FIRSTNAME><![CDATA[Jason]]></FIRSTNAME>
 <LASTNAME><![CDATA[Kim]]></LASTNAME>
 </USER>
 <LAST_UPDATE>2018-02-12T18:09:10Z</LAST_UPDATE>
 <GLOBAL>0</GLOBAL>
 </REPORT_TEMPLATE>
 <REPORT_TEMPLATE>
 <ID>235164</ID>
 <TYPE>Auto</TYPE>
 <TEMPLATE_TYPE>Policy</TEMPLATE_TYPE>
 <TITLE><![CDATA[My Policy Report Template]]></TITLE>
 <USER>
 <LOGIN><![CDATA[acme_vs]]></LOGIN>
 <FIRSTNAME><![CDATA[Victor]]></FIRSTNAME>
 <LASTNAME><![CDATA[Smith]]></LASTNAME>
 </USER>
 <LAST_UPDATE>2017-12-09T22:47:58Z</LAST_UPDATE>
 <GLOBAL>0</GLOBAL>
 </REPORT_TEMPLATE>
 <REPORT_TEMPLATE>
 <ID>232556</ID>
 <TYPE>Auto</TYPE>
 <TEMPLATE_TYPE>Scan</TEMPLATE_TYPE>
 <TITLE><![CDATA[Executive Report]]></TITLE>
 <USER>
 <LOGIN><![CDATA[acme_jk]]></LOGIN>
 <FIRSTNAME><![CDATA[Jason]]></FIRSTNAME>
 <LASTNAME><![CDATA[Kim]]></LASTNAME>
 </USER>
 <LAST_UPDATE>2017-11-11T17:11:55Z</LAST_UPDATE>
 <GLOBAL>1</GLOBAL>
 </REPORT_TEMPLATE>
</REPORT_TEMPLATE_LIST>"""

mock_report_information = """<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE SIMPLE_RETURN SYSTEM
"https://qualysapi.qualys.com/api/2.0/simple_return.dtd">
<SIMPLE_RETURN>
 <RESPONSE>
 <DATETIME>2018-06-15T21:55:36Z</DATETIME>
 <TEXT>Report generation cancelled</TEXT>
 <ITEM_LIST>
 <ITEM>
 <KEY>ID</KEY>
 <VALUE>18198</VALUE>
 </ITEM>
 <ITEM>
 <KEY>REFERENCE</KEY>
 <VALUE>compliance/1473976536.18198</VALUE>
 </ITEM>
 </ITEM_LIST>
 </RESPONSE>
</SIMPLE_RETURN>"""

mock_scap_scan_list = """<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE SCAN_LIST_OUTPUT SYSTEM
"https://qualysapi.qualys.com/api/2.0/fo/scan/scap/qscap_scan_list_output.dtd">
<SCAN_LIST_OUTPUT>
 <RESPONSE>
 <DATETIME>2018-06-13T22:56:19Z</DATETIME>
 <SCAN_LIST>
 <SCAN>
 <ID>6980366</ID>
 <REF>qscap/1402694682.80366</REF>
 <TYPE>On-Demand</TYPE>
 <TITLE><![CDATA[<IMG
SRC="http://www.google.com/images/logos/ps_logo2.png">]]></TITLE>
 <POLICY>
 <ID>39298</ID>
 <TITLE><![CDATA[Policy A]]></TITLE>
 </POLICY>
 <USER_LOGIN>acme_ab</USER_LOGIN>
 <LAUNCH_DATETIME>2018-06-13T21:24:42Z</LAUNCH_DATETIME>
 <STATUS>
 <STATE>Finished</STATE>
 </STATUS>
 <TARGET><![CDATA[10.10.30.244, 10.10.34.222]]></TARGET>
</SCAN>
</SCAN_LIST>
</RESPONSE>
</SCAN_LIST_OUTPUT>"""

mock_scheduled_scans = """<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE SCHEDULE_SCAN_LIST_OUTPUT SYSTEM
"https://qualysapi.qualys.com/api/2.0/fo/schedule/scan/schedule_sc
an_list_output.dtd">
<SCHEDULE_SCAN_LIST_OUTPUT>
 <RESPONSE>
 <DATETIME>2017-12-01T19:26:50Z</DATETIME>
 <SCHEDULE_SCAN_LIST>
 <SCAN>
 <ID>160642</ID>
 <ACTIVE>1</ACTIVE>
 <TITLE><![CDATA[My Daily Scan]]></TITLE>
 <USER_LOGIN>qualys_ps</USER_LOGIN>
 <TARGET><![CDATA[10.10.10.10-10.10.10.20]]></TARGET>
 <NETWORK_ID><![CDATA[0]]></NETWORK_ID>
 <ISCANNER_NAME><![CDATA[External Scanner]]></ISCANNER_NAME>
 <USER_ENTERED_IPS>
 <RANGE>
 <START>10.10.10.10</START>
<END>10.10.10.20</END>
 </RANGE>
 </USER_ENTERED_IPS>
 <OPTION_PROFILE>
 <TITLE><![CDATA[Initial Options]]></TITLE>
 <DEFAULT_FLAG>1</DEFAULT_FLAG>
 </OPTION_PROFILE>
 <PROCESSING_PRIORITY>0 - No Priority</PROCESSING_PRIORITY>
 <SCHEDULE>
 <DAILY frequency_days="1" />
 <START_DATE_UTC>2017-11-30T00:30:00Z</START_DATE_UTC>
 <START_HOUR>16</START_HOUR>
 <START_MINUTE>30</START_MINUTE>
 <NEXTLAUNCH_UTC>2017-12-02T00:30:00</NEXTLAUNCH_UTC>
 <TIME_ZONE>
 <TIME_ZONE_CODE>US-CA</TIME_ZONE_CODE>
 <TIME_ZONE_DETAILS>(GMT-0800) United States:
America/Los_Angeles</TIME_ZONE_DETAILS>
 </TIME_ZONE>
 <DST_SELECTED>1</DST_SELECTED>
 </SCHEDULE>
 <NOTIFICATIONS>
 <BEFORE_LAUNCH>
 <TIME>30</TIME>
 <UNIT><![CDATA[minutes]]></UNIT>
 <MESSAGE><![CDATA[This is my custom before scan email
message.]]></MESSAGE>
 </BEFORE_LAUNCH>
 <AFTER_COMPLETE>
 <MESSAGE><![CDATA[This is my custom after scan email
message.]]></MESSAGE>
 </AFTER_COMPLETE>
 </NOTIFICATIONS>
 </SCAN>
 </SCHEDULE_SCAN_LIST>
 </RESPONSE>
</SCHEDULE_SCAN_LIST_OUTPUT>"""

mock_scheduled_reports = """<SCHEDULE_REPORT_LIST_OUTPUT>
 <RESPONSE>
 <DATETIME>2017-10-30T22:32:15Z</DATETIME>
 <SCHEDULE_REPORT_LIST>
 <REPORT>
 <ACTIVE>0</ACTIVE>
 <ID>42703</ID>
 <TITLE><![CDATA[Test now]]></TITLE>
 <TEMPLATE_TITLE><![CDATA[Test now]]></TEMPLATE_TITLE>
 <OUTPUT_FORMAT>PDF</OUTPUT_FORMAT>
 <SCHEDULE>
 	<DAILY>
 	    -frequencey=1
 	    </DAILY>
 	   <DST_SELECTED>0</DST_SELECTED>
 	   <START_DATE_UTC>2018-05-12T22:00:00Z</START_DATE_UTC>
 	   <START_HOUR>0</START_HOUR>
 	   <START_MINUTE>0</START_MINUTE>
 	<TIME_ZONE>
 	    <TIME_ZONE_CODE>IL</TIME_ZONE_CODE>
 	    <TIME_ZONE_DETAIL>(GMT +02:00) Israel</TIME_ZONE_DETAIL>
 	</TIME_ZONE>
 </SCHEDULE>
 </REPORT>
 </SCHEDULE_REPORT_LIST>
 </RESPONSE>
</SCHEDULE_REPORT_LIST_OUTPUT>s"""

mock_scan_report = "JVBERi0xLjUKJb/3ov4KMiAwIG9iago8PCAvTGluZWFyaXplZCAxIC9MIDE1NjE3IC9IIFsgNjg3IDEyNiBdIC9PIDYgL0UgMTUzNDIgL04gMSAvVCAxNTM0MSA+PgplbmRvYmoKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKMyAwIG9iago8PCAvVHlwZSAvWFJlZiAvTGVuZ3RoIDUwIC9GaWx0ZXIgL0ZsYXRlRGVjb2RlIC9EZWNvZGVQYXJtcyA8PCAvQ29sdW1ucyA0IC9QcmVkaWN0b3IgMTIgPj4gL1cgWyAxIDIgMSBdIC9JbmRleCBbIDIgMTUgXSAvSW5mbyAxMSAwIFIgL1Jvb3QgNCAwIFIgL1NpemUgMTcgL1ByZXYgMTUzNDIgICAgICAgICAgICAgICAgIC9JRCBbPGZjOTYzNWY4MDFjNTcxOTE1MGQ4ODkwYzZjMWZkMGJhPjxmYzk2MzVmODAxYzU3MTkxNTBkODg5MGM2YzFmZDBiYT5dID4+CnN0cmVhbQp4nGNiZOBnYGJgOAkkmJaCWEZAgrEORNwHEceBhLETiFXMwMR4vAmkhIERGwEAGOcGMAplbmRzdHJlYW0KZW5kb2JqCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCjQgMCBvYmoKPDwgL1BhZ2VzIDE0IDAgUiAvVHlwZSAvQ2F0YWxvZyA+PgplbmRvYmoKNSAwIG9iago8PCAvRmlsdGVyIC9GbGF0ZURlY29kZSAvUyAzNiAvTGVuZ3RoIDQ5ID4+CnN0cmVhbQp4nGNgYGBlYGBazwAEFgcZ4ADKZgZiFoQoSC0YMzDcZ+BjYODriTgwhU2GAQCrOgYPCmVuZHN0cmVhbQplbmRvYmoKNiAwIG9iago8PCAvQ29udGVudHMgNyAwIFIgL01lZGlhQm94IFsgMCAwIDYxMiA3OTIgXSAvUGFyZW50IDE0IDAgUiAvUmVzb3VyY2VzIDw8IC9FeHRHU3RhdGUgPDwgL0czIDEyIDAgUiA+PiAvRm9udCA8PCAvRjQgMTMgMCBSID4+IC9Qcm9jU2V0IFsgL1BERiAvVGV4dCAvSW1hZ2VCIC9JbWFnZUMgL0ltYWdlSSBdID4+IC9TdHJ1Y3RQYXJlbnRzIDAgL1R5cGUgL1BhZ2UgPj4KZW5kb2JqCjcgMCBvYmoKPDwgL0ZpbHRlciAvRmxhdGVEZWNvZGUgL0xlbmd0aCAzODQgPj4Kc3RyZWFtCnicxVRRSwMxDH7vr+izsC5pk7QFEdyce1YO/AHqBsIE5/8He71zd4MFt8n0CnclX/Ml6X0JWihrguUVs7fPG/NhWougr4btq3m6su/F6iLXs9/fchRtux6Xttts12a6DHb9WRkSikVgaSlWR1keyhpHR+f59wnwBcizVPYscC55TzVrzPSeLJITzuVJtlkZHP4J2GZjSrQJYtm+2GuAEG9s82aSy+zFY8vYATTrAeRyOqYBmFcglKQEKYcdwFKB6IJP6AcmCNVODiLmyPESTKQkq3oEqAB65yHFCIMLe61wJStanJit7+4cwXEiHymcH5uT4sBqfaS64ABAHgeJo0IyDgV2t75oLqxYL+Q4h+I8Em5/uxcPXtsl/EtU3glmrihJbwite1WFcdCkp+lFDc5zRaxq7JNDHCXi/TLutGGjZqWUodfNPZASCPERV6jOLYoaoM5MtfDbEeDD4TIE6HC7j4E9UY2Y9nISkp/n+F8NjhQdSaqDg+FgC38B11HMuGVuZHN0cmVhbQplbmRvYmoKOCAwIG9iago8PCAvRmlsdGVyIC9GbGF0ZURlY29kZSAvTGVuZ3RoMSAyMjIyOCAvTGVuZ3RoIDEyNzc4ID4+CnN0cmVhbQp4nO18CXhURfbvqbpb7317X5O+nU53IB0SSAJZiKQDCYuRHTFBIgkQIQiSBRAUNIwiGBeQcZ8ZwR11lCYEDKhDRhnHHVxn1FFQ4zZOhJm/4oJJv1O3EwwuT//f275539yb+tWpqnPPrTp16tSpphsgACAj8ABTZ+bkbs1uvxCAGLB29uzyyVXTti75AssLASw3LFhW1wgGGA9g/QrbsxasWqHc1PjyKgBbOoA4/PzGRcsuyrgf+T2zAIT4orqWRnCDFiDAs7csWrrm/BHHu0UARQPgW7V44bLVrx2s2gkwuhVAq1lcX7fw2aITm5H/MPKPWowV1mWGIwDlm7CcvnjZitX1Ee1RLP8e+7Ri6fIFdW0tNziR347tjy2rW90ocIZfA4xXsKxcWLesvq7M4MNyDPvT1Li8ZUUiE24CqOxg7Y3N9Y2fPtT0HpZfBdD1AuE2kS0gIO9tQh6+wZfMuZfgfGrVCFQv8pRdbDSnXZOXX7gcYgm8hFf6ppM8aQxpjwHBcj8DBxxhl8BxhBICbuEf+i74SpMADWgSfagjbaIXdKBD1IMe0QAGRCMYEU0qmsGEKIMZ0YL4LVjBgmgDK6IdbIgOxJPgBDuiCxyIbsRvwAMupL3gQdoHXkS/iingQ0wFf+JrCKioQApiEAKIaaAghhC/gnQIIoYhDTGC+CVkQAhxCKQjDoUIYqaKUchInIAsGII4TMVsyETMgSjicBiGOALxC8iFbMQ8yEHMh+GJz2GkiqNgBGIB5CEWQn7iv6BIxWIYiThaxRIYhXgGFCCOgULEUihK/AtiUIxYBqMRx0IJ4jjEf0I5nIFYAWMQx0Np4jhMwBk7DhOhDHESjEU8U8VKGId4FpQjTobxiWMwRcWpMAFxGkxEnA6TEp/BDBVnwpmIs6Ay0QNnw2TE2SqeA1MQq2Bq4h9QDdMQ5yD2wLkwHem5MBOxBmYhnqfiPDg78SnUwmzEOjgHcT7i32EBVCMuhDmI9XAu4vkwN/EJLFJxMdQgNsB5iY9hCdQifYGKS6EOcRnMx/oLYQHichUbYWHiI2iCesRmWITYouIKWJz4EFZCA+IqWIJ4EeIHsBouQFwDyxAvhgsRL1FxLSxHXAeNiJdCU6IbLlOxFVoQ18MKxF/BysT7cDmsQrxCxQ1wUeI9uBJWI26ENYib4GLEq+CSxLvQBmsRr4Z1WHMN4rtwLVyKeB1chrgZ1iNuQTwK18OvELfC5Yi/hisSR+AGFW+EDYg3wUbEm2ETtt6CeARuhasQb4O2xDvwG7ga8bdwDeLvVLwdrkPcBpsRt8MWxDsQ34Y74XrEu2Ar4t3wa8R74IbE3+BeuDHxFtwHNyHugJsR71fxAbgF8UG4FfH38BvEh1R8GH6LuBN+hxiH2xF3Ib4J7bANcTdsR+yAOxNvwB64K/FX2KviI3A3Yifcg7gP7kXcr+KjsAPxMbg/8Rd4HB5A/IOKB+BBxC74PeIf4SHEJ+BhxCdhZ+J1OAhxxD/BrsRr8JSKf4Z2xKdhd+JVeAY6EJ+FPYjPwV7E5+ERxBegE/FF2Id4SMXDsB/xJXgM8WV4PPEKvIL4MrwKf0B8DQ4gvg5diZfgLyr+FZ5AfAOeRHwTDiK+peLf4E+Ib8NTiO/AnxOH4YiKR+GZxCF4F55FfA+eQ3xfxW54HvEDeAHxQ3gR8SM4nHgRPlbxE3gJ8e/wcuIF+BReQfyHij3wKuJn8HrieTgGf0E8ruI/4a+I/4I3EP8L3kT8XMUv4G+J5+AEvI34JbyD+BXis/A1HEH8Bo4inoR3Eb9VsRfeTzwDfdCNmIAPEP/j0//P+/R//pv79E9/sU//5Cd8+ic/8Okf/4RP/+gHPv3DX+DTu0/59ObTfPr7P+HT31d9+vs/8OnvqT79vUE+/T3Vp7+n+vT3Bvn0d3/g04+qPv2o6tOP/hv69Df+H/n0V//j0//j0//tfPq/e5z+7+vTfypO/49P/49P/3Gf/vT/Bz4dgKqfywB6ZA6ImvPohVk9awH22Q0mbBH2gweTV7gPPHyE8eAKBFydmPc1JD5m7Synf8fHOvsToMU9RBrQsg7AE+Q4PrUTraMD59GFPu63uC5vwJUloq95GlfVDLwFrL+BeBId6IHvwD7dgbPqQu90KdqTk7jRP1wGG7hX8KkNuN+koe+chr7iWnJWYiV6qSP85eiJz0If0khaE1WJ6xJbE3fjOtjHPa3uVV70TwtwVj4T/oorYxg+cSOutiNkq3YP+uJz0B/s436HnuY2roYniUW423C4u1yEfeDRu75AumgUpdfDR8RN1nLjUMpdiXjiIHL50TsuxjW7n4wkE2hQmJuYjHPpxHesRqm34urZi3cnroE3iUE4nrgb/bUH951JOJ4OeJF0cX296/tKUWMCamko7iGTcFx/QLs/TELkj3S5YBByhZhwMVqyHXeks7G39+GTH5Iv6aV4X8Y9xY9PjMXddwP6G9Q2rp53iZfkkKlkNh1Kl9PbuWbcv7Pw2RHonxtQ37eg9HdIlOylBnqIu4t/kD8ppvQdTZhwRiLoeX4HfyRGHKlCWsivyOvkfTqOzqO/oe9xN/D38y9LdTjq89BrX4te5EtiJYVkOjmXLCZryUZyPbmVvEAOk49pGZ1FL6DHuMVcE/c4PxbvmXwLf7lwpXC1+HFfVd/Bvpf6vkzkJq7EfWot+uLrcU5ux5HtwzX8Bt5H4D0iED0x4a2QIDmbXIL3peRacifZQe4nHfiWw+Q98gn5F/mCnGSGS0Xqo0GahneINtOL6A30t/QQ3ofpP+jXnItL46LcSK6Eq+aWY682clvw3sO9y3v5Q3wC9Zwr3CRsE3YIDwpPCMdFg/QrDHye//au3szed/qgb1PfTX3tfR3o2R04h17UQgB3+Om4D9bhrrYaPfo9aOevEAPqzksyyRhyFmpmHllCmshq1OQV5DZyj9r3h8ljqKW/kGPYZyP1q33OpiPpWDoV7/NoPW2iW+hW2kFfp99wEqfnzJyDy+QmcDVcPbeCW8PdxMW557m3ufe4E9y3eCd4HR/g0/gIH+Un8PP4lfzt/Ef8R8Jc4TnhA1EnLhOvFDvFf0qjpDHSNGm6VCNtlvZKr2pq0TqfRI/+yOBPdMlRbj1Xwe2B62ge76Ev0hfRnufBQm4yRUulO8gmuo500HRhtTiajiZT4DgfQV0/RbfRE3Q0N5lUkpmwhI5IShPt/AOYlfBPQg//GI7tRZS8WjSQS+kx0QDtBGgRvvNP3HA+yj0Hb3JHiMTfAW/xOuIiPfQ+bhpaweP8GKEKgtxv4WGuiayDPbQCQHdScw3a8RTyAPqFWSSXfMUlgKNT0IoKOLanX0D/it71Ity/byYL+UW4R+eRteiT78VVMVS4UMwUHeQZ2sC3URvpAMrfj6MrIumEE+xwBanhbhOP0Tcw3jjE6+Ad7vfY+0P0YW4yf1yYQRbjCliHUUJTYj2sEar4l8ki4MhsCPNsn1/L5fJBzDHeQG+Tg1p2oyfrhDJuMta40XLOQrs4Gz3EbXjfgn6CRwtqwDV+DnqxF6FDnEU7YZFgIuh1APjn+mZgbHUv7tqLMLLZipHpqxg/rEWJO3C/2Qw7yIa+SzBuSsWV8w45SxhPDwnjE8NoG32DzqQ3nT6/qO0wceNO9Hfc9cfDGOFRaOP/gjFiaeIa3HMdGC+nYc/mY6zZjaP8DN8wkeuCvL4pdFdiPNeI4z2C8eF9iQDRYUS2FKPOx+AeSYA6KRorK4uVjjmjZHRxUWHByPy83BHDc7KHZUUzhw7JiITTQ2lBJZCa4vd5PW6X02G3WS2y2WQ06HVajSQKPEcJZFWExtcq8UhtnI+EJk4cxsqhOqyoG1RRG1ewavzpPHGlVmVTTueMIef53+OMJTljpziJrJRAybAspSKkxF8oDymdZM70KqSvLQ9VK/EelZ6s0ltU2oh0MIgPKBXuxeVKnNQqFfHxqxa3VdSWo7hdet240Lh63bAs2KXTI6lHKu4KNe4irjFEJairongXBY0ROxX3hsor4p5QOetBnAtX1C2MT5teVVHuCwarh2XFybgFoflxCI2Nm6MqC4xTXxMXx8Ul9TVKAxsNXK3syupqu6ZThvm1UcPC0MK6uVVxrq6avcMSxfeWx10Xd7u/K6Jw67iqjYNbfVxbhbtBYcW2to1KfPv0qsGtQYbV1SgDn6Xh8bVt4/HV16ASK2cq+Da6oboqTjbgKxU2Ejaq5PjqQxWspnaJEteGxoYWty2pxanxtsVhxppgu9cb24fBsLdCaZtVFQrGS32h6rpy/y47tM1Ys9sTUzyntwzL2iVbkordZTL3EwbjYKL+VJtKqeyMqpxxSrOE9Sg0CQ0irixQsCdVIRxTIYP6QmhbUIhseFUTfCq+EGekIa4dV9smF7N69nxcCMshpe0LQAsI9fzj9Jq6/hoxLH8BjGR2csrUsH2Ajkej8cxMZiLSOJxT7OMYtTxyWNaqThoKNcoKZqg+mIa6rasuzkH1B4Nsgq/ujMF8LMRbp1clywrM97VDLCdaHae1rKVroMVxNmtpHWg59XhtCC25Qw0FHXFN5NSfWXbaKhYXx4nzf9Jcn2yvnBmqnD6nSqloq+3XbeWs00rJ9sJTbf1U3DauivPRfor6OLUVjXLuKWZWqDLE+TD+iapRL+yUNGiVag1Rxsfl2olJrNYFg7/woc7EcfaUmn33WH8348XR08ujTyuf1j1DG4cdxk2wctactjbdaW1oaskXTurP0OJhVlVQGReHs3FlhvGvM9FVyFK1Lx5DlY1jDGh/yar+4mmMvn66Gi9mncOyxqOja2sbH1LGt9W21XUmWueHFDnUto8+QZ9oa6yoHTCczsT+q33x8ddUo64Wk+Jh6jlAg8GThf2TrXomGNV/r/nfcvcM3GRc8sZoZ/B97k/dGKeVcIf4BsGE91NiTNwqgYbgfYs2Tfuwbjze9+rfMpQZ/py8jY+q9klf+ofXWPjwPHPJFxqfRt3t7nw/I5Ple85of/qbnb2L5GLNWVjUqvzsokQNwAWmCwnGdlDSLUqd9NaYDQS+mwOdxHcT8GhEoZtyj2Fgo8UwNxvcUflESW/JFPnzksm9JVCKtPwtwojhQUvQEkYguK1/q3Bd38YEPJIpfBc7YcVx/92M5yYBe3DOLr/QSXfGIpoSkYKo0z/HaYuFQr4ECsViwpVQqhBCntPp9OuDd9zijkbxZTUlk+Ueubu7t7tb/gxKSyfLvR9WzqzaLfBAiFwil1SPGG7jLHkWjhuZ5/io4Ej+XYfIUk5LKvoe/fbLvhteeIH14nYc8RzshRlS4IpYRAmQcRp/Siol1CKnmkHjiihaovUGUmSFKKipmtTRc9mAa9goT9T0qMMtVUc7bk1sFOeTNKJG0PAaXvS4vW4q6nUGnVHHiQ6n3WlzcqKPcwWJ1YTg1viDxKmzBCEaJdFoJl7rSU2eJZjrcrqcVoedmmgoHMwdVTBq1Mj8SEYkFLydfP3gnEurV7RMufj6Fzb07SJF198zomLyzUunPNT3vLDfkXLW/L5DB+/r67u/LvehUSMqPrn3wy8zU1HReCYCsh7HycENewhutlTAhbO78Ix8Nc/LT+bDhifzIUOTeSiczFNSk7nbq+axHKOcrwhbhJ0CxyloNZthO84nn4PHyGl4ZDkOglXByi34ujv516tVhaEXam/Fqampbmou6a2J9l9oMKUjhufhPB14Qtj/zXjs6y0YLZuxrzJZGbsMqFljpz4Nv8pwpeFpA6c1TDJMMnND+bAxy1TFncuvMq42bTRq9FTQFBlHmabSSq5cimkmG8eadLfQW7mbpJs0O7j7JNFKzSbTcIHaBYFqDEbjcEGDpMYwwzyDxAilGo1Wp9cbjSaTDBotrbW2Wql1P90BRjKiXVA0nWRETGfQ6pSY4TI90e+ns8FE9NhCO4k+pjUTUMyNMpE76exHFKFWaBU4NOoduy2jUQEeNFg0WTdaTY/XI/cg7T1V6K4Bd2lpSYk86PbKPT0bhezoxnUHN2a7WTZiOFTG9TMr46nohx8HQ+IkaBKvA028XlhYWE0q4wZsG4Jt+8CY+GqXScdqUeus+OreYJEpK1hk7ESyoMiUW6CSe4Zh7bCi5ExUNzfVQFONaoLE6RpVQIKWkAXP35Zb8DBw7nCnZyQe44RH+2bv7KsS9p/81/UTp/2G+/ab8fxzJ0fyR08qzM6GY5S+H+dOgqkxo0BTMZQFNaTVdtKW3QpP+E5CHhEVQnM4wiG9h6jrirVq9t6aXFpsccu93TUfMkWgfQw4k5FBR9BCbX0pfFufTzA+9NA3/8XW8JmJj3k/Pwbj9QKSErtOa9RmeozezKHGzEy0CEeBrzhzUmaNsSZzibEhs3Z4m/HKobc5f+O93+i41/PAkL2eR4cc9Bwa8rLj7SGacicJuALuaFZmfhFflDWJn5g1W1MdPV/TEF1l2Gh4xvC18euopSDfRHg5Jz3flRu0u+cNXT6UDvXnmEpNm03bTAmTsM2003TMxJlMfs7VSR+IOd032v1+CSoydLl+Tj+0Tq6DcDC9k54bkzNiEJEjSmR4ZGdEiIwoYssrkBrKH17UVUS3F5EiV9idlpN+QDwk0oBYKlJxRCHqqKnn8x65pimKLujzkt4PPoDSntLu0p7ebou1KAdbmzDHvyJisbqK0HJqCJvcsCiG0iIj80ehT2H3yHz0KmmilDGG5uU60es4HHanKxThRMlEkcxjzmckV7Jw35Kdj01omTjygjcXkbyKTZetSYm7Lzx81aYHpslaV9pjftf8g8vn5i5rWHxnJOXys8c/uGHK+il2k9GbHtZdOOyM6iZ309WVsbozs1cfP7nhjELy9hC/PGRyzsTac6eecRHO/rTEx1wPzqAXXohN0BpIwD/ONs410zbTVWurdf2G/oa7zXi3fLfXoDF6dEtoA7dEWGloNLYa7zXs0e7V7TEYnOgd3qecKW2eebn5MjNnJkzxk4arHqkWj4Rb0EUdRc+kBbNZj0Zq9eslt5/X+83EnG5K82Ev0vXRACHoosgkvyP9kEQCUqlEpRG+/IOqXTb1IDT3B0L7MFDAyKOn+fOeZqb8HtS7pShHrunGP6bwJoJ/LqZwsORbR6F+XVKEaTupV65kV8qxh9/s+7L5k6se+ltgp+eyOZseuPuKJdeRDa5HDpEUovs9oet33uG7YOmTr7z+xK/Qzsejlo7g2rLgXvV67EEd5Y1hY76x3CiMtI/0n0Nn6WbYZ/oX0YVCvXaBvdbfFXhVeM32tucD2wf2Y65PPR+kHA0kAs5AIOotcZZ4K72NgS0BKZumG7OdxXSksZJWGMfbJ/nP0c02LjJ+IH7k/IZ8bpKJgzPpZTP4UGMW0DnQgt15BMIWc1iWD1uIbIlZai2tFt6ywpp+QDokHZESEs90N1XiJE9q/jS3ul83Te7prWlClyf3lnQzlZWwZGFmespAgyOZgaKFJhWGuwJRtYX7H2qOK6w/eNlrK5e8enntTTm7e5Xfr1x1z45LVt9x5e3XnLxrG+HappdR0zfjqfX5Z//41JvPH0SdVaJvSEXLcqDO3oktDIDfQc/maoQa7dn6eu4CYbm2Xq+RcauRaYb1DeEb+wmvNMJa7BnhL7NO9pb5p1vnemb466zLvHX+1eJqxwl6wi2Dk5iNLtc0Z62z0ck5/eYt8naZyjLv8+skYIanJTfa0LhcMSNbz9qMzPy4kRi9AbaJhiP5LI+lsFUeIAFnnpwuxdIz8weprCCpsujk3u4pclM0eqIpOhljDVzfqqFh9NFUQtj6ZrojNUx7zQPGJkNeLljsUtDJNEeCEXWNc+ftz/ps3yd9x4j9b68RE/n2Y137hgXX9L5JpxsKZ1+19n4y23VXBwkQjhjIkL53+r6WlZ37F5Mbrxy3+F7mZcf2Tef+jppMhUw4HqvV6wV7lj5sP0tfYRe1KZ6ULH3EnhUq0o+yn6kfb58tVekX67/RfeEwZYeyMsaExmSclbEla3uWNCo4amhp1nj9+GDF0FnBWUMbpAXBBUNrs1qz3sz4OPhZ6FiGxeUUHZ10V8cQv01S17Gs4MbCVnErdMFhYDpeFysT/H6zriLNb9A5HXnhPF3Y7T7sIrIr5qp1tbp41wozCUNaIP2A+ZD5iDlh5gPmUvNU9A2eaNaKIDPL6BTVLNGVqpbZ230Ct5se5kdrullewpTbhGvZxUIy1RtmoI5p0j5dI/MsdtWj2gYZ6fk79bnjVqzb5DaRVfG3jl/40rWPXXxv/Vvb//D3W+9dt3bHQxev3lHlnR7OXTinIH41KXn7FkKuuaX12yVfHVr9IJf5UteB55986kn0RhsxDGf/rmCHXfvAifZidLjyw/xIroLbb+S5zsTRWLrLk+/SWAwWOycQMPsFyY7hZlgbyxuVn9CSLoxcpziZqbnyR+XHncedtNG53Rl3Jpy8k9rDuOtimwOZj7MzgALsn3R4mOKYMC3p76IsyMUMlRRlkS6uV1yuRYQZHUa7JtEkhU2iwUeMGrOPAIti10O0hkRZOMcWsNOBEYSqFdFh2dhxadeqhys7Vl4w7doSYX/vv7bW3P3b3nn0jo2XzLxuXe+jaGObMIQoUaNUCdbFaqZqt2i3a+PaLu0R7XGtBNqAtlHbqt3WX3VUm9DqAlr02BJPOa3IXUpAFEReJ0phAfht/HY+znfxR3mxiz/OU+AV/jCWeH6KZmCEGImqAUZpj7qaWGJT3txkwzMDOzxs6ujo4D89dOikg4+cfBPXQeLOvumkWO2jFW6NTeaFsDCazxOuFASXRhAknqe8YANi1FPObuAtgl5i/dKLkt9i3mIndpfLazAYwzrdFj0J6Ev1U/Wc3mOzPxScMGCQeLBhx6mK+vIPm6B0ck9paQ92zFp0qouWvLyNsiZ55DBpZHNEI+t8RGuSfJCcBFLD+k8KVKvEUdgltNIrO/oWp40KFIzqyCu7eRL/yUsvfX3JraZJW/m5J7cfnLyQRW+of+4rHJuePB/zSuJscY6WMxv/SzghcmdzF+moVVRswXxNZ+L4bmtGvhbzDsytgloRVCtiV2CNyPMCLxZoJ6B2xGG6Kt1F3Erdm9z7onSvSEJiRAprisRCbalxqrGarxarpGrtOn6NcKv2KfFl/nWxW/xE+lL8WuOw6nR4wuCpKEparQYLWo0mLIl2SRI5ng8LOgzgdTqceV6DhxpeECWNRq8HHQaZ5nYhDUN2cyykqLu4dws6YH0YaJiQLUBKYSram8dgfDc44fzv9N4j96C/PVHDfAIaPIs/0ThKLK4iFovz6+SDmLujJiQknAFNCaci2gwG2jGdNiulSKtJSSkROxPvtKcUYfZqu6Jmu4LJMLtajbGb8MynhuZioqs9WISruavdybJ32uUiMZmpJYOa7dIPxOg4u+zBmPVtnmjsTnyb3V6iAj51ot3NHv7HLl+SHc9auDPUNLHlSPIIhvISGjR54JO+JeTAO313XCbs//YxEu9b1buQBi7uOzfpdcQIevkQPLUPtIm/xsr0RvQ63Xy39l3XB4rwmnBCoS6NEtK6fYqW40KpftHh16N5EzGEZxnd4TDZEt4epmG0c1N4i4VYOknNHnd4i4/4kIp5gOaFwuQwEBaR0QCwmeDAkx7uJKt3f7cImktw78MtEE9KvVPUpYBhVklJCS5WdZpwSoi6KpKrwGC3RewGi49YjY4BV8T2ReaKHKPUYIJB0h+pUdhgz3RH7r1LVt0cuPTZ2x/YHZo7pvGGjqqFZ60v5iM3Tpk3v2r/zr29GfR3S+cV33h37820ffXqabdd3/tGv4/+ELXlhOdjNoETbXSH3Cm/z31kO86dsIk8Ww8jUIFrZHKLfNh91J1w84rGbrI7reisieg06owmgyldr3psPcE//RQ388pe5rHdx9200b3dHXd3uXk3R/Mczn6nbf2B03YNOOzPS5LnAnTZ6umphLmPUz7bKVq0Oo1O0nGiHLGIJh8x66z9CmMfP6BhqvbiGNV/IBiksI13rny79o5psq4j84KJLffxkZt3VjROzl3X20KvvHBZ2dbnex/DNVWOEVcG6sQIHvhjrMYq6TyGCeJEzWyxWrNIbNBo8uVia7FzpLtCrrRWOivcc4W52hlyjbXGOcO9TFimXSgvsy5zLnRfRBxaUTCey80SZunONSzl6oV63VKDzuXnJQuanD1dYqqwpYfzh0sEJFlSMHgacYQZGtZ7WHiFtCkdYsjCDI3CCC8LrVBV0R4Mq2pO1NSwjQ2jd1zBLP5kS0s7U5ipnS/M1/K4fmxyAWoCHOo+D4P3+fK7r/rTW8R5yadXH+nr2de+8cr23Rs2tlMbybhuVd+7vS98+iuSSozPP/f8S3967ll89ca+Bj6IerFiBHUodo9BHiafIVfKfKkSV2hAGWoIpeQ6clPGpjQqWxRNsavYd6brTF+15lzDXNdc3xLNBYYGeZnrAl+X8or9bffb3ldSu+3dqUeVhOIM8VE56hjJF8vj+TPlOfIH+k9T+mS9xYSxqZ+tTKffpAeTJ/2wjsi6mK5W16rjdSuILY/mWcMAXegSyXYSJ8cJHyClZCoGgZ7AhAI3SQbuzWxH+rybBUmorVJ1Qyrqj9qxFZpsA4vM6bBTFhBlWLhBqtp4d/HWxZsOL1l55JI5m7Mt965a/eB9K1p29TUIj7dNn35N4pa7+k5efVZx70nu7hcOPvfac8/+BU17A262T6G+LHB5bHSOjcg8CfH5/Dh+Jn8+v4IXtRaNVqM12ixaI3AaolcHCjrtkC0aoklTbMRG0yw/GeNYJxw8FePgie3zZjyRqMPC+Ca50YL8zEaT+qlLTTP7TCQ5QjzDsQMzroYNd45pKD33vDFjx44+z57KR+5omlh8X8aE0trm3lfZXlqKp7Vd2P/h5I3YJXyaPa1Ye6a2PH12Wn3aWu112ivS77U9mPUEZ9S6vG7X8Mqs112Cj55NqZxLdO65mrnaubq5+rmGucYlmiXaJbol+iWGJcaOSEeGOSOSnpE+dFT6HF21fmFk4ZAVoRXprem/1v3WsHXIzVk3Dr9bd7/hroy7h+yO/CniTMHtI2ZNLZqjyQgbdLxXiTh4fXaKl4XV/oCn1DPVM8+z03PII5o9Ac9yzxEPH/Bs9lDPo/RsPDUBi75l9vmYTA7jHktkQgk7xdid+SyPpZos+YRkz01ZmkJT/A6J92frA17iTffEbO58Tyc9t11Kz0TOR/xFhzNJpjeXPRXBE1FtblcuLc1tzaW5Mp6500FJN6cdObU1jxg4BDVNxvi8p3mK6tbYOejzaP+RuwmPQlH0V82qaTZ3Jz/z6P/IA51dLGNYagiPKRGLbJVtMiemGRUfaIdIPiIMQ0i1YzFoCvkgLWQ0aIZiEDUkQ6sTo7wPAnIKc4tRFgIkgW290czo+vUsxm1iQWKNrcCZtPKMSEY2ngrYR7Wq3xw46bNjgyuVJt1HpLTdfNUla1ePDP/6qVunlhVmXj9z3eNzLHFDS8PaJU5nju+KAzfPbnhq3aE3yBn+C5rry88IucO5k9ZPmbBmSCA68ZJF7hlzZxSE/Ck2XXpe2dq5c7adw34EB+mJf9FM4VZwQes+0LGPbSMsFOuKlSHR6sH42GDUEQ6csjZq1qEz4PRmOQ3SiNEaNpCEpKnQVtRKjVKrtEXiAb3odikudUmHJVHaT5eAm4zadX5ysaAP6GFngu7PS9QDfG8J8wMYjsrPsLA5Gg27kud3SwjPRgW4ZkIWO1MRlb1nlcxfmnXFFbv37LFFh6TesU0eU38nXXANkZb2XXtN768nZ3nZWC7HVXNU/YbV4/vAy87OeOqhis2Zb2ab6VCrPT9qI+kam9NAbE49LngLDgfynGG3S91EXaTLRVxTvOqyZ5uo97iXNnq3e+PehJf34unolEPAk4NW0R7GcwSvneI5dejpGdg/0TOwUZaWJD2CalJeXjYZzUYqJj/nx12UN/jAqLEkQ+/MzPXoE9FO+j/IyIio4bdLNRM1FOdK17523l1TZX2H3nLh9OnXje74bcfEZVNHttCtvbuvHTFh+szNm2gRHjUIBPHE/Rnqwks27jb7iZmt5Lv9RUPss807dVzMGDNTszJkeL7MQDJorU6j25qhzzBkGEcZRhlHmm616IdYh9gmOqut1bZqR4O1wdbgWCOuMq6xXGy/2LHB2Ga5xnqN7Sr7Lbod+sfkRy377X/XfWT/wtgrf21P+FOtZrNBtlitOuA8dpstbNXZsWA2mC2GsF5n1+t1NqvVYNCLnN9jBr/spzn+A37q76Sle8y2mDVm76SzYvpSa8xK51kPWKm1k4zdayZpUOHTsSarWdHHYophuGGqgZtmSBioATl255hxsLS0w6esRcPDqLK3Cd2A161+WO6WP+/2yN24FXndco9KgZsZI1ukLErXDI7SASduo0kuKdEcrIybZlbG3dPnVD0KhsTHoE98TAoLq5Ox+z6wJ97ZW1CkSysoMnUmPt7jKLKkOYqSEXtTNIpBO4bTtozkhwB4kzwb+4zclkdwN8C5vsw+OqtkossSEfR9y554O5oWiL7f0be0LH342tn5fYvul4ek+y4wp/BDem9duX7tKnrByad3jq2emfyXN/adw1q9RoPhJP3+D0t/eEnQ/9VFTf9XiwY3iiCKLFEqgIaRvMiJar1Br0X53M/L1wIkvxapHfS+714uShJIEodS9RKSPAZd6r8bGvU6AP6/I1//o/KlfvnSgHxeUuvNRva5rfDz8vXfk68d3KgBjYYlJt/ISPaPdap82Wj4ZfINA/KNPyJfCxqtFrQantOgfCRPybcYkV/4pfKFn5SvZfK1qnxGihpeq9bbZBM+Jn5f2g8vEwPGZx70voFLBzo8Qet1PEqVGSnqBJ0q32GR8bFfIN88IN/yI/INoNezJPA6kPUGPUh6kc2THtx2K6pJ8/PyLQPybYPGM3AZwWAygskkiAawm4wm0Bgkk/pen8uO0/8L5LNfkqtry5Usy6cPzmQ2g9ksiiZwmpHUmjRmtRMpHic+pv2+tB9eDgbSd/JtgxtlMMsyyLKEvfbISOrMGlkdl+JDN6HV/7x8VSzrh+9H5FtAtljQK0qSDD4rknpZa1XHFfR5fpl89/fkO06Xb7FawDog3wp6S7/8cMCP5vUL5PsG5AcGjWfgsoPNYQeHQ9LaIOBwOMBg1TnU92amKzjNJvjZK5UBM8pQsuwd3OgCh8sFLpcOpaa7kDTZDS51kNkR5Df+AvnBAfnhZNk/uNELLq8XvF6dzgURL5Jml9Grvjd3aATNSP6+tB9e6QxYP4Ymy4HBjX7w+P3g9xt0HhjiR9LiMbEOeGDUMOQ3W35efgYDZtPDBo1n4EoFX2oqpKYYjT4YloKk1WdOATZpxSOy0Hxt35f2wytzQH7OoPEMXAqkKAooitGYCiMUJG0psqLKH1eUi7bs/Hn5wxmwfhQky0MHN4YhLRyGcNhsToOiMJLONFtYHWRlaSFOs+v70n54jWLAbO6MZHnY6YOLZGZCZqbFEoHSTCQ9EUem+t6ZE8bgNHt+Xn4JA9aPimQ5f3BjNmRmZ0N2ttUWhQnZSPozXdnAJm3uZOT3er8v7YfXWAaMrzJZLhrcmAfZeXmQn2d35MDkPCQD2d48dZALZyG/3/99aT+8JjJgfP3RzZjBjYWQW1gIBYVOZy7MKkQymOtHvcMIFv2DNKZvCoyT4ZudfXly8alvJg1cNeKgKvZ9aUzxn+/Q/51L+DP7NtHpF/bvwOCy+AD7dsuPX/z7Scv971x8C5yp5gDTkB6PqbK/fiymjeTPsIn8OXEntm/qf/9GVo+pnOVqHx+ADdhein1Nx7rLT5PPFgZTeQ1CKSzAsITiFpXDbIg36HoxDGKBaDZlJpgM/frYd9JVmoCOju6nKZjosH6ag/PIoX6aH8Qj4FHzkX5aBBO5/9RkX0Yy+2kCAgn30xQkktpPc9inY/00P4hHQEf8fj8t4qb7N/ZLH5712gCHVTo5oi6VFtX6DpWW1Pq7VVqj0jeotLZ/jEk6OcYknRxjkk6OMUnzg3iSY0zSyTEyWjeoP3r1XVeotGFQvUmlV6u0zN4FS1TahrQVqlTaPojfocqZqNLOQfUe9dlilfapPJkqnTKIJzCITlf5/SqdqdImlR6m0kzzRDOo/5pB7zIMqjcMjKUMmvFeCRfCCqhjv2UkcXIHTvmFsAimYM0qTAuxtBxLy5FzGbwLS7Fcz6fyI/hKfgJ/BmLRqdY6tXUNOhsm70J8lv0SpRnzwRz1p0n7roW1NXC3cbu4x7kDmPZx+7nfnyarub83A5KWw3xYQ4wocQnWfzL4LWXNDXVLJ8+aXd/c0rD8QiU3uzCX/bdAK9Y01herbcqM+kUrl9Y1Fw9mUYZMbljQvLxl+fkrhva3q8yz8LHz6xbUK/crsxbXKwOSlHHLmxuXN9etYM83Ll2QrZTXraj7GaYcJkyZuXzpSlbToky6EJ8bUVQ0fBhCbrZSthT71rBo8YoW7GJLffOq+oXqRDWoQ54Ms2A2DrgZWrBmOQ5bYT8IZr4c25ar6lmBU9CIPMWDnlNgBtYswsleqiqy+CelKDAEJTWgg2nGlhZM56PEod97/jvJs/rfdj6WFmCuwP2YZsFilf5+nxQYp05So4rM6Abe34iyFmAfFChX6+v+FyXlnOqZgka0HOtWnuJpwbpJ7Ae+6vtG4LZbxH5i3U/lqrVl+ERSbw047sX4bEu/FltUza1CXAinfC0kMtj/ZfXDqywEZs4FxzAlMHEQQMzBNBXTPEybMW3DJKp8rGY5psswHcB0XG2Jca72rXmxTsyuVrPdS5bmqsW6ZHFujVrcfU51Mp88PZmXT0qyFSfZRuQnq7PHJvOMrGRuDee2slxnzO0qc3JOOMwx59GISOhBMBOCoe12zgFxTJQT+2tinHV3eiR32wGOB8JRjqBGAokujrQbLbllOpqgx9AhBuhntCfZQnt2myy528rOpO/BTkwHMHH0Pbzfpe/CZfQoenEzYimmbZgOYDqE6RgmkR7F+wje79B3kOttyMFUimkepm2YDmA6hkmibyPK9G9st1GR0aWYKP0bokzfwmG9hWimbyL1Jn0Tu/ZKe0FR7j6ViOb0E4FwP+Hy9RNWZ24nfbn966GBTvr+biUa2F42nL4KcUy4/SLKmBRM0zDVYmrEJCL1OlKvQyumLZi2Y4pjwrMzooxJoc9ieh7T6zAcUwzTNEwaergdX9NJD7VHxgbKnPRF+mcMSQP0Bfq0mj9Pn1Lz5+if1PwZzFMxf5Y+1Z4agDI9tgM+I2MuY56D7QL94+50ayBRZqEHUD0BxBxMpZimYpqHaTMmkR6gae0LA1YU8ig8iwfxAG2HT9T8XrhTA7ElgVhkHNqYwiBSfAZSCNuUbREai9x0KxYZRK7bihSDyBXXIMUgcvF6pBhElq5CikFk4RKkGETmzEOKQWTqLKQQOuntj6RnBAqmXkCUMjO9CLV0EWrpItTSRcDTi9gNX/Osb79pz8xEjd0Wiw7NDLTuJ62PkdYZpPVO0lpPWi8lretJawlpPY+0Rkmrn7SmktYYaX2UFKIqWkms47RiUcxNWp8lrQ+R1hbSGiGtYdKaTloVUhDrpMH2SXlqVqFmu8vYusL8jDG5ZuxjEDUaRLMO4rI/gHgIU0ItxZBJSUsye1JZnrY7szRZzi7OXV42kT6JDz6J0/AkHMHE4wQ9iWb0JAp5EgWYEUsxzcPUhekYpgQmEbnTsOObVTQj5mAqxTQP02WYjmES1e4cw0RheX8Xd6ody+nv9FRWok/izX69GqTBWIrsl6PyRG6zn5hTydTURCotACc7BFotGksnMe790vjVl0bQlmnpdXQzpOBEbOnPN7d/nRLoJLe0Rx4NlDnIzZDKo9WRIohgeBhATbeo5ZHg17A8H/z0Qcxz2/2zA+wLJJGswH5iYk/tDXzt7w584u+kSH7sfzTwF6WTJ+2B17Dmwb2BV/1XBZ7J6dRgzWORToLZfkVl3ecvDDz0rMq6Hhtuaw9cyrK9gXX+CYEL/GpDfbLhvBYsxcyBGZE5gYkor9w/PxBrQZl7A6X+8wIlSa6R7Jm9geHYhWiSzMTODvWrLw2lqgLPLugki2NZ0k1SlTRVGiXlSllSUApIKZJPsmusGllj0hg0Oo1GI2p4DdWAxs6+TBZlwbVdlFkm8gx5lZYpQ6rG3kCJhuKJI27jKmnlzLGkMt61ACrnK/ETM0OdRDd9TlwIjSVxayVUzhobL4xWdkqJGfGCaGVcmnZu1S5CrqvG2jjd1ElgVlUnSbCqDT7207t9QIhlw7U+lg/ZcG11Nbidq0rdpdYxlqLx5T8Ctf0Y/e5yn0anxG+qnFkVfyClOp7LiERKdWX81+y3efvIv8jxivJ95J8sq67ax40h/6qYweq5MeXV1ZWdZLbKBwr5J/KhxfxT5dOkgsL4QNGkJvluS/KF8XnkS2cZ8mm1EFb5wlqtyscTxrerJb2ifFd6usrjUqBF5WlxKYN5ng0jTzis8jhb4VmV51lnK+OJj1FZ/H5kSfWrLMQLfpXFT7wqy+zvWHL6Wa46xXKV+iaOfMfjT/IYjw7wGI8iT/SXXvVjo1Gye3T1grnsd421oYp6TLXxq1ctdsdb5yvKrgXV/T94jNTOX7CY5XX18epQfXl8Qahc2TV67o80z2XNo0Plu2BuxayqXXNj9eXto2OjK0J15dW7J0zLLzjtXVedelf+tB8RNo0Jy2fvmlDwI80FrHkCe1cBe1cBe9eE2AT1XaDa+LSqXRoYWz1ubjLfTfU6tNdaX7B6rFNuHKMa7+ig+1LffgxIdoA+Wh03hMbGjZhY07CyYWWsCdcUazKxH6/2N7kvHR307Sc7+ptkrLaExkJ0xcqWleCuaChP/rXghVUrVjKFJzHa8lMXtlXEY3XlLSsAKuOZMyvjpdPnVO2SJKytZUOKFw/U6fUVnYmuZGU2VhazSo47xcjqSlidVtvP+MP5X9mfq/+G1kof3U1iqQTD1mounlo5i6IrmNX/K8H9GC6x7aGlGgfYQqKkZUCG2m1I0sDGO5BWrOyn+vWwoj9PPoWPtAyo49SFz6Cr+h8ctJJJZW5kc3RyZWFtCmVuZG9iago5IDAgb2JqCjw8IC9GaWx0ZXIgL0ZsYXRlRGVjb2RlIC9MZW5ndGggMzAwID4+CnN0cmVhbQp4nF1Ry2rDMBC86yv2mB6CZTu2GzCG4LTgQx/U7Qc40joV1LKQlYP/vpI2TaACG2Z3ZneYTdru2GnlIHm3s+jRwai0tLjMFysQTnhWmqUZSCXcFcW/mAbDEi/u18Xh1OlxZnUNkHz47uLsCpuDnE/4wJI3K9EqfYbNV9t73F+M+cEJtQPOmgYkjn7Sy2BehwkhibJtJ31fuXXrNXfG52oQsohTciNmiYsZBNpBn5HV3L8G6mf/GoZa/uuXpDqN4nuwgZ1Vns35btdE1BLaR5RzQkdCxCyI6QUBlWlEBemqfdx5nV787bpbyyONkzbjNKmkLY80MKfigYpPVKxoC/kpaEpJtoqCiiSvsqsD2hkCCIe6pSsu1vpg4zVjoiFLpfF2cDOboArfL9N4mrhlbmRzdHJlYW0KZW5kb2JqCjEwIDAgb2JqCjw8IC9UeXBlIC9PYmpTdG0gL0xlbmd0aCA1MTMgL0ZpbHRlciAvRmxhdGVEZWNvZGUgL04gNiAvRmlyc3QgMzggPj4Kc3RyZWFtCnicfVLLbtswELz3K/YYHyy+RQoIAthx3RiFUyN2m0PgA2OxqlBZFCQaqP++SzmR1RwKQa/l7M5whowBBcZBMGAClAImgWl8KeAsA5aClPTT7S2QTevz08G1cLP9XVqyWSzhaOQE7u765fkayKNvj7YCcrDAhrrt3NLXAcisLW213gFZuO7g6tzWIS508BJpKDzBHsjn+uDzsi6ArHJXhzKcpw9AtqfXcG4ckB0+Kb7897pEoIOsb+zrQHqeN957f8IfBuRrmUeKgeEC3djCde/YWdQTIKMq4VpIid22eXBl8SuAZioxnKI/b7oDTDljScYkTZGyskUH8sI9n/s/SDVNU5koRbWBqeAy0VRTAZxykwicBIwKnTCaCRP1xMZlWTkO5rKXWHi0RzdybBVsVR5mdVE5xJBtcMcfIFFYZiROGW0/amzLJvj2PwHcrxbbc4dDVvVPDxH0rc1dG22/ebd9AuTJFWUX2jPczHL/6iYxh6ap3DGaQHF+P2nnv6wWa9tcE0OnnqPMD3rwSPX7G8LE5giJ4vk/EZJndJHirRWFeHGtE9N7d/3ag8gihPOEpTrTWMDkXkaIS68RIqGYBUMAnm88CYwiAJ3DQmqwoFSaMMWFRLSiFMuaIfWorlPQGvhApfs2+nE8PowYtZlIJwZAbLiqG7PSgXkfY/sLmsPutWVuZHN0cmVhbQplbmRvYmoKMSAwIG9iago8PCAvVHlwZSAvWFJlZiAvTGVuZ3RoIDE2IC9GaWx0ZXIgL0ZsYXRlRGVjb2RlIC9EZWNvZGVQYXJtcyA8PCAvQ29sdW1ucyA0IC9QcmVkaWN0b3IgMTIgPj4gL1cgWyAxIDIgMSBdIC9TaXplIDIgL0lEIFs8ZmM5NjM1ZjgwMWM1NzE5MTUwZDg4OTBjNmMxZmQwYmE+PGZjOTYzNWY4MDFjNTcxOTE1MGQ4ODkwYzZjMWZkMGJhPl0gPj4Kc3RyZWFtCnicY2IAAiZG63cMAAK5AS8KZW5kc3RyZWFtCmVuZG9iagogICAgICAgICAgICAgICAKc3RhcnR4cmVmCjIxNgolJUVPRgo="
mock_scan_report_xml = "PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiID8+Cgo8IURPQ1RZUEUgQVNTRVRfREFUQV9SRVBPUlQgU1lTVEVNICJodHRwczovL3F1YWx5c2d1YXJkLnFnMi5hcHBzLnF1YWx5cy5jb20vYXNzZXRfZGF0YV9yZXBvcnQuZHRkIj4KPEFTU0VUX0RBVEFfUkVQT1JUPgogIDxIRUFERVI+CiAgICA8Q09NUEFOWT48IVtDREFUQVtEZW1pc3RvXV0+PC9DT01QQU5ZPgogICAgPFVTRVJOQU1FPmRlbXN0Mm5yPC9VU0VSTkFNRT4KICAgIDxHRU5FUkFUSU9OX0RBVEVUSU1FPjIwMjAtMDktMTdUMTU6NDc6NTlaPC9HRU5FUkFUSU9OX0RBVEVUSU1FPgogICAgPFRFTVBMQVRFPjwhW0NEQVRBW0Fzc2V0cyB3aXRoIE9ic29sZXRlIFNvZnR3YXJlIHYuMV1dPjwvVEVNUExBVEU+CiAgICA8VEFSR0VUPgogICAgICA8VVNFUl9BU1NFVF9HUk9VUFM+CiAgICAgICAgPEFTU0VUX0dST1VQX1RJVExFPjwhW0NEQVRBW0FsbF1dPjwvQVNTRVRfR1JPVVBfVElUTEU+CiAgICAgIDwvVVNFUl9BU1NFVF9HUk9VUFM+CiAgICAgIDxDT01CSU5FRF9JUF9MSVNUPgogICAgICAgIDxSQU5HRT4KICAgICAgICAgIDxTVEFSVD4xLjEuMS4xPC9TVEFSVD4KICAgICAgICAgIDxFTkQ+MS4xLjEuMTwvRU5EPgogICAgICAgIDwvUkFOR0U+CiAgICAgICAgPFJBTkdFPgogICAgICAgICAgPFNUQVJUPjEuMS4xLjM8L1NUQVJUPgogICAgICAgICAgPEVORD4xLjEuMS4zPC9FTkQ+CiAgICAgICAgPC9SQU5HRT4KICAgICAgICA8UkFOR0U+CiAgICAgICAgICA8U1RBUlQ+MS4yLjIuMjwvU1RBUlQ+CiAgICAgICAgICA8RU5EPjEuMi4yLjM8L0VORD4KICAgICAgICA8L1JBTkdFPgogICAgICAgIDxSQU5HRT4KICAgICAgICAgIDxTVEFSVD4xOC4xMzAuMTYuMzI8L1NUQVJUPgogICAgICAgICAgPEVORD4xOC4xMzAuMTYuMzI8L0VORD4KICAgICAgICA8L1JBTkdFPgogICAgICAgIDxSQU5HRT4KICAgICAgICAgIDxTVEFSVD4yMy45Ni4yNS4xMDA8L1NUQVJUPgogICAgICAgICAgPEVORD4yMy45Ni4yNS4xMDA8L0VORD4KICAgICAgICA8L1JBTkdFPgogICAgICAgIDxSQU5HRT4KICAgICAgICAgIDxTVEFSVD4zNC45OS4yMzEuMjQxPC9TVEFSVD4KICAgICAgICAgIDxFTkQ+MzQuOTkuMjMxLjI0MTwvRU5EPgogICAgICAgIDwvUkFOR0U+CiAgICAgICAgPFJBTkdFPgogICAgICAgICAgPFNUQVJUPjM1LjE4NS4yNy41NzwvU1RBUlQ+CiAgICAgICAgICA8RU5EPjM1LjE4NS4yNy41NzwvRU5EPgogICAgICAgIDwvUkFOR0U+CiAgICAgICAgPFJBTkdFPgogICAgICAgICAgPFNUQVJUPjUyLjU4LjIwNC4yMzwvU1RBUlQ+CiAgICAgICAgICA8RU5EPjUyLjU4LjIwNC4yMzwvRU5EPgogICAgICAgIDwvUkFOR0U+CiAgICAgICAgPFJBTkdFPgogICAgICAgICAgPFNUQVJUPjk2LjI1Mi4xOC4xNTg8L1NUQVJUPgogICAgICAgICAgPEVORD45Ni4yNTIuMTguMTU4PC9FTkQ+CiAgICAgICAgPC9SQU5HRT4KICAgICAgICA8UkFOR0U+CiAgICAgICAgICA8U1RBUlQ+MTcyLjMxLjEwLjExMDwvU1RBUlQ+CiAgICAgICAgICA8RU5EPjE3Mi4zMS4xMC4xMTA8L0VORD4KICAgICAgICA8L1JBTkdFPgogICAgICAgIDxSQU5HRT4KICAgICAgICAgIDxTVEFSVD4xNzIuMzEuMTEuNDc8L1NUQVJUPgogICAgICAgICAgPEVORD4xNzIuMzEuMTEuNDc8L0VORD4KICAgICAgICA8L1JBTkdFPgogICAgICAgIDxSQU5HRT4KICAgICAgICAgIDxTVEFSVD4xNzIuMzEuMTEuMjI5PC9TVEFSVD4KICAgICAgICAgIDxFTkQ+MTcyLjMxLjExLjIyOTwvRU5EPgogICAgICAgIDwvUkFOR0U+CiAgICAgICAgPFJBTkdFPgogICAgICAgICAgPFNUQVJUPjE5Mi4xNjguMC44NzwvU1RBUlQ+CiAgICAgICAgICA8RU5EPjE5Mi4xNjguMC45MjwvRU5EPgogICAgICAgIDwvUkFOR0U+CiAgICAgIDwvQ09NQklORURfSVBfTElTVD4KICAgIDwvVEFSR0VUPgogICAgPFJJU0tfU0NPUkVfU1VNTUFSWT4KICAgICAgPFRPVEFMX1ZVTE5FUkFCSUxJVElFUz4xPC9UT1RBTF9WVUxORVJBQklMSVRJRVM+CiAgICAgIDxBVkdfU0VDVVJJVFlfUklTSz41LjA8L0FWR19TRUNVUklUWV9SSVNLPgogICAgICA8QlVTSU5FU1NfUklTSz42NC8xMDA8L0JVU0lORVNTX1JJU0s+CiAgICA8L1JJU0tfU0NPUkVfU1VNTUFSWT4KICA8L0hFQURFUj4KICA8SE9TVF9MSVNUPgogICAgPEhPU1Q+CiAgICAgIDxJUD4xNzIuMzEuMTEuMjI5PC9JUD4KICAgICAgPFRSQUNLSU5HX01FVEhPRD5FQzI8L1RSQUNLSU5HX01FVEhPRD4KICAgICAgPEROUz48IVtDREFUQVtpLTA1NWVmMWI0NzM0NDkxNTc1XV0+PC9ETlM+CiAgICAgIDxORVRCSU9TPjwhW0NEQVRBW0FNQVpPTi01NDREQjk2QV1dPjwvTkVUQklPUz4KICAgICAgPFFHX0hPU1RJRD48IVtDREFUQVs4NzI1ZDIzNi03ZjViLTQxZTEtYjc5NS1mYTY3ZTNhZGMxMDhdXT48L1FHX0hPU1RJRD4KICAgICAgPE9QRVJBVElOR19TWVNURU0+PCFbQ0RBVEFbV2luZG93cyAyMDAzIFIyIFNlcnZpY2UgUGFjayAyXV0+PC9PUEVSQVRJTkdfU1lTVEVNPgogICAgICA8QVNTRVRfR1JPVVBTPgogICAgICAgIDxBU1NFVF9HUk9VUF9USVRMRT48IVtDREFUQVtFQzItSW5zdGFuY2VzXV0+PC9BU1NFVF9HUk9VUF9USVRMRT4KICAgICAgPC9BU1NFVF9HUk9VUFM+CiAgICAgIDxWVUxOX0lORk9fTElTVD4KICAgICAgICA8VlVMTl9JTkZPPgogICAgICAgICAgPFFJRCBpZD0icWlkXzEwNTYzMiI+MTA1NjMyPC9RSUQ+CiAgICAgICAgICA8VFlQRT5WdWxuPC9UWVBFPgogICAgICAgICAgPFNTTD5mYWxzZTwvU1NMPgogICAgICAgICAgPFJFU1VMVD48IVtDREFUQVtFT0wvT2Jzb2xldGUgT3BlcmF0aW5nIFN5c3RlbSA6IFdpbmRvd3MgU2VydmVyIDIwMDMgUjIgRGV0ZWN0ZWRdXT48L1JFU1VMVD4KICAgICAgICAgIDxGSVJTVF9GT1VORD4yMDE4LTA1LTE0VDEzOjU0OjQ1WjwvRklSU1RfRk9VTkQ+CiAgICAgICAgICA8TEFTVF9GT1VORD4yMDE4LTEwLTI1VDE5OjExOjM1WjwvTEFTVF9GT1VORD4KICAgICAgICAgIDxUSU1FU19GT1VORD41OTwvVElNRVNfRk9VTkQ+CiAgICAgICAgICA8VlVMTl9TVEFUVVM+QWN0aXZlPC9WVUxOX1NUQVRVUz4KICAgICAgICA8L1ZVTE5fSU5GTz4KICAgICAgPC9WVUxOX0lORk9fTElTVD4KICAgIDwvSE9TVD4KICA8L0hPU1RfTElTVD4KICA8R0xPU1NBUlk+CiAgICA8VlVMTl9ERVRBSUxTX0xJU1Q+CiAgICAgIDxWVUxOX0RFVEFJTFMgaWQ9InFpZF8xMDU2MzIiPgogICAgICAgIDxRSUQgaWQ9InFpZF8xMDU2MzIiPjEwNTYzMjwvUUlEPgogICAgICAgIDxUSVRMRT48IVtDREFUQVtFT0wvT2Jzb2xldGUgT3BlcmF0aW5nIFN5c3RlbTogTWljcm9zb2Z0IFdpbmRvd3MgU2VydmVyIDIwMDMgRGV0ZWN0ZWRdXT48L1RJVExFPgogICAgICAgIDxTRVZFUklUWT41PC9TRVZFUklUWT4KICAgICAgICA8Q0FURUdPUlk+U2VjdXJpdHkgUG9saWN5PC9DQVRFR09SWT4KICAgICAgICA8VEhSRUFUPjwhW0NEQVRBW1RoZSBob3N0IGlzIHJ1bm5pbmcgV2luZG93cyBTZXJ2ZXIgMjAwMy4gTWljcm9zb2Z0IGVuZGVkIHN1cHBvcnQgZm9yIFdpbmRvd3MgU2VydmVyIDIwMDMgb24gSnVseSAxNCwgMjAxNSBhbmQgcHJvdmlkZXMgbm8gZnVydGhlciBzdXBwb3J0IGZvciB0aGlzIG9wZXJhdGluZyBzeXN0ZW0uXV0+PC9USFJFQVQ+CiAgICAgICAgPElNUEFDVD48IVtDREFUQVtUaGUgc3lzdGVtIGlzIGF0IGhpZ2ggcmlzayBvZiBiZWluZyBleHBvc2VkIHRvIHNlY3VyaXR5IHZ1bG5lcmFiaWxpdGllcy4gU2luY2UgdGhlIHZlbmRvciBubyBsb25nZXIgcHJvdmlkZXMgdXBkYXRlcywgb2Jzb2xldGUgc29mdHdhcmUgaXMgbW9yZSB2dWxuZXJhYmxlIHRvIHZpcnVzZXMgYW5kIG90aGVyIGF0dGFja3MuXV0+PC9JTVBBQ1Q+CiAgICAgICAgPFNPTFVUSU9OPjwhW0NEQVRBW1VwZGF0ZSB0byB0aGUgbGF0ZXN0IHN1cHBvcnRlZCBXaW5kb3dzIG9wZXJhdGluZyBzeXN0ZW0gZnJvbSBNaWNyb3NvZnQuIFJlZmVyIHRvIDxBIEhSRUY9Imh0dHA6Ly93aW5kb3dzLm1pY3Jvc29mdC5jb20vZW4tdXMvd2luZG93cy9wcm9kdWN0cyIgVEFSR0VUPSJfYmxhbmsiPldpbmRvd3MgUHJvZHVjdHM8L0E+Ll1dPjwvU09MVVRJT04+CiAgICAgICAgPFBDSV9GTEFHPjE8L1BDSV9GTEFHPgogICAgICAgIDxMQVNUX1VQREFURT4yMDE5LTA1LTIzVDA3OjE4OjE1WjwvTEFTVF9VUERBVEU+CiAgICAgICAgPFZFTkRPUl9SRUZFUkVOQ0VfTElTVD4KICAgICAgICAgIDxWRU5ET1JfUkVGRVJFTkNFPgogICAgICAgICAgICA8SUQ+PCFbQ0RBVEFbV2luZG93cyBTZXJ2ZXIgMjAwMyBFbmQgb2YgTGlmZV1dPjwvSUQ+CiAgICAgICAgICAgIDxVUkw+PCFbQ0RBVEFbaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL2VuLXVzL3NlcnZlci1jbG91ZC9wcm9kdWN0cy93aW5kb3dzLXNlcnZlci0yMDAzL11dPjwvVVJMPgogICAgICAgICAgPC9WRU5ET1JfUkVGRVJFTkNFPgogICAgICAgIDwvVkVORE9SX1JFRkVSRU5DRV9MSVNUPgogICAgICA8L1ZVTE5fREVUQUlMUz4KICAgIDwvVlVMTl9ERVRBSUxTX0xJU1Q+CiAgPC9HTE9TU0FSWT4KICA8QVBQRU5ESUNFUz4KICAgIDxOT19SRVNVTFRTPgogICAgICA8SVBfTElTVD4KICAgICAgICA8UkFOR0U+CiAgICAgICAgICA8U1RBUlQ+MS4xLjEuMTwvU1RBUlQ+CiAgICAgICAgICA8RU5EPjEuMS4xLjE8L0VORD4KICAgICAgICA8L1JBTkdFPgogICAgICAgIDxSQU5HRT4KICAgICAgICAgIDxTVEFSVD4xLjEuMS4zPC9TVEFSVD4KICAgICAgICAgIDxFTkQ+MS4xLjEuMzwvRU5EPgogICAgICAgIDwvUkFOR0U+CiAgICAgICAgPFJBTkdFPgogICAgICAgICAgPFNUQVJUPjEuMi4yLjI8L1NUQVJUPgogICAgICAgICAgPEVORD4xLjIuMi4zPC9FTkQ+CiAgICAgICAgPC9SQU5HRT4KICAgICAgICA8UkFOR0U+CiAgICAgICAgICA8U1RBUlQ+MTguMTMwLjE2LjMyPC9TVEFSVD4KICAgICAgICAgIDxFTkQ+MTguMTMwLjE2LjMyPC9FTkQ+CiAgICAgICAgPC9SQU5HRT4KICAgICAgICA8UkFOR0U+CiAgICAgICAgICA8U1RBUlQ+MjMuOTYuMjUuMTAwPC9TVEFSVD4KICAgICAgICAgIDxFTkQ+MjMuOTYuMjUuMTAwPC9FTkQ+CiAgICAgICAgPC9SQU5HRT4KICAgICAgICA8UkFOR0U+CiAgICAgICAgICA8U1RBUlQ+MzQuOTkuMjMxLjI0MTwvU1RBUlQ+CiAgICAgICAgICA8RU5EPjM0Ljk5LjIzMS4yNDE8L0VORD4KICAgICAgICA8L1JBTkdFPgogICAgICAgIDxSQU5HRT4KICAgICAgICAgIDxTVEFSVD4zNS4xODUuMjcuNTc8L1NUQVJUPgogICAgICAgICAgPEVORD4zNS4xODUuMjcuNTc8L0VORD4KICAgICAgICA8L1JBTkdFPgogICAgICAgIDxSQU5HRT4KICAgICAgICAgIDxTVEFSVD41Mi41OC4yMDQuMjM8L1NUQVJUPgogICAgICAgICAgPEVORD41Mi41OC4yMDQuMjM8L0VORD4KICAgICAgICA8L1JBTkdFPgogICAgICAgIDxSQU5HRT4KICAgICAgICAgIDxTVEFSVD45Ni4yNTIuMTguMTU4PC9TVEFSVD4KICAgICAgICAgIDxFTkQ+OTYuMjUyLjE4LjE1ODwvRU5EPgogICAgICAgIDwvUkFOR0U+CiAgICAgICAgPFJBTkdFPgogICAgICAgICAgPFNUQVJUPjE3Mi4zMS4xMC4xMTA8L1NUQVJUPgogICAgICAgICAgPEVORD4xNzIuMzEuMTAuMTEwPC9FTkQ+CiAgICAgICAgPC9SQU5HRT4KICAgICAgICA8UkFOR0U+CiAgICAgICAgICA8U1RBUlQ+MTcyLjMxLjExLjQ3PC9TVEFSVD4KICAgICAgICAgIDxFTkQ+MTcyLjMxLjExLjQ3PC9FTkQ+CiAgICAgICAgPC9SQU5HRT4KICAgICAgICA8UkFOR0U+CiAgICAgICAgICA8U1RBUlQ+MTkyLjE2OC4wLjg3PC9TVEFSVD4KICAgICAgICAgIDxFTkQ+MTkyLjE2OC4wLjkyPC9FTkQ+CiAgICAgICAgPC9SQU5HRT4KICAgICAgPC9JUF9MSVNUPgogICAgPC9OT19SRVNVTFRTPgogICAgPFRFTVBMQVRFX0RFVEFJTFM+CiAgICAgIDxWVUxOX0xJU1RTPjwhW0NEQVRBW09ic29sZXRlIFNvZnR3YXJlIHYuMV1dPjwvVlVMTl9MSVNUUz4KICAgICAgPFNFTEVDVElWRV9WVUxOUz4xMTU0MiwgMTE1NDQsIDExNTgyLCAxMTYxNiwgMTE2MTcsIDExNjE4LCAxMTYzNiwgMTE2NTIsIDExNjYxLCAxMTY2OSwgMTE2NzAsIDExNjcxLCAxMTcyNiwgMTE3MjcsIDExNzI4LCAxMTcyOSwgMTE3MzAsIDExNzkyLCAxMTc5OCwgMTI1ODMsIDEyNTg0LCAxMjk1NiwgMTM0NzcsIDE5NjAxLCAxOTYwMiwgMTk2MDMsIDE5NjA1LCAxOTcyOSwgMTk3MzAsIDE5NzMxLCAxOTkyNSwgMzg2NjIsIDYyMDI4LCA4NzI4MCwgODcyODksIDg3Mzc2LCAxMDUxMzgsIDEwNTMzNywgMTA1MzM4LCAxMDUzMzksIDEwNTM0MCwgMTA1MzQxLCAxMDUzNDIsIDEwNTM0MywgMTA1MzQ0LCAxMDUzNDUsIDEwNTM0NiwgMTA1MzQ3LCAxMDUzNDgsIDEwNTM0OSwgMTA1MzUwLCAxMDUzNTEsIDEwNTM1MiwgMTA1MzUzLCAxMDUzNTQsIDEwNTM1NSwgMTA1MzU2LCAxMDUzNTcsIDEwNTM1OCwgMTA1MzU5LCAxMDUzNjAsIDEwNTM2MSwgMTA1MzYyLCAxMDUzNjMsIDEwNTM2NCwgMTA1MzY1LCAxMDUzNjYsIDEwNTM2NywgMTA1MzY4LCAxMDUzNjksIDEwNTM3MCwgMTA1MzcxLCAxMDUzNzIsIDEwNTM3MywgMTA1Mzc0LCAxMDUzNzUsIDEwNTM3NiwgMTA1Mzc3LCAxMDUzNzgsIDEwNTM3OSwgMTA1MzgxLCAxMDUzODIsIDEwNTM4MywgMTA1Mzg2LCAxMDUzODcsIDEwNTM4OCwgMTA1MzkyLCAxMDUzOTMsIDEwNTM5NCwgMTA1Mzk1LCAxMDUzOTYsIDEwNTM5NywgMTA1Mzk4LCAxMDUzOTksIDEwNTQwMCwgMTA1NDAxLCAxMDU0MDIsIDEwNTQwMywgMTA1NDA0LCAxMDU0MDUsIDEwNTQwNiwgMTA1NDA3LCAxMDU0MDgsIDEwNTQwOSwgMTA1NDEwLCAxMDU0MTEsIDEwNTQxMiwgMTA1NDEzLCAxMDU0MTQsIDEwNTQxNSwgMTA1NDE2LCAxMDU0MTcsIDEwNTQxOCwgMTA1NDE5LCAxMDU0MjIsIDEwNTQyMywgMTA1NDI0LCAxMDU0MjUsIDEwNTQyNiwgMTA1NDI3LCAxMDU0MjgsIDEwNTQyOSwgMTA1NDMwLCAxMDU0MzEsIDEwNTQzMiwgMTA1NDMzLCAxMDU0MzQsIDEwNTQzNSwgMTA1NDM2LCAxMDU0MzcsIDEwNTQzOCwgMTA1NDM5LCAxMDU0NDAsIDEwNTQ0MiwgMTA1NDQ0LCAxMDU0NDUsIDEwNTQ0NiwgMTA1NDQ3LCAxMDU0NDgsIDEwNTQ0OSwgMTA1NDUwLCAxMDU0NTEsIDEwNTQ1MiwgMTA1NDUzLCAxMDU0NTQsIDEwNTQ1NSwgMTA1NDU2LCAxMDU0NTcsIDEwNTQ1OCwgMTA1NDU5LCAxMDU0NjAsIDEwNTQ2MSwgMTA1NDYyLCAxMDU0NjUsIDEwNTQ2NiwgMTA1NDY4LCAxMDU0NjksIDEwNTQ3MCwgMTA1NDcxLCAxMDU0NzIsIDEwNTQ3MywgMTA1NDc0LCAxMDU0NzUsIDEwNTQ3NiwgMTA1NDc3LCAxMDU0NzgsIDEwNTQ3OSwgMTA1NDgwLCAxMDU0ODEsIDEwNTQ4MiwgMTA1NDgzLCAxMDU0ODgsIDEwNTQ5MCwgMTA1NDkyLCAxMDU0OTMsIDEwNTQ5NCwgMTA1NDk1LCAxMDU0OTcsIDEwNTQ5OCwgMTA1NDk5LCAxMDU1MDIsIDEwNTUwMywgMTA1NTA1LCAxMDU1MDYsIDEwNTUwNywgMTA1NTA4LCAxMDU1MDksIDEwNTUxMCwgMTA1NTExLCAxMDU1MTIsIDEwNTUxMywgMTA1NTE0LCAxMDU1MTUsIDEwNTUxNiwgMTA1NTE3LCAxMDU1MTgsIDEwNTUxOSwgMTA1NTIxLCAxMDU1MjIsIDEwNTUyMywgMTA1NTI0LCAxMDU1MjUsIDEwNTUyNiwgMTA1NTI5LCAxMDU1MzAsIDEwNTUzMSwgMTA1NTMyLCAxMDU1MzMsIDEwNTUzNCwgMTA1NTM1LCAxMDU1MzYsIDEwNTUzNywgMTA1NTM4LCAxMDU1MzksIDEwNTU0MCwgMTA1NTQxLCAxMDU1NDIsIDEwNTU0MywgMTA1NTQ0LCAxMDU1NDUsIDEwNTU0OCwgMTA1NTQ5LCAxMDU1NTAsIDEwNTU1MSwgMTA1NTUyLCAxMDU1NTMsIDEwNTU1NCwgMTA1NTU1LCAxMDU1NTcsIDEwNTU1OCwgMTA1NTU5LCAxMDU1NjAsIDEwNTU2MSwgMTA1NTYyLCAxMDU1NjMsIDEwNTU2NCwgMTA1NTY1LCAxMDU1NjYsIDEwNTU2NywgMTA1NTY5LCAxMDU1NzAsIDEwNTU3MSwgMTA1NTcyLCAxMDU1NzMsIDEwNTU3NCwgMTA1NTc1LCAxMDU1NzYsIDEwNTU3NywgMTA1NTc4LCAxMDU1NzksIDEwNTU4MCwgMTA1NTgxLCAxMDU1ODIsIDEwNTU4MywgMTA1NTg0LCAxMDU1ODUsIDEwNTU4NiwgMTA1NTg3LCAxMDU1ODgsIDEwNTU4OSwgMTA1NTkwLCAxMDU1OTIsIDEwNTU5MywgMTA1NTk0LCAxMDU1OTUsIDEwNTU5NiwgMTA1NTk3LCAxMDU1OTgsIDEwNTU5OSwgMTA1NjAwLCAxMDU2MDEsIDEwNTYwMiwgMTA1NjAzLCAxMDU2MDQsIDEwNTYwNSwgMTA1NjA2LCAxMDU2MDcsIDEwNTYwOCwgMTA1NjA5LCAxMDU2MTAsIDEwNTYxMSwgMTA1NjEyLCAxMDU2MTMsIDEwNTYxNCwgMTA1NjE1LCAxMDU2MTYsIDEwNTYxNywgMTA1NjE4LCAxMDU2MTksIDEwNTYyMCwgMTA1NjIxLCAxMDU2MjIsIDEwNTYyMywgMTA1NjI0LCAxMDU2MjUsIDEwNTYyNiwgMTA1NjI3LCAxMDU2MjgsIDEwNTYyOSwgMTA1NjMwLCAxMDU2MzEsIDEwNTYzMiwgMTA1NjMzLCAxMDU2MzQsIDEwNTYzNSwgMTA1NjM2LCAxMDU2MzcsIDEwNTYzOCwgMTA1NjM5LCAxMDU2NDAsIDEwNTY0MSwgMTA1NjQyLCAxMDU2NDMsIDEwNTY0NCwgMTA1NjQ1LCAxMDU2NDYsIDEwNTY0NywgMTA1NjQ4LCAxMDU2NDksIDEwNTY1MCwgMTA1NjUxLCAxMDU2NTIsIDEwNTY1MywgMTA1NjU0LCAxMDU2NTUsIDEwNTY1NiwgMTA1NjU3LCAxMDU2NTgsIDEwNTY1OSwgMTA1NjYwLCAxMDU2NjEsIDEwNTY2MiwgMTA1NjY0LCAxMDU2NjUsIDEwNTY2NiwgMTA1NjY3LCAxMDU2NjgsIDEwNTY2OSwgMTA1NjcwLCAxMDU2NzEsIDEwNTY3MiwgMTA1NjczLCAxMDU2NzQsIDEwNTY3NSwgMTA1Njc2LCAxMDU2NzcsIDEwNTY4OSwgMTA1NjkwLCAxMDU2OTMsIDEwNTY5NCwgMTA1Njk1LCAxMDU2OTYsIDEwNTY5NywgMTA1Njk4LCAxMDU2OTksIDEwNTcwMCwgMTA1NzAxLCAxMDU3MDIsIDEwNTcwMywgMTA1NzA2LCAxMDU3MDcsIDEwNTcxMCwgMTA1NzExLCAxMDU3MTIsIDEwNTcxMywgMTA1NzE0LCAxMDU3MTUsIDEwNTcxOCwgMTA1NzE5LCAxMDU3MjAsIDEwNTcyMSwgMTA1NzI0LCAxMDU3MjUsIDEwNTcyNiwgMTA1NzI3LCAxMDU3MjgsIDEwNTcyOSwgMTA1NzMwLCAxMDU3MzEsIDEwNTczMiwgMTA1NzMzLCAxMDU3MzQsIDEwNTczNSwgMTA1NzM2LCAxMDU3MzcsIDEwNTczOCwgMTA1NzM5LCAxMDU3NDAsIDEwNTc0MSwgMTA1NzQyLCAxMDU3NDMsIDEwNTc0NCwgMTA1NzQ1LCAxMDU3NDYsIDEwNTc0NywgMTA1NzQ4LCAxMDU3NDksIDEwNTc1MCwgMTA1NzUxLCAxMDU3NTIsIDEwNTc1MywgMTA1NzU0LCAxMDU3NTUsIDEwNTc1NiwgMTA1NzU3LCAxMDU3NTgsIDEwNTc1OSwgMTA1NzYwLCAxMDU3NjEsIDEwNTc2MiwgMTA1NzYzLCAxMDU3NjQsIDEwNTc2NSwgMTA1NzY2LCAxMDU3NjcsIDEwNTc2OSwgMTA1NzcwLCAxMDU3NzEsIDEwNTc3MiwgMTA1NzczLCAxMDU3NzQsIDEwNTc3NSwgMTA1Nzc2LCAxMDU3NzcsIDEwNTc3OCwgMTA1Nzc5LCAxMDU3ODAsIDEwNTc4MiwgMTA1NzgzLCAxMDU3ODQsIDEwNTc4NiwgMTA1Nzg4LCAxMDU3ODksIDEwNTc5MCwgMTA1NzkxLCAxMDU3OTIsIDEwNTc5MywgMTA1Nzk0LCAxMDU3OTYsIDEwNTc5NywgMTA1Nzk5LCAxMDU4MDEsIDEwNTgwMiwgMTA1ODAzLCAxMDU4MDQsIDEwNTgwNSwgMTA1ODA2LCAxMDU4MDcsIDEwNTgwOSwgMTA1ODEyLCAxMDU4MTMsIDEwNTgxNCwgMTA1ODE2LCAxMDU4MTcsIDEwNTgxOCwgMTA1ODE5LCAxMDU4MjAsIDEwNTgyMSwgMTA1ODIyLCAxMDU4MjMsIDEwNTgyNCwgMTA1ODI1LCAxMDU4MjYsIDEwNTgyNywgMTA1ODI4LCAxMDU4MjksIDEwNTgzMCwgMTA1ODMxLCAxMDU4MzIsIDEwNTgzMywgMTA1ODM0LCAxMDU4MzUsIDEwNTgzNiwgMTA1ODM3LCAxMDU4MzgsIDEwNTgzOSwgMTA1ODQwLCAxMDU4NDEsIDEwNTg0MiwgMTA1ODQzLCAxMDU4NDQsIDEwNTg0NSwgMTA1ODQ2LCAxMDU4NDcsIDEwNTg0OCwgMTA1ODQ5LCAxMDU4NTAsIDEwNTg1MSwgMTA1ODUyLCAxMDU4NTMsIDEwNTg1NCwgMTA1ODU1LCAxMDU4NTYsIDEwNTg1NywgMTA1ODU4LCAxMDU4NTksIDEwNTg2MCwgMTA1ODYxLCAxMDU4NjIsIDEwNTg2MywgMTA1ODY0LCAxMDU4NjUsIDEwNTg2NiwgMTA1ODY3LCAxMDU4NjgsIDEwNTg2OSwgMTA1ODcwLCAxMDU4NzEsIDEwNTg3MiwgMTA1ODczLCAxMDU4NzQsIDEwNTg3NSwgMTA1ODc2LCAxMDU4NzcsIDEwNTg3OSwgMTA1ODgwLCAxMDU4ODEsIDEwNTg4MiwgMTA1ODgzLCAxMDU4ODQsIDEwNTg4NSwgMTA1ODg2LCAxMDU4ODcsIDEwNTg5MSwgMTA1ODkzLCAxMDU4OTQsIDEwNTg5NSwgMTA1OTAwLCAxMDU5MDEsIDEwNTkwMiwgMTA1OTAzLCAxMDU5MDQsIDEwNTkwNSwgMTA1OTA2LCAxMDU5MDcsIDEwNTkwOCwgMTA1OTA5LCAxMDU5MTAsIDEwNTkxMSwgMTA1OTEyLCAxMDU5MTMsIDEwNTkxNCwgMTA1OTE1LCAxMDU5MTYsIDEwNTkxNywgMTA1OTE4LCAxMDU5MjAsIDEwNTkyMSwgMTA1OTIyLCAxMDU5MjMsIDEwNTkyNCwgMTA1OTI1LCAxMDU5MjYsIDEwNTkyNywgMTA1OTI5LCAxMTg4MTEsIDEyMzQ4OCwgMTI0Mzc4LCAxNTQwNzAsIDE1NjMwOSwgMTU2NjM2LCAzNzAxNDIsIDM3MDE0MywgMzcwMTQ1LCAzNzAzMDAsIDM3MDM5MywgMzcwMzk0LCAzNzAzOTUsIDM3MDU3MywgMzcwNjYwLCAzNzA3ODcsIDM3MDc4OCwgMzcwNzg5LCAzNzA3OTAsIDM3MDc5MSwgMzcxMTQ5LCAzNzE3MDMsIDY1MDAwMSwgNjUwMDAyLCA2NTAwMDMsIDY1MDAwNCwgNjUwMDA1LCA2NTAwMDYsIDY1MDAwNywgNjUwMDA4LCA2NTAwMDksIDY1MDAxMSwgNjUwMDEyLCA2NTAwMTQsIDY1MDAxNTwvU0VMRUNUSVZFX1ZVTE5TPgogICAgICA8RklMVEVSX1NVTU1BUlk+CiAgICAgICAgU3RhdHVzOk5ldywgQWN0aXZlLCBSZS1PcGVuZWQKICAgICAgICBEaXNwbGF5IG5vbi1ydW5uaW5nIGtlcm5lbHM6CiAgICAgICAgT2ZmCiAgICAgICAgRXhjbHVkZSBub24tcnVubmluZyBrZXJuZWxzOgogICAgICAgIE9mZgogICAgICAgIEV4Y2x1ZGUgbm9uLXJ1bm5pbmcgc2VydmljZXM6CiAgICAgICAgT2ZmCiAgICAgICAgRXhjbHVkZSBRSURzIG5vdCBleHBsb2l0YWJsZSBkdWUgdG8gY29uZmlndXJhdGlvbjoKICAgICAgICBPZmYKICAgICAgICBJbmNsdWRlZCBPcGVyYXRpbmcgU3lzdGVtczoKICAgICAgICBBbGwgT3BlcmF0aW5nIFN5c3RlbXMKICAgICAgPC9GSUxURVJfU1VNTUFSWT4KICAgIDwvVEVNUExBVEVfREVUQUlMUz4KICA8L0FQUEVORElDRVM+CjwvQVNTRVRfREFUQV9SRVBPUlQ+CjwhLS0gQ09ORklERU5USUFMIEFORCBQUk9QUklFVEFSWSBJTkZPUk1BVElPTi4gUXVhbHlzIHByb3ZpZGVzIHRoZSBRdWFseXNHdWFyZCBTZXJ2aWNlICJBcyBJcywiIHdpdGhvdXQgYW55IHdhcnJhbnR5IG9mIGFueSBraW5kLiBRdWFseXMgbWFrZXMgbm8gd2FycmFudHkgdGhhdCB0aGUgaW5mb3JtYXRpb24gY29udGFpbmVkIGluIHRoaXMgcmVwb3J0IGlzIGNvbXBsZXRlIG9yIGVycm9yLWZyZWUuIENvcHlyaWdodCAyMDIwLCBRdWFseXMsIEluYy4gLy8tLT4gCg=="

mock_scan_report_json = {
   "@value": "scan/1589961742.46404",
   "HEADER": {
      "KEY": [
         {
            "@value": "USERNAME",
            "#text": "user2"
         },
         {
            "@value": "COMPANY",
            "#text": "ACompany"
         },
         {
            "@value": "DATE",
            "#text": "2015-05-20T08:02:22Z"
         },
         {
            "@value": "TITLE",
            "#text": "periodic scan"
         },
         {
            "@value": "TARGET",
            "#text": "118.110.16.132, 23.49.1.100, 135.18.2.157, 152.5.20.123"
         },
         {
            "@value": "EXCLUDED_TARGET",
            "#text": "N/A"
         },
         {
            "@value": "DURATION",
            "#text": "00:08:34"
         },
         {
            "@value": "SCAN_HOST",
            "#text": "64.39.103.114 (Scanner 11.9.22-1, Vulnerability Signatures 2.4.896-3)"
         },
         {
            "@value": "NBHOST_ALIVE",
            "#text": "2"
         },
         {
            "@value": "NBHOST_TOTAL",
            "#text": "4"
         },
         {
            "@value": "REPORT_TYPE",
            "#text": "Scheduled"
         },
         {
            "@value": "OPTIONS",
            "#text": "Limited Password Brute Forcing, parallel ML scaling disabled for appliances, Load balancer detection OFF, Vulnerability lists: Option Profile: Qualys Top 20 Options, QIDs: 12260, 38142, 38304, 38560, 38602, 38605, 43051, 91041, 91104, 91107, 91110, 91112, 91133, 91140, 100269, 105578, 110261, 123407, 124169, 124208, Overall Performance: Normal, Hosts to Scan in Parallel - External Scanners: 15, Hosts to Scan in Parallel - Scanner Appliances: 30, Total Processes to Run in Parallel: 10, HTTP Processes to Run in Parallel: 10, Packet (Burst) Delay: Medium, Intensity: Normal"
         },
         {
            "@value": "STATUS",
            "#text": "NOVULNSFOUND"
         }
      ],
      "OPTION_PROFILE": {
         "OPTION_PROFILE_TITLE": {
            "@option_profile_default": "0",
            "#text": "Qualys Top 20 Options"
         }
      }
   },
   "IP": [
      {
         "@value": "118.110.16.132",
         "@name": "somecomputer.domain.com",
         "OS": "Windows 2012"
      },
      {
         "@value": "135.18.2.157",
         "@name": "somecomputer2.domain.com"
      }
   ]
}

@qualys_api.route(f'/{BASE_URL}/report/', methods=['GET', 'POST'])
def get_reports():
    args = request.args
    if request.method == 'GET':
        action = args.get('action')
        return_mock_reports = mock_reports
        if action == 'list':
            return(return_mock_reports)
        else:
            return None
    elif request.method == 'POST':
        action = args.get('action')
        return_data = mock_report_information
        if action == 'delete':
            report_id = args.get('id')
            return_data = return_data.replace("18198", report_id)
            return_data = return_data.replace("Report generation cancelled", "Report deleted")
        if action == 'fetch':
            report_id = args.get('id')
            return_data = return_data.replace("18198", report_id)
            if report_id == "42699":
               return_data=b64decode(mock_scan_report_xml)
            else:
               return_data = b64decode(mock_scan_report)
        if action == 'launch':
            template_id = args.get("template_id")
            return_data = mock_scan_modify
            return_data = return_data.replace("compliance scan", "report")

        return(return_data)


@qualys_api.route(f'/{BASE_URL}/asset/group/', methods=['GET'])
def get_groups():
    if request.method == 'GET':
        args = request.args
        action = args.get('action')
        title = args.get('title', None)
        if action == 'list':
            return_mock_groups = mock_groups
            if title:
                return_mock_groups = return_mock_groups.replace("user_john", title)
            return(return_mock_groups)
        else:
            return None


@qualys_api.route(f'/{BASE_URL}/asset/host/', methods=['GET', 'POST'])
def get_hosts():
    if request.method == 'POST':
        args = request.args
        action = args.get('action')
        if action == 'list':
            return_mock_hosts = mock_hosts
            return(return_mock_hosts)
        else:
            return None


@qualys_api.route(f'/{BASE_URL}/asset/vhost/', methods=['GET', 'POST'])
def get_vhosts():
    args = request.args
    if request.method == 'GET':
        action = args.get('action')
        if action == 'list':
            return_mock_hosts = mock_vhosts
            return(return_mock_hosts)
        else:
            return None
    elif request.method == 'POST':
        action = args.get('action')
        return_data = mock_modify_vhost
        if action == 'create':
            return_data = return_data.replace("$TEXT$", "Successfully created new vhost")
        if action == 'add_fqdn':
            return_data = return_data.replace("$TEXT$", "Successfully added FQDN to vhost")
        if action == 'delete':
            return_data = return_data.replace("$TEXT$", "Successfully deleted vhost")
        if action == 'delete_fqdn':
            return_data = return_data.replace("$TEXT$", "Successfully deleted FQDN from vhost")
        if action == 'update':
            return_data = return_data.replace("$TEXT$", "Successfully updated vhost")
        return(return_data)


@qualys_api.route(f'/{BASE_URL}/asset/ip/', methods=['GET', 'POST'])
def get_ips():
    now = datetime.now()
    if request.method == 'POST':
        args = request.args
        action = args.get('action')
        return_mock_ips = mock_modify_ips
        if action == 'remove':
            return_mock_ips = return_mock_ips.replace("added", "removed")
        if action == 'update':
            return_mock_ips = return_mock_ips.replace("added", "updated")
        return_mock_ips = return_mock_ips.replace("$DATE$", now.isoformat())
        return(return_mock_ips)
    elif request.method == 'GET':
        args = request.args
        action = args.get('action')
        if action == 'list':
            return_ips = mock_ips
        return return_ips

@qualys_api.route(f'/{BASE_URL}/asset/excluded_ip/', methods=['GET', 'POST'])
def get_excluded_ip():
    now = datetime.now()
    if request.method == 'GET':
        args = request.args
        action = args.get('action')
        if action == 'list':
            return_mock_excluded_ips = mock_excluded_ips
            return(return_mock_excluded_ips)
        else:
            return None
    elif request.method == 'POST':
        args = request.args
        action = args.get('action')
        ips = args.get('ips', None)
        return_data = mock_modify_excluded_ips
        return_data = return_data.replace("$DATE$", now.isoformat())
        if action in ['remove', 'remove_all']:
            return_data = return_data.replace("Adding", "Removing all")
            return_data = return_data.replace("Added", "Removed all")
            return_data = return_data.replace("to", "from")
        if ips:
            return_data = return_data.replace("10.0.0.1", ips)
        return return_data


@qualys_api.route(f'/{BASE_URL}/scan/compliance/', methods=['GET', 'POST'])
def get_scan_compliance():
    now = datetime.now()
    args = request.args
    if request.method == 'GET':
        action = args.get('action')
        if action == 'fetch':
            return_data = mock_scan_data
            return(return_data)
        else:
            return None
    elif request.method == 'POST':
        action = args.get('action')
        if action == 'list':
            return_data = mock_scan_list
            return (return_data)
        elif action == 'launch':
            return_data = mock_scan_compliance_launch
            return (return_data)
        elif action in ['cancel', 'delete', 'pause', 'resume']:
            scan_ref = args.get('scan_ref')
            return_data = mock_scan_modify
            if action == 'cancel':
                return_data = return_data.replace("New compliance scan launched", "Scan successfully cancelled")
            elif action == 'delete':
                return_data = return_data.replace("New compliance scan launched", "Scan successfully deleted")
            elif action == 'pause':
                return_data = return_data.replace("New compliance scan launched", "Scan successfully paused")
            elif action == 'resume':
                return_data = return_data.replace("New compliance scan launched", "Scan successfully resumed")
            return_data = return_data.replace("compliance/1473976536.18198", scan_ref)
            return (return_data)


@qualys_api.route(f'/{BASE_URL}/scan/', methods=['GET', 'POST'])
def get_scan():
    now = datetime.now()
    args = request.args
    if request.method == 'POST':
        action = args.get('action')
        if action in ['cancel', 'delete', 'pause', 'resume']:
            scan_ref = args.get('scan_ref')
            return_data = mock_scan_modify
            if action == 'cancel':
                return_data = return_data.replace("New compliance scan launched", "Scan successfully cancelled")
            elif action == 'delete':
                return_data = return_data.replace("New compliance scan launched", "Scan successfully deleted")
            elif action == 'pause':
                return_data = return_data.replace("New compliance scan launched", "Scan successfully paused")
            elif action == 'resume':
                return_data = return_data.replace("New compliance scan launched", "Scan successfully resumed")
            return_data = return_data.replace("compliance/1473976536.18198", scan_ref)
            return (return_data)
        elif action == 'launch':
            return_data = mock_scan_vm_launch
            return (return_data)
    elif request.method == 'GET':
        action = args.get('action')
        if action == 'fetch':
            return_data = mock_scan_report_json
            return json.dumps(return_data)
        elif action == 'list':
            return_data = mock_vm_scan_list
            return (return_data)


@qualys_api.route(f'/qualys/msp/report_template_list.php/', methods=['GET'])
def get_report_templates():
    now = datetime.now()
    args = request.args
    if request.method == 'GET':
        action = args.get('action')
        return_data = mock_report_templates
        return(return_data)


@qualys_api.route(f'/{BASE_URL}/scan/scap/', methods=['GET'])
def get_scap_scans():
    now = datetime.now()
    args = request.args
    if request.method == 'GET':
        action = args.get('action')
        return_data = mock_scap_scan_list
        return(return_data)


@qualys_api.route(f'/{BASE_URL}/schedule/scan/', methods=['GET'])
def get_schedule_scans():
    now = datetime.now()
    args = request.args
    if request.method == 'GET':
        action = args.get('action')
        if action == 'list':
            return_data = mock_scheduled_scans
        return(return_data)


@qualys_api.route(f'/{BASE_URL}/schedule/report/', methods=['GET', 'POST'])
def get_schedule_report():
    now = datetime.now()
    args = request.args
    if request.method == 'POST':
        action = args.get('action')
        if action == 'launch_now':
            return_data = mock_report_information
            return_data = return_data.replace("Report generation cancelled", "New report launched")
            return(return_data)
    elif request.method == 'GET':
        action = args.get('action')
        if action == 'list':
            return_data = mock_scheduled_reports
            return(return_data)
        else:
            return None


@qualys_api.route(f'/{BASE_URL}/report/scorecard/', methods=['POST'])
def report_scorecard():
    now = datetime.now()
    args = request.args
    if request.method == 'POST':
        action = args.get('action')
        if action == 'launch':
            return_data = mock_scan_compliance_launch
            return_data = return_data.replace("compliance scan", "report scorecard")
            return(return_data)


@qualys_api.route(f'/{BASE_URL}/knowledge_base/vuln/', methods=['POST'])
def knowledgebase_vuln():
    now = datetime.now()
    args = request.args
    if request.method == 'POST':
        action = args.get('action')
        if action == 'list':
            return_data = mock_knowledge_base_vulns
            return(return_data)