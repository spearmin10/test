from flask import Blueprint, request, make_response, Response, jsonify
from flask import Flask
import json
import re
import logging
from random import randint
from datetime import datetime
'''
Create issue command will work only if the ProjectKey argument is 'ED'(case-insensitive)
'''
BASE_URL = '/rest/api/'.strip('/')
INTEGRATION = 'jira_api'

jira_api = Blueprint(f'{INTEGRATION}', __name__)
logger = logging.getLogger(__name__)
now = datetime.now()
# Oauth Authentication
@jira_api.route('/rest/api/latest/myself', methods=['GET'])
def login():
    
    resp = {
            "self": "https://demistodev.atlassian.net/rest/api/2/user?accountId=557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76",
            "accountId": "557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76",
            "emailAddress": "admin@demistodev.com",
            "avatarUrls": {
                "48x48": "https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=48&s=48",
                "24x24": "https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=24&s=24",
                "16x16": "https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=16&s=16",
                "32x32": "https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=32&s=32"
            },
            "displayName": "Mia Krystof",
            "active": True,
            "timeZone": "Asia/Jerusalem",
            "locale": "en_US",
            "groups": {
                "size": 3,
                "items": []
            },
            "applicationRoles": {
                "size": 1,
                "items": []
            },
            "expand": "groups,applicationRoles"
            }
    return resp

#Get Issue
@jira_api.route(f'/{BASE_URL}/latest/issue/<id>', methods=['GET'])
def get_issue(id):
    return {
            "id": id,
            "self": "https://your-domain.atlassian.net/rest/api/2/issue/" + id,
            "key": "ED-1",
            "fields": {
                "watcher": {
                "self": "https://your-domain.atlassian.net/rest/api/2/issue/EX-1/watchers",
                "isWatching": False,
                "watchCount": 1,
                "watchers": [
                    {
                    "self": "https://your-domain.atlassian.net/rest/api/2/user?accountId=5b10a2844c20165700ede21g",
                    "accountId": "5b10a2844c20165700ede21g",
                    "displayName": "Mia Krystof",
                    "active": False
                    }
                ]
                },
                "status": {
              "self": "https://your-domain.atlassian.net/rest/api/2/statuscategory/1",
              "id": 1,
              "key": "in-flight",
              "colorName": "yellow",
              "name": "In Progress"
            },

              "summary": "A task that needs to be done",
              "priority": {
              "self": "https://your-domain.atlassian.net/rest/api/2/priority/5",
              "statusColor": "#cfcfcf",
              "description": "little impact.",
              "iconUrl": "https://your-domain.atlassian.net/images/icons/priorities/trivial.png",
              "name": "Medium",
              "id": "2"
            },
            "issuetype": {
              "self": "https://your-domain.atlassian.net/rest/api/2/issueType/1",
              "id": "1",
              "description": "A problem with the software.",
              "iconUrl": "https://your-domain.atlassian.net/secure/viewavatar?size=xsmall&avatarId=10316&avatarType=issuetype\",",
              "name": "Bug",
              "subtask": False,
              "avatarId": 10002,
              "entityId": "9d7dd6f7-e8b6-4247-954b-7b2c9b2a5ba2",
            },
              "duedate": "2020-04-11T00:00:00.000Z",
              "created": now,
              "assignee": {
              "self": "https://your-domain.atlassian.net/rest/api/2/user?accountId=5b10a2844c20165700ede21g",
              "key": "",
              "accountId": "5b10a2844c20165700ede21g",
              "displayName": "Mia Krystof",
              "emailAddress": "mkrystof@jira.com"
              },
              "reporter": {
              "self": "https://your-domain.atlassian.net/rest/api/2/user?accountId=5b10a2844c20165700ede21g",
              "key": "",
              "accountId": "5b10a2844c20165700ede21g",
              "displayName": "Mia Krystof",
              "emailAddress": "mkrystof@jira.com"
              },
              "creator": {
              "displayName": "David Gold",
              "emailAddress": "Dgoldf@jira.com"
              },
                "labels": [
              "bugfix",
              "blitz_test"
              ],
        
              "sub-tasks": [
              {
                "id": id,
                "type": {
                "id": id,
                "name": "",
                "inward": "Parent",
                "outward": "Sub-task"
                },
                "outwardIssue": {
                "id": id,
                "key": "ED-2",
                "self": "https://your-domain.atlassian.net/rest/api/2/issue/ED-2",
                "fields": {
                    "status": {
                    "iconUrl": "https://your-domain.atlassian.net/images/icons/statuses/open.png",
                    "name": "Open"
                    }
                }
                }
            }
            ],
            "description": "Main order flow broken",
            "project": {
            "self": "https://your-domain.atlassian.net/rest/api/2/project/EX",
            "id": id,
            "key": "EX",
            "name": "Example",
            "avatarUrls": {
                "48x48": "https://your-domain.atlassian.net/secure/projectavatar?size=large&pid=10000",
                "24x24": "https://your-domain.atlassian.net/secure/projectavatar?size=small&pid=10000",
                "16x16": "https://your-domain.atlassian.net/secure/projectavatar?size=xsmall&pid=10000",
                "32x32": "https://your-domain.atlassian.net/secure/projectavatar?size=medium&pid=10000"
            },
            "projectCategory": {
                "self": "https://your-domain.atlassian.net/rest/api/2/projectCategory/" + id,
                "id": id,
                "name": "FIRST",
                "description": "First Project Category"
            },
            "simplified": False,
            "style": "classic",
            "insight": {
                "totalIssueCount": 100,
                "lastIssueUpdateTime": "2020-05-14T03:51:31.283+0000"
            }
            },
            "comment": [
            {
                "self": "https://your-domain.atlassian.net/rest/api/2/issue/10010/comment/" + id,
                "id": id,
                "author": {
                "self": "https://your-domain.atlassian.net/rest/api/2/user?accountId=5b10a2844c20165700ede21g",
                "accountId": "5b10a2844c20165700ede21g",
                "displayName": "Mia Krystof",
                "active": False
                },
                "body": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque eget venenatis elit. Duis eu justo eget augue iaculis fermentum. Sed semper quam laoreet nisi egestas at posuere augue semper.",
                "updateAuthor": {
                "self": "https://your-domain.atlassian.net/rest/api/2/user?accountId=5b10a2844c20165700ede21g",
                "accountId": "5b10a2844c20165700ede21g",
                "displayName": "Mia Krystof",
                "active": False
                },
                "created": "2020-05-14T03:51:35.721+0000",
                "updated": "2020-05-14T03:51:35.721+0000",
                "visibility": {
                "type": "role",
                "value": "Administrators"
                }
            }
            ],
            "issuelinks": [
            {
                "id": "10001",
                "type": {
                "id": "10000",
                "name": "Dependent",
                "inward": "depends on",
                "outward": "is depended by"
                },
                "outwardIssue": {
                "id": "10004L",
                "key": "PR-2",
                "self": "https://your-domain.atlassian.net/rest/api/2/issue/PR-2",
                "fields": {
                    "status": {
                    "iconUrl": "https://your-domain.atlassian.net/images/icons/statuses/open.png",
                    "name": "Open"
                    }
                }
                }
            },
            {
                "id": "10002",
                "type": {
                "id": "10000",
                "name": "Dependent",
                "inward": "depends on",
                "outward": "is depended by"
                },
                "inwardIssue": {
                "id": "10004",
                "key": "PR-3",
                "self": "https://your-domain.atlassian.net/rest/api/2/issue/PR-3",
                "fields": {
                    "status": {
                    "iconUrl": "https://your-domain.atlassian.net/images/icons/statuses/open.png",
                    "name": "Open"
                    }
                }
                }
            }
            ],
                "worklog": [
                {
                "self": "https://your-domain.atlassian.net/rest/api/2/issue/10010/worklog/" + id,
                "author": {
                "self": "https://your-domain.atlassian.net/rest/api/2/user?accountId=5b10a2844c20165700ede21g",
                "accountId": "5b10a2844c20165700ede21g",
                "displayName": "Mia Krystof",
                "active": False
                },
                "updateAuthor": {
                "self": "https://your-domain.atlassian.net/rest/api/2/user?accountId=5b10a2844c20165700ede21g",
                "accountId": "5b10a2844c20165700ede21g",
                "displayName": "Mia Krystof",
                "active": False
                },
                "comment": "I did some work here.",
                "updated": "2020-05-14T03:51:35.957+0000",
                "visibility": {
                "type": "group",
                "value": "jira-developers"
                },
                "started": "2020-05-14T03:51:35.957+0000",
                "timeSpent": "3h 20m",
                "timeSpentSeconds": 12000,
                "id": "100028",
                "issueId": "10002"
                }
                ],
                "updated": 1,
                "timetracking": {
                "originalEstimate": "10m",
                "remainingEstimate": "3m",
                "timeSpent": "6m",
                "originalEstimateSeconds": 600,
                "remainingEstimateSeconds": 200,
                "timeSpentSeconds": 400
                }
            }
            }   


# Create Issue
@jira_api.route(f'/{BASE_URL}/latest/issue', methods=['POST'])
def create_issue():
    request_data = request.get_json()
    projectKey = request_data['fields']['project']['key']
    issueTypeName = request_data['fields']['issuetype']
    name = ''
    if issueTypeName:
        name = issueTypeName['name']
    randomint = randint(10000, 19999)
    return {
                  "id": randomint,
                  "key": projectKey + "-26",
                  "self": "https://your-domain.atlassian.net/rest/api/2/issue/"+str(randomint)
                  }

#Create Issue Meta
@jira_api.route(f'/{BASE_URL}/latest/issue/createmeta', methods=['GET'])
def create_issue_meta():
    return {
                  "projects": [
                    {
                      "self": "https://your-domain.atlassian.net/rest/api/2/project/ED",
                      "id": "10000",
                      "key": "ED",
                      "name": "Edison Project",
                      "avatarUrls": {
                        "16x16": "https://your-domain.atlassian.net/secure/projectavatar?size=xsmall&pid=10000&avatarId=10011",
                        "24x24": "https://your-domain.atlassian.net/secure/projectavatar?size=small&pid=10000&avatarId=10011",
                        "32x32": "https://your-domain.atlassian.net/secure/projectavatar?size=medium&pid=10000&avatarId=10011",
                        "48x48": "https://your-domain.atlassian.net/secure/projectavatar?pid=10000&avatarId=10011"
                      },
                      "issuetypes": [
                    {
                      "self": "https://your-domain.atlassian.net/rest/api/2/issueType/1",
                      "id": "1",
                      "description": "An error in the code",
                      "iconUrl": "https://your-domain.atlassian.net/images/icons/issuetypes/bug.png",
                      "name": "Bug",
                      "subtask": False,
                      "fields": {
                        "issuetype": {
                          "required": True,
                          "name": "Issue Type",
                          "key": "issuetype",
                          "hasDefaultValue": False,
                          "operations": [
                            "set"
                          ]
                        }
                      }
                    }
                  ]
                }
              ]
            }


#Edit Issue
@jira_api.route(f'/{BASE_URL}/latest/issue/<id>/', methods=['GET', 'PUT'])
def edit_issue(id):
    if request.method == 'PUT' or request.method == 'GET' :
            request_data = request.get_json()
            if 'summary' in request_data['fields']:
              summary = request_data['fields']['summary']
            else:
              summary="something"

            return {
                    "id": id,
                    "self": "https://your-domain.atlassian.net/rest/api/2/issue/" + id,
                    "key": "ED-1",
                    "summary": summary,
                    "fields": {
                        "watcher": {
                        "self": "https://your-domain.atlassian.net/rest/api/2/issue/EX-1/watchers",
                        "isWatching": False,
                        "watchCount": 1,
                        "watchers": [
                            {
                            "self": "https://your-domain.atlassian.net/rest/api/2/user?accountId=5b10a2844c20165700ede21g",
                            "accountId": "5b10a2844c20165700ede21g",
                            "displayName": "Mia Krystof",
                            "active": False
                                }
                            ]
                            },
                            "status": {
                          "self": "https://your-domain.atlassian.net/rest/api/2/statuscategory/1",
                          "id": 1,
                          "key": "in-flight",
                          "colorName": "yellow",
                          "name": "In Progress"
                        },
                        "summary": summary,
                        "priority": {
                        "self": "https://your-domain.atlassian.net/rest/api/2/priority/5",
                        "statusColor": "#cfcfcf",
                        "description": "little impact.",
                        "iconUrl": "https://your-domain.atlassian.net/images/icons/priorities/trivial.png",
                        "name": "Medium",
                        "id": "2"
                      },
                      "issuetype": {
                        "self": "https://your-domain.atlassian.net/rest/api/2/issueType/1",
                        "id": "1",
                        "description": "A problem with the software.",
                        "iconUrl": "https://your-domain.atlassian.net/secure/viewavatar?size=xsmall&avatarId=10316&avatarType=issuetype\",",
                        "name": "Bug",
                        "subtask": False,
                        "avatarId": 10002,
                        "entityId": "9d7dd6f7-e8b6-4247-954b-7b2c9b2a5ba2",
                      },
                        "duedate": "2020-04-11T00:00:00.000Z",
                        "created": now,
                        "assignee": {
                        "self": "https://your-domain.atlassian.net/rest/api/2/user?accountId=5b10a2844c20165700ede21g",
                        "key": "",
                        "accountId": "5b10a2844c20165700ede21g",
                        "displayName": "Mia Krystof",
                        "emailAddress": "mkrystof@jira.com"
                        },
                        "reporter": {
                        "self": "https://your-domain.atlassian.net/rest/api/2/user?accountId=5b10a2844c20165700ede21g",
                        "key": "",
                        "accountId": "5b10a2844c20165700ede21g",
                        "displayName": "Mia Krystof",
                        "emailAddress": "mkrystof@jira.com"
                        },
                        "creator": {
                        "displayName": "David Gold",
                        "emailAddress": "Dgoldf@jira.com"
                        },
                        "labels": [
                          "bugfix",
                          "blitz_test"
                        ],
        
                        "sub-tasks": [
                        {
                        "id": id,
                        "type": {
                        "id": id,
                        "name": "",
                        "inward": "Parent",
                        "outward": "Sub-task"
                        },
                        "outwardIssue": {
                        "id": id,
                        "key": "ED-2",
                        "self": "https://your-domain.atlassian.net/rest/api/2/issue/ED-2",
                        "fields": {
                            "status": {
                            "iconUrl": "https://your-domain.atlassian.net/images/icons/statuses/open.png",
                            "name": "Open"
                            }
                        }
                        }
                    }
                    ],
                        "description": "Main order flow broken",
                        "project": {
                        "self": "https://your-domain.atlassian.net/rest/api/2/project/EX",
                        "id": id,
                        "key": "EX",
                        "name": "Example",
                        "avatarUrls": {
                            "48x48": "https://your-domain.atlassian.net/secure/projectavatar?size=large&pid=10000",
                            "24x24": "https://your-domain.atlassian.net/secure/projectavatar?size=small&pid=10000",
                            "16x16": "https://your-domain.atlassian.net/secure/projectavatar?size=xsmall&pid=10000",
                            "32x32": "https://your-domain.atlassian.net/secure/projectavatar?size=medium&pid=10000"
                        },
                        "projectCategory": {
                            "self": "https://your-domain.atlassian.net/rest/api/2/projectCategory/" + id,
                            "id": id,
                            "name": "FIRST",
                            "description": "First Project Category"
                        },
                        "simplified": False,
                        "style": "classic",
                        "insight": {
                            "totalIssueCount": 100,
                            "lastIssueUpdateTime": "2020-05-14T03:51:31.283+0000"
                        }
                        },
                        "comment": [
                        {
                            "self": "https://your-domain.atlassian.net/rest/api/2/issue/10010/comment/" + id,
                            "id": id,
                            "author": {
                            "self": "https://your-domain.atlassian.net/rest/api/2/user?accountId=5b10a2844c20165700ede21g",
                            "accountId": "5b10a2844c20165700ede21g",
                            "displayName": "Mia Krystof",
                            "active": False
                            },
                            "body": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque eget venenatis elit. Duis eu justo eget augue iaculis fermentum. Sed semper quam laoreet nisi egestas at posuere augue semper.",
                            "updateAuthor": {
                            "self": "https://your-domain.atlassian.net/rest/api/2/user?accountId=5b10a2844c20165700ede21g",
                            "accountId": "5b10a2844c20165700ede21g",
                            "displayName": "Mia Krystof",
                            "active": False
                            },
                            "created": "2020-05-14T03:51:35.721+0000",
                            "updated": "2020-05-14T03:51:35.721+0000",
                            "visibility": {
                            "type": "role",
                            "value": "Administrators"
                            }
                        }
                        ],
                        "issuelinks": [
                        {
                            "id": "10001",
                            "type": {
                            "id": "10000",
                            "name": "Dependent",
                            "inward": "depends on",
                            "outward": "is depended by"
                            },
                            "outwardIssue": {
                            "id": "10004L",
                            "key": "PR-2",
                            "self": "https://your-domain.atlassian.net/rest/api/2/issue/PR-2",
                            "fields": {
                                "status": {
                                "iconUrl": "https://your-domain.atlassian.net/images/icons/statuses/open.png",
                                "name": "Open"
                                }
                            }
                            }
                        },
                        {
                            "id": "10002",
                            "type": {
                            "id": "10000",
                            "name": "Dependent",
                            "inward": "depends on",
                            "outward": "is depended by"
                            },
                            "inwardIssue": {
                            "id": "10004",
                            "key": "PR-3",
                            "self": "https://your-domain.atlassian.net/rest/api/2/issue/PR-3",
                            "fields": {
                                "status": {
                                "iconUrl": "https://your-domain.atlassian.net/images/icons/statuses/open.png",
                                "name": "Open"
                                }
                            }
                            }
                        }
                        ],
                        "worklog": [
                        {
                            "self": "https://your-domain.atlassian.net/rest/api/2/issue/10010/worklog/" + id,
                            "author": {
                            "self": "https://your-domain.atlassian.net/rest/api/2/user?accountId=5b10a2844c20165700ede21g",
                            "accountId": "5b10a2844c20165700ede21g",
                            "displayName": "Mia Krystof",
                            "active": False
                            },
                            "updateAuthor": {
                            "self": "https://your-domain.atlassian.net/rest/api/2/user?accountId=5b10a2844c20165700ede21g",
                            "accountId": "5b10a2844c20165700ede21g",
                            "displayName": "Mia Krystof",
                            "active": False
                            },
                            "comment": "I did some work here.",
                            "updated": "2020-05-14T03:51:35.957+0000",
                            "visibility": {
                            "type": "group",
                            "value": "jira-developers"
                            },
                            "started": "2020-05-14T03:51:35.957+0000",
                            "timeSpent": "3h 20m",
                            "timeSpentSeconds": 12000,
                            "id": "100028",
                            "issueId": "10002"
                        }
                        ],
                        "updated": 1,
                        "timetracking": {
                        "originalEstimate": "10m",
                        "remainingEstimate": "3m",
                        "timeSpent": "6m",
                        "originalEstimateSeconds": 600,
                        "remainingEstimateSeconds": 200,
                        "timeSpentSeconds": 400
                        }
                    }
                    }           

#Delete Issue
@jira_api.route(f'/{BASE_URL}/latest/issue/<id>', methods=['DELETE'])
def delete_issue(id):
    
    data = {'result': 'Issue deleted successfully.'}
    return jsonify(data), 204      


#GET Comment
@jira_api.route(f'/{BASE_URL}/latest/issue/<id>/comment', methods=['GET'])
def get_comment(id):
    return {
            "startAt": 0,
            "maxResults": 1,
            "total": 1,
            "comments": [
            {
              "self": "https://your-domain.atlassian.net/rest/api/2/issue/"+id+"/comment/"+id,
              "id": id,
              "author": {
                "self": "https://your-domain.atlassian.net/rest/api/2/user?accountId=5b10a2844c20165700ede21g",
                "accountId": "5b10a2844c20165700ede21g",
                "displayName": "Mia Krystof",
                "active": False
              },
              "body": "Please see the details for the ticket.",
              "updateAuthor": {
                "self": "https://your-domain.atlassian.net/rest/api/2/user?accountId=5b10a2844c20165700ede21g",
                "accountId": "5b10a2844c20165700ede21g",
                "displayName": "Mia Krystof",
                "name": "David Gold",
                "active": False
              },
              "created": "2020-04-14T03:51:35.721+0000",
              "updated": "2020-05-14T03:51:35.721+0000",
              "visibility": {
                "type": "role",
                "value": "Administrators"
              }
            }
          ]
        }


#ADD Comment
@jira_api.route(f'/{BASE_URL}/latest/issue/<id>/comment', methods=['POST'])
def add_comment(id):
    request_data = request.get_json()
    comment = request_data['body']
    return {
            "self": "https://your-domain.atlassian.net/rest/api/2/issue/"+id+"/comment/"+id,
            "id": id,
            "key": "ED-1",
            "author": {
                "self": "https://your-domain.atlassian.net/rest/api/2/user?accountId=5b10a2844c20165700ede21g",
                "accountId": "5b10a2844c20165700ede21g",
                "displayName": "Mia Krystof",
                "active": False
            },
            "body": comment,
            "updateAuthor": {
                "self": "https://your-domain.atlassian.net/rest/api/2/user?accountId=5b10a2844c20165700ede21g",
                "accountId": "5b10a2844c20165700ede21g",
                "displayName": "Mia Krystof",
                "key": "ED-1",
                "active": False
            },
            "created": "2020-05-14T03:51:35.721+0000",
            "updated": "2020-05-14T03:51:35.721+0000",
            "visibility": {
                "type": "role",
                "value": "Administrators"
            }
            }


#GET ID Offset
@jira_api.route(f'/{BASE_URL}/latest/search/', methods=['GET'])
def get_id_offset():
    
    return {
            "expand": "names,schema",
            "issues": [{
              "expand": "operations,versionedRepresentations,editmeta,changelog,renderedFields",
              "fields": {
                "aggregateprogress": {
                  "progress": 0,
                  "total": 0
                },
                "aggregatetimeestimate": None,
                "aggregatetimeoriginalestimate": None,
                "aggregatetimespent": None,
                "assignee":{
                  "displayName": "Mia Krystof",
                  "emailAddress": "mkrystof@jira.com"
                },
                "components": [],
                "description": "Please fix this bug.",
                "created": "2019-12-11T20:02:44.679+0200",
                "duedate": "2020-04-11T00:00:00.000Z",
                 "labels": [
                    "bugfix",
                    "blitz_test"
                          ],
                "creator": {
                  "accountId": "557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76",
                  "accountType": "atlassian",
                  "active": True,
                  "avatarUrls": {
                    "16x16": "https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=16\u0026s=16",
                    "24x24": "https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=24\u0026s=24",
                    "32x32": "https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=32\u0026s=32",
                    "48x48": "https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=48\u0026s=48"
                  },
                  "displayName": "Mia Krystof",
                  "emailAddress": "mkrystof@jira.com",
                  "self": "https://demistodev.atlassian.net/rest/api/2/user?accountId=557058%3Afb80ffc0-b374-4260-99a0-ea0c140a4e76",
                  "timeZone": "Asia/Jerusalem"
                },
                "customfield_10000": "{}",
                "customfield_10001": None,
                "customfield_10002": None,
                "customfield_10003": None,
                "customfield_10004": None,
                "customfield_10005": None,
                "customfield_10006": None,
                "customfield_10007": None,
                "customfield_10008": None,
                "customfield_10009": None,
                "customfield_10013": None,
                "customfield_10014": None,
                "customfield_10015": {
                  "hasEpicLinkFieldDependency": False,
                  "nonEditableReason": {
                    "message": "The Parent Link is only available to Jira Premium users.",
                    "reason": "PLUGIN_LICENSE_ERROR"
                  },
                  "showField": False
                },
                "customfield_10016": None,
                "customfield_10017": None,
                "customfield_10018": None,
                "customfield_10019": "0|i0001j:",
                "customfield_10022": None,
                "customfield_10023": [],
                "customfield_10024": None,
                "customfield_10025": None,
                "customfield_10027": None,
                "customfield_10029": None,
                "customfield_10031": None,
                "customfield_10032": None,
                "customfield_10033": None,
                "customfield_10034": None,
                "customfield_10035": None,
                "customfield_10036": None,
                "customfield_10037": None,
                "customfield_10038": None,
                "customfield_10039": None,
                "customfield_10040": None,
                "customfield_10041": None,
                "description": None,
                "duedate": None,
                "environment": None,
                "fixVersions": [],
                "issuelinks": [],
                "issuetype": {
                  "avatarId": 10318,
                  "description": "A task that needs to be done.",
                  "iconUrl": "https://demistodev.atlassian.net/secure/viewavatar?size=medium\u0026avatarId=10318\u0026avatarType=issuetype",
                  "id": "10001",
                  "name": "Task",
                  "self": "https://demistodev.atlassian.net/rest/api/2/issuetype/10001",
                  "subtask": False
                },
                 "labels": [
                      "bugfix",
                      "blitz_test"
                    ],
                "lastViewed": None,
                "priority": {
                  "iconUrl": "https://demistodev.atlassian.net/images/icons/priorities/medium.svg",
                  "id": "3",
                  "name": "Medium",
                  "self": "https://demistodev.atlassian.net/rest/api/2/priority/3"
                },
                "progress": {
                  "progress": 0,
                  "total": 0
                },
                "description" : "First Project Category",
                "duedate": "2020-04-11T00:00:00.000Z",
                "project": {
                  "avatarUrls": {
                    "16x16": "https://demistodev.atlassian.net/secure/projectavatar?size=xsmall\u0026s=xsmall\u0026avatarId=10324",
                    "24x24": "https://demistodev.atlassian.net/secure/projectavatar?size=small\u0026s=small\u0026avatarId=10324",
                    "32x32": "https://demistodev.atlassian.net/secure/projectavatar?size=medium\u0026s=medium\u0026avatarId=10324",
                    "48x48": "https://demistodev.atlassian.net/secure/projectavatar?avatarId=10324"
                  },
                  "id": "10000",
                  "key": "DEM",
                  "name": "Xmocky",
                  "projectTypeKey": "software",
                  "self": "https://demistodev.atlassian.net/rest/api/2/project/10000",
                  "simplified": False
                },
                "reporter": {
                  "accountId": "557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76",
                  "accountType": "atlassian",
                  "active": True,
                  "avatarUrls": {
                    "16x16": "https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=16\u0026s=16",
                    "24x24": "https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=24\u0026s=24",
                    "32x32": "https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=32\u0026s=32",
                    "48x48": "https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=48\u0026s=48"
                  },
                  "displayName": "Mia Krystof",
                  "emailAddress": "mkrystof@jira.com",
                  "self": "https://demistodev.atlassian.net/rest/api/2/user?accountId=557058%3Afb80ffc0-b374-4260-99a0-ea0c140a4e76",
                  "timeZone": "Asia/Jerusalem"
                },
                "resolution": None,
                "resolutiondate": None,
                "security": None,
                "status": {
                  "description": "",
                  "iconUrl": "https://demistodev.atlassian.net/images/icons/status_generic.gif",
                  "id": "10000",
                  "name": "To Do",
                  "self": "https://demistodev.atlassian.net/rest/api/2/status/10000",
                  "statusCategory": {
                    "colorName": "blue-gray",
                    "id": 2,
                    "key": "new",
                    "name": "To Do",
                    "self": "https://demistodev.atlassian.net/rest/api/2/statuscategory/2"
                  }
                },
                "statuscategorychangedate": "2018-12-11T20:02:44.679+0200",
                "subtasks": [],
                "summary": "Please find the bugs related to this issue.",
                "timeestimate": None,
                "timeoriginalestimate": None,
                "timespent": None,
                "updated": "2018-12-11T20:02:44.679+0200",
                "versions": [],
                "votes": {
                  "hasVoted": False,
                  "self": "https://demistodev.atlassian.net/rest/api/2/issue/DEM-158/votes",
                  "votes": 0
                },
                "watches": {
                  "isWatching": True,
                  "self": "https://demistodev.atlassian.net/rest/api/2/issue/DEM-158/watchers",
                  "watchCount": 1
                },
                "workratio": -1
              },
              "id": "10161",
              "key": "DEM-158",
              "self": "https://demistodev.atlassian.net/rest/api/latest/issue/10161"
            }],
            "maxResults": 1,
            "startAt": 0,
            "total": 1047
          }
    


#Add Link
@jira_api.route(f'/{BASE_URL}/latest/issue/<id>/remotelink', methods=['POST'])
def add_link(id):
    return {
            "id": id,
            "self": "https://your-domain.atlassian.net/rest/api/issue/ED-1/remotelink/"+id
            }  


#Issue Query
@jira_api.route(f'/{BASE_URL}/latest/search', methods=['POST'])
def issue_query():
    return {
              "expand": "names,schema",
              "startAt": 0,
              "maxResults": 50,
              "total": 1,
              "issues": [
            {
              "expand": "",
              "id": "10002",
              "self": "https://your-domain.atlassian.net/rest/api/2/issue/10002",
              "key": "ED-1",
              "fields": {
                "watcher": {
                  "self": "https://your-domain.atlassian.net/rest/api/2/issue/EX-1/watchers",
                  "isWatching": False,
                  "watchCount": 1,
                  "watchers": [
                    {
                      "self": "https://your-domain.atlassian.net/rest/api/2/user?accountId=5b10a2844c20165700ede21g",
                      "accountId": "5b10a2844c20165700ede21g",
                      "displayName": "Mia Krystof",
                      "active": False
                    }
                  ]
                },
                "attachment": [
                  {
                    "id": 10001,
                    "self": "https://your-domain.atlassian.net/rest/api/2/attachments/10001",
                    "filename": "debuglog.txt",
                    "author": {
                      "self": "https://your-domain.atlassian.net/rest/api/2/user?accountId=5b10a2844c20165700ede21g",
                      "key": "",
                      "accountId": "5b10a2844c20165700ede21g",
                      "name": "",
                      "avatarUrls": {
                        "48x48": "https://avatar-management--avatars.server-location.prod.public.atl-paas.net/initials/MK-5.png?size=48&s=48",
                        "24x24": "https://avatar-management--avatars.server-location.prod.public.atl-paas.net/initials/MK-5.png?size=24&s=24",
                        "16x16": "https://avatar-management--avatars.server-location.prod.public.atl-paas.net/initials/MK-5.png?size=16&s=16",
                        "32x32": "https://avatar-management--avatars.server-location.prod.public.atl-paas.net/initials/MK-5.png?size=32&s=32"
                      },
                      "displayName": "Mia Krystof",
                      "active": False
                    },
                    "created": "2020-05-14T03:51:36.823+0000",
                    "size": 2460,
                    "mimeType": "text/plain",
                    "content": "https://your-domain.atlassian.net/jira/secure/attachments/10001/debuglog.txt"
                  }
                ],
                  "sub-tasks": [
                    {
                      "id": "10000",
                      "type": {
                        "id": "10000",
                        "name": "",
                        "inward": "Parent",
                        "outward": "Sub-task"
                      },
                      "outwardIssue": {
                        "id": "10003",
                        "key": "ED-2",
                        "self": "https://your-domain.atlassian.net/rest/api/2/issue/ED-2",
                        "fields": {
                          "status": {
                            "iconUrl": "https://your-domain.atlassian.net/images/icons/statuses/open.png",
                            "name": "Open"
                          }
                        }
                      }
                    }
                  ],
              "description": "Main order flow broken",
              "project": {
                "self": "https://your-domain.atlassian.net/rest/api/2/project/EX",
                "id": "10000",
                "key": "EX",
                "name": "Example",
                "avatarUrls": {
                  "48x48": "https://your-domain.atlassian.net/secure/projectavatar?size=large&pid=10000",
                  "24x24": "https://your-domain.atlassian.net/secure/projectavatar?size=small&pid=10000",
                  "16x16": "https://your-domain.atlassian.net/secure/projectavatar?size=xsmall&pid=10000",
                  "32x32": "https://your-domain.atlassian.net/secure/projectavatar?size=medium&pid=10000"
                },
                "projectCategory": {
                  "self": "https://your-domain.atlassian.net/rest/api/2/projectCategory/10000",
                  "id": "10000",
                  "name": "FIRST",
                  "description": "First Project Category"
                },
                "simplified": False,
                "style": "classic",
                "insight": {
                  "totalIssueCount": 100,
                  "lastIssueUpdateTime": "2020-05-14T03:51:31.283+0000"
                }
              },
              "comment": [
                {
                  "self": "https://your-domain.atlassian.net/rest/api/2/issue/10010/comment/10000",
                  "id": "10000",
                  "author": {
                    "self": "https://your-domain.atlassian.net/rest/api/2/user?accountId=5b10a2844c20165700ede21g",
                    "accountId": "5b10a2844c20165700ede21g",
                    "displayName": "Mia Krystof",
                    "active": False
                  },
                  "body": "Xmocky Test",
                  "updateAuthor": {
                    "self": "https://your-domain.atlassian.net/rest/api/2/user?accountId=5b10a2844c20165700ede21g",
                    "accountId": "5b10a2844c20165700ede21g",
                    "displayName": "Mia Krystof",
                    "active": False
                  },
                  "created": "2020-05-14T03:51:35.721+0000",
                  "updated": "2020-05-14T03:51:35.721+0000",
                  "visibility": {
                    "type": "role",
                    "value": "Administrators"
                  }
                }
              ],
              "issuelinks": [
                {
                  "id": "10001",
                  "type": {
                    "id": "10000",
                    "name": "Dependent",
                    "inward": "depends on",
                    "outward": "is depended by"
                  },
                  "outwardIssue": {
                    "id": "10004L",
                    "key": "PR-2",
                    "self": "https://your-domain.atlassian.net/rest/api/2/issue/PR-2",
                    "fields": {
                      "status": {
                        "iconUrl": "https://your-domain.atlassian.net/images/icons/statuses/open.png",
                        "name": "Open"
                      }
                    }
                  }
                },
                {
                  "id": "10002",
                  "type": {
                    "id": "10000",
                    "name": "Dependent",
                    "inward": "depends on",
                    "outward": "is depended by"
                  },
                  "inwardIssue": {
                    "id": "10004",
                    "key": "PR-3",
                    "self": "https://your-domain.atlassian.net/rest/api/2/issue/PR-3",
                    "fields": {
                      "status": {
                        "iconUrl": "https://your-domain.atlassian.net/images/icons/statuses/open.png",
                        "name": "Open"
                      }
                    }
                  }
                }
              ],
              "worklog": [
                {
                  "self": "https://your-domain.atlassian.net/rest/api/2/issue/10010/worklog/10000",
                  "author": {
                    "self": "https://your-domain.atlassian.net/rest/api/2/user?accountId=5b10a2844c20165700ede21g",
                    "accountId": "5b10a2844c20165700ede21g",
                    "displayName": "Mia Krystof",
                    "active": False
                  },
                  "updateAuthor": {
                    "self": "https://your-domain.atlassian.net/rest/api/2/user?accountId=5b10a2844c20165700ede21g",
                    "accountId": "5b10a2844c20165700ede21g",
                    "displayName": "Mia Krystof",
                    "active": False
                  },
                  "comment": "I did some work here.",
                  "updated": "2020-05-14T03:51:35.957+0000",
                  "visibility": {
                    "type": "group",
                    "value": "jira-developers"
                  },
                  "started": "2020-05-14T03:51:35.957+0000",
                  "timeSpent": "3h 20m",
                  "timeSpentSeconds": 12000,
                  "id": "100028",
                  "issueId": "10002"
                }
              ],
              "updated": 1,
              "timetracking": {
                "originalEstimate": "10m",
                "remainingEstimate": "3m",
                "timeSpent": "6m",
                "originalEstimateSeconds": 600,
                "remainingEstimateSeconds": 200,
                "timeSpentSeconds": 400
              }
            }
          }
        ],
        "warningMessages": [
          "The value 'bar' does not exist for the field."
        ]
      }              



#Upload File
@jira_api.route(f'/{BASE_URL}/latest/issue/<id>/attachments', methods=['POST'])
def upload_file(id):
    request_data = str(request.get_data())
    
    startIndex=request_data.find("filename=\"")
    filename=request_data[startIndex+len("filename=\""):request_data.find("\"",startIndex+len("filename=\""))]
  
    return {
          "author": {
              "accountId": "557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76",
              "accountType": "atlassian",
              "active": True,
              "avatarUrls": {
                  "16x16": "https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=16\u0026s=16",
                  "24x24": "https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=24\u0026s=24",
                  "32x32": "https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=32\u0026s=32",
                  "48x48": "https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=48\u0026s=48"
              },
              "displayName": "XMOCKY",
              "emailAddress": "admin@demistodev.com",
              "self": "https://demistodev.atlassian.net/rest/api/2/user?accountId=557058%3Afb80ffc0-b374-4260-99a0-ea0c140a4e76",
              "timeZone": "Asia/Jerusalem"
          },
          "content": "https://demistodev.atlassian.net/secure/attachment/"+id+"/Mock_File.txt",
          "created": "2020-05-20T08:00:51.327+0300",
          "filename": filename,
          "id": "13937",
          "self": "https://demistodev.atlassian.net/rest/api/2/attachment/"+id,
          "size": 5747
      }


#fetch incidents
@jira_api.route(f'/{BASE_URL}/latest/search/', methods=['GET'])
def fetch_incident():
  return {
            "id": "",
            "version": 0,
            "modified": "0001-01-01T00:00:00Z",
            "sortValues": None,
            "roles": None,
            "previousRoles": None,
            "hasRole": False,
            "dbotCreatedBy": "",
            "ShardID": 0,
            "account": "",
            "autime": 0,
            "type": "",
            "rawType": "",
            "name": "Jira issue: 12652",
            "rawName": "",
            "status": 0,
            "reason": "",
            "created": "0001-01-01T00:00:00Z",
            "occurred": "0001-01-01T00:00:00Z",
            "closed": "0001-01-01T00:00:00Z",
            "sla": 0,
            "severity": 3,
            "investigationId": "",
            "labels": [{
              "value": "{\"expand\": \"operations,versionedRepresentations,editmeta,changelog,renderedFields\", \"id\": \"12652\", \"self\": \"https://demistodev.atlassian.net/rest/api/latest/issue/12652\", \"key\": \"VIK-3\", \"fields\": {\"statuscategorychangedate\": \"2019-05-15T21:24:07.222+0300\", \"issuetype\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/issuetype/10001\", \"id\": \"10001\", \"description\": \"A task that needs to be done.\", \"iconUrl\": \"https://demistodev.atlassian.net/secure/viewavatar?size=medium\u0026avatarId=10318\u0026avatarType=issuetype\", \"name\": \"Task\", \"subtask\": False, \"avatarId\": 10318}, \"timespent\": None, \"customfield_10031\": None, \"project\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/project/10005\", \"id\": \"10005\", \"key\": \"VIK\", \"name\": \"VikTest\", \"projectTypeKey\": \"software\", \"simplified\": False, \"avatarUrls\": {\"48x48\": \"https://demistodev.atlassian.net/secure/projectavatar?avatarId=10324\", \"24x24\": \"https://demistodev.atlassian.net/secure/projectavatar?size=small\u0026s=small\u0026avatarId=10324\", \"16x16\": \"https://demistodev.atlassian.net/secure/projectavatar?size=xsmall\u0026s=xsmall\u0026avatarId=10324\", \"32x32\": \"https://demistodev.atlassian.net/secure/projectavatar?size=medium\u0026s=medium\u0026avatarId=10324\"}}, \"customfield_10032\": None, \"customfield_10033\": None, \"fixVersions\": [], \"customfield_10034\": None, \"aggregatetimespent\": None, \"resolution\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/resolution/10000\", \"id\": \"10000\", \"description\": \"Work has been completed on this issue.\", \"name\": \"Done\"}, \"customfield_10035\": None, \"customfield_10036\": None, \"customfield_10037\": None, \"customfield_10027\": None, \"customfield_10029\": None, \"resolutiondate\": \"2019-05-15T21:04:39.147+0300\", \"workratio\": -1, \"lastViewed\": None, \"watches\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/issue/VIK-3/watchers\", \"watchCount\": 1, \"isWatching\": True}, \"created\": \"2019-05-04T00:44:31.743+0300\", \"customfield_10022\": None, \"priority\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/priority/2\", \"iconUrl\": \"https://demistodev.atlassian.net/images/icons/priorities/high.svg\", \"name\": \"High\", \"id\": \"2\"}, \"customfield_10023\": [], \"customfield_10024\": None, \"customfield_10025\": None, \"labels\": [], \"customfield_10016\": None, \"customfield_10017\": \"10000_*:*_1_*:*_1023607418_*|*_10001_*:*_1_*:*_0\", \"customfield_10018\": None, \"customfield_10019\": \"0|i006cf:\", \"aggregatetimeoriginalestimate\": None, \"timeestimate\": None, \"versions\": [], \"issuelinks\": [], \"assignee\": None, \"updated\": \"2019-05-15T21:24:07.222+0300\", \"status\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/status/10000\", \"description\": \"\", \"iconUrl\": \"https://demistodev.atlassian.net/images/icons/status_generic.gif\", \"name\": \"To Do\", \"id\": \"10000\", \"statusCategory\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/statuscategory/2\", \"id\": 2, \"key\": \"new\", \"colorName\": \"blue-gray\", \"name\": \"To Do\"}}, \"components\": [], \"timeoriginalestimate\": None, \"description\": \"hello\", \"customfield_10013\": None, \"customfield_10014\": None, \"customfield_10015\": {\"hasEpicLinkFieldDependency\": False, \"showField\": False, \"nonEditableReason\": {\"reason\": \"PLUGIN_LICENSE_ERROR\", \"message\": \"The Parent Link is only available to Jira Premium users.\"}}, \"customfield_10005\": None, \"customfield_10006\": None, \"customfield_10007\": None, \"security\": None, \"customfield_10008\": None, \"aggregatetimeestimate\": None, \"customfield_10009\": None, \"summary\": \"JiraTestMohitM\", \"creator\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/user?accountId=557058%3Afb80ffc0-b374-4260-99a0-ea0c140a4e76\", \"accountId\": \"557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76\", \"emailAddress\": \"admin@demistodev.com\", \"avatarUrls\": {\"48x48\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=48\u0026s=48\", \"24x24\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=24\u0026s=24\", \"16x16\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=16\u0026s=16\", \"32x32\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=32\u0026s=32\"}, \"displayName\": \"Meir Wahnon\", \"active\": True, \"timeZone\": \"Asia/Jerusalem\", \"accountType\": \"atlassian\"}, \"subtasks\": [], \"customfield_10040\": None, \"customfield_10041\": None, \"reporter\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/user?accountId=557058%3Afb80ffc0-b374-4260-99a0-ea0c140a4e76\", \"accountId\": \"557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76\", \"emailAddress\": \"admin@demistodev.com\", \"avatarUrls\": {\"48x48\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=48\u0026s=48\", \"24x24\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=24\u0026s=24\", \"16x16\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=16\u0026s=16\", \"32x32\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=32\u0026s=32\"}, \"displayName\": \"Meir Wahnon\", \"active\": True, \"timeZone\": \"Asia/Jerusalem\", \"accountType\": \"atlassian\"}, \"customfield_10000\": \"{}\", \"aggregateprogress\": {\"progress\": 0, \"total\": 0}, \"customfield_10001\": None, \"customfield_10002\": None, \"customfield_10003\": None, \"customfield_10004\": None, \"customfield_10038\": None, \"customfield_10039\": None, \"environment\": None, \"duedate\": None, \"progress\": {\"progress\": 0, \"total\": 0}, \"votes\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/issue/VIK-3/votes\", \"votes\": 0, \"hasVoted\": False}}}",
              "type": "issue"
            }, {
              "value": "12652",
              "type": "id"
            }, {
              "value": "None",
              "type": "lastViewed"
            }, {
              "value": "High",
              "type": "priority"
            }, {
              "value": "To Do",
              "type": "status"
            }, {
              "value": "VikTest",
              "type": "project"
            }, {
              "value": "2019-05-15T21:24:07.222+0300",
              "type": "updated"
            }, {
              "value": "Meir Wahnon",
              "type": "reportername"
            }, {
              "value": "admin@demistodev.com",
              "type": "reporteremail"
            }, {
              "value": "2019-05-04T00:44:31.743+0300",
              "type": "created"
            }, {
              "value": "JiraTestMohitM",
              "type": "summary"
            }, {
              "value": "hello",
              "type": "description"
            }],
            "attachment": None,
            "details": "hello",
            "openDuration": 0,
            "lastOpen": "0001-01-01T00:00:00Z",
            "closingUserId": "",
            "owner": "",
            "activated": "0001-01-01T00:00:00Z",
            "closeReason": "",
            "rawCloseReason": "",
            "closeNotes": "",
            "playbookId": "",
            "dueDate": "0001-01-01T00:00:00Z",
            "reminder": "0001-01-01T00:00:00Z",
            "runStatus": "",
            "notifyTime": "0001-01-01T00:00:00Z",
            "phase": "",
            "rawPhase": "",
            "isPlayground": False,
            "CustomFields": None,
            "rawJSON": "{\"expand\": \"operations,versionedRepresentations,editmeta,changelog,renderedFields\", \"id\": \"12652\", \"self\": \"https://demistodev.atlassian.net/rest/api/latest/issue/12652\", \"key\": \"VIK-3\", \"fields\": {\"statuscategorychangedate\": \"2019-05-15T21:24:07.222+0300\", \"issuetype\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/issuetype/10001\", \"id\": \"10001\", \"description\": \"A task that needs to be done.\", \"iconUrl\": \"https://demistodev.atlassian.net/secure/viewavatar?size=medium\u0026avatarId=10318\u0026avatarType=issuetype\", \"name\": \"Task\", \"subtask\": False, \"avatarId\": 10318}, \"timespent\": None, \"customfield_10031\": None, \"project\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/project/10005\", \"id\": \"10005\", \"key\": \"VIK\", \"name\": \"VikTest\", \"projectTypeKey\": \"software\", \"simplified\": False, \"avatarUrls\": {\"48x48\": \"https://demistodev.atlassian.net/secure/projectavatar?avatarId=10324\", \"24x24\": \"https://demistodev.atlassian.net/secure/projectavatar?size=small\u0026s=small\u0026avatarId=10324\", \"16x16\": \"https://demistodev.atlassian.net/secure/projectavatar?size=xsmall\u0026s=xsmall\u0026avatarId=10324\", \"32x32\": \"https://demistodev.atlassian.net/secure/projectavatar?size=medium\u0026s=medium\u0026avatarId=10324\"}}, \"customfield_10032\": None, \"customfield_10033\": None, \"fixVersions\": [], \"customfield_10034\": None, \"aggregatetimespent\": None, \"resolution\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/resolution/10000\", \"id\": \"10000\", \"description\": \"Work has been completed on this issue.\", \"name\": \"Done\"}, \"customfield_10035\": None, \"customfield_10036\": None, \"customfield_10037\": None, \"customfield_10027\": None, \"customfield_10029\": None, \"resolutiondate\": \"2019-05-15T21:04:39.147+0300\", \"workratio\": -1, \"lastViewed\": None, \"watches\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/issue/VIK-3/watchers\", \"watchCount\": 1, \"isWatching\": True}, \"created\": \"2019-05-04T00:44:31.743+0300\", \"customfield_10022\": None, \"priority\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/priority/2\", \"iconUrl\": \"https://demistodev.atlassian.net/images/icons/priorities/high.svg\", \"name\": \"High\", \"id\": \"2\"}, \"customfield_10023\": [], \"customfield_10024\": None, \"customfield_10025\": None, \"labels\": [], \"customfield_10016\": None, \"customfield_10017\": \"10000_*:*_1_*:*_1023607418_*|*_10001_*:*_1_*:*_0\", \"customfield_10018\": None, \"customfield_10019\": \"0|i006cf:\", \"aggregatetimeoriginalestimate\": None, \"timeestimate\": None, \"versions\": [], \"issuelinks\": [], \"assignee\": None, \"updated\": \"2019-05-15T21:24:07.222+0300\", \"status\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/status/10000\", \"description\": \"\", \"iconUrl\": \"https://demistodev.atlassian.net/images/icons/status_generic.gif\", \"name\": \"To Do\", \"id\": \"10000\", \"statusCategory\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/statuscategory/2\", \"id\": 2, \"key\": \"new\", \"colorName\": \"blue-gray\", \"name\": \"To Do\"}}, \"components\": [], \"timeoriginalestimate\": None, \"description\": \"hello\", \"customfield_10013\": None, \"customfield_10014\": None, \"customfield_10015\": {\"hasEpicLinkFieldDependency\": False, \"showField\": False, \"nonEditableReason\": {\"reason\": \"PLUGIN_LICENSE_ERROR\", \"message\": \"The Parent Link is only available to Jira Premium users.\"}}, \"customfield_10005\": None, \"customfield_10006\": None, \"customfield_10007\": None, \"security\": None, \"customfield_10008\": None, \"aggregatetimeestimate\": None, \"customfield_10009\": None, \"summary\": \"JiraTestMohitM\", \"creator\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/user?accountId=557058%3Afb80ffc0-b374-4260-99a0-ea0c140a4e76\", \"accountId\": \"557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76\", \"emailAddress\": \"admin@demistodev.com\", \"avatarUrls\": {\"48x48\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=48\u0026s=48\", \"24x24\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=24\u0026s=24\", \"16x16\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=16\u0026s=16\", \"32x32\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=32\u0026s=32\"}, \"displayName\": \"Meir Wahnon\", \"active\": True, \"timeZone\": \"Asia/Jerusalem\", \"accountType\": \"atlassian\"}, \"subtasks\": [], \"customfield_10040\": None, \"customfield_10041\": None, \"reporter\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/user?accountId=557058%3Afb80ffc0-b374-4260-99a0-ea0c140a4e76\", \"accountId\": \"557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76\", \"emailAddress\": \"admin@demistodev.com\", \"avatarUrls\": {\"48x48\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=48\u0026s=48\", \"24x24\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=24\u0026s=24\", \"16x16\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=16\u0026s=16\", \"32x32\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=32\u0026s=32\"}, \"displayName\": \"Meir Wahnon\", \"active\": True, \"timeZone\": \"Asia/Jerusalem\", \"accountType\": \"atlassian\"}, \"customfield_10000\": \"{}\", \"aggregateprogress\": {\"progress\": 0, \"total\": 0}, \"customfield_10001\": None, \"customfield_10002\": None, \"customfield_10003\": None, \"customfield_10004\": None, \"customfield_10038\": None, \"customfield_10039\": None, \"environment\": None, \"duedate\": None, \"progress\": {\"progress\": 0, \"total\": 0}, \"votes\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/issue/VIK-3/votes\", \"votes\": 0, \"hasVoted\": False}}}",
            "parent": "",
            "category": "",
            "rawCategory": "",
            "linkedIncidents": None,
            "linkedCount": 0,
            "droppedCount": 0,
            "sourceInstance": "",
            "sourceBrand": "",
            "canvases": None,
            "lastJobRunTime": "0001-01-01T00:00:00Z",
            "feedBased": False
          }, {
            "id": "",
            "version": 0,
            "modified": "0001-01-01T00:00:00Z",
            "sortValues": None,
            "roles": None,
            "previousRoles": None,
            "hasRole": False,
            "dbotCreatedBy": "",
            "ShardID": 0,
            "account": "",
            "autime": 0,
            "type": "",
            "rawType": "",
            "name": "Jira issue: 12049",
            "rawName": "",
            "status": 0,
            "reason": "",
            "created": "0001-01-01T00:00:00Z",
            "occurred": "0001-01-01T00:00:00Z",
            "closed": "0001-01-01T00:00:00Z",
            "sla": 0,
            "severity": 2,
            "investigationId": "",
            "labels": [{
              "value": "{\"expand\": \"operations,versionedRepresentations,editmeta,changelog,renderedFields\", \"id\": \"12049\", \"self\": \"https://demistodev.atlassian.net/rest/api/latest/issue/12049\", \"key\": \"VIK-2\", \"fields\": {\"statuscategorychangedate\": \"2019-03-19T00:34:55.467+0200\", \"issuetype\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/issuetype/10004\", \"id\": \"10004\", \"description\": \"jira.translation.issuetype.bug.name.desc\", \"iconUrl\": \"https://demistodev.atlassian.net/secure/viewavatar?size=medium\u0026avatarId=10303\u0026avatarType=issuetype\", \"name\": \"Bug\", \"subtask\": False, \"avatarId\": 10303}, \"timespent\": None, \"project\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/project/10005\", \"id\": \"10005\", \"key\": \"VIK\", \"name\": \"VikTest\", \"projectTypeKey\": \"software\", \"simplified\": False, \"avatarUrls\": {\"48x48\": \"https://demistodev.atlassian.net/secure/projectavatar?avatarId=10324\", \"24x24\": \"https://demistodev.atlassian.net/secure/projectavatar?size=small\u0026s=small\u0026avatarId=10324\", \"16x16\": \"https://demistodev.atlassian.net/secure/projectavatar?size=xsmall\u0026s=xsmall\u0026avatarId=10324\", \"32x32\": \"https://demistodev.atlassian.net/secure/projectavatar?size=medium\u0026s=medium\u0026avatarId=10324\"}}, \"customfield_10031\": None, \"customfield_10032\": None, \"customfield_10033\": None, \"fixVersions\": [], \"aggregatetimespent\": None, \"customfield_10034\": None, \"customfield_10035\": None, \"resolution\": None, \"customfield_10036\": None, \"customfield_10037\": None, \"customfield_10027\": None, \"customfield_10029\": None, \"resolutiondate\": None, \"workratio\": -1, \"watches\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/issue/VIK-2/watchers\", \"watchCount\": 1, \"isWatching\": True}, \"lastViewed\": None, \"created\": \"2019-03-19T00:34:55.467+0200\", \"customfield_10022\": None, \"priority\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/priority/3\", \"iconUrl\": \"https://demistodev.atlassian.net/images/icons/priorities/medium.svg\", \"name\": \"Medium\", \"id\": \"3\"}, \"customfield_10023\": [], \"customfield_10024\": None, \"customfield_10025\": None, \"labels\": [], \"customfield_10016\": None, \"customfield_10017\": None, \"customfield_10018\": None, \"customfield_10019\": \"0|i0061r:\", \"aggregatetimeoriginalestimate\": None, \"timeestimate\": None, \"versions\": [], \"issuelinks\": [], \"assignee\": None, \"updated\": \"2019-03-19T00:37:38.220+0200\", \"status\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/status/10000\", \"description\": \"\", \"iconUrl\": \"https://demistodev.atlassian.net/images/icons/status_generic.gif\", \"name\": \"To Do\", \"id\": \"10000\", \"statusCategory\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/statuscategory/2\", \"id\": 2, \"key\": \"new\", \"colorName\": \"blue-gray\", \"name\": \"To Do\"}}, \"components\": [], \"timeoriginalestimate\": None, \"description\": None, \"customfield_10013\": None, \"customfield_10014\": None, \"customfield_10015\": {\"hasEpicLinkFieldDependency\": False, \"showField\": False, \"nonEditableReason\": {\"reason\": \"PLUGIN_LICENSE_ERROR\", \"message\": \"The Parent Link is only available to Jira Premium users.\"}}, \"customfield_10005\": None, \"customfield_10006\": None, \"security\": None, \"customfield_10007\": None, \"customfield_10008\": None, \"customfield_10009\": None, \"aggregatetimeestimate\": None, \"summary\": \"sfs\", \"creator\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/user?accountId=557058%3Afb80ffc0-b374-4260-99a0-ea0c140a4e76\", \"accountId\": \"557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76\", \"emailAddress\": \"admin@demistodev.com\", \"avatarUrls\": {\"48x48\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=48\u0026s=48\", \"24x24\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=24\u0026s=24\", \"16x16\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=16\u0026s=16\", \"32x32\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=32\u0026s=32\"}, \"displayName\": \"Meir Wahnon\", \"active\": True, \"timeZone\": \"Asia/Jerusalem\", \"accountType\": \"atlassian\"}, \"subtasks\": [], \"customfield_10040\": None, \"customfield_10041\": None, \"reporter\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/user?accountId=557058%3Afb80ffc0-b374-4260-99a0-ea0c140a4e76\", \"accountId\": \"557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76\", \"emailAddress\": \"admin@demistodev.com\", \"avatarUrls\": {\"48x48\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=48\u0026s=48\", \"24x24\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=24\u0026s=24\", \"16x16\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=16\u0026s=16\", \"32x32\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=32\u0026s=32\"}, \"displayName\": \"Meir Wahnon\", \"active\": True, \"timeZone\": \"Asia/Jerusalem\", \"accountType\": \"atlassian\"}, \"customfield_10000\": \"{}\", \"aggregateprogress\": {\"progress\": 0, \"total\": 0}, \"customfield_10001\": None, \"customfield_10002\": None, \"customfield_10003\": None, \"customfield_10004\": None, \"customfield_10038\": None, \"customfield_10039\": None, \"environment\": None, \"duedate\": None, \"progress\": {\"progress\": 0, \"total\": 0}, \"votes\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/issue/VIK-2/votes\", \"votes\": 0, \"hasVoted\": False}}}",
              "type": "issue"
            }, {
              "value": "12049",
              "type": "id"
            }, {
              "value": "None",
              "type": "lastViewed"
            }, {
              "value": "Medium",
              "type": "priority"
            }, {
              "value": "To Do",
              "type": "status"
            }, {
              "value": "VikTest",
              "type": "project"
            }, {
              "value": "2019-03-19T00:37:38.220+0200",
              "type": "updated"
            }, {
              "value": "Meir Wahnon",
              "type": "reportername"
            }, {
              "value": "admin@demistodev.com",
              "type": "reporteremail"
            }, {
              "value": "2019-03-19T00:34:55.467+0200",
              "type": "created"
            }, {
              "value": "sfs",
              "type": "summary"
            }, {
              "value": "None",
              "type": "description"
            }],
            "attachment": None,
            "details": "",
            "openDuration": 0,
            "lastOpen": "0001-01-01T00:00:00Z",
            "closingUserId": "",
            "owner": "",
            "activated": "0001-01-01T00:00:00Z",
            "closeReason": "",
            "rawCloseReason": "",
            "closeNotes": "",
            "playbookId": "",
            "dueDate": "0001-01-01T00:00:00Z",
            "reminder": "0001-01-01T00:00:00Z",
            "runStatus": "",
            "notifyTime": "0001-01-01T00:00:00Z",
            "phase": "",
            "rawPhase": "",
            "isPlayground": False,
            "CustomFields": None,
            "rawJSON": "{\"expand\": \"operations,versionedRepresentations,editmeta,changelog,renderedFields\", \"id\": \"12049\", \"self\": \"https://demistodev.atlassian.net/rest/api/latest/issue/12049\", \"key\": \"VIK-2\", \"fields\": {\"statuscategorychangedate\": \"2019-03-19T00:34:55.467+0200\", \"issuetype\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/issuetype/10004\", \"id\": \"10004\", \"description\": \"jira.translation.issuetype.bug.name.desc\", \"iconUrl\": \"https://demistodev.atlassian.net/secure/viewavatar?size=medium\u0026avatarId=10303\u0026avatarType=issuetype\", \"name\": \"Bug\", \"subtask\": False, \"avatarId\": 10303}, \"timespent\": None, \"project\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/project/10005\", \"id\": \"10005\", \"key\": \"VIK\", \"name\": \"VikTest\", \"projectTypeKey\": \"software\", \"simplified\": False, \"avatarUrls\": {\"48x48\": \"https://demistodev.atlassian.net/secure/projectavatar?avatarId=10324\", \"24x24\": \"https://demistodev.atlassian.net/secure/projectavatar?size=small\u0026s=small\u0026avatarId=10324\", \"16x16\": \"https://demistodev.atlassian.net/secure/projectavatar?size=xsmall\u0026s=xsmall\u0026avatarId=10324\", \"32x32\": \"https://demistodev.atlassian.net/secure/projectavatar?size=medium\u0026s=medium\u0026avatarId=10324\"}}, \"customfield_10031\": None, \"customfield_10032\": None, \"customfield_10033\": None, \"fixVersions\": [], \"aggregatetimespent\": None, \"customfield_10034\": None, \"customfield_10035\": None, \"resolution\": None, \"customfield_10036\": None, \"customfield_10037\": None, \"customfield_10027\": None, \"customfield_10029\": None, \"resolutiondate\": None, \"workratio\": -1, \"watches\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/issue/VIK-2/watchers\", \"watchCount\": 1, \"isWatching\": True}, \"lastViewed\": None, \"created\": \"2019-03-19T00:34:55.467+0200\", \"customfield_10022\": None, \"priority\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/priority/3\", \"iconUrl\": \"https://demistodev.atlassian.net/images/icons/priorities/medium.svg\", \"name\": \"Medium\", \"id\": \"3\"}, \"customfield_10023\": [], \"customfield_10024\": None, \"customfield_10025\": None, \"labels\": [], \"customfield_10016\": None, \"customfield_10017\": None, \"customfield_10018\": None, \"customfield_10019\": \"0|i0061r:\", \"aggregatetimeoriginalestimate\": None, \"timeestimate\": None, \"versions\": [], \"issuelinks\": [], \"assignee\": None, \"updated\": \"2019-03-19T00:37:38.220+0200\", \"status\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/status/10000\", \"description\": \"\", \"iconUrl\": \"https://demistodev.atlassian.net/images/icons/status_generic.gif\", \"name\": \"To Do\", \"id\": \"10000\", \"statusCategory\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/statuscategory/2\", \"id\": 2, \"key\": \"new\", \"colorName\": \"blue-gray\", \"name\": \"To Do\"}}, \"components\": [], \"timeoriginalestimate\": None, \"description\": None, \"customfield_10013\": None, \"customfield_10014\": None, \"customfield_10015\": {\"hasEpicLinkFieldDependency\": False, \"showField\": False, \"nonEditableReason\": {\"reason\": \"PLUGIN_LICENSE_ERROR\", \"message\": \"The Parent Link is only available to Jira Premium users.\"}}, \"customfield_10005\": None, \"customfield_10006\": None, \"security\": None, \"customfield_10007\": None, \"customfield_10008\": None, \"customfield_10009\": None, \"aggregatetimeestimate\": None, \"summary\": \"sfs\", \"creator\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/user?accountId=557058%3Afb80ffc0-b374-4260-99a0-ea0c140a4e76\", \"accountId\": \"557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76\", \"emailAddress\": \"admin@demistodev.com\", \"avatarUrls\": {\"48x48\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=48\u0026s=48\", \"24x24\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=24\u0026s=24\", \"16x16\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=16\u0026s=16\", \"32x32\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=32\u0026s=32\"}, \"displayName\": \"Meir Wahnon\", \"active\": True, \"timeZone\": \"Asia/Jerusalem\", \"accountType\": \"atlassian\"}, \"subtasks\": [], \"customfield_10040\": None, \"customfield_10041\": None, \"reporter\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/user?accountId=557058%3Afb80ffc0-b374-4260-99a0-ea0c140a4e76\", \"accountId\": \"557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76\", \"emailAddress\": \"admin@demistodev.com\", \"avatarUrls\": {\"48x48\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=48\u0026s=48\", \"24x24\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=24\u0026s=24\", \"16x16\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=16\u0026s=16\", \"32x32\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=32\u0026s=32\"}, \"displayName\": \"Meir Wahnon\", \"active\": True, \"timeZone\": \"Asia/Jerusalem\", \"accountType\": \"atlassian\"}, \"customfield_10000\": \"{}\", \"aggregateprogress\": {\"progress\": 0, \"total\": 0}, \"customfield_10001\": None, \"customfield_10002\": None, \"customfield_10003\": None, \"customfield_10004\": None, \"customfield_10038\": None, \"customfield_10039\": None, \"environment\": None, \"duedate\": None, \"progress\": {\"progress\": 0, \"total\": 0}, \"votes\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/issue/VIK-2/votes\", \"votes\": 0, \"hasVoted\": False}}}",
            "parent": "",
            "category": "",
            "rawCategory": "",
            "linkedIncidents": None,
            "linkedCount": 0,
            "droppedCount": 0,
            "sourceInstance": "",
            "sourceBrand": "",
            "canvases": None,
            "lastJobRunTime": "0001-01-01T00:00:00Z",
            "feedBased": False
          }, {
            "id": "",
            "version": 0,
            "modified": "0001-01-01T00:00:00Z",
            "sortValues": None,
            "roles": None,
            "previousRoles": None,
            "hasRole": False,
            "dbotCreatedBy": "",
            "ShardID": 0,
            "account": "",
            "autime": 0,
            "type": "",
            "rawType": "",
            "name": "Jira issue: 12048",
            "rawName": "",
            "status": 0,
            "reason": "",
            "created": "0001-01-01T00:00:00Z",
            "occurred": "0001-01-01T00:00:00Z",
            "closed": "0001-01-01T00:00:00Z",
            "sla": 0,
            "severity": 2,
            "investigationId": "",
            "labels": [{
              "value": "{\"expand\": \"operations,versionedRepresentations,editmeta,changelog,renderedFields\", \"id\": \"12048\", \"self\": \"https://demistodev.atlassian.net/rest/api/latest/issue/12048\", \"key\": \"VIK-1\", \"fields\": {\"statuscategorychangedate\": \"2019-03-19T00:17:15.089+0200\", \"issuetype\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/issuetype/10004\", \"id\": \"10004\", \"description\": \"jira.translation.issuetype.bug.name.desc\", \"iconUrl\": \"https://demistodev.atlassian.net/secure/viewavatar?size=medium\u0026avatarId=10303\u0026avatarType=issuetype\", \"name\": \"Bug\", \"subtask\": False, \"avatarId\": 10303}, \"timespent\": None, \"customfield_10031\": None, \"project\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/project/10005\", \"id\": \"10005\", \"key\": \"VIK\", \"name\": \"VikTest\", \"projectTypeKey\": \"software\", \"simplified\": False, \"avatarUrls\": {\"48x48\": \"https://demistodev.atlassian.net/secure/projectavatar?avatarId=10324\", \"24x24\": \"https://demistodev.atlassian.net/secure/projectavatar?size=small\u0026s=small\u0026avatarId=10324\", \"16x16\": \"https://demistodev.atlassian.net/secure/projectavatar?size=xsmall\u0026s=xsmall\u0026avatarId=10324\", \"32x32\": \"https://demistodev.atlassian.net/secure/projectavatar?size=medium\u0026s=medium\u0026avatarId=10324\"}}, \"customfield_10032\": None, \"fixVersions\": [], \"customfield_10033\": None, \"aggregatetimespent\": None, \"customfield_10034\": None, \"resolution\": None, \"customfield_10035\": None, \"customfield_10036\": None, \"customfield_10037\": None, \"customfield_10027\": None, \"customfield_10029\": None, \"resolutiondate\": None, \"workratio\": -1, \"watches\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/issue/VIK-1/watchers\", \"watchCount\": 1, \"isWatching\": True}, \"lastViewed\": None, \"created\": \"2019-03-19T00:12:52.407+0200\", \"customfield_10022\": None, \"priority\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/priority/3\", \"iconUrl\": \"https://demistodev.atlassian.net/images/icons/priorities/medium.svg\", \"name\": \"Medium\", \"id\": \"3\"}, \"customfield_10023\": [], \"customfield_10024\": None, \"customfield_10025\": None, \"labels\": [], \"customfield_10016\": None, \"customfield_10017\": None, \"customfield_10018\": None, \"customfield_10019\": \"0|i0061j:\", \"aggregatetimeoriginalestimate\": None, \"timeestimate\": None, \"versions\": [], \"issuelinks\": [], \"assignee\": None, \"updated\": \"2019-03-19T00:17:15.084+0200\", \"status\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/status/3\", \"description\": \"This issue is being actively worked on at the moment by the assignee.\", \"iconUrl\": \"https://demistodev.atlassian.net/images/icons/statuses/inprogress.png\", \"name\": \"In Progress\", \"id\": \"3\", \"statusCategory\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/statuscategory/4\", \"id\": 4, \"key\": \"indeterminate\", \"colorName\": \"yellow\", \"name\": \"In Progress\"}}, \"components\": [], \"timeoriginalestimate\": None, \"description\": None, \"customfield_10013\": None, \"customfield_10014\": None, \"customfield_10015\": {\"hasEpicLinkFieldDependency\": False, \"showField\": False, \"nonEditableReason\": {\"reason\": \"PLUGIN_LICENSE_ERROR\", \"message\": \"The Parent Link is only available to Jira Premium users.\"}}, \"customfield_10005\": None, \"customfield_10006\": None, \"security\": None, \"customfield_10007\": None, \"customfield_10008\": None, \"aggregatetimeestimate\": None, \"customfield_10009\": None, \"summary\": \"This is a test\", \"creator\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/user?accountId=557058%3Afb80ffc0-b374-4260-99a0-ea0c140a4e76\", \"accountId\": \"557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76\", \"emailAddress\": \"admin@demistodev.com\", \"avatarUrls\": {\"48x48\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=48\u0026s=48\", \"24x24\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=24\u0026s=24\", \"16x16\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=16\u0026s=16\", \"32x32\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=32\u0026s=32\"}, \"displayName\": \"Meir Wahnon\", \"active\": True, \"timeZone\": \"Asia/Jerusalem\", \"accountType\": \"atlassian\"}, \"subtasks\": [], \"customfield_10040\": None, \"customfield_10041\": None, \"reporter\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/user?accountId=557058%3Afb80ffc0-b374-4260-99a0-ea0c140a4e76\", \"accountId\": \"557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76\", \"emailAddress\": \"admin@demistodev.com\", \"avatarUrls\": {\"48x48\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=48\u0026s=48\", \"24x24\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=24\u0026s=24\", \"16x16\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=16\u0026s=16\", \"32x32\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=32\u0026s=32\"}, \"displayName\": \"Meir Wahnon\", \"active\": True, \"timeZone\": \"Asia/Jerusalem\", \"accountType\": \"atlassian\"}, \"customfield_10000\": \"{}\", \"aggregateprogress\": {\"progress\": 0, \"total\": 0}, \"customfield_10001\": None, \"customfield_10002\": None, \"customfield_10003\": None, \"customfield_10004\": None, \"customfield_10038\": None, \"customfield_10039\": None, \"environment\": None, \"duedate\": None, \"progress\": {\"progress\": 0, \"total\": 0}, \"votes\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/issue/VIK-1/votes\", \"votes\": 0, \"hasVoted\": False}}}",
              "type": "issue"
            }, {
              "value": "12048",
              "type": "id"
            }, {
              "value": "None",
              "type": "lastViewed"
            }, {
              "value": "Medium",
              "type": "priority"
            }, {
              "value": "In Progress",
              "type": "status"
            }, {
              "value": "VikTest",
              "type": "project"
            }, {
              "value": "2019-03-19T00:17:15.084+0200",
              "type": "updated"
            }, {
              "value": "Meir Wahnon",
              "type": "reportername"
            }, {
              "value": "admin@demistodev.com",
              "type": "reporteremail"
            }, {
              "value": "2019-03-19T00:12:52.407+0200",
              "type": "created"
            }, {
              "value": "This is a test",
              "type": "summary"
            }, {
              "value": "None",
              "type": "description"
            }],
            "attachment": None,
            "details": "",
            "openDuration": 0,
            "lastOpen": "0001-01-01T00:00:00Z",
            "closingUserId": "",
            "owner": "",
            "activated": "0001-01-01T00:00:00Z",
            "closeReason": "",
            "rawCloseReason": "",
            "closeNotes": "",
            "playbookId": "",
            "dueDate": "0001-01-01T00:00:00Z",
            "reminder": "0001-01-01T00:00:00Z",
            "runStatus": "",
            "notifyTime": "0001-01-01T00:00:00Z",
            "phase": "",
            "rawPhase": "",
            "isPlayground": False,
            "CustomFields": None,
            "rawJSON": "{\"expand\": \"operations,versionedRepresentations,editmeta,changelog,renderedFields\", \"id\": \"12048\", \"self\": \"https://demistodev.atlassian.net/rest/api/latest/issue/12048\", \"key\": \"VIK-1\", \"fields\": {\"statuscategorychangedate\": \"2019-03-19T00:17:15.089+0200\", \"issuetype\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/issuetype/10004\", \"id\": \"10004\", \"description\": \"jira.translation.issuetype.bug.name.desc\", \"iconUrl\": \"https://demistodev.atlassian.net/secure/viewavatar?size=medium\u0026avatarId=10303\u0026avatarType=issuetype\", \"name\": \"Bug\", \"subtask\": False, \"avatarId\": 10303}, \"timespent\": None, \"customfield_10031\": None, \"project\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/project/10005\", \"id\": \"10005\", \"key\": \"VIK\", \"name\": \"VikTest\", \"projectTypeKey\": \"software\", \"simplified\": False, \"avatarUrls\": {\"48x48\": \"https://demistodev.atlassian.net/secure/projectavatar?avatarId=10324\", \"24x24\": \"https://demistodev.atlassian.net/secure/projectavatar?size=small\u0026s=small\u0026avatarId=10324\", \"16x16\": \"https://demistodev.atlassian.net/secure/projectavatar?size=xsmall\u0026s=xsmall\u0026avatarId=10324\", \"32x32\": \"https://demistodev.atlassian.net/secure/projectavatar?size=medium\u0026s=medium\u0026avatarId=10324\"}}, \"customfield_10032\": None, \"fixVersions\": [], \"customfield_10033\": None, \"aggregatetimespent\": None, \"customfield_10034\": None, \"resolution\": None, \"customfield_10035\": None, \"customfield_10036\": None, \"customfield_10037\": None, \"customfield_10027\": None, \"customfield_10029\": None, \"resolutiondate\": None, \"workratio\": -1, \"watches\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/issue/VIK-1/watchers\", \"watchCount\": 1, \"isWatching\": True}, \"lastViewed\": None, \"created\": \"2019-03-19T00:12:52.407+0200\", \"customfield_10022\": None, \"priority\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/priority/3\", \"iconUrl\": \"https://demistodev.atlassian.net/images/icons/priorities/medium.svg\", \"name\": \"Medium\", \"id\": \"3\"}, \"customfield_10023\": [], \"customfield_10024\": None, \"customfield_10025\": None, \"labels\": [], \"customfield_10016\": None, \"customfield_10017\": None, \"customfield_10018\": None, \"customfield_10019\": \"0|i0061j:\", \"aggregatetimeoriginalestimate\": None, \"timeestimate\": None, \"versions\": [], \"issuelinks\": [], \"assignee\": None, \"updated\": \"2019-03-19T00:17:15.084+0200\", \"status\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/status/3\", \"description\": \"This issue is being actively worked on at the moment by the assignee.\", \"iconUrl\": \"https://demistodev.atlassian.net/images/icons/statuses/inprogress.png\", \"name\": \"In Progress\", \"id\": \"3\", \"statusCategory\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/statuscategory/4\", \"id\": 4, \"key\": \"indeterminate\", \"colorName\": \"yellow\", \"name\": \"In Progress\"}}, \"components\": [], \"timeoriginalestimate\": None, \"description\": None, \"customfield_10013\": None, \"customfield_10014\": None, \"customfield_10015\": {\"hasEpicLinkFieldDependency\": False, \"showField\": False, \"nonEditableReason\": {\"reason\": \"PLUGIN_LICENSE_ERROR\", \"message\": \"The Parent Link is only available to Jira Premium users.\"}}, \"customfield_10005\": None, \"customfield_10006\": None, \"security\": None, \"customfield_10007\": None, \"customfield_10008\": None, \"aggregatetimeestimate\": None, \"customfield_10009\": None, \"summary\": \"This is a test\", \"creator\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/user?accountId=557058%3Afb80ffc0-b374-4260-99a0-ea0c140a4e76\", \"accountId\": \"557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76\", \"emailAddress\": \"admin@demistodev.com\", \"avatarUrls\": {\"48x48\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=48\u0026s=48\", \"24x24\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=24\u0026s=24\", \"16x16\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=16\u0026s=16\", \"32x32\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=32\u0026s=32\"}, \"displayName\": \"Meir Wahnon\", \"active\": True, \"timeZone\": \"Asia/Jerusalem\", \"accountType\": \"atlassian\"}, \"subtasks\": [], \"customfield_10040\": None, \"customfield_10041\": None, \"reporter\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/user?accountId=557058%3Afb80ffc0-b374-4260-99a0-ea0c140a4e76\", \"accountId\": \"557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76\", \"emailAddress\": \"admin@demistodev.com\", \"avatarUrls\": {\"48x48\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=48\u0026s=48\", \"24x24\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=24\u0026s=24\", \"16x16\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=16\u0026s=16\", \"32x32\": \"https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/557058:fb80ffc0-b374-4260-99a0-ea0c140a4e76/7db37854-040f-4c34-b7c3-203db2669142/128?size=32\u0026s=32\"}, \"displayName\": \"Meir Wahnon\", \"active\": True, \"timeZone\": \"Asia/Jerusalem\", \"accountType\": \"atlassian\"}, \"customfield_10000\": \"{}\", \"aggregateprogress\": {\"progress\": 0, \"total\": 0}, \"customfield_10001\": None, \"customfield_10002\": None, \"customfield_10003\": None, \"customfield_10004\": None, \"customfield_10038\": None, \"customfield_10039\": None, \"environment\": None, \"duedate\": None, \"progress\": {\"progress\": 0, \"total\": 0}, \"votes\": {\"self\": \"https://demistodev.atlassian.net/rest/api/2/issue/VIK-1/votes\", \"votes\": 0, \"hasVoted\": False}}}",
            "parent": "",
            "category": "",
            "rawCategory": "",
            "linkedIncidents": None,
            "linkedCount": 0,
            "droppedCount": 0,
            "sourceInstance": "",
            "sourceBrand": "",
            "canvases": None,
            "lastJobRunTime": "0001-01-01T00:00:00Z",
            "feedBased": False
          }

