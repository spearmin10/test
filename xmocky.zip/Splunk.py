from flask import Blueprint, request, Response
import json
import logging


INTEGRATION = 'splunk_api'
splunk_api = Blueprint(f'{INTEGRATION}', __name__)
logger = logging.getLogger(__name__)

xmlresponse_search_job = (
        """
        <?xml version="1.0" encoding="UTF-8"?>
        <entry xmlns="http://www.w3.org/2005/Atom" xmlns:opensearch="http://a9.com/-/spec/opensearch/1.1/" xmlns:s="http://dev.splunk.com/ns/rest">
            <title>search index</title>
            <id>https://localhost:8089/services/search/jobs/mysearch_02151949</id>
            <updated>2011-07-07T20:49:58.000-07:00</updated>
            <link href="/services/search/jobs/mysearch_02151949" rel="alternate" />
            <published>2011-07-07T20:49:57.000-07:00</published>
            <link href="/services/search/jobs/mysearch_02151949/search.log" rel="search.log" />
            <link href="/services/search/jobs/mysearch_02151949/events" rel="events" />
            <link href="/services/search/jobs/mysearch_02151949/results" rel="results" />
            <link href="/services/search/jobs/mysearch_02151949/results_preview" rel="results_preview" />
            <link href="/services/search/jobs/mysearch_02151949/timeline" rel="timeline" />
            <link href="/services/search/jobs/mysearch_02151949/summary" rel="summary" />
            <link href="/services/search/jobs/mysearch_02151949/control" rel="control" />
            <author>
                <name>admin</name>
            </author>
            <content type="text/xml">
                <s:dict>
                    <s:key name="cursorTime">1969-12-31T16:00:00.000-08:00</s:key>
                    <s:key name="delegate" />
                    <s:key name="diskUsage">2174976</s:key>
                    <s:key name="dispatchState">DONE</s:key>
                    <s:key name="doneProgress">1.00000</s:key>
                    <s:key name="dropCount">0</s:key>
                    <s:key name="earliestTime">2011-07-07T11:18:08.000-07:00</s:key>
                    <s:key name="eventAvailableCount">287</s:key>
                    <s:key name="eventCount">287</s:key>
                    <s:key name="eventFieldCount">6</s:key>
                    <s:key name="eventIsStreaming">1</s:key>
                    <s:key name="eventIsTruncated">0</s:key>
                    <s:key name="eventSearch">search index</s:key>
                    <s:key name="eventSorting">desc</s:key>
                    <s:key name="isDone">1</s:key>
                    <s:key name="isFailed">0</s:key>
                    <s:key name="isFinalized">0</s:key>
                    <s:key name="isPaused">0</s:key>
                    <s:key name="isPreviewEnabled">0</s:key>
                    <s:key name="isRealTimeSearch">0</s:key>
                    <s:key name="isRemoteTimeline">0</s:key>
                    <s:key name="isSaved">0</s:key>
                    <s:key name="isSavedSearch">0</s:key>
                    <s:key name="isZombie">0</s:key>
                    <s:key name="keywords">index</s:key>
                    <s:key name="label" />
                    <s:key name="latestTime">1969-12-31T16:00:00.000-08:00</s:key>
                    <s:key name="numPreviews">0</s:key>
                    <s:key name="priority">5</s:key>
                    <s:key name="remoteSearch">litsearch index | fields  keepcolorder=t "host" "index" "linecount" "source" "sourcetype" "splunk_server"</s:key>
                    <s:key name="reportSearch" />
                    <s:key name="resultCount">287</s:key>
                    <s:key name="resultIsStreaming">1</s:key>
                    <s:key name="resultPreviewCount">287</s:key>
                    <s:key name="runDuration">1.004000</s:key>
                    <s:key name="scanCount">287</s:key>
                    <s:key name="sid">156621733.628</s:key>
                    <s:key name="statusBuckets">0</s:key>
                    <s:key name="ttl">516</s:key>
                    <s:key name="performance">
                        <s:dict>
                        <s:key name="command.fields">
                            <s:dict>
                            <s:key name="duration_secs">0.004</s:key>
                            <s:key name="invocations">4</s:key>
                            <s:key name="input_count">287</s:key>
                            <s:key name="output_count">287</s:key>
                            </s:dict>
                        </s:key>
                        <s:key name="command.search">
                            <s:dict>
                            <s:key name="duration_secs">0.089</s:key>
                            <s:key name="invocations">4</s:key>
                            <s:key name="input_count">0</s:key>
                            <s:key name="output_count">287</s:key>
                            </s:dict>
                        </s:key>
                        <s:key name="command.search.fieldalias">
                            <s:dict>
                            <s:key name="duration_secs">0.002</s:key>
                            <s:key name="invocations">2</s:key>
                            <s:key name="input_count">287</s:key>
                            <s:key name="output_count">287</s:key>
                            </s:dict>
                        </s:key>
                        <s:key name="command.search.index">
                            <s:dict>
                            <s:key name="duration_secs">0.005</s:key>
                            <s:key name="invocations">4</s:key>
                            </s:dict>
                        </s:key>
                        <s:key name="command.search.kv">
                            <s:dict>
                            <s:key name="duration_secs">0.002</s:key>
                            <s:key name="invocations">2</s:key>
                            </s:dict>
                        </s:key>
                        <s:key name="command.search.lookups">
                            <s:dict>
                            <s:key name="duration_secs">0.002</s:key>
                            <s:key name="invocations">2</s:key>
                            <s:key name="input_count">287</s:key>
                            <s:key name="output_count">287</s:key>
                            </s:dict>
                        </s:key>
                        <s:key name="command.search.rawdata">
                            <s:dict>
                            <s:key name="duration_secs">0.083</s:key>
                            <s:key name="invocations">2</s:key>
                            </s:dict>
                        </s:key>
                        <s:key name="command.search.tags">
                            <s:dict>
                            <s:key name="duration_secs">0.004</s:key>
                            <s:key name="invocations">4</s:key>
                            <s:key name="input_count">287</s:key>
                            <s:key name="output_count">287</s:key>
                            </s:dict>
                        </s:key>
                        <s:key name="command.search.typer">
                            <s:dict>
                            <s:key name="duration_secs">0.004</s:key>
                            <s:key name="invocations">4</s:key>
                            <s:key name="input_count">287</s:key>
                            <s:key name="output_count">287</s:key>
                            </s:dict>
                        </s:key>
                        <s:key name="dispatch.createProviderQueue">
                            <s:dict>
                            <s:key name="duration_secs">0.059</s:key>
                            <s:key name="invocations">1</s:key>
                            </s:dict>
                        </s:key>
                        <s:key name="dispatch.evaluate">
                            <s:dict>
                            <s:key name="duration_secs">0.037</s:key>
                            <s:key name="invocations">1</s:key>
                            </s:dict>
                        </s:key>
                        <s:key name="dispatch.evaluate.search">
                            <s:dict>
                            <s:key name="duration_secs">0.036</s:key>
                            <s:key name="invocations">1</s:key>
                            </s:dict>
                        </s:key>
                        <s:key name="dispatch.fetch">
                            <s:dict>
                            <s:key name="duration_secs">0.092</s:key>
                            <s:key name="invocations">5</s:key>
                            </s:dict>
                        </s:key>
                        <s:key name="dispatch.readEventsInResults">
                            <s:dict>
                            <s:key name="duration_secs">0.110</s:key>
                            <s:key name="invocations">1</s:key>
                            </s:dict>
                        </s:key>
                        <s:key name="dispatch.stream.local">
                            <s:dict>
                            <s:key name="duration_secs">0.089</s:key>
                            <s:key name="invocations">4</s:key>
                            </s:dict>
                        </s:key>
                        <s:key name="dispatch.timeline">
                            <s:dict>
                            <s:key name="duration_secs">0.359</s:key>
                            <s:key name="invocations">5</s:key>
                            </s:dict>
                        </s:key>
                        </s:dict>
                    </s:key>
                    <s:key name="messages">
                        <s:dict />
                    </s:key>
                    <s:key name="request">
                        <s:dict>
                        <s:key name="id">mysearch_02151949</s:key>
                        <s:key name="search">search index</s:key>
                        </s:dict>
                    </s:key>
                    <s:key name="eai:acl">
                        <s:dict>
                        <s:key name="perms">
                            <s:dict>
                            <s:key name="read">
                                <s:list>
                                    <s:item>admin</s:item>
                                </s:list>
                            </s:key>
                            <s:key name="write">
                                <s:list>
                                    <s:item>admin</s:item>
                                </s:list>
                            </s:key>
                            </s:dict>
                        </s:key>
                        <s:key name="owner">admin</s:key>
                        <s:key name="modifiable">true</s:key>
                        <s:key name="sharing">global</s:key>
                        <s:key name="app">search</s:key>
                        <s:key name="can_write">true</s:key>
                        </s:dict>
                    </s:key>
                    <s:key name="searchProviders">
                        <s:list>
                            <s:item>mbp15.splunk.com</s:item>
                        </s:list>
                    </s:key>
                </s:dict>
            </content>
        </entry>
        """ )
xmlresponse_job_result = (
        """
        <?xml version='1.0' encoding='UTF-8'?>
        <results preview='0'>
        <meta>
        <fieldOrder>
        <field>_bkt</field>
        <field>_cd</field>
        <field>_indextime</field>
        <field>_raw</field>
        <field>_serial</field>
        <field>_si</field>
        <field>_sourcetype</field>
        <field>_time</field>
        <field>host</field>
        <field>index</field>
        <field>linecount</field>
        <field>source</field>
        <field>sourcetype</field>
        <field>splunk_server</field>
        <field>rule_name</field>
        <field>rule_title</field>
        </fieldOrder>
        </meta>
            <result offset='0'>
                <field k='_bkt'>
                    <value><text>summary~0~0F01DAC7-D81D-4FA2-B76B-72C22992AC98</text></value>
                </field>
                <field k='_cd'>
                    <value><text>0:4</text></value>
                </field>
                <field k='_indextime'>
                    <value><text>1589319138</text></value>
                </field>
                <field k='_raw'><v xml:space='preserve' trunc='0'>search_name=\"Endpoint - High Or Critical Priority Host With Malware - Rule\", count=\"1\", dest=\"DEMAC-ADMIN\", dest_priority=\"high\", info_max_time=\"1524486600.000000000\", info_min_time=\"1524486240.000000000\", info_search_time=\"1524486639.307244000\", lastTime=\"1524486532\", orig_raw=\"2018-04-23 14:28:52,Potential risk found,Computer name: DEMAC-ADMIN,Detection type: Heuristic,First Seen: Symantec has known about this file approximately 1 month.,Application name: Microsoft\\\\xAE Windows\\\\xAE Operating System,Application type: 127,Application version: 6.1.7600.16385,Hash type: SHA-256,Application hash: 335426e42bda4f69a9582f697d01d05e,Company name: BigBank,File size (bytes): 1785,Sensitivity: 2,Detection score: 3,COH Engine Version: 11.3.2.9,Detection Submissions No,Permitted application reason: Not on the permitted application list,Disposition: Good,Download site: https://www.example.org/,Web domain: qdpqjkvtbrsvsfu.com,Downloaded by: c:/users/administrator/desktop/tools/tools/xxxtools.exe,Prevalence: This file has been seen by thousands of Symantec users.,Confidence: Reputation was not used in this detection.,URL Tracking Status: on,Risk Level: High,Detection Source: N/A,Source: Heuristic Scan,Risk name: Trojan.Gen.2,Occurrences: 2,PolicyZZZ,Realtime deferred scanning,Actual action: Left alone,Requested action: Quarantined,Secondary action: Quarantined,Event time: 2018-04-23 14:28:52,Inserted: 2018-04-23 14:28:52,End: 2018-04-23 14:28:52,Domain: Domain A,Group: My Company\\\\Default Group,Server: Example Server C,User: user_b,Source computer: DEMAC-ADMIN,Destination IP:208.67.222.222,Source IP: 10.0.0.1\n\"</v></field>
                <field k='_serial'>
                    <value><text>0</text></value>
                </field>
                <field k='_si'>
                    <value><text>4ea382304ed1</text></value>
                    <value><text>summary</text></value>
                </field>
                <field k='_sourcetype'>
                    <value><text>json</text></value>
                </field>
                <field k='_time'>
                    <value><text>2020-05-19T21:32:18.000+00:00</text></value>
                </field>
                <field k='host'>
                    <value><text>0.0.0.0</text></value>
                </field>
                <field k='index'>
                    <value h='1'><text>summary</text></value>
                </field>
                <field k='linecount'>
                    <value><text>1</text></value>
                </field>
                <field k='source'>
                    <value><text>http-simple</text></value>
                </field>
                <field k='sourcetype'>
                    <value><text>json</text></value>
                </field>
                <field k='splunk_server'>
                    <value><text>4ea382304ed1</text></value>
                </field>
                <field k='rule_name'>
                    <value><text>Malicious Document </text></value>
                </field>
                <field k='rule_title'>
                    <value><text>Splunk Event </text></value>
                </field>
            </result>
        <meta>
        <fieldOrder>
        <field>_bkt</field>
        <field>_cd</field>
        <field>_indextime</field>
        <field>_raw</field>
        <field>_serial</field>
        <field>_si</field>
        <field>_sourcetype</field>
        <field>_subsecond</field>
        <field>_time</field>
        <field>host</field>
        <field>index</field>
        <field>linecount</field>
        <field>source</field>
        <field>sourcetype</field>
        <field>splunk_server</field>
        <field>rule_name</field>
        <field>rule_title</field>
        </fieldOrder>
        </meta>
            <result offset='0'>
                <field k='_bkt'>
                    <value><text>_internal~26~6C4FD68A-A664-44BA-A4B1-22759F85DBE2</text></value>
                </field>
                <field k='_cd'>
                    <value><text>26:314447</text></value>
                </field>
                <field k='_indextime'>
                    <value><text>1378940924</text></value>
                </field>
                <field k='_raw'><v xml:space='preserve' trunc='0'>09-11-2013 16:08:43.567 -0700 INFO Metrics - group=tpool, id=indexertpool, qsize=0, workers=6, qwork_units=0</v></field>
                <field k='_serial'>
                    <value><text>0</text></value>
                </field>
                <field k='_si'>
                    <value><text>TESTBOX-mbp15.local</text></value>
                    <value><text>_internal</text></value>
                </field>
                <field k='_sourcetype'>
                    <value><text>splunkd</text></value>
                </field>
                <field k='_subsecond'>
                    <value><text>.567</text></value>
                </field>
                <field k='_time'>
                    <value><text>2013-09-11T16:08:43.567-07:00</text></value>
                </field>
                <field k='host'>
                    <value><text>TESTBOX-mbp15.local</text></value>
                </field>
                <field k='index'>
                    <value><text>_internal</text></value>
                </field>
                <field k='linecount'>
                    <value><text>1</text></value>
                </field>
                <field k='source'>
                    <value><text>/Applications/splunk/var/log/splunk/metrics.log</text></value>
                </field>
                <field k='sourcetype'>
                    <value><text>splunkd</text></value>
                </field>
                <field k='splunk_server'>
                    <value><text>TESTBOX-mbp15.local</text></value>
                </field>
                <field k='rule_name'>
                    <value><text>Metrics </text></value>
                </field>
                <field k='rule_title'>
                    <value><text>Splunk Event </text></value>
                </field>
            </result>
        <meta>
        <fieldOrder>
        <field>_bkt</field>
        <field>_cd</field>
        <field>_indextime</field>
        <field>_raw</field>
        <field>_serial</field>
        <field>_si</field>
        <field>_sourcetype</field>
        <field>_subsecond</field>
        <field>_time</field>
        <field>host</field>
        <field>index</field>
        <field>linecount</field>
        <field>source</field>
        <field>sourcetype</field>
        <field>splunk_server</field>
        <field>rule_name</field>
        <field>rule_title</field>
        </fieldOrder>
        </meta>
            <result offset='0'>
                <field k='_bkt'>
                    <value><text>_external~26~A454554-A664-44BA-A4B1-22759F85DBE2</text></value>
                </field>
                <field k='_cd'>
                    <value><text>26:314447</text></value>
                </field>
                <field k='_indextime'>
                    <value><text>2323943974</text></value>
                </field>
                <field k='_raw'><v xml:space='preserve' trunc='0'>search_name=\"Endpoint - High Or Critical Priority Host With Malware - Rule\", count=\"1\", dest=\"DEMAC-ADMIN\", dest_priority=\"high\", info_max_time=\"1524486600.000000000\", info_min_time=\"1524486240.000000000\", info_search_time=\"1524486639.307244000\", lastTime=\"1524486532\", orig_raw=\"2018-04-23 14:28:52,Potential risk found,Computer name: DEMAC-ADMIN,Detection type: Heuristic,First Seen: Symantec has known about this file approximately 1 month.,Application name: Microsoft\\\\xAE Windows\\\\xAE Operating System,</v></field>
                <field k='_serial'>
                    <value><text>0</text></value>
                </field>
                <field k='_si'>
                    <value><text>Lab007</text></value>
                    <value><text>_external</text></value>
                </field>
                <field k='_sourcetype'>
                    <value><text>splunkd</text></value>
                </field>
                <field k='_subsecond'>
                    <value><text>.567</text></value>
                </field>
                <field k='_time'>
                    <value><text>2013-09-11T16:08:43.567-07:00</text></value>
                </field>
                <field k='host'>
                    <value><text>TESTBOX-mbp15.local</text></value>
                </field>
                <field k='index'>
                    <value><text>_internal</text></value>
                </field>
                <field k='linecount'>
                    <value><text>1</text></value>
                </field>
                <field k='source'>
                    <value><text>/Applications/splunk/var/log/splunk/metrics.log</text></value>
                </field>
                <field k='sourcetype'>
                    <value><text>splunkd</text></value>
                </field>
                <field k='splunk_server'>
                    <value><text>TESTBOX-mbp15.local</text></value>
                </field>
                <field k='rule_name'>
                    <value><text>Infected Host </text></value>
                </field>
                <field k='rule_title'>
                    <value><text>Splunk Event </text></value>
                </field>
            </result>      
        </results>
        """
    )
xmlresponse_index_summary = (
    """
        <?xml version="1.0" encoding="UTF-8"?>
        <!--This is to override browser formatting; see server.conf[httpServer] to disable. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .-->
        <?xml-stylesheet type="text/xml" href="/static/atom.xsl"?>
        <feed xmlns="http://www.w3.org/2005/Atom" xmlns:opensearch="http://a9.com/-/spec/opensearch/1.1/" xmlns:s="http://dev.splunk.com/ns/rest">
            <title>indexes</title>
            <id>https://0.0.0.0:32787/services/data/indexes</id>
            <updated>2020-05-11T17:33:26+00:00</updated>
            <generator build="a6754d8441bf" version="8.0.3" />
            <author>
                <name>Splunk</name>
            </author>
            <link href="/services/data/indexes/_new" rel="create" />
            <link href="/services/data/indexes/_reload" rel="_reload" />
            <link href="/services/data/indexes/_acl" rel="_acl" />
            <opensearch:totalResults>9</opensearch:totalResults>
            <opensearch:itemsPerPage>30</opensearch:itemsPerPage>
            <opensearch:startIndex>0</opensearch:startIndex>
            <s:messages />
            <entry>
                    <title>summary</title>
                    <id>https://0.0.0.0:32787/servicesNS/nobody/system/data/indexes/summary</id>
                    <updated>2020-05-10T01:35:13+00:00</updated>
                    <link href="/servicesNS/nobody/system/data/indexes/summary" rel="alternate" />
                    <author>
                    <name>nobody</name>
                    </author>
                    <link href="/servicesNS/nobody/system/data/indexes/summary" rel="list" />
                    <link href="/servicesNS/nobody/system/data/indexes/summary/_reload" rel="_reload" />
                    <link href="/servicesNS/nobody/system/data/indexes/summary" rel="edit" />
                    <link href="/servicesNS/nobody/system/data/indexes/summary/disable" rel="disable" />
                    <content type="text/xml">
                    <s:dict>
                        <s:key name="archiver.enableDataArchive">0</s:key>
                        <s:key name="archiver.maxDataArchiveRetentionPeriod">0</s:key>
                        <s:key name="assureUTF8">0</s:key>
                        <s:key name="bucketRebuildMemoryHint">auto</s:key>
                        <s:key name="coldPath">$SPLUNK_DB/summarydb/colddb</s:key>
                        <s:key name="coldPath.maxDataSizeMB">0</s:key>
                        <s:key name="coldPath_expanded">/opt/splunk/var/lib/splunk/summarydb/colddb</s:key>
                        <s:key name="coldToFrozenDir" />
                        <s:key name="coldToFrozenScript" />
                        <s:key name="compressRawdata">1</s:key>
                        <s:key name="currentDBSizeMB">1</s:key>
                        <s:key name="datatype">event</s:key>
                        <s:key name="defaultDatabase">main</s:key>
                        <s:key name="disabled">0</s:key>
                        <s:key name="eai:acl">
                        <s:dict>
                            <s:key name="app">system</s:key>
                            <s:key name="can_list">1</s:key>
                            <s:key name="can_write">1</s:key>
                            <s:key name="modifiable">0</s:key>
                            <s:key name="owner">nobody</s:key>
                            <s:key name="perms">
                            <s:dict>
                                <s:key name="read">
                                <s:list>
                                    <s:item>*</s:item>
                                </s:list>
                                </s:key>
                                <s:key name="write">
                                <s:list>
                                    <s:item>admin</s:item>
                                    <s:item>splunk-system-role</s:item>
                                </s:list>
                                </s:key>
                            </s:dict>
                            </s:key>
                            <s:key name="removable">0</s:key>
                            <s:key name="sharing">system</s:key>
                        </s:dict>
                        </s:key>
                        <s:key name="enableDataIntegrityControl">0</s:key>
                        <s:key name="enableOnlineBucketRepair">1</s:key>
                        <s:key name="enableRealtimeSearch">1</s:key>
                        <s:key name="enableTsidxReduction">0</s:key>
                        <s:key name="fileSystemExecutorWorkers">5</s:key>
                        <s:key name="frozenTimePeriodInSecs">188697600</s:key>
                        <s:key name="homePath">$SPLUNK_DB/summarydb/db</s:key>
                        <s:key name="homePath.maxDataSizeMB">0</s:key>
                        <s:key name="homePath_expanded">/opt/splunk/var/lib/splunk/summarydb/db</s:key>
                        <s:key name="hotBucketTimeRefreshInterval">10</s:key>
                        <s:key name="indexThreads">auto</s:key>
                        <s:key name="isInternal">0</s:key>
                        <s:key name="isReady">1</s:key>
                        <s:key name="isVirtual">0</s:key>
                        <s:key name="journalCompression">gzip</s:key>
                        <s:key name="lastInitSequenceNumber">1</s:key>
                        <s:key name="lastInitTime">1589074513</s:key>
                        <s:key name="maxBloomBackfillBucketAge">30d</s:key>
                        <s:key name="maxBucketSizeCacheEntries">0</s:key>
                        <s:key name="maxConcurrentOptimizes">6</s:key>
                        <s:key name="maxDataSize">auto</s:key>
                        <s:key name="maxGlobalDataSizeMB">0</s:key>
                        <s:key name="maxGlobalRawDataSizeMB">0</s:key>
                        <s:key name="maxHotBuckets">3</s:key>
                        <s:key name="maxHotIdleSecs">0</s:key>
                        <s:key name="maxHotSpanSecs">7776000</s:key>
                        <s:key name="maxMemMB">5</s:key>
                        <s:key name="maxMetaEntries">1000000</s:key>
                        <s:key name="maxRunningProcessGroups">8</s:key>
                        <s:key name="maxRunningProcessGroupsLowPriority">1</s:key>
                        <s:key name="maxTime" />
                        <s:key name="maxTimeUnreplicatedNoAcks">300</s:key>
                        <s:key name="maxTimeUnreplicatedWithAcks">60</s:key>
                        <s:key name="maxTotalDataSizeMB">500000</s:key>
                        <s:key name="maxWarmDBCount">300</s:key>
                        <s:key name="memPoolMB">auto</s:key>
                        <s:key name="metric.compressionBlockSize">1024</s:key>
                        <s:key name="metric.enableFloatingPointCompression">1</s:key>
                        <s:key name="metric.tsidxTargetSizeMB">1500</s:key>
                        <s:key name="minHotIdleSecsBeforeForceRoll">auto</s:key>
                        <s:key name="minRawFileSyncSecs">disable</s:key>
                        <s:key name="minStreamGroupQueueSize">2000</s:key>
                        <s:key name="minTime" />
                        <s:key name="partialServiceMetaPeriod">0</s:key>
                        <s:key name="processTrackerServiceInterval">1</s:key>
                        <s:key name="quarantineFutureSecs">2592000</s:key>
                        <s:key name="quarantinePastSecs">77760000</s:key>
                        <s:key name="rawChunkSizeBytes">131072</s:key>
                        <s:key name="repFactor">0</s:key>
                        <s:key name="rotatePeriodInSecs">60</s:key>
                        <s:key name="rtRouterQueueSize" />
                        <s:key name="rtRouterThreads" />
                        <s:key name="selfStorageThreads" />
                        <s:key name="serviceInactiveIndexesPeriod">60</s:key>
                        <s:key name="serviceMetaPeriod">25</s:key>
                        <s:key name="serviceOnlyAsNeeded">1</s:key>
                        <s:key name="serviceSubtaskTimingPeriod">30</s:key>
                        <s:key name="splitByIndexKeys" />
                        <s:key name="streamingTargetTsidxSyncPeriodMsec">5000</s:key>
                        <s:key name="summaryHomePath_expanded">/opt/splunk/var/lib/splunk/summarydb/summary</s:key>
                        <s:key name="suppressBannerList" />
                        <s:key name="suspendHotRollByDeleteQuery">0</s:key>
                        <s:key name="sync">0</s:key>
                        <s:key name="syncMeta">1</s:key>
                        <s:key name="thawedPath">$SPLUNK_DB/summarydb/thaweddb</s:key>
                        <s:key name="thawedPath_expanded">/opt/splunk/var/lib/splunk/summarydb/thaweddb</s:key>
                        <s:key name="throttleCheckPeriod">15</s:key>
                        <s:key name="timePeriodInSecBeforeTsidxReduction">604800</s:key>
                        <s:key name="totalEventCount">0</s:key>
                        <s:key name="tsidxReductionCheckPeriodInSec">600</s:key>
                        <s:key name="tsidxTargetSizeMB">1500</s:key>
                        <s:key name="tsidxWritingLevel" />
                        <s:key name="tstatsHomePath">volume:_splunk_summaries/summarydb/datamodel_summary</s:key>
                        <s:key name="tstatsHomePath_expanded">/opt/splunk/var/lib/splunk/summarydb/datamodel_summary</s:key>
                        <s:key name="waitPeriodInSecsForManifestWrite">60</s:key>
                        <s:key name="warmToColdScript" />
                    </s:dict>
                </content>
            </entry>
        </feed>
    """

)
xmlresponse_index_internal = (
    """
        <?xml version="1.0" encoding="UTF-8"?>
        <!--This is to override browser formatting; see server.conf[httpServer] to disable. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .-->
        <?xml-stylesheet type="text/xml" href="/static/atom.xsl"?>
        <feed xmlns="http://www.w3.org/2005/Atom" xmlns:opensearch="http://a9.com/-/spec/opensearch/1.1/" xmlns:s="http://dev.splunk.com/ns/rest">
            <title>indexes</title>
            <id>https://0.0.0.0:32787/services/data/indexes</id>
            <updated>2020-05-11T17:33:26+00:00</updated>
            <generator build="a6754d8441bf" version="8.0.3" />
            <author>
                <name>Splunk</name>
            </author>
            <link href="/services/data/indexes/_new" rel="create" />
            <link href="/services/data/indexes/_reload" rel="_reload" />
            <link href="/services/data/indexes/_acl" rel="_acl" />
            <opensearch:totalResults>9</opensearch:totalResults>
            <opensearch:itemsPerPage>30</opensearch:itemsPerPage>
            <opensearch:startIndex>0</opensearch:startIndex>
            <s:messages />
            <entry>
                    <title>_internal</title>
                    <id>https://0.0.0.0:32787/servicesNS/nobody/system/data/indexes/_internal</id>
                    <updated>2020-05-11T17:33:25+00:00</updated>
                    <link href="/servicesNS/nobody/system/data/indexes/_internal" rel="alternate" />
                    <author>
                    <name>nobody</name>
                    </author>
                    <link href="/servicesNS/nobody/system/data/indexes/_internal" rel="list" />
                    <link href="/servicesNS/nobody/system/data/indexes/_internal/_reload" rel="_reload" />
                    <link href="/servicesNS/nobody/system/data/indexes/_internal" rel="edit" />
                    <link href="/servicesNS/nobody/system/data/indexes/_internal/disable" rel="disable" />
                    <content type="text/xml">
                    <s:dict>
                        <s:key name="archiver.enableDataArchive">0</s:key>
                        <s:key name="archiver.maxDataArchiveRetentionPeriod">0</s:key>
                        <s:key name="assureUTF8">0</s:key>
                        <s:key name="bucketRebuildMemoryHint">auto</s:key>
                        <s:key name="coldPath">$SPLUNK_DB/_internaldb/colddb</s:key>
                        <s:key name="coldPath.maxDataSizeMB">0</s:key>
                        <s:key name="coldPath_expanded">/opt/splunk/var/lib/splunk/_internaldb/colddb</s:key>
                        <s:key name="coldToFrozenDir" />
                        <s:key name="coldToFrozenScript" />
                        <s:key name="compressRawdata">1</s:key>
                        <s:key name="currentDBSizeMB">16</s:key>
                        <s:key name="datatype">event</s:key>
                        <s:key name="defaultDatabase">main</s:key>
                        <s:key name="disabled">0</s:key>
                        <s:key name="eai:acl">
                        <s:dict>
                            <s:key name="app">system</s:key>
                            <s:key name="can_list">1</s:key>
                            <s:key name="can_write">1</s:key>
                            <s:key name="modifiable">0</s:key>
                            <s:key name="owner">nobody</s:key>
                            <s:key name="perms">
                            <s:dict>
                                <s:key name="read">
                                <s:list>
                                    <s:item>*</s:item>
                                </s:list>
                                </s:key>
                                <s:key name="write">
                                <s:list>
                                    <s:item>admin</s:item>
                                    <s:item>splunk-system-role</s:item>
                                </s:list>
                                </s:key>
                            </s:dict>
                            </s:key>
                            <s:key name="removable">0</s:key>
                            <s:key name="sharing">system</s:key>
                        </s:dict>
                        </s:key>
                        <s:key name="enableDataIntegrityControl">0</s:key>
                        <s:key name="enableOnlineBucketRepair">1</s:key>
                        <s:key name="enableRealtimeSearch">1</s:key>
                        <s:key name="enableTsidxReduction">0</s:key>
                        <s:key name="fileSystemExecutorWorkers">5</s:key>
                        <s:key name="frozenTimePeriodInSecs">2592000</s:key>
                        <s:key name="homePath">$SPLUNK_DB/_internaldb/db</s:key>
                        <s:key name="homePath.maxDataSizeMB">0</s:key>
                        <s:key name="homePath_expanded">/opt/splunk/var/lib/splunk/_internaldb/db</s:key>
                        <s:key name="hotBucketTimeRefreshInterval">10</s:key>
                        <s:key name="indexThreads">auto</s:key>
                        <s:key name="isInternal">1</s:key>
                        <s:key name="isReady">1</s:key>
                        <s:key name="isVirtual">0</s:key>
                        <s:key name="journalCompression">gzip</s:key>
                        <s:key name="lastInitSequenceNumber">1</s:key>
                        <s:key name="lastInitTime">1589074513</s:key>
                        <s:key name="maxBloomBackfillBucketAge">30d</s:key>
                        <s:key name="maxBucketSizeCacheEntries">0</s:key>
                        <s:key name="maxConcurrentOptimizes">6</s:key>
                        <s:key name="maxDataSize">1000</s:key>
                        <s:key name="maxGlobalDataSizeMB">0</s:key>
                        <s:key name="maxGlobalRawDataSizeMB">0</s:key>
                        <s:key name="maxHotBuckets">3</s:key>
                        <s:key name="maxHotIdleSecs">0</s:key>
                        <s:key name="maxHotSpanSecs">432000</s:key>
                        <s:key name="maxMemMB">5</s:key>
                        <s:key name="maxMetaEntries">1000000</s:key>
                        <s:key name="maxRunningProcessGroups">8</s:key>
                        <s:key name="maxRunningProcessGroupsLowPriority">1</s:key>
                        <s:key name="maxTime">2020-05-11T17:33:30+0000</s:key>
                        <s:key name="maxTimeUnreplicatedNoAcks">300</s:key>
                        <s:key name="maxTimeUnreplicatedWithAcks">60</s:key>
                        <s:key name="maxTotalDataSizeMB">500000</s:key>
                        <s:key name="maxWarmDBCount">300</s:key>
                        <s:key name="memPoolMB">auto</s:key>
                        <s:key name="metric.compressionBlockSize">1024</s:key>
                        <s:key name="metric.enableFloatingPointCompression">1</s:key>
                        <s:key name="metric.tsidxTargetSizeMB">1500</s:key>
                        <s:key name="minHotIdleSecsBeforeForceRoll">auto</s:key>
                        <s:key name="minRawFileSyncSecs">disable</s:key>
                        <s:key name="minStreamGroupQueueSize">2000</s:key>
                        <s:key name="minTime">2020-05-10T01:35:06+0000</s:key>
                        <s:key name="partialServiceMetaPeriod">0</s:key>
                        <s:key name="processTrackerServiceInterval">1</s:key>
                        <s:key name="quarantineFutureSecs">2592000</s:key>
                        <s:key name="quarantinePastSecs">77760000</s:key>
                        <s:key name="rawChunkSizeBytes">131072</s:key>
                        <s:key name="repFactor">0</s:key>
                        <s:key name="rotatePeriodInSecs">60</s:key>
                        <s:key name="rtRouterQueueSize" />
                        <s:key name="rtRouterThreads" />
                        <s:key name="selfStorageThreads" />
                        <s:key name="serviceInactiveIndexesPeriod">60</s:key>
                        <s:key name="serviceMetaPeriod">25</s:key>
                        <s:key name="serviceOnlyAsNeeded">1</s:key>
                        <s:key name="serviceSubtaskTimingPeriod">30</s:key>
                        <s:key name="splitByIndexKeys" />
                        <s:key name="streamingTargetTsidxSyncPeriodMsec">5000</s:key>
                        <s:key name="summaryHomePath_expanded">/opt/splunk/var/lib/splunk/_internaldb/summary</s:key>
                        <s:key name="suppressBannerList" />
                        <s:key name="suspendHotRollByDeleteQuery">0</s:key>
                        <s:key name="sync">0</s:key>
                        <s:key name="syncMeta">1</s:key>
                        <s:key name="thawedPath">$SPLUNK_DB/_internaldb/thaweddb</s:key>
                        <s:key name="thawedPath_expanded">/opt/splunk/var/lib/splunk/_internaldb/thaweddb</s:key>
                        <s:key name="throttleCheckPeriod">15</s:key>
                        <s:key name="timePeriodInSecBeforeTsidxReduction">604800</s:key>
                        <s:key name="totalEventCount">141501</s:key>
                        <s:key name="tsidxReductionCheckPeriodInSec">600</s:key>
                        <s:key name="tsidxTargetSizeMB">1500</s:key>
                        <s:key name="tsidxWritingLevel" />
                        <s:key name="tstatsHomePath">volume:_splunk_summaries/_internaldb/datamodel_summary</s:key>
                        <s:key name="tstatsHomePath_expanded">/opt/splunk/var/lib/splunk/_internaldb/datamodel_summary</s:key>
                        <s:key name="waitPeriodInSecsForManifestWrite">60</s:key>
                        <s:key name="warmToColdScript" />
                    </s:dict>
                    </content>
                </entry>
            </feed>
    """
)
xmlresponse_index_audit = (
    """
        <?xml version="1.0" encoding="UTF-8"?>
        <!--This is to override browser formatting; see server.conf[httpServer] to disable. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .-->
        <?xml-stylesheet type="text/xml" href="/static/atom.xsl"?>
        <feed xmlns="http://www.w3.org/2005/Atom" xmlns:opensearch="http://a9.com/-/spec/opensearch/1.1/" xmlns:s="http://dev.splunk.com/ns/rest">
            <title>indexes</title>
            <id>https://0.0.0.0:32787/services/data/indexes</id>
            <updated>2020-05-11T17:33:26+00:00</updated>
            <generator build="a6754d8441bf" version="8.0.3" />
            <author>
                <name>Splunk</name>
            </author>
            <link href="/services/data/indexes/_new" rel="create" />
            <link href="/services/data/indexes/_reload" rel="_reload" />
            <link href="/services/data/indexes/_acl" rel="_acl" />
            <opensearch:totalResults>9</opensearch:totalResults>
            <opensearch:itemsPerPage>30</opensearch:itemsPerPage>
            <opensearch:startIndex>0</opensearch:startIndex>
            <s:messages />
            <entry>
                <title>_audit</title>
                <id>https://0.0.0.0:32787/servicesNS/nobody/system/data/indexes/_audit</id>
                <updated>2020-05-11T17:33:26+00:00</updated>
                <link href="/servicesNS/nobody/system/data/indexes/_audit" rel="alternate" />
                <author>
                <name>nobody</name>
                </author>
                <link href="/servicesNS/nobody/system/data/indexes/_audit" rel="list" />
                <link href="/servicesNS/nobody/system/data/indexes/_audit/_reload" rel="_reload" />
                <link href="/servicesNS/nobody/system/data/indexes/_audit" rel="edit" />
                <link href="/servicesNS/nobody/system/data/indexes/_audit/disable" rel="disable" />
                <content type="text/xml">
                    <s:dict>
                        <s:key name="archiver.enableDataArchive">0</s:key>
                        <s:key name="archiver.maxDataArchiveRetentionPeriod">0</s:key>
                        <s:key name="assureUTF8">0</s:key>
                        <s:key name="bucketRebuildMemoryHint">auto</s:key>
                        <s:key name="coldPath">$SPLUNK_DB/audit/colddb</s:key>
                        <s:key name="coldPath.maxDataSizeMB">0</s:key>
                        <s:key name="coldPath_expanded">/opt/splunk/var/lib/splunk/audit/colddb</s:key>
                        <s:key name="coldToFrozenDir" />
                        <s:key name="coldToFrozenScript" />
                        <s:key name="compressRawdata">1</s:key>
                        <s:key name="currentDBSizeMB">1</s:key>
                        <s:key name="datatype">event</s:key>
                        <s:key name="defaultDatabase">main</s:key>
                        <s:key name="disabled">0</s:key>
                        <s:key name="eai:acl">
                        <s:dict>
                            <s:key name="app">system</s:key>
                            <s:key name="can_list">1</s:key>
                            <s:key name="can_write">1</s:key>
                            <s:key name="modifiable">0</s:key>
                            <s:key name="owner">nobody</s:key>
                            <s:key name="perms">
                            <s:dict>
                                <s:key name="read">
                                <s:list>
                                    <s:item>*</s:item>
                                </s:list>
                                </s:key>
                                <s:key name="write">
                                <s:list>
                                    <s:item>admin</s:item>
                                    <s:item>splunk-system-role</s:item>
                                </s:list>
                                </s:key>
                            </s:dict>
                            </s:key>
                            <s:key name="removable">0</s:key>
                            <s:key name="sharing">system</s:key>
                        </s:dict>
                        </s:key>
                        <s:key name="enableDataIntegrityControl">0</s:key>
                        <s:key name="enableOnlineBucketRepair">1</s:key>
                        <s:key name="enableRealtimeSearch">1</s:key>
                        <s:key name="enableTsidxReduction">0</s:key>
                        <s:key name="fileSystemExecutorWorkers">5</s:key>
                        <s:key name="frozenTimePeriodInSecs">188697600</s:key>
                        <s:key name="homePath">$SPLUNK_DB/audit/db</s:key>
                        <s:key name="homePath.maxDataSizeMB">0</s:key>
                        <s:key name="homePath_expanded">/opt/splunk/var/lib/splunk/audit/db</s:key>
                        <s:key name="hotBucketTimeRefreshInterval">10</s:key>
                        <s:key name="indexThreads">auto</s:key>
                        <s:key name="isInternal">1</s:key>
                        <s:key name="isReady">1</s:key>
                        <s:key name="isVirtual">0</s:key>
                        <s:key name="journalCompression">gzip</s:key>
                        <s:key name="lastInitSequenceNumber">1</s:key>
                        <s:key name="lastInitTime">1589074513</s:key>
                        <s:key name="maxBloomBackfillBucketAge">30d</s:key>
                        <s:key name="maxBucketSizeCacheEntries">0</s:key>
                        <s:key name="maxConcurrentOptimizes">6</s:key>
                        <s:key name="maxDataSize">auto</s:key>
                        <s:key name="maxGlobalDataSizeMB">0</s:key>
                        <s:key name="maxGlobalRawDataSizeMB">0</s:key>
                        <s:key name="maxHotBuckets">3</s:key>
                        <s:key name="maxHotIdleSecs">0</s:key>
                        <s:key name="maxHotSpanSecs">7776000</s:key>
                        <s:key name="maxMemMB">5</s:key>
                        <s:key name="maxMetaEntries">1000000</s:key>
                        <s:key name="maxRunningProcessGroups">8</s:key>
                        <s:key name="maxRunningProcessGroupsLowPriority">1</s:key>
                        <s:key name="maxTime">2020-05-11T17:33:24+0000</s:key>
                        <s:key name="maxTimeUnreplicatedNoAcks">300</s:key>
                        <s:key name="maxTimeUnreplicatedWithAcks">60</s:key>
                        <s:key name="maxTotalDataSizeMB">500000</s:key>
                        <s:key name="maxWarmDBCount">300</s:key>
                        <s:key name="memPoolMB">auto</s:key>
                        <s:key name="metric.compressionBlockSize">1024</s:key>
                        <s:key name="metric.enableFloatingPointCompression">1</s:key>
                        <s:key name="metric.tsidxTargetSizeMB">1500</s:key>
                        <s:key name="minHotIdleSecsBeforeForceRoll">auto</s:key>
                        <s:key name="minRawFileSyncSecs">disable</s:key>
                        <s:key name="minStreamGroupQueueSize">2000</s:key>
                        <s:key name="minTime">2020-05-10T01:35:12+0000</s:key>
                        <s:key name="partialServiceMetaPeriod">0</s:key>
                        <s:key name="processTrackerServiceInterval">1</s:key>
                        <s:key name="quarantineFutureSecs">2592000</s:key>
                        <s:key name="quarantinePastSecs">77760000</s:key>
                        <s:key name="rawChunkSizeBytes">131072</s:key>
                        <s:key name="repFactor">0</s:key>
                        <s:key name="rotatePeriodInSecs">60</s:key>
                        <s:key name="rtRouterQueueSize" />
                        <s:key name="rtRouterThreads" />
                        <s:key name="selfStorageThreads" />
                        <s:key name="serviceInactiveIndexesPeriod">60</s:key>
                        <s:key name="serviceMetaPeriod">25</s:key>
                        <s:key name="serviceOnlyAsNeeded">1</s:key>
                        <s:key name="serviceSubtaskTimingPeriod">30</s:key>
                        <s:key name="splitByIndexKeys" />
                        <s:key name="streamingTargetTsidxSyncPeriodMsec">5000</s:key>
                        <s:key name="summaryHomePath_expanded">/opt/splunk/var/lib/splunk/audit/summary</s:key>
                        <s:key name="suppressBannerList" />
                        <s:key name="suspendHotRollByDeleteQuery">0</s:key>
                        <s:key name="sync">0</s:key>
                        <s:key name="syncMeta">1</s:key>
                        <s:key name="thawedPath">$SPLUNK_DB/audit/thaweddb</s:key>
                        <s:key name="thawedPath_expanded">/opt/splunk/var/lib/splunk/audit/thaweddb</s:key>
                        <s:key name="throttleCheckPeriod">15</s:key>
                        <s:key name="timePeriodInSecBeforeTsidxReduction">604800</s:key>
                        <s:key name="totalEventCount">4834</s:key>
                        <s:key name="tsidxReductionCheckPeriodInSec">600</s:key>
                        <s:key name="tsidxTargetSizeMB">1500</s:key>
                        <s:key name="tsidxWritingLevel" />
                        <s:key name="tstatsHomePath">volume:_splunk_summaries/audit/datamodel_summary</s:key>
                        <s:key name="tstatsHomePath_expanded">/opt/splunk/var/lib/splunk/audit/datamodel_summary</s:key>
                        <s:key name="waitPeriodInSecsForManifestWrite">60</s:key>
                        <s:key name="warmToColdScript" />
                    </s:dict>
                    </content>
                </entry>
            </feed>
            """
)
xmlresponse_get_index = (
    """
        <?xml version="1.0" encoding="UTF-8"?>
        <!--This is to override browser formatting; see server.conf[httpServer] to disable. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .-->
        <?xml-stylesheet type="text/xml" href="/static/atom.xsl"?>
        <feed xmlns="http://www.w3.org/2005/Atom" xmlns:opensearch="http://a9.com/-/spec/opensearch/1.1/" xmlns:s="http://dev.splunk.com/ns/rest">
            <title>indexes</title>
            <id>https://0.0.0.0:32787/services/data/indexes</id>
            <updated>2020-05-11T17:33:26+00:00</updated>
            <generator build="a6754d8441bf" version="8.0.3" />
            <author>
                <name>Splunk</name>
            </author>
            <link href="/services/data/indexes/_new" rel="create" />
            <link href="/services/data/indexes/_reload" rel="_reload" />
            <link href="/services/data/indexes/_acl" rel="_acl" />
            <opensearch:totalResults>9</opensearch:totalResults>
            <opensearch:itemsPerPage>30</opensearch:itemsPerPage>
            <opensearch:startIndex>0</opensearch:startIndex>
            <s:messages />
            <entry>
                <title>_audit</title>
                <id>https://0.0.0.0:32787/servicesNS/nobody/system/data/indexes/_audit</id>
                <updated>2020-05-11T17:33:26+00:00</updated>
                <link href="/servicesNS/nobody/system/data/indexes/_audit" rel="alternate" />
                <author>
                <name>nobody</name>
                </author>
                <link href="/servicesNS/nobody/system/data/indexes/_audit" rel="list" />
                <link href="/servicesNS/nobody/system/data/indexes/_audit/_reload" rel="_reload" />
                <link href="/servicesNS/nobody/system/data/indexes/_audit" rel="edit" />
                <link href="/servicesNS/nobody/system/data/indexes/_audit/disable" rel="disable" />
                <content type="text/xml">
                    <s:dict>
                        <s:key name="archiver.enableDataArchive">0</s:key>
                        <s:key name="archiver.maxDataArchiveRetentionPeriod">0</s:key>
                        <s:key name="assureUTF8">0</s:key>
                        <s:key name="bucketRebuildMemoryHint">auto</s:key>
                        <s:key name="coldPath">$SPLUNK_DB/audit/colddb</s:key>
                        <s:key name="coldPath.maxDataSizeMB">0</s:key>
                        <s:key name="coldPath_expanded">/opt/splunk/var/lib/splunk/audit/colddb</s:key>
                        <s:key name="coldToFrozenDir" />
                        <s:key name="coldToFrozenScript" />
                        <s:key name="compressRawdata">1</s:key>
                        <s:key name="currentDBSizeMB">1</s:key>
                        <s:key name="datatype">event</s:key>
                        <s:key name="defaultDatabase">main</s:key>
                        <s:key name="disabled">0</s:key>
                        <s:key name="eai:acl">
                        <s:dict>
                            <s:key name="app">system</s:key>
                            <s:key name="can_list">1</s:key>
                            <s:key name="can_write">1</s:key>
                            <s:key name="modifiable">0</s:key>
                            <s:key name="owner">nobody</s:key>
                            <s:key name="perms">
                            <s:dict>
                                <s:key name="read">
                                <s:list>
                                    <s:item>*</s:item>
                                </s:list>
                                </s:key>
                                <s:key name="write">
                                <s:list>
                                    <s:item>admin</s:item>
                                    <s:item>splunk-system-role</s:item>
                                </s:list>
                                </s:key>
                            </s:dict>
                            </s:key>
                            <s:key name="removable">0</s:key>
                            <s:key name="sharing">system</s:key>
                        </s:dict>
                        </s:key>
                        <s:key name="enableDataIntegrityControl">0</s:key>
                        <s:key name="enableOnlineBucketRepair">1</s:key>
                        <s:key name="enableRealtimeSearch">1</s:key>
                        <s:key name="enableTsidxReduction">0</s:key>
                        <s:key name="fileSystemExecutorWorkers">5</s:key>
                        <s:key name="frozenTimePeriodInSecs">188697600</s:key>
                        <s:key name="homePath">$SPLUNK_DB/audit/db</s:key>
                        <s:key name="homePath.maxDataSizeMB">0</s:key>
                        <s:key name="homePath_expanded">/opt/splunk/var/lib/splunk/audit/db</s:key>
                        <s:key name="hotBucketTimeRefreshInterval">10</s:key>
                        <s:key name="indexThreads">auto</s:key>
                        <s:key name="isInternal">1</s:key>
                        <s:key name="isReady">1</s:key>
                        <s:key name="isVirtual">0</s:key>
                        <s:key name="journalCompression">gzip</s:key>
                        <s:key name="lastInitSequenceNumber">1</s:key>
                        <s:key name="lastInitTime">1589074513</s:key>
                        <s:key name="maxBloomBackfillBucketAge">30d</s:key>
                        <s:key name="maxBucketSizeCacheEntries">0</s:key>
                        <s:key name="maxConcurrentOptimizes">6</s:key>
                        <s:key name="maxDataSize">auto</s:key>
                        <s:key name="maxGlobalDataSizeMB">0</s:key>
                        <s:key name="maxGlobalRawDataSizeMB">0</s:key>
                        <s:key name="maxHotBuckets">3</s:key>
                        <s:key name="maxHotIdleSecs">0</s:key>
                        <s:key name="maxHotSpanSecs">7776000</s:key>
                        <s:key name="maxMemMB">5</s:key>
                        <s:key name="maxMetaEntries">1000000</s:key>
                        <s:key name="maxRunningProcessGroups">8</s:key>
                        <s:key name="maxRunningProcessGroupsLowPriority">1</s:key>
                        <s:key name="maxTime">2020-05-11T17:33:24+0000</s:key>
                        <s:key name="maxTimeUnreplicatedNoAcks">300</s:key>
                        <s:key name="maxTimeUnreplicatedWithAcks">60</s:key>
                        <s:key name="maxTotalDataSizeMB">500000</s:key>
                        <s:key name="maxWarmDBCount">300</s:key>
                        <s:key name="memPoolMB">auto</s:key>
                        <s:key name="metric.compressionBlockSize">1024</s:key>
                        <s:key name="metric.enableFloatingPointCompression">1</s:key>
                        <s:key name="metric.tsidxTargetSizeMB">1500</s:key>
                        <s:key name="minHotIdleSecsBeforeForceRoll">auto</s:key>
                        <s:key name="minRawFileSyncSecs">disable</s:key>
                        <s:key name="minStreamGroupQueueSize">2000</s:key>
                        <s:key name="minTime">2020-05-10T01:35:12+0000</s:key>
                        <s:key name="partialServiceMetaPeriod">0</s:key>
                        <s:key name="processTrackerServiceInterval">1</s:key>
                        <s:key name="quarantineFutureSecs">2592000</s:key>
                        <s:key name="quarantinePastSecs">77760000</s:key>
                        <s:key name="rawChunkSizeBytes">131072</s:key>
                        <s:key name="repFactor">0</s:key>
                        <s:key name="rotatePeriodInSecs">60</s:key>
                        <s:key name="rtRouterQueueSize" />
                        <s:key name="rtRouterThreads" />
                        <s:key name="selfStorageThreads" />
                        <s:key name="serviceInactiveIndexesPeriod">60</s:key>
                        <s:key name="serviceMetaPeriod">25</s:key>
                        <s:key name="serviceOnlyAsNeeded">1</s:key>
                        <s:key name="serviceSubtaskTimingPeriod">30</s:key>
                        <s:key name="splitByIndexKeys" />
                        <s:key name="streamingTargetTsidxSyncPeriodMsec">5000</s:key>
                        <s:key name="summaryHomePath_expanded">/opt/splunk/var/lib/splunk/audit/summary</s:key>
                        <s:key name="suppressBannerList" />
                        <s:key name="suspendHotRollByDeleteQuery">0</s:key>
                        <s:key name="sync">0</s:key>
                        <s:key name="syncMeta">1</s:key>
                        <s:key name="thawedPath">$SPLUNK_DB/audit/thaweddb</s:key>
                        <s:key name="thawedPath_expanded">/opt/splunk/var/lib/splunk/audit/thaweddb</s:key>
                        <s:key name="throttleCheckPeriod">15</s:key>
                        <s:key name="timePeriodInSecBeforeTsidxReduction">604800</s:key>
                        <s:key name="totalEventCount">4834</s:key>
                        <s:key name="tsidxReductionCheckPeriodInSec">600</s:key>
                        <s:key name="tsidxTargetSizeMB">1500</s:key>
                        <s:key name="tsidxWritingLevel" />
                        <s:key name="tstatsHomePath">volume:_splunk_summaries/audit/datamodel_summary</s:key>
                        <s:key name="tstatsHomePath_expanded">/opt/splunk/var/lib/splunk/audit/datamodel_summary</s:key>
                        <s:key name="waitPeriodInSecsForManifestWrite">60</s:key>
                        <s:key name="warmToColdScript" />
                    </s:dict>
                    </content>
                </entry>
                <entry>
                    <title>_internal</title>
                    <id>https://0.0.0.0:32787/servicesNS/nobody/system/data/indexes/_internal</id>
                    <updated>2020-05-11T17:33:25+00:00</updated>
                    <link href="/servicesNS/nobody/system/data/indexes/_internal" rel="alternate" />
                    <author>
                    <name>nobody</name>
                    </author>
                    <link href="/servicesNS/nobody/system/data/indexes/_internal" rel="list" />
                    <link href="/servicesNS/nobody/system/data/indexes/_internal/_reload" rel="_reload" />
                    <link href="/servicesNS/nobody/system/data/indexes/_internal" rel="edit" />
                    <link href="/servicesNS/nobody/system/data/indexes/_internal/disable" rel="disable" />
                    <content type="text/xml">
                    <s:dict>
                        <s:key name="archiver.enableDataArchive">0</s:key>
                        <s:key name="archiver.maxDataArchiveRetentionPeriod">0</s:key>
                        <s:key name="assureUTF8">0</s:key>
                        <s:key name="bucketRebuildMemoryHint">auto</s:key>
                        <s:key name="coldPath">$SPLUNK_DB/_internaldb/colddb</s:key>
                        <s:key name="coldPath.maxDataSizeMB">0</s:key>
                        <s:key name="coldPath_expanded">/opt/splunk/var/lib/splunk/_internaldb/colddb</s:key>
                        <s:key name="coldToFrozenDir" />
                        <s:key name="coldToFrozenScript" />
                        <s:key name="compressRawdata">1</s:key>
                        <s:key name="currentDBSizeMB">16</s:key>
                        <s:key name="datatype">event</s:key>
                        <s:key name="defaultDatabase">main</s:key>
                        <s:key name="disabled">0</s:key>
                        <s:key name="eai:acl">
                        <s:dict>
                            <s:key name="app">system</s:key>
                            <s:key name="can_list">1</s:key>
                            <s:key name="can_write">1</s:key>
                            <s:key name="modifiable">0</s:key>
                            <s:key name="owner">nobody</s:key>
                            <s:key name="perms">
                            <s:dict>
                                <s:key name="read">
                                <s:list>
                                    <s:item>*</s:item>
                                </s:list>
                                </s:key>
                                <s:key name="write">
                                <s:list>
                                    <s:item>admin</s:item>
                                    <s:item>splunk-system-role</s:item>
                                </s:list>
                                </s:key>
                            </s:dict>
                            </s:key>
                            <s:key name="removable">0</s:key>
                            <s:key name="sharing">system</s:key>
                        </s:dict>
                        </s:key>
                        <s:key name="enableDataIntegrityControl">0</s:key>
                        <s:key name="enableOnlineBucketRepair">1</s:key>
                        <s:key name="enableRealtimeSearch">1</s:key>
                        <s:key name="enableTsidxReduction">0</s:key>
                        <s:key name="fileSystemExecutorWorkers">5</s:key>
                        <s:key name="frozenTimePeriodInSecs">2592000</s:key>
                        <s:key name="homePath">$SPLUNK_DB/_internaldb/db</s:key>
                        <s:key name="homePath.maxDataSizeMB">0</s:key>
                        <s:key name="homePath_expanded">/opt/splunk/var/lib/splunk/_internaldb/db</s:key>
                        <s:key name="hotBucketTimeRefreshInterval">10</s:key>
                        <s:key name="indexThreads">auto</s:key>
                        <s:key name="isInternal">1</s:key>
                        <s:key name="isReady">1</s:key>
                        <s:key name="isVirtual">0</s:key>
                        <s:key name="journalCompression">gzip</s:key>
                        <s:key name="lastInitSequenceNumber">1</s:key>
                        <s:key name="lastInitTime">1589074513</s:key>
                        <s:key name="maxBloomBackfillBucketAge">30d</s:key>
                        <s:key name="maxBucketSizeCacheEntries">0</s:key>
                        <s:key name="maxConcurrentOptimizes">6</s:key>
                        <s:key name="maxDataSize">1000</s:key>
                        <s:key name="maxGlobalDataSizeMB">0</s:key>
                        <s:key name="maxGlobalRawDataSizeMB">0</s:key>
                        <s:key name="maxHotBuckets">3</s:key>
                        <s:key name="maxHotIdleSecs">0</s:key>
                        <s:key name="maxHotSpanSecs">432000</s:key>
                        <s:key name="maxMemMB">5</s:key>
                        <s:key name="maxMetaEntries">1000000</s:key>
                        <s:key name="maxRunningProcessGroups">8</s:key>
                        <s:key name="maxRunningProcessGroupsLowPriority">1</s:key>
                        <s:key name="maxTime">2020-05-11T17:33:30+0000</s:key>
                        <s:key name="maxTimeUnreplicatedNoAcks">300</s:key>
                        <s:key name="maxTimeUnreplicatedWithAcks">60</s:key>
                        <s:key name="maxTotalDataSizeMB">500000</s:key>
                        <s:key name="maxWarmDBCount">300</s:key>
                        <s:key name="memPoolMB">auto</s:key>
                        <s:key name="metric.compressionBlockSize">1024</s:key>
                        <s:key name="metric.enableFloatingPointCompression">1</s:key>
                        <s:key name="metric.tsidxTargetSizeMB">1500</s:key>
                        <s:key name="minHotIdleSecsBeforeForceRoll">auto</s:key>
                        <s:key name="minRawFileSyncSecs">disable</s:key>
                        <s:key name="minStreamGroupQueueSize">2000</s:key>
                        <s:key name="minTime">2020-05-10T01:35:06+0000</s:key>
                        <s:key name="partialServiceMetaPeriod">0</s:key>
                        <s:key name="processTrackerServiceInterval">1</s:key>
                        <s:key name="quarantineFutureSecs">2592000</s:key>
                        <s:key name="quarantinePastSecs">77760000</s:key>
                        <s:key name="rawChunkSizeBytes">131072</s:key>
                        <s:key name="repFactor">0</s:key>
                        <s:key name="rotatePeriodInSecs">60</s:key>
                        <s:key name="rtRouterQueueSize" />
                        <s:key name="rtRouterThreads" />
                        <s:key name="selfStorageThreads" />
                        <s:key name="serviceInactiveIndexesPeriod">60</s:key>
                        <s:key name="serviceMetaPeriod">25</s:key>
                        <s:key name="serviceOnlyAsNeeded">1</s:key>
                        <s:key name="serviceSubtaskTimingPeriod">30</s:key>
                        <s:key name="splitByIndexKeys" />
                        <s:key name="streamingTargetTsidxSyncPeriodMsec">5000</s:key>
                        <s:key name="summaryHomePath_expanded">/opt/splunk/var/lib/splunk/_internaldb/summary</s:key>
                        <s:key name="suppressBannerList" />
                        <s:key name="suspendHotRollByDeleteQuery">0</s:key>
                        <s:key name="sync">0</s:key>
                        <s:key name="syncMeta">1</s:key>
                        <s:key name="thawedPath">$SPLUNK_DB/_internaldb/thaweddb</s:key>
                        <s:key name="thawedPath_expanded">/opt/splunk/var/lib/splunk/_internaldb/thaweddb</s:key>
                        <s:key name="throttleCheckPeriod">15</s:key>
                        <s:key name="timePeriodInSecBeforeTsidxReduction">604800</s:key>
                        <s:key name="totalEventCount">141501</s:key>
                        <s:key name="tsidxReductionCheckPeriodInSec">600</s:key>
                        <s:key name="tsidxTargetSizeMB">1500</s:key>
                        <s:key name="tsidxWritingLevel" />
                        <s:key name="tstatsHomePath">volume:_splunk_summaries/_internaldb/datamodel_summary</s:key>
                        <s:key name="tstatsHomePath_expanded">/opt/splunk/var/lib/splunk/_internaldb/datamodel_summary</s:key>
                        <s:key name="waitPeriodInSecsForManifestWrite">60</s:key>
                        <s:key name="warmToColdScript" />
                    </s:dict>
                    </content>
                </entry>
                <entry>
                    <title>summary</title>
                    <id>https://0.0.0.0:32787/servicesNS/nobody/system/data/indexes/summary</id>
                    <updated>2020-05-10T01:35:13+00:00</updated>
                    <link href="/servicesNS/nobody/system/data/indexes/summary" rel="alternate" />
                    <author>
                    <name>nobody</name>
                    </author>
                    <link href="/servicesNS/nobody/system/data/indexes/summary" rel="list" />
                    <link href="/servicesNS/nobody/system/data/indexes/summary/_reload" rel="_reload" />
                    <link href="/servicesNS/nobody/system/data/indexes/summary" rel="edit" />
                    <link href="/servicesNS/nobody/system/data/indexes/summary/disable" rel="disable" />
                    <content type="text/xml">
                    <s:dict>
                        <s:key name="archiver.enableDataArchive">0</s:key>
                        <s:key name="archiver.maxDataArchiveRetentionPeriod">0</s:key>
                        <s:key name="assureUTF8">0</s:key>
                        <s:key name="bucketRebuildMemoryHint">auto</s:key>
                        <s:key name="coldPath">$SPLUNK_DB/summarydb/colddb</s:key>
                        <s:key name="coldPath.maxDataSizeMB">0</s:key>
                        <s:key name="coldPath_expanded">/opt/splunk/var/lib/splunk/summarydb/colddb</s:key>
                        <s:key name="coldToFrozenDir" />
                        <s:key name="coldToFrozenScript" />
                        <s:key name="compressRawdata">1</s:key>
                        <s:key name="currentDBSizeMB">1</s:key>
                        <s:key name="datatype">event</s:key>
                        <s:key name="defaultDatabase">main</s:key>
                        <s:key name="disabled">0</s:key>
                        <s:key name="eai:acl">
                        <s:dict>
                            <s:key name="app">system</s:key>
                            <s:key name="can_list">1</s:key>
                            <s:key name="can_write">1</s:key>
                            <s:key name="modifiable">0</s:key>
                            <s:key name="owner">nobody</s:key>
                            <s:key name="perms">
                            <s:dict>
                                <s:key name="read">
                                <s:list>
                                    <s:item>*</s:item>
                                </s:list>
                                </s:key>
                                <s:key name="write">
                                <s:list>
                                    <s:item>admin</s:item>
                                    <s:item>splunk-system-role</s:item>
                                </s:list>
                                </s:key>
                            </s:dict>
                            </s:key>
                            <s:key name="removable">0</s:key>
                            <s:key name="sharing">system</s:key>
                        </s:dict>
                        </s:key>
                        <s:key name="enableDataIntegrityControl">0</s:key>
                        <s:key name="enableOnlineBucketRepair">1</s:key>
                        <s:key name="enableRealtimeSearch">1</s:key>
                        <s:key name="enableTsidxReduction">0</s:key>
                        <s:key name="fileSystemExecutorWorkers">5</s:key>
                        <s:key name="frozenTimePeriodInSecs">188697600</s:key>
                        <s:key name="homePath">$SPLUNK_DB/summarydb/db</s:key>
                        <s:key name="homePath.maxDataSizeMB">0</s:key>
                        <s:key name="homePath_expanded">/opt/splunk/var/lib/splunk/summarydb/db</s:key>
                        <s:key name="hotBucketTimeRefreshInterval">10</s:key>
                        <s:key name="indexThreads">auto</s:key>
                        <s:key name="isInternal">0</s:key>
                        <s:key name="isReady">1</s:key>
                        <s:key name="isVirtual">0</s:key>
                        <s:key name="journalCompression">gzip</s:key>
                        <s:key name="lastInitSequenceNumber">1</s:key>
                        <s:key name="lastInitTime">1589074513</s:key>
                        <s:key name="maxBloomBackfillBucketAge">30d</s:key>
                        <s:key name="maxBucketSizeCacheEntries">0</s:key>
                        <s:key name="maxConcurrentOptimizes">6</s:key>
                        <s:key name="maxDataSize">auto</s:key>
                        <s:key name="maxGlobalDataSizeMB">0</s:key>
                        <s:key name="maxGlobalRawDataSizeMB">0</s:key>
                        <s:key name="maxHotBuckets">3</s:key>
                        <s:key name="maxHotIdleSecs">0</s:key>
                        <s:key name="maxHotSpanSecs">7776000</s:key>
                        <s:key name="maxMemMB">5</s:key>
                        <s:key name="maxMetaEntries">1000000</s:key>
                        <s:key name="maxRunningProcessGroups">8</s:key>
                        <s:key name="maxRunningProcessGroupsLowPriority">1</s:key>
                        <s:key name="maxTime" />
                        <s:key name="maxTimeUnreplicatedNoAcks">300</s:key>
                        <s:key name="maxTimeUnreplicatedWithAcks">60</s:key>
                        <s:key name="maxTotalDataSizeMB">500000</s:key>
                        <s:key name="maxWarmDBCount">300</s:key>
                        <s:key name="memPoolMB">auto</s:key>
                        <s:key name="metric.compressionBlockSize">1024</s:key>
                        <s:key name="metric.enableFloatingPointCompression">1</s:key>
                        <s:key name="metric.tsidxTargetSizeMB">1500</s:key>
                        <s:key name="minHotIdleSecsBeforeForceRoll">auto</s:key>
                        <s:key name="minRawFileSyncSecs">disable</s:key>
                        <s:key name="minStreamGroupQueueSize">2000</s:key>
                        <s:key name="minTime" />
                        <s:key name="partialServiceMetaPeriod">0</s:key>
                        <s:key name="processTrackerServiceInterval">1</s:key>
                        <s:key name="quarantineFutureSecs">2592000</s:key>
                        <s:key name="quarantinePastSecs">77760000</s:key>
                        <s:key name="rawChunkSizeBytes">131072</s:key>
                        <s:key name="repFactor">0</s:key>
                        <s:key name="rotatePeriodInSecs">60</s:key>
                        <s:key name="rtRouterQueueSize" />
                        <s:key name="rtRouterThreads" />
                        <s:key name="selfStorageThreads" />
                        <s:key name="serviceInactiveIndexesPeriod">60</s:key>
                        <s:key name="serviceMetaPeriod">25</s:key>
                        <s:key name="serviceOnlyAsNeeded">1</s:key>
                        <s:key name="serviceSubtaskTimingPeriod">30</s:key>
                        <s:key name="splitByIndexKeys" />
                        <s:key name="streamingTargetTsidxSyncPeriodMsec">5000</s:key>
                        <s:key name="summaryHomePath_expanded">/opt/splunk/var/lib/splunk/summarydb/summary</s:key>
                        <s:key name="suppressBannerList" />
                        <s:key name="suspendHotRollByDeleteQuery">0</s:key>
                        <s:key name="sync">0</s:key>
                        <s:key name="syncMeta">1</s:key>
                        <s:key name="thawedPath">$SPLUNK_DB/summarydb/thaweddb</s:key>
                        <s:key name="thawedPath_expanded">/opt/splunk/var/lib/splunk/summarydb/thaweddb</s:key>
                        <s:key name="throttleCheckPeriod">15</s:key>
                        <s:key name="timePeriodInSecBeforeTsidxReduction">604800</s:key>
                        <s:key name="totalEventCount">0</s:key>
                        <s:key name="tsidxReductionCheckPeriodInSec">600</s:key>
                        <s:key name="tsidxTargetSizeMB">1500</s:key>
                        <s:key name="tsidxWritingLevel" />
                        <s:key name="tstatsHomePath">volume:_splunk_summaries/summarydb/datamodel_summary</s:key>
                        <s:key name="tstatsHomePath_expanded">/opt/splunk/var/lib/splunk/summarydb/datamodel_summary</s:key>
                        <s:key name="waitPeriodInSecsForManifestWrite">60</s:key>
                        <s:key name="warmToColdScript" />
                    </s:dict>
                </content>
            </entry>
        </feed>
    """ )

xmlresponse_initial_kv_list_collections = (
    """
        <?xml version="1.0" encoding="UTF-8"?>
        <!--This is to override browser formatting; see server.conf[httpServer] to disable. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .-->
        <?xml-stylesheet type="text/xml" href="/static/atom.xsl"?>
        <feed xmlns="http://www.w3.org/2005/Atom" xmlns:s="http://dev.splunk.com/ns/rest" xmlns:opensearch="http://a9.com/-/spec/opensearch/1.1/">
        <title>localapps</title>
        <id>https://localhost:32771/servicesNS/nobody/search/apps/local</id>
        <updated>2020-12-04T00:17:53+00:00</updated>
        <generator build="24fd52428b5a" version="8.1.0.1"/>
        <author>
            <name>Splunk</name>
        </author>
        <link href="/servicesNS/nobody/search/apps/local/_new" rel="create"/>
        <link href="/servicesNS/nobody/search/apps/local/_reload" rel="_reload"/>
        <opensearch:totalResults>1</opensearch:totalResults>
        <opensearch:itemsPerPage>30</opensearch:itemsPerPage>
        <opensearch:startIndex>0</opensearch:startIndex>
        <s:messages/>
        <entry>
            <title>search</title>
            <id>https://localhost:32771/servicesNS/nobody/system/apps/local/search</id>
            <updated>1970-01-01T00:00:00+00:00</updated>
            <link href="/servicesNS/nobody/system/apps/local/search" rel="alternate"/>
            <author>
            <name>nobody</name>
            </author>
            <link href="/servicesNS/nobody/system/apps/local/search" rel="list"/>
            <link href="/servicesNS/nobody/system/apps/local/search/_reload" rel="_reload"/>
            <link href="/servicesNS/nobody/system/apps/local/search" rel="edit"/>
            <link href="/servicesNS/nobody/system/apps/local/search/package" rel="package"/>
            <content type="text/xml">
            <s:dict>
                <s:key name="author">Splunk</s:key>
                <s:key name="check_for_updates">1</s:key>
                <s:key name="configured">1</s:key>
                <s:key name="core">1</s:key>
                <s:key name="description"><![CDATA[The Search app is Splunk's default interface for searching and analyzing IT data. It allows you to index data into Splunk, add knowledge, build reports, and create alerts. The Search app can be used across many areas of IT including application management, operations management, security, and compliance.]]></s:key>
                <s:key name="disabled">0</s:key>
                <s:key name="eai:acl">
                <s:dict>
                    <s:key name="app">system</s:key>
                    <s:key name="can_change_perms">1</s:key>
                    <s:key name="can_list">1</s:key>
                    <s:key name="can_share_app">1</s:key>
                    <s:key name="can_share_global">1</s:key>
                    <s:key name="can_share_user">0</s:key>
                    <s:key name="can_write">1</s:key>
                    <s:key name="modifiable">1</s:key>
                    <s:key name="owner">nobody</s:key>
                    <s:key name="perms">
                    <s:dict>
                        <s:key name="read">
                        <s:list>
                            <s:item>*</s:item>
                        </s:list>
                        </s:key>
                        <s:key name="write">
                        <s:list>
                            <s:item>admin</s:item>
                            <s:item>power</s:item>
                        </s:list>
                        </s:key>
                    </s:dict>
                    </s:key>
                    <s:key name="removable">0</s:key>
                    <s:key name="sharing">app</s:key>
                </s:dict>
                </s:key>
                <s:key name="eai:attributes">
                <s:dict>
                    <s:key name="optionalFields">
                    <s:list>
                        <s:item>author</s:item>
                        <s:item>check_for_updates</s:item>
                        <s:item>configured</s:item>
                        <s:item>description</s:item>
                        <s:item>label</s:item>
                        <s:item>version</s:item>
                        <s:item>visible</s:item>
                    </s:list>
                    </s:key>
                    <s:key name="requiredFields">
                    <s:list/>
                    </s:key>
                    <s:key name="wildcardFields">
                    <s:list/>
                    </s:key>
                </s:dict>
                </s:key>
                <s:key name="label">Search &amp; Reporting</s:key>
                <s:key name="managed_by_deployment_client">0</s:key>
                <s:key name="show_in_nav">1</s:key>
                <s:key name="state_change_requires_restart">0</s:key>
                <s:key name="version">8.1.0.1</s:key>
                <s:key name="visible">1</s:key>
            </s:dict>
            </content>
        </entry>
        </feed>
    """
        )

xmlresponse_kv_list_collections = (
    """
        <?xml version="1.0" encoding="UTF-8"?>
        <!--This is to override browser formatting; see server.conf[httpServer] to disable. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .-->
        <?xml-stylesheet type="text/xml" href="/static/atom.xsl"?>
        <feed xmlns="http://www.w3.org/2005/Atom" xmlns:s="http://dev.splunk.com/ns/rest" xmlns:opensearch="http://a9.com/-/spec/opensearch/1.1/">
        <title>collections-conf</title>
        <id>https://localhost:32771/servicesNS/nobody/search/storage/collections/config</id>
        <updated>2020-12-04T00:19:55+00:00</updated>
        <generator build="24fd52428b5a" version="8.1.0.1"/>
        <author>
            <name>Splunk</name>
        </author>
        <link href="/servicesNS/nobody/search/storage/collections/config/_new" rel="create"/>
        <link href="/servicesNS/nobody/search/storage/collections/config/_reload" rel="_reload"/>
        <link href="/servicesNS/nobody/search/storage/collections/config/_acl" rel="_acl"/>
        <opensearch:totalResults>7</opensearch:totalResults>
        <opensearch:itemsPerPage>30</opensearch:itemsPerPage>
        <opensearch:startIndex>0</opensearch:startIndex>
        <s:messages/>
        <entry>
            <title>JsonWebTokensV1</title>
            <id>https://localhost:32771/servicesNS/nobody/system/storage/collections/config/JsonWebTokensV1</id>
            <updated>1970-01-01T00:00:00+00:00</updated>
            <link href="/servicesNS/nobody/system/storage/collections/config/JsonWebTokensV1" rel="alternate"/>
            <author>
            <name>nobody</name>
            </author>
            <link href="/servicesNS/nobody/system/storage/collections/config/JsonWebTokensV1" rel="list"/>
            <link href="/servicesNS/nobody/system/storage/collections/config/JsonWebTokensV1/_reload" rel="_reload"/>
            <link href="/servicesNS/nobody/system/storage/collections/config/JsonWebTokensV1" rel="edit"/>
            <link href="/servicesNS/nobody/system/storage/collections/config/JsonWebTokensV1/enable" rel="enable"/>
            <content type="text/xml">
            <s:dict>
                <s:key name="disabled">1</s:key>
                <s:key name="eai:acl">
                <s:dict>
                    <s:key name="app">system</s:key>
                    <s:key name="can_change_perms">1</s:key>
                    <s:key name="can_list">1</s:key>
                    <s:key name="can_share_app">1</s:key>
                    <s:key name="can_share_global">1</s:key>
                    <s:key name="can_share_user">0</s:key>
                    <s:key name="can_write">1</s:key>
                    <s:key name="modifiable">1</s:key>
                    <s:key name="owner">nobody</s:key>
                    <s:key name="perms">
                    <s:dict>
                        <s:key name="read">
                        <s:list>
                            <s:item>admin</s:item>
                        </s:list>
                        </s:key>
                        <s:key name="write">
                        <s:list>
                            <s:item>admin</s:item>
                        </s:list>
                        </s:key>
                    </s:dict>
                    </s:key>
                    <s:key name="removable">0</s:key>
                    <s:key name="sharing">system</s:key>
                </s:dict>
                </s:key>
                <s:key name="eai:appName">search</s:key>
                <s:key name="eai:userName">nobody</s:key>
                <s:key name="profilingEnabled">false</s:key>
                <s:key name="profilingThresholdMs">1000</s:key>
                <s:key name="replicate">false</s:key>
                <s:key name="replication_dump_maximum_file_size">10240</s:key>
                <s:key name="replication_dump_strategy">auto</s:key>
                <s:key name="type">undefined</s:key>
            </s:dict>
            </content>
        </entry>
        <entry>
            <title>SamlIdpCerts</title>
            <id>https://localhost:32771/servicesNS/nobody/system/storage/collections/config/SamlIdpCerts</id>
            <updated>1970-01-01T00:00:00+00:00</updated>
            <link href="/servicesNS/nobody/system/storage/collections/config/SamlIdpCerts" rel="alternate"/>
            <author>
            <name>nobody</name>
            </author>
            <link href="/servicesNS/nobody/system/storage/collections/config/SamlIdpCerts" rel="list"/>
            <link href="/servicesNS/nobody/system/storage/collections/config/SamlIdpCerts/_reload" rel="_reload"/>
            <link href="/servicesNS/nobody/system/storage/collections/config/SamlIdpCerts" rel="edit"/>
            <link href="/servicesNS/nobody/system/storage/collections/config/SamlIdpCerts/enable" rel="enable"/>
            <content type="text/xml">
            <s:dict>
                <s:key name="disabled">1</s:key>
                <s:key name="eai:acl">
                <s:dict>
                    <s:key name="app">system</s:key>
                    <s:key name="can_change_perms">1</s:key>
                    <s:key name="can_list">1</s:key>
                    <s:key name="can_share_app">1</s:key>
                    <s:key name="can_share_global">1</s:key>
                    <s:key name="can_share_user">0</s:key>
                    <s:key name="can_write">1</s:key>
                    <s:key name="modifiable">1</s:key>
                    <s:key name="owner">nobody</s:key>
                    <s:key name="perms">
                    <s:dict>
                        <s:key name="read">
                        <s:list>
                            <s:item>*</s:item>
                        </s:list>
                        </s:key>
                        <s:key name="write">
                        <s:list>
                            <s:item>admin</s:item>
                        </s:list>
                        </s:key>
                    </s:dict>
                    </s:key>
                    <s:key name="removable">0</s:key>
                    <s:key name="sharing">system</s:key>
                </s:dict>
                </s:key>
                <s:key name="eai:appName">search</s:key>
                <s:key name="eai:userName">nobody</s:key>
                <s:key name="profilingEnabled">false</s:key>
                <s:key name="profilingThresholdMs">1000</s:key>
                <s:key name="replicate">false</s:key>
                <s:key name="replication_dump_maximum_file_size">10240</s:key>
                <s:key name="replication_dump_strategy">auto</s:key>
                <s:key name="type">undefined</s:key>
            </s:dict>
            </content>
        </entry>
        <entry>
            <title>SearchHeadClusterHealthStates</title>
            <id>https://localhost:32771/servicesNS/nobody/system/storage/collections/config/SearchHeadClusterHealthStates</id>
            <updated>1970-01-01T00:00:00+00:00</updated>
            <link href="/servicesNS/nobody/system/storage/collections/config/SearchHeadClusterHealthStates" rel="alternate"/>
            <author>
            <name>nobody</name>
            </author>
            <link href="/servicesNS/nobody/system/storage/collections/config/SearchHeadClusterHealthStates" rel="list"/>
            <link href="/servicesNS/nobody/system/storage/collections/config/SearchHeadClusterHealthStates/_reload" rel="_reload"/>
            <link href="/servicesNS/nobody/system/storage/collections/config/SearchHeadClusterHealthStates" rel="edit"/>
            <link href="/servicesNS/nobody/system/storage/collections/config/SearchHeadClusterHealthStates/disable" rel="disable"/>
            <content type="text/xml">
            <s:dict>
                <s:key name="disabled">0</s:key>
                <s:key name="eai:acl">
                <s:dict>
                    <s:key name="app">system</s:key>
                    <s:key name="can_change_perms">1</s:key>
                    <s:key name="can_list">1</s:key>
                    <s:key name="can_share_app">1</s:key>
                    <s:key name="can_share_global">1</s:key>
                    <s:key name="can_share_user">0</s:key>
                    <s:key name="can_write">1</s:key>
                    <s:key name="modifiable">1</s:key>
                    <s:key name="owner">nobody</s:key>
                    <s:key name="perms">
                    <s:dict>
                        <s:key name="read">
                        <s:list>
                            <s:item>*</s:item>
                        </s:list>
                        </s:key>
                        <s:key name="write">
                        <s:list>
                            <s:item>admin</s:item>
                        </s:list>
                        </s:key>
                    </s:dict>
                    </s:key>
                    <s:key name="removable">0</s:key>
                    <s:key name="sharing">system</s:key>
                </s:dict>
                </s:key>
                <s:key name="eai:appName">search</s:key>
                <s:key name="eai:userName">nobody</s:key>
                <s:key name="profilingEnabled">false</s:key>
                <s:key name="profilingThresholdMs">1000</s:key>
                <s:key name="replicate">false</s:key>
                <s:key name="replication_dump_maximum_file_size">10240</s:key>
                <s:key name="replication_dump_strategy">auto</s:key>
                <s:key name="type">internal_cache</s:key>
            </s:dict>
            </content>
        </entry>
        </feed>
    """
)

xmlresponse_kv_collections_specific_get = (
    """
        <?xml version="1.0" encoding="UTF-8"?>
        <!--This is to override browser formatting; see server.conf[httpServer] to disable. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .-->
        <?xml-stylesheet type="text/xml" href="/static/atom.xsl"?>
        <feed xmlns="http://www.w3.org/2005/Atom" xmlns:s="http://dev.splunk.com/ns/rest" xmlns:opensearch="http://a9.com/-/spec/opensearch/1.1/">
        <title>collections-conf</title>
        <id>https://localhost:32771/servicesNS/nobody/search/storage/collections/config</id>
        <updated>2020-12-04T18:06:09+00:00</updated>
        <generator build="24fd52428b5a" version="8.1.0.1"/>
        <author>
            <name>Splunk</name>
        </author>
        <link href="/servicesNS/nobody/search/storage/collections/config/_new" rel="create"/>
        <link href="/servicesNS/nobody/search/storage/collections/config/_reload" rel="_reload"/>
        <link href="/servicesNS/nobody/search/storage/collections/config/_acl" rel="_acl"/>
        <opensearch:totalResults>1</opensearch:totalResults>
        <opensearch:itemsPerPage>30</opensearch:itemsPerPage>
        <opensearch:startIndex>0</opensearch:startIndex>
        <s:messages/>
        <entry>
            <title>JsonWebTokensV1</title>
            <id>https://localhost:32771/servicesNS/nobody/system/storage/collections/config/JsonWebTokensV1</id>
            <updated>1970-01-01T00:00:00+00:00</updated>
            <link href="/servicesNS/nobody/system/storage/collections/config/JsonWebTokensV1" rel="alternate"/>
            <author>
            <name>nobody</name>
            </author>
            <link href="/servicesNS/nobody/system/storage/collections/config/JsonWebTokensV1" rel="list"/>
            <link href="/servicesNS/nobody/system/storage/collections/config/JsonWebTokensV1/_reload" rel="_reload"/>
            <link href="/servicesNS/nobody/system/storage/collections/config/JsonWebTokensV1" rel="edit"/>
            <link href="/servicesNS/nobody/system/storage/collections/config/JsonWebTokensV1/enable" rel="enable"/>
            <content type="text/xml">
            <s:dict>
                <s:key name="disabled">1</s:key>
                <s:key name="eai:acl">
                <s:dict>
                    <s:key name="app">system</s:key>
                    <s:key name="can_change_perms">1</s:key>
                    <s:key name="can_list">1</s:key>
                    <s:key name="can_share_app">1</s:key>
                    <s:key name="can_share_global">1</s:key>
                    <s:key name="can_share_user">0</s:key>
                    <s:key name="can_write">1</s:key>
                    <s:key name="modifiable">1</s:key>
                    <s:key name="owner">nobody</s:key>
                    <s:key name="perms">
                    <s:dict>
                        <s:key name="read">
                        <s:list>
                            <s:item>admin</s:item>
                        </s:list>
                        </s:key>
                        <s:key name="write">
                        <s:list>
                            <s:item>admin</s:item>
                        </s:list>
                        </s:key>
                    </s:dict>
                    </s:key>
                    <s:key name="removable">0</s:key>
                    <s:key name="sharing">system</s:key>
                </s:dict>
                </s:key>
                <s:key name="eai:appName">search</s:key>
                <s:key name="eai:attributes">
                <s:dict>
                    <s:key name="optionalFields">
                    <s:list>
                        <s:item>enforceTypes</s:item>
                        <s:item>profilingEnabled</s:item>
                        <s:item>profilingThresholdMs</s:item>
                        <s:item>replicate</s:item>
                        <s:item>replication_dump_maximum_file_size</s:item>
                        <s:item>replication_dump_strategy</s:item>
                    </s:list>
                    </s:key>
                    <s:key name="requiredFields">
                    <s:list/>
                    </s:key>
                    <s:key name="wildcardFields">
                    <s:list>
                        <s:item>accelerated_fields\..*</s:item>
                        <s:item>field\..*</s:item>
                    </s:list>
                    </s:key>
                </s:dict>
                </s:key>
                <s:key name="eai:userName">nobody</s:key>
                <s:key name="profilingEnabled">false</s:key>
                <s:key name="profilingThresholdMs">1000</s:key>
                <s:key name="replicate">false</s:key>
                <s:key name="replication_dump_maximum_file_size">10240</s:key>
                <s:key name="replication_dump_strategy">auto</s:key>
                <s:key name="type">undefined</s:key>
            </s:dict>
            </content>
        </entry>
        </feed>
    """
)

xmlresponse_kv_collections_specific_post = (
    """
        <?xml version="1.0" encoding="UTF-8"?>
        <!--This is to override browser formatting; see server.conf[httpServer] to disable. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .-->
        <?xml-stylesheet type="text/xml" href="/static/atom.xsl"?>
        <feed xmlns="http://www.w3.org/2005/Atom" xmlns:s="http://dev.splunk.com/ns/rest" xmlns:opensearch="http://a9.com/-/spec/opensearch/1.1/">
        <title>collections-conf</title>
        <id>https://localhost:32771/servicesNS/nobody/search/storage/collections/config</id>
        <updated>2020-12-04T18:16:31+00:00</updated>
        <generator build="24fd52428b5a" version="8.1.0.1"/>
        <author>
            <name>Splunk</name>
        </author>
        <link href="/servicesNS/nobody/search/storage/collections/config/_new" rel="create"/>
        <link href="/servicesNS/nobody/search/storage/collections/config/_reload" rel="_reload"/>
        <link href="/servicesNS/nobody/search/storage/collections/config/_acl" rel="_acl"/>
        <opensearch:totalResults>1</opensearch:totalResults>
        <opensearch:itemsPerPage>30</opensearch:itemsPerPage>
        <opensearch:startIndex>0</opensearch:startIndex>
        <s:messages/>
        <entry>
            <title>localkv</title>
            <id>https://localhost:32771/servicesNS/nobody/search/storage/collections/config/localkv</id>
            <updated>2020-12-04T18:16:31+00:00</updated>
            <link href="/servicesNS/nobody/search/storage/collections/config/localkv" rel="alternate"/>
            <author>
            <name>admin</name>
            </author>
            <link href="/servicesNS/nobody/search/storage/collections/config/localkv" rel="list"/>
            <link href="/servicesNS/nobody/search/storage/collections/config/localkv/_reload" rel="_reload"/>
            <link href="/servicesNS/nobody/search/storage/collections/config/localkv" rel="edit"/>
            <link href="/servicesNS/nobody/search/storage/collections/config/localkv" rel="remove"/>
            <link href="/servicesNS/nobody/search/storage/collections/config/localkv/disable" rel="disable"/>
            <content type="text/xml">
            <s:dict>
                <s:key name="accelerated_fields.bar">{"b": -1}</s:key>
                <s:key name="accelerated_fields.foo">{"a": 1}</s:key>
                <s:key name="disabled">0</s:key>
                <s:key name="eai:acl">
                <s:dict>
                    <s:key name="app">search</s:key>
                    <s:key name="can_change_perms">1</s:key>
                    <s:key name="can_list">1</s:key>
                    <s:key name="can_share_app">1</s:key>
                    <s:key name="can_share_global">1</s:key>
                    <s:key name="can_share_user">1</s:key>
                    <s:key name="can_write">1</s:key>
                    <s:key name="modifiable">1</s:key>
                    <s:key name="owner">admin</s:key>
                    <s:key name="perms">
                    <s:dict>
                        <s:key name="read">
                        <s:list>
                            <s:item>*</s:item>
                        </s:list>
                        </s:key>
                        <s:key name="write">
                        <s:list>
                            <s:item>admin</s:item>
                            <s:item>power</s:item>
                        </s:list>
                        </s:key>
                    </s:dict>
                    </s:key>
                    <s:key name="removable">1</s:key>
                    <s:key name="sharing">app</s:key>
                </s:dict>
                </s:key>
                <s:key name="eai:appName">search</s:key>
                <s:key name="eai:userName">nobody</s:key>
                <s:key name="field.a">number</s:key>
                <s:key name="field.b">cidr</s:key>
                <s:key name="profilingEnabled">false</s:key>
                <s:key name="profilingThresholdMs">1000</s:key>
                <s:key name="replicate">false</s:key>
                <s:key name="replication_dump_maximum_file_size">10240</s:key>
                <s:key name="replication_dump_strategy">auto</s:key>
                <s:key name="type">undefined</s:key>
            </s:dict>
            </content>
        </entry>
        </feed>
    """
)

@splunk_api.route(f'/services/auth/login',methods=['POST'])
def test_module():
    if len(request.form) == 0:
        xmlresponse = (
            """
            <response>
                <sessionKey>192fd3e46a31246da7ea7f109e7f95ff</sessionKey>
            </response>
            """
        )
        return Response(xmlresponse, mimetype='text/xml')
    else:
        return {
            "sessionKey":"192fd3e46a31246da7ea7f109e7f95ff",
            "message":"Splunk Server",
            "code":200
        }

@splunk_api.route(f'/services/notable_update',methods=['POST'])
def updateNotableEvents():
    number_of_events = len(request.form.getlist('ruleUIDs'))
    return {
        "message":f"{number_of_events} event updated successfully",
        "failure_count":0,
        "success":True,
        "details":{},
        "success_count":1
    }

@splunk_api.route(f'/services/data/indexes/_audit',methods=['GET'])
def splunk_submit_audit_event_command():
    xmlresponse = xmlresponse_index_audit
    return Response(xmlresponse, mimetype='text/xml')

@splunk_api.route(f'/services/receivers/<headers>',methods=['POST'])
def splunk_submit_event_audit(headers):
    xmlresponse = xmlresponse_index_audit
    return Response(xmlresponse, mimetype='text/xml')

@splunk_api.route(f'/services/data/indexes/_internal',methods=['GET'])
def splunk_submit_internal_event_command():
    xmlresponse = xmlresponse_index_internal
    return Response(xmlresponse, mimetype='text/xml')

@splunk_api.route(f'/services/receivers/<headers>',methods=['POST'])
def splunk_submit_event_internal(headers):
    xmlresponse = xmlresponse_index_internal
    return Response(xmlresponse, mimetype='text/xml')

@splunk_api.route(f'/services/data/indexes/summary',methods=['GET'])
def splunk_submit_summary_event_command():
    xmlresponse = xmlresponse_index_summary
    return Response(xmlresponse, mimetype='text/xml')

@splunk_api.route(f'/services/receivers/<headers>',methods=['POST'])
def splunk_submit_event_summary(headers):
    xmlresponse = xmlresponse_index_summary
    return Response(xmlresponse, mimetype='text/xml')

@splunk_api.route(f'/services/data/indexes/',methods=['GET'])
def splunk_get_indexes_command():
    xmlresponse = xmlresponse_get_index
    return Response(xmlresponse, mimetype='text/xml')

@splunk_api.route(f'/services/search/jobs/',methods=['POST'])
def splunk_job_create_command():
    print(request.data)
    if "oneshot" in str(request.data):
        xmlresponse = xmlresponse_job_result
    else:
        xmlresponse =(
        """
        <response><sid>156621733.628</sid></response>
        """ )
    return Response(xmlresponse, mimetype='text/xml')

@splunk_api.route(f'/servicesNS/nobody/search/search/jobs/156621733.628/results',methods=['GET'])
def splunk_results_command():
    xmlresponse = xmlresponse_job_result
    return Response(xmlresponse, mimetype='text/xml')

@splunk_api.route(f'/services/search/jobs/156621733.628/',methods=['GET'])
def splunk_search_command_jobs():
    xmlresponse = xmlresponse_search_job
    return Response(xmlresponse, mimetype='text/xml')

@splunk_api.route(f'/services/collector/event',methods=['POST'])
def splunk_submit_hec_event():
    return {
        "text":"Success",
        "code":"0"
    }

@splunk_api.route(f'/servicesNS/nobody/<appname1>/apps/local/<appname2>',methods=['GET'])
def splunk_kv_list_collections_initial_call(appname1,appname2):
    xmlresponse = xmlresponse_initial_kv_list_collections
    return Response(xmlresponse, mimetype='text/xml')

@splunk_api.route(f'/servicesNS/nobody/<appname>/storage/collections/config/',methods=['GET','POST'])
def splunk_kv_list_collections_from_app(appname):
    if request.method == 'POST':
        xmlresponse = json.dumps(xmlresponse_kv_collections_specific_post)
        return Response(xmlresponse, mimetype='text/xml')
    else:
        xmlresponse = xmlresponse_kv_list_collections
        return Response(xmlresponse, mimetype='text/xml')

@splunk_api.route(f'/servicesNS/nobody/<appname>/storage/collections/config/<collectioname>',methods=['GET'])
def splunk_kv_collection_config_from_app(appname,collectioname):
    xmlresponse = xmlresponse_kv_collections_specific_get
    return Response(xmlresponse, mimetype='text/xml')

@splunk_api.route(f'/servicesNS/nobody/system/storage/collections/data/<collectioname>/',methods=['GET','POST','DELETE'])
def splunk_kv_collection_system_data(collectioname):
    if request.method == "POST":
        xmlresponse = json.dumps(xmlresponse_kv_collections_specific_post)
        return Response(xmlresponse, mimetype='text/xml')
    elif request.method == "GET":
        response = [ { "myKey" : "abc", "_user" : "nobody", "_key" : "5410be5441ba15298e4624d1" } ]
        return Response(json.dumps(response), mimetype='text/xml')
    else:
        xmlresponse = (
            """
            """
        )
        return Response(xmlresponse, mimetype='text/xml')
        
@splunk_api.route(f'/servicesNS/nobody/system/storage/collections/config/<collectioname>/',methods=['POST','DELETE'])
def splunk_kv_collection_config(collectioname):
    if request.method == "POST":
        xmlresponse = json.dumps(xmlresponse_kv_collections_specific_post)
        return Response(xmlresponse, mimetype='text/xml')
    elif request.method == "DELETE":
        xmlresponse = (
            """
            """
        )
        return Response(xmlresponse, mimetype='text/xml')