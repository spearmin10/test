from flask import Blueprint
import json
import logging
import xml.etree.ElementTree as Parser
import glob

BASE_URL = '/phoenix/'.strip('/')
INTEGRATION = 'fortisiem_api'
fortisiem_api = Blueprint(f'{INTEGRATION}', __name__)
logger = logging.getLogger(__name__)

query_id = 500
counter = 0


# Two Routes for the Integration Test
@fortisiem_api.route(f'/{BASE_URL}/login-html.jsf', methods=['GET', 'POST'])
def login():
    return 'value="00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000=="'


@fortisiem_api.route(f'/{BASE_URL}/rest/h5/eventAttributeType/all')
def load_event_attributes():
    mocked_attribute = [
        {
            "attributeId": "00",
            "displayName": "Void"
        }
    ]
    return json.dumps(mocked_attribute)


# Three Routes for Fetch Incidents
@fortisiem_api.route(f'/{BASE_URL}/rest/query/eventQuery', methods=['POST'])
def return_mocked_query_id():
    return str(query_id)


@fortisiem_api.route(f'/{BASE_URL}/rest/query/progress/{str(query_id)}')
def return_mocked_query_status():
    return str(100)


@fortisiem_api.route(f'/{BASE_URL}/rest/query/events/{str(query_id)}/0/1000')
def return_mocked_incidents():
    global counter
    incidents = []
    incidents_count = len(glob.glob1('FortiSIEM', "*.xml"))
    for n in range(incidents_count):
        incidents.append(Parser.tostring(Parser.parse(f'FortiSIEM/incident{n+1}.xml').getroot(), encoding='utf8', method='xml'))
    if counter == incidents_count:
        counter = 0
    counter += 1
    return incidents[counter-1]
