## A FortiSEIM Mock Overview:

The following has been mocked and tested
1. Login function, the mock will accept any combination of credentials without validation
2. Test command
3. Fetch incidents, you can add more incidents to the folder (incident[x].xml), the mock will respond with a new incident for each query

**TestWithoutSOAR** is a replica of our integration incase you don't have an XSOAR to test the Mock with, example:
```bash
python3 FortiSIEM/TestWithoutSOAR.py -command 'fetch-incidents'
```
