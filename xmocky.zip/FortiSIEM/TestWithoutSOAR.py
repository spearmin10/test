import requests
import json
import time
import re
from xml.dom.minidom import Node, Document, parseString
import argparse
import urllib3

# disable insecure warnings
urllib3.disable_warnings()

USERNAME = 'mock'
PASSWORD = 'mock'
AUTH = ('super/' + USERNAME, PASSWORD)
VERIFY_SSL = False
HOST = 'https://localhost:3000'
QUERY_URL = HOST + "/phoenix/rest/query/"
REST_ADDRESS = HOST + "/phoenix/rest/h5"

EXTENDED_KEYS = {}  # type: dict

def validateSuccessfulResponse(resp, error_text):
    if resp.status_code != 200:
        raise('Got response status {} when {}'.format(resp.status_code, error_text))


def login():
    session = requests.session()
    login_url = HOST + '/phoenix/login-html.jsf'

    response = session.get(login_url, verify=VERIFY_SSL)

    # get the VIEW_STATE from the xml returned in the UI login page.


    p = re.compile('(value=".{1046}==")')
    viewState = p.findall(response.text)
    VIEW_STATE = viewState[0][len('value="'):][:-1]


    headers = {
        'Upgrade-Insecure-Requests': '1',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
        'Accept-Encoding': 'gzip, deflate, br',
        'Accept-Language': 'en-US,en;q=0.9,he;q=0.8'
    }
    data = {
        'loginHtml': 'loginHtml',
        'loginHtml:username': USERNAME,
        'loginHtml:password': PASSWORD,
        'loginHtml:userDomain': 'Empty',
        'loginHtml:loginBtn': 'Log In',
        'javax.faces.ViewState': VIEW_STATE
    }

    response = session.post(login_url, headers=headers, data=data, verify=VERIFY_SSL)  # type: ignore
    return session

def GetEventQuery():
    in_xml = create_query_xml("all", interval='1')
    url = QUERY_URL + "eventQuery"
    headers = {'Content-Type': 'text/xml'}
    resp = requests.request('POST', url, headers=headers, data=in_xml, verify=VERIFY_SSL, auth=AUTH)
    validateSuccessfulResponse(resp, "fetching event query")
    queryId = resp.text
    if 'error code="255"' in queryId:
        raise ("Got error code 255 while getting event query. Make sure the query has valid syntax")

    return queryId


def GetIncidentsByOrg(queryId):
    # The request will poll until the server completes the query.
    url = QUERY_URL + "progress/" + queryId
    resp = requests.request('GET', url, verify=VERIFY_SSL, auth=AUTH)

    while resp.text != '100':
        resp = requests.request('GET', url, verify=VERIFY_SSL, auth=AUTH)

    outXML = []
    if resp.text == '100':
        url = QUERY_URL + 'events/' + queryId + '/0/1000'
        resp = requests.request('GET', url, verify=VERIFY_SSL, auth=AUTH)
        content = resp.text
        print (content)
        if content != '':
            outXML.append(content)

        # this code is taken directly from their documentation.
        # get all results (last "page" has less than 1000 records)
        p = re.compile(r'totalCount="\d+"')
        mlist = p.findall(content)
        if mlist and mlist[0] != '':
            mm = mlist[0].replace('"', '')
            m = mm.split("=")[-1]
            num = 0
            if int(m) > 1000:
                num = int(m) / 1000
                if int(m) % 1000 > 0:
                    num += 1
            if num > 0:
                for i in range(num):
                    url = QUERY_URL + 'events/' + queryId + '/' + str(i * 1000 + 1) + '/1000'
                    resp = requests.request('GET', url, verify=VERIFY_SSL, auth=AUTH)
                    content = resp.text
                    if content != '':
                        outXML.append(content)
        else:
            raise ("In Progress")
    phCustId = "all"
    param = dumpXML(outXML, phCustId)
    return param


def create_query_xml(include_value, interval="", single_evt_value="phEventCategory=1", interval_type="Minute",
                     attr_list=None, limit="All"):
    doc = Document()
    reports = doc.createElement("Reports")
    doc.appendChild(reports)
    report = doc.createElement("Report")
    report.setAttribute("id", "")
    report.setAttribute("group", "report")
    reports.appendChild(report)
    name = doc.createElement("Name")
    report.appendChild(name)
    doc.createTextNode("All Incidents")
    custScope = doc.createElement("CustomerScope")
    custScope.setAttribute("groupByEachCustomer", "true")
    report.appendChild(custScope)
    include = doc.createElement("Include")
    if include_value == "all":
        include.setAttribute("all", "true")
        custScope.appendChild(include)
    else:
        custScope.appendChild(include)
        include_text = doc.createTextNode(include_value)
        include.appendChild(include_text)
    exclude = doc.createElement("Exclude")
    custScope.appendChild(exclude)
    description = doc.createElement("description")
    report.appendChild(description)
    select = doc.createElement("SelectClause")
    select.setAttribute("numEntries", limit)
    report.appendChild(select)
    attrList = doc.createElement("AttrList")
    if attr_list:
        attr_text = doc.createTextNode(str(attr_list))
        attrList.appendChild(attr_text)
    select.appendChild(attrList)
    reportInterval = doc.createElement("ReportInterval")
    report.appendChild(reportInterval)
    window = doc.createElement("Window")
    window.setAttribute("unit", interval_type)
    window.setAttribute("val", interval)
    reportInterval.appendChild(window)
    pattern = doc.createElement("PatternClause")
    pattern.setAttribute("window", "3600")
    report.appendChild(pattern)
    subPattern = doc.createElement("SubPattern")
    subPattern.setAttribute("displayName", "Events")
    subPattern.setAttribute("name", "Events")
    pattern.appendChild(subPattern)
    single = doc.createElement("SingleEvtConstr")
    subPattern.appendChild(single)
    single_text = doc.createTextNode(single_evt_value)
    single.appendChild(single_text)
    _filter = doc.createElement("RelevantFilterAttr")
    report.appendChild(_filter)
    return doc.toxml()


def dumpXML(xmlList, phCustId):
    param = []
    for xml in xmlList:
        doc = parseString(xml.encode('utf-8'))
        for node in doc.getElementsByTagName("events"):
            for node1 in node.getElementsByTagName("event"):
                mapping = {}
                for node2 in node1.getElementsByTagName("attributes"):
                    for node3 in node2.getElementsByTagName("attribute"):
                        item_name = node3.getAttribute("name")
                        for node4 in node3.childNodes:
                            if node4.nodeType == Node.TEXT_NODE:
                                mapping[item_name] = node4.data
                    if phCustId == "all" or mapping['phCustId'] == phCustId:
                        param.append(mapping)
    return param



def test():
    try:
        login()
    except Exception as e:
        if isinstance(e, requests.exceptions.SSLError):
            raise("Not verified certificate")
        else:
            raise(str(e))
    return('ok')


def fetch_incidents():
    lastrun = {}
    query_id = GetEventQuery()
    res = GetIncidentsByOrg(query_id)
    known_ids = lastrun.get('ids', None)
    if known_ids is None or not known_ids:
        known_ids = []

    incidents = []
    for inc in res:
        if inc.get('incidentId') not in known_ids:
            incidents.append({"name": inc.get('eventName', 'New FortiSIEM Event'), "rawJSON": json.dumps(inc)})
            if len(known_ids) >= 1000:
                known_ids.pop(0)
            known_ids.append(inc.get('incidentId'))

    lastrun={
        'ids': known_ids
    }
    return incidents


parser = argparse.ArgumentParser(description="Simulated Integration Commands")
parser.add_argument('-command', dest='command', help='Your Test Command')
args = parser.parse_args()
if args.command is None:
  raise ValueError ("Please enter a command to test with")


if args.command == 'test-module':
        print (test())

elif args.command == 'fetch-incidents':
        print (fetch_incidents())
