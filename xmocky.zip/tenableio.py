from flask import Blueprint, request
import json
import logging

BASE_URL = '/'.strip('/')
INTEGRATION = 'tenableio_api'

mock_scans = {
    "folders": [{
        "unread_count": 0,
        "custom": 0,
        "default_tag": 0,
        "type": "trash",
        "name": "Trash",
        "id": 8
    }, {
        "unread_count": 0,
        "custom": 0,
        "default_tag": 1,
        "type": "main",
        "name": "My Scans",
        "id": 9
    }],
    "scans": [
        {
            "legacy": False,
            "permissions": 128,
            "type": None,
            "read": True,
            "last_modification_date": 1430934526,
            "creation_date": 1430933086,
            "status": "complete",
            "uuid": "2776e999-1f5b-45b9-2e15-65a7be35b2e3ab8f7ecb158c480e",
            "shared": False,
            "user_permissions": 128,
            "owner": "user2@example.com",
            "schedule_uuid": "0fafc7a8-c5f6-fe9d-68b9-4d60ab0d9d2cf60557ee0e264228",
            "timezone": None,
            "rrules": None,
            "starttime": None,
            "enabled": False,
            "control": False,
            "name": "KitchenSinkScan",
            "id": 11
        }
    ],
    "timestamp": 1544146142
}

mock_scan = {
        "info": {
            "owner": "user2@example.com",
            "name": "KitchenSinkScan",
            "no_target": False,
            "folder_id": 9,
            "control": False,
            "user_permissions": 128,
            "schedule_uuid": "0fafc7a8-c5f6-fe9d-68b9-4d60ab0d9d2cf60557ee0e264228",
            "edit_allowed": False,
            "scanner_name": "Global Scanner",
            "policy": "Everything including the kitchen sink",
            "shared": False,
            "id": 11,
            "tag_targets": [
                "6fb39d03-fc3d-470d-96f1-6dbb7bef1f51",
                "715f11cc-c503-4a73-9dc2-cbfb1089616d"
            ],
            "acls": [
                {
                    "permissions": 0,
                    "owner": None,
                    "display_name": None,
                    "name": None,
                    "id": None,
                    "type": "default"
                },
                {
                    "permissions": 128,
                    "owner": 1,
                    "display_name": "user2@example.com",
                    "name": "user2@example.com",
                    "id": 2,
                    "type": "user"
                }],
            "hostcount": 10,
            "uuid": "2776e999-1f5b-45b9-2e15-65a7be35b2e3ab8f7ecb158c480e",
            "status": "complete",
            "scan_type": "local",
            "targets": ["172.204.81.57" ],
            "alt_targets_used": None,
            "pci-can-upload": None,
            "scan_start": 1430933086,
            "timestamp": 1430934526,
            "is_archived": False,
            "scan_end": 1430934526,
            "haskb": True,
            "hasaudittrail": True,
            "scanner_start": None,
            "scanner_end": None,
        },
        "history": [
            {
                "history_id": 10328682,
                "owner_id": 2,
                "creation_date": 1430933086,
                "last_modification_date": 1430934526,
                "uuid": "2776e999-1f5b-45b9-2e15-65a7be35b2e3ab8f7ecb158c480e",
                "type": None,
                "status": "pending",
                "scheduler": 0,
                "alt_targets_used": False,
                "is_archived": False,
            }],
        "hosts": [
            {
                "asset_id": 5,
                "host_id": 5,
                "hostname": "172.204.81.57",
                "progress": "100-100/200-200",
                "scanprogresscurrent": 100,
                "scanprogresstotal": 100,
                "numchecksconsidered": 100,
                "totalchecksconsidered": 100,
                "severitycount": {
                    "item": [
                        {
                            "count": 156,
                            "severitylevel": 0,
                        },
                        {
                            "count": 1,
                            "severitylevel": 1,
                        },
                        {
                            "count": 6,
                            "severitylevel": 2,
                        },
                        {
                            "count": 3,
                            "severitylevel": 3,
                        },
                        {
                            "count": 0,
                            "severitylevel": 4,
                        }
                    ]
                },
                "severity": 166,
                "score": 3766,
                "info": 156,
                "low": 1,
                "medium": 6,
                "high": 3,
                "critical": 0,
                "host_index": 0,
            },
            {
                "asset_id": 3,
                "host_id": 3,
                "hostname": "172.204.81.57",
                "progress": "100-100/200-200",
                "scanprogresscurrent": 100,
                "scanprogresstotal": 100,
                "numchecksconsidered": 100,
                "totalchecksconsidered": 100,
                "severitycount": {
                    "item": [
                        {
                            "count": 52,
                            "severitylevel": 0,
                        },
                        {
                            "count": 11,
                            "severitylevel": 1,
                        },
                        {
                            "count": 100,
                            "severitylevel": 2,
                        },
                        {
                            "count": 58,
                            "severitylevel": 3,
                        },
                        {
                            "count": 32,
                            "severitylevel": 4,
                        }
                    ]
                },
                "severity": 253,
                "score": 388162,
                "info": 52,
                "low": 11,
                "medium": 100,
                "high": 58,
                "critical": 32,
                "host_index": 1,
            },
            {
                "asset_id": 9,
                "host_id": 9,
                "hostname": "172.204.81.57",
                "progress": "100-100/200-200",
                "scanprogresscurrent": 100,
                "scanprogresstotal": 100,
                "numchecksconsidered": 100,
                "totalchecksconsidered": 100,
                "severitycount": {
                    "item": [
                        {
                            "count": 115,
                            "severitylevel": 0
                        },
                        {
                            "count": 5,
                            "severitylevel": 1
                        },
                        {
                            "count": 21,
                            "severitylevel": 2
                        },
                        {
                            "count": 45,
                            "severitylevel": 3
                        },
                        {
                            "count": 16,
                            "severitylevel": 4
                        }
                    ]
                },
                "severity": 202,
                "score": 207265,
                "info": 115,
                "low": 5,
                "medium": 21,
                "high": 45,
                "critical": 16,
                "host_index": 2,
            }],
        "vulnerabilities": [
            {
                "count": 68,
                "plugin_id": 34220,
                "plugin_name": "Netstat Portscanner (WMI)",
                "severity": 0,
                "plugin_family": "Port scanners",
                "vuln_index": 1,
            },
            {
                "count": 65,
                "plugin_id": 34252,
                "plugin_name": "Microsoft Windows Remote Listeners Enumeration (WMI)",
                "severity": 0,
                "plugin_family": "Windows",
                "vuln_index": 2,
            },
            {
                "count": 41,
                "plugin_id": 14272,
                "plugin_name": "netstat portscanner (SSH)",
                "severity": 0,
                "plugin_family": "Port scanners",
                "vuln_index": 3,
            }],
        "comphosts": [
            {
                "asset_id": 5,
                "host_id": 5,
                "hostname": "172.204.81.57",
                "progress": "100-100/200-200",
                "scanprogresscurrent": 100,
                "scanprogresstotal": 100,
                "numchecksconsidered": 100,
                "totalchecksconsidered": 100,
                "severitycount": {
                    "item": [
                        {
                            "count": 0,
                            "severitylevel": 0
                        },
                        {
                            "count": 145,
                            "severitylevel": 1
                        },
                        {
                            "count": 62,
                            "severitylevel": 2
                        },
                        {
                            "count": 0,
                            "severitylevel": 3
                        },
                        {
                            "count": 86,
                            "severitylevel": 4
                        }
                    ]
                },
                "score": 867650,
                "info": 0,
                "low": 145,
                "medium": 62,
                "high": 0,
                "critical": 86,
                "host_index": 0,
                "severity": 293,
            },
            {
                "asset_id": 3,
                "host_id": 3,
                "hostname": "172.204.81.57",
                "progress": "100-100/200-200",
                "scanprogresscurrent": 100,
                "scanprogresstotal": 100,
                "numchecksconsidered": 100,
                "totalchecksconsidered": 100,
                "severitycount": {
                    "item": [
                        {
                            "count": 0,
                            "severitylevel": 0
                        },
                        {
                            "count": 52,
                            "severitylevel": 1
                        },
                        {
                            "count": 1,
                            "severitylevel": 2
                        },
                        {
                            "count": 0,
                            "severitylevel": 3
                        },
                        {
                            "count": 45,
                            "severitylevel": 4
                        }
                    ]
                },
                "score": 450620,
                "info": 0,
                "low": 52,
                "medium": 1,
                "high": 0,
                "critical": 45,
                "host_index": 1,
                "severity": 98,
            },
            {
                "asset_id": 9,
                "host_id": 9,
                "hostname": "172.204.81.57",
                "progress": "100-100/200-200",
                "scanprogresscurrent": 100,
                "scanprogresstotal": 100,
                "numchecksconsidered": 100,
                "totalchecksconsidered": 100,
                "severitycount": {
                    "item": [
                        {
                            "count": 0,
                            "severitylevel": 0
                        },
                        {
                            "count": 61,
                            "severitylevel": 1
                        },
                        {
                            "count": 23,
                            "severitylevel": 2
                        },
                        {
                            "count": 0,
                            "severitylevel": 3
                        },
                        {
                            "count": 64,
                            "severitylevel": 4
                        }
                    ]
                },
                "score": 642910,
                "info": 0,
                "low": 61,
                "medium": 23,
                "high": 0,
                "critical": 64,
                "host_index": 2,
                "severity": 148,
            }],
        "compliance": [
            {
                "count": 5,
                "host_id": 0,
                "hostname": None,
                "plugin_family": "Unix Compliance Checks",
                "plugin_id": "143e17d31e1a30830fcc2c3539d803d0",
                "plugin_name": "BSI-100-2: S 4.13: /etc/group consistency - Careful allocation of identifiers",
                "severity": 1,
                "severity_index": 0,
            },
            {
                "count": 5,
                "host_id": 0,
                "hostname": None,
                "plugin_family": "Unix Compliance Checks",
                "plugin_id": "21361aed1df4e64051bc939431ca3096",
                "plugin_name": "BSI-100-2: S 4.105: No world writeable files - Preventing unauthorised acquisition of administrator  ...",
                "severity": 3,
                "severity_index": 1,
            },
            {
                "count": 5,
                "host_id": 0,
                "hostname": None,
                "plugin_family": "Unix Compliance Checks",
                "plugin_id": "5784176f032f448cb73b6cd4d4cff8be",
                "plugin_name": "BSI-100-2: S 4.105: Rlogind must be deactivated",
                "severity": 3,
                "severity_index": 2,
            }],
        "filters": [
            {
                "name": "host.id",
                "readable_name": "Asset ID",
                "control": {
                    "type": "entry",
                    "regex": "[0-9a-f]{8}-([0-9a-f]{4}-){3}[0-9a-f]{12}(,[0-9a-f]{8}-([0-9a-f]{4}-){3}[0-9a-f]{12})*",
                    "readable_regex": "01234567-abcd-ef01-2345-6789abcdef01"
                },
                "operators": [
                    "eq",
                    "neq",
                    "match",
                    "nmatch"
                ],
                "group_name": "vulnerability",
            },
            {
                "name": "plugin.attributes.bid",
                "readable_name": "Bugtraq ID",
                "control": {
                    "type": "entry",
                    "regex": "^[0-9]+(,[0-9]+)*",
                    "readable_regex": "NUMBER",
                    "maxlength": 18
                },
                "operators": [
                    "eq",
                    "neq",
                    "match",
                    "nmatch"
                ],
                "group_name": "vulnerability",
            },
            {
                "name": "plugin.attributes.exploit_framework_canvas",
                "readable_name": "CANVAS Exploit Framework",
                "control": {
                    "type": "dropdown",
                    "list": [
                        "True",
                        "False"
                    ]
                },
                "operators": [
                    "eq",
                    "neq"
                ],
                "group_name": "vulnerability",
            }],
        "notes": [
            {
                "message": "One or more AirWatch API settings are not set",
                "title": "MDM501 AirWatch API settings misconfiguration",
            },
            {
                "message": "Unable to connect to the ActiveSync server.",
                "title": "MDM501 ActiveSync connection error",
            },
            {
                "message": "ADSI server (matrix.tenablesecurity.com) could not connect to server.",
                "title": "adsi_enum_directory_trusts.nbin: ADSI error",
            }],
        "remediations": {
            "num_cves": 2536,
            "num_hosts": 10,
            "num_remediated_cves": 2283,
            "num_impacted_hosts": 8,
            "remediations": [
                {
                    "vulns": 1,
                    "value": "96a449d372af3d23ca9a4f9f9a2ea73e",
                    "hosts": 1,
                    "remediation": "FreeBSD : gpgme -- heap-based buffer overflow in gpgsm status handler (90ca3ba5-19e6-11e4-8616-001b3 ..."
                },
                {
                    "vulns": 296,
                    "value": "319a8ba9e264c876028b2a5abf5a1b0e",
                    "hosts": 1,
                    "remediation": "FreeBSD : mozilla -- multiple vulnerabilities (d0c97697-df2c-4b8b-bff2-cec24dc35af8): Update the aff ..."
                },
                {
                    "vulns": 0,
                    "value": "c22105fdc2756d11c39d1380e58c8fbc",
                    "hosts": 1,
                    "remediation": "RHEL 6 / 7 : postgresql (RHSA-2015:0750): Update the affected packages."
                }
            ]
        }
    }

mock_vulnerability = {
    "info": {
        "id": 34220,
        "count": 13,
        "vuln_count": 14,
        "description": "The remote web server is affected by a command injection vulnerability in GNU Bash known as Shellsho ...",
        "synopsis": "The remote web server is affected by a remote code execution vulnerability.",
        "solution": "Apply the referenced patch.",
        "discovery": {
            "seen_first": "2019-12-31T17:15:52.000Z",
            "seen_last": "2019-12-31T22:53:45.000Z",
        },
        "severity": 4,
        "plugin_details": {
            "family": "CGI abuses",
            "modification_date": "2017-12-31T00:00:00Z",
            "name": "GNU Bash Environment Variable Handling Code Injection (Shellshock)",
            "publication_date": "2014-12-31T00:00:00Z",
            "type": "remote",
            "version": None,
            "severity": 4
        },
        "reference_information": [
        {
            "name": "bid",
            "url": "http://www.securityfocus.com/bid/",
            "values": [
                70103
            ]
        },
        {
            "name": "cert",
            "url": "http://www.kb.cert.org/vuls/id/",
            "values": [
                "252743"
            ]
        },
        {
            "name": "cve",
            "url": "http://web.nvd.nist.gov/view/vuln/detail?vulnId=",
            "values": [
                "CVE-2014-6271"
            ]
        },
        {
            "name": "edb-id",
            "url": "http://www.exploit-db.com/exploits/",
            "values": [
                "34766",
                "34777",
                "34765"
            ]
        },
        {
            "name": "iava",
            "values": [
                "2014-A-0142"
            ]
        },
        {
            "name": "osvdb",
            "values": [
                "112004"
            ]
        }],
        "risk_information": {
            "risk_factor": "Critical",
            "cvss_vector": "AV:N/AC:L/Au:N/C:C/I:C/A:C",
            "cvss_base_score": "10.0",
            "cvss_temporal_vector": "E:F/RL:OF/RC:ND",
            "cvss_temporal_score": "8.3",
            "cvss3_vector": None,
            "cvss3_base_score": None,
            "cvss3_temporal_vector": None,
            "cvss3_temporal_score": None,
            "stig_severity": None,
        },
        "see_also": [
            "http://seclists.org/oss-sec/2014/q3/650",
            "http://www.nessus.org/u?dacf7829",
            "https://www.invisiblethreat.ca/post/shellshock/"
        ],
        "vulnerability_information": {
            "vulnerability_publication_date": "2014-12-31T00:00:00Z",
            "exploited_by_malware": True,
            "patch_publication_date": "2014-12-31T00:00:00Z",
            "exploit_available": True,
            "exploitability_ease": None,
            "asset_inventory": None,
            "default_account": None,
            "exploited_by_nessus": None,
            "in_the_news": True,
            "malware": None,
            "unsupported_by_vendor": None,
            "cpe": None,
            "exploit_frameworks": [
                {
                    "name": "Core Impact"
                },
                {
                    "name": "Metasploit",
                    "exploits": [
                        {
                            "name": "Apache mod_cgi Bash Environment Variable Code Injection (Shellshock)",
                            "url": None
                        }
                    ]
            }]
        },
        "vpr": {
            "score": 9.6,
            "drivers": {
                "age_of_vuln": {
                    "lower_bound": 731,
                    "upper_bound": 0
                },
                "exploit_code_maturity": "HIGH",
                "cvss3_impact_score": 5.9,
                "cvss_impact_score_predicted": True,
                "threat_intensity_last28": "HIGH",
                "threat_recency": {
                    "lower_bound": 0,
                    "upper_bound": 7
                },
                "threat_sources_last28": [
                    "Others",
                    "Mainstream Media",
                    "Code Repo and Paste Bins"
                ],
                "product_coverage": "LOW"
            },
            "updated": "2019-12-31T10:10:57Z"
        }
    }
}

mock_vulnerability_maps = {
    "14272": {
        "name": "Netstat Portscanner (SSH)",
        "description": "Nessus was able to run 'netstat' on the remote host to enumerate the open ports. See the section 'plugins options' about configuring this plugin.\nNote: This plugin will run on Windows (using netstat.exe) in the event that the target being scanned is localhost.",
        "synopsis": "Remote open ports can be enumerated via SSH."
    },
    "34252": {
        "name": "Microsoft Windows Remote Listeners Enumeration (WMI)",
        "description": "This script uses WMI to list the processes running on the remote host and listening on TCP / UDP ports.",
        "synopsis": "It is possible to obtain the names of processes listening on the remote UDP and TCP ports."
    },
    "34220": {
        "name": "Netstat Portscanner (WMI)",
        "description": "Using the WMI interface, Nessus was able to run 'netstat' on the remote host to enumerate the open ports.",
        "synopsis": "Remote open ports can be enumerated via WMI."
    }
}

mock_vulnerabilities = {
    "vulnerabilities": [
        {
            "count": 55,
            "plugin_family": "Port scanners",
            "plugin_id": 34220,
            "plugin_name": "Netstat Portscanner (WMI)",
            "vulnerability_state": "Active",
            "vpr_score": 2.4,
            "accepted_count": 0,
            "recasted_count": 0,
            "counts_by_severity": [
                {
                    "count": 55,
                    "value": 0
                }
            ],
            "severity": 0,
        },
        {
            "count": 54,
            "plugin_family": "Windows",
            "plugin_id": 34252,
            "plugin_name": "Microsoft Windows Remote Listeners Enumeration (WMI)",
            "vulnerability_state": "Active",
            "vpr_score": 6.3,
            "accepted_count": 0,
            "recasted_count": 0,
            "counts_by_severity": [
                {
                    "count": 54,
                    "value": 0
                }
            ],
            "severity": 0,
        },
        {
            "count": 21,
            "plugin_family": "Service detection",
            "plugin_id": 22964,
            "plugin_name": "Service Detection",
            "vulnerability_state": "Active",
            "vpr_score": 4.5,
            "accepted_count": 0,
            "recasted_count": 0,
            "counts_by_severity": [
                {
                    "count": 21,
                    "value": 0
                }
            ],
            "severity": 0
        },
        {
            "count": 18,
            "plugin_family": "Web Servers",
            "plugin_id": 24260,
            "plugin_name": "HyperText Transfer Protocol (HTTP) Information",
            "vulnerability_state": "Active",
            "vpr_score": 5.5,
            "accepted_count": 0,
            "recasted_count": 0,
            "counts_by_severity": [
                {
                    "count": 18,
                    "value": 0
                }
            ],
            "severity": 0
    }
    ],
    "total_vulnerability_count": 3,
    "total_asset_count": 0
}

mock_asset = {
    "assets": [
        {
            "id": "31e37f64-cf0f-4ba0-9359-f5094a92352b",
            "has_agent": False,
            "last_seen": "2018-12-31T17:28:28.000Z",
            "last_scan_target": "172.204.81.57",
            "sources": [{
                "name": "NESSUS_SCAN",
                "first_seen": "2018-12-31T15:00:25.000Z",
                "last_seen": "2018-12-31T17:28:28.000Z",
            }],
            "ipv4": ["172.204.81.57"],
            "ipv6": [],
            "fqdn": [],
            "netbios_name": ["S11C"],
            "operating_system": ["Microsoft Windows Server 2008 R2 Datacenter Service Pack 1"],
            "agent_name": [],
            "aws_ec2_name": [],
            "mac_address": [],
            "bigfix_asset_id": [],
        },
        {
            "id": "7e35af00-a3f0-4d43-a354-0638ba2b05ae",
            "has_agent": False,
            "last_seen": "2018-12-31T17:28:28.000Z",
            "last_scan_target": "172.204.81.58",
            "sources": [{
                "name": "NESSUS_SCAN",
                "first_seen": "2018-12-31T15:00:25.000Z",
                "last_seen": "2018-12-31T17:28:28.000Z",
            }],
            "acr_score": 8,
            "acr_drivers": [{
                "driver_name": "device_type",
                "driver_value": ["general_purpose"]
            },
            {
                "driver_name": "device_capability",
                "driver_value": ["pci"]
            },
                {
                "driver_name": "internet_exposure",
                "driver_value": ["internal"]
                }
            ],
            "exposure_score": 753,
            "scan_frequency": [
                {
                    "interval": 90,
                    "frequency": 3,
                    "licensed": False
                },
                {
                    "interval": 30,
                    "frequency": 1,
                    "licensed": False
                },
                {
                    "interval": 60,
                    "frequency": 1,
                    "licensed": False
                }
            ],
            "ipv4": ["172.204.81.58"],
            "ipv6": [],
            "fqdn": ["freebsd11.dc.demo.io"],
            "netbios_name": [],
            "operating_system": ["FreeBSD 11.1"],
            "agent_name": [],
            "aws_ec2_name": [],
            "mac_address": [],
            "bigfix_asset_id": [],
        },
        {
            "id": "466934be-abb4-4fa9-b8b8-27ace85e5523",
            "has_agent": False,
            "last_seen": "2018-12-31T17:28:28.000Z",
            "last_scan_target": "172.204.81.59",
            "sources": [
                {
                    "name": "NESSUS_SCAN",
                    "first_seen": "2018-12-31T15:00:25.000Z",
                    "last_seen": "2018-12-31T17:28:28.000Z"
                }
            ],
            "ipv4": ["172.204.81.59"],
            "ipv6": [],
            "fqdn": ["fedorawork27.dc.demo.io"],
            "netbios_name": [],
            "operating_system": ["Linux Kernel 4.13.9-300.fc27.x86_64 on Fedora release 27 (Twenty Seven)"],
            "agent_name": [],
            "aws_ec2_name": [],
            "mac_address": [],
            "bigfix_asset_id": [],
        }
    ],
    "total": 3
}

tenableio_api = Blueprint(f'{INTEGRATION}', __name__)
logger = logging.getLogger(__name__)


@tenableio_api.route(f'/{BASE_URL}/scans/', methods=['GET'])
def get_scans():
    if request.method == 'GET':
        args = request.args
        folder_id = args.get('folder_id', None)
        return_scans = mock_scans
        if folder_id:
            return_scans['scans'][0]['id'] = folder_id
        return json.dumps(mock_scans)


@tenableio_api.route(f'/{BASE_URL}/scans/<scanID>', methods=['GET'])
def get_scan(scanID):
    if request.method == 'GET':
        return_scan = mock_scan
        return_scan['info']['folder_id'] = scanID
        return json.dumps(return_scan)


@tenableio_api.route(f'/{BASE_URL}/scans/<scanID>/launch', methods=['POST'])
def launch_scan(scanID):
    if request.method == 'POST':
        return json.dumps({
            "scan_uuid": "e7f6c3f2-1718-4451-b459-1e8aa2ec6cdf"
        })


@tenableio_api.route(f'/{BASE_URL}/workbenches/vulnerabilities/<vulnID>/info', methods=['GET'])
def get_vuln_info(vulnID):
    if request.method == 'GET':
        return_vuln = mock_vulnerability
        return_vuln['info']['id'] = vulnID
        try:
            return_vuln['info']['plugin_details']['name'] = mock_vulnerability_maps[vulnID]['name']
            return_vuln['info']['description'] = mock_vulnerability_maps[vulnID]['description']
            return_vuln['info']['synopsis'] = mock_vulnerability_maps[vulnID]['synopsis']
        except Exception:
            pass
        return json.dumps(return_vuln)


@tenableio_api.route(f'/{BASE_URL}/workbenches/assets', methods=['GET'])
def get_asset():
    args = request.args
    user_filter = args.get('filter.0.value', None)
    asset = dict()
    if request.method == 'GET':
        if user_filter:
            asset['assets'] = [mock_asset['assets'][0]]
            asset['total'] = 1
            filter_is_ip = False
            if len(user_filter.split(".")) > 3:
                filter_is_ip = True
            asset = json.dumps(asset)
            asset = asset.replace("172.204.81.57", user_filter) if filter_is_ip else asset.replace("S11C", user_filter)
            asset = json.loads(asset)
        return json.dumps(asset)


@tenableio_api.route(f'/{BASE_URL}/workbenches/assets/<assetID>/vulnerabilities/', methods=['GET'])
def get_asset_vulnerabilities(assetID):
    return json.dumps(mock_vulnerabilities)
    