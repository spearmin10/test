from flask import Blueprint, request
import json
import logging

BASE_URL = '/vtapi/v2/'.strip('/')
INTEGRATION = 'VT_api'

VT_api = Blueprint(f'{INTEGRATION}', __name__)
logger = logging.getLogger(__name__)

@VT_api.route(f'/{BASE_URL}/test')
def test():
    return {'result': 'it works'}

@VT_api.route(f'/{BASE_URL}/file/report', methods = ['GET', 'POST'])
def files():
    resource = request.form.get('resource')
    if len(resource) == 64:
        return {"scans": {"Bkav": {"detected": False, "version": "1.3.0.9899", "result": "null", "update": "20200602"}, "TotalDefense": {"detected": False, "version": "37.1.62.1", "result": "null", "update": "20200601"}, "MicroWorld-eScan": {"detected": False, "version": "14.0.409.0", "result": "null", "update": "20200602"}, "FireEye": {"detected": True, "version": "32.31.0.0", "result": "null", "update": "20200602"}, "CAT-QuickHeal": {"detected": False, "version": "14.00", "result": "null", "update": "20200602"}, "McAfee": {"detected": True, "version": "6.0.6.653", "result": "null", "update": "20200602"}, "Malwarebytes": {"detected": False, "version": "3.6.4.335", "result": "null", "update": "20200602"}, "Zillya": {"detected": False, "version": "2.0.0.4101", "result": "null", "update": "20200601"}, "SUPERAntiSpyware": {"detected": False, "version": "5.6.0.1032", "result": "null", "update": "20200530"}, "Sangfor": {"detected": False, "version": "1.0", "result": "null", "update": "20200423"}, "Trustlook": {"detected": False, "version": "1.0", "result": "null", "update": "20200602"}, "Alibaba": {"detected": False, "version": "0.3.0.5", "result": "null", "update": "20190527"}, "K7GW": {"detected": False, "version": "11.113.34274", "result": "null", "update": "20200602"}, "K7AntiVirus": {"detected": False, "version": "11.113.34273", "result": "null", "update": "20200602"}, "BitDefenderTheta": {"detected": False, "version": "7.2.37796.0", "result": "null", "update": "20200521"}, "F-Prot": {"detected": False, "version": "4.7.1.166", "result": "null", "update": "20200602"}, "SymantecMobileInsight": {"detected": False, "version": "2.0", "result": "null", "update": "20200527"}, "Symantec": {"detected": False, "version": "1.11.0.0", "result": "null", "update": "20200602"}, "ESET-NOD32": {"detected": False, "version": "21426", "result": "null", "update": "20200602"}, "Baidu": {"detected": False, "version": "1.0.0.2", "result": "null", "update": "20190318"}, "TrendMicro-HouseCall": {"detected": False, "version": "10.0.0.1040", "result": "null", "update": "20200602"}, "Avast": {"detected": False, "version": "18.4.3895.0", "result": "null", "update": "20200602"}, "ClamAV": {"detected": False, "version": "0.102.3.0", "result": "null", "update": "20200601"}, "Kaspersky": {"detected": False, "version": "15.0.1.13", "result": "null", "update": "20200602"}, "BitDefender": {"detected": False, "version": "7.2", "result": "null", "update": "20200602"}, "NANO-Antivirus": {"detected": False, "version": "1.0.134.25112", "result": "null", "update": "20200602"}, "ViRobot": {"detected": False, "version": "2014.3.20.0", "result": "null", "update": "20200602"}, "Tencent": {"detected": False, "version": "1.0.0.1", "result": "null", "update": "20200602"}, "Ad-Aware": {"detected": False, "version": "3.0.5.370", "result": "null", "update": "20200602"}, "Emsisoft": {"detected": False, "version": "2018.12.0.1641", "result": "null", "update": "20200602"}, "Comodo": {"detected": False, "version": "32497", "result": "null", "update": "20200602"}, "F-Secure": {"detected": False, "version": "12.0.86.52", "result": "null", "update": "20200602"}, "DrWeb": {"detected": False, "version": "7.0.46.3050", "result": "null", "update": "20200602"}, "VIPRE": {"detected": False, "version": "84170", "result": "null", "update": "20200602"}, "TrendMicro": {"detected": False, "version": "11.0.0.1006", "result": "null", "update": "20200602"}, "McAfee-GW-Edition": {"detected": False, "version": "v2017.3010", "result": "null", "update": "20200602"}, "CMC": {"detected": False, "version": "1.1.0.977", "result": "null", "update": "20190321"}, "Sophos": {"detected": False, "version": "4.98.0", "result": "null", "update": "20200602"}, "Ikarus": {"detected": False, "version": "0.1.5.2", "result": "null", "update": "20200602"}, "Cyren": {"detected": False, "version": "6.3.0.2", "result": "null", "update": "20200602"}, "Jiangmin": {"detected": False, "version": "16.0.100", "result": "null", "update": "20200602"}, "Avira": {"detected": False, "version": "8.3.3.8", "result": "null", "update": "20200602"}, "Fortinet": {"detected": False, "version": "6.2.142.0", "result": "null", "update": "20200602"}, "Antiy-AVL": {"detected": False, "version": "3.0.0.1", "result": "null", "update": "20200602"}, "Kingsoft": {"detected": False, "version": "2013.8.14.323", "result": "null", "update": "20200602"}, "Arcabit": {"detected": False, "version": "1.0.0.875", "result": "null", "update": "20200602"}, "AegisLab": {"detected": False, "version": "4.2", "result": "null", "update": "20200602"}, "ZoneAlarm": {"detected": False, "version": "1.0", "result": "null", "update": "20200602"}, "Avast-Mobile": {"detected": False, "version": "200602-00", "result": "null", "update": "20200602"}, "Microsoft": {"detected": False, "version": "1.1.17100.2", "result": "null", "update": "20200602"}, "TACHYON": {"detected": False, "version": "2020-06-02.03", "result": "null", "update": "20200602"}, "AhnLab-V3": {"detected": False, "version": "3.17.6.27456", "result": "null", "update": "20200602"}, "VBA32": {"detected": False, "version": "4.4.1", "result": "null", "update": "20200602"}, "ALYac": {"detected": False, "version": "1.1.1.5", "result": "null", "update": "20200602"}, "MAX": {"detected": False, "version": "2019.9.16.1", "result": "null", "update": "20200602"}, "Zoner": {"detected": False, "version": "0.0.0.0", "result": "null", "update": "20200601"}, "Rising": {"detected": False, "version": "25.0.0.25", "result": "null", "update": "20200602"}, "Yandex": {"detected": False, "version": "5.5.2.24", "result": "null", "update": "20200602"}, "SentinelOne": {"detected": False, "version": "4.3.0.105", "result": "null", "update": "20200601"}, "MaxSecure": {"detected": False, "version": "1.0.0.1", "result": "null", "update": "20200602"}, "GData": {"detected": False, "version": "A:25.25812B:26.18948", "result": "null", "update": "20200602"}, "AVG": {"detected": False, "version": "18.4.3895.0", "result": "null", "update": "20200602"}, "Panda": {"detected": False, "version": "4.6.4.2", "result": "null", "update": "20200601"}, "Qihoo-360": {"detected": False, "version": "1.0.0.1120", "result": "null", "update": "20200602"}}, "scan_id": resource+"-1591091521", "sha1": "a64ca33d288601dade89b776bf04ae5b6e33261a", "resource": resource, "response_code": 1, "scan_date": "2020-06-02 09:52:01", "permalink": "https://www.virustotal.com/gui/file/f8ae6655f82b1cf1d6b7d37d0d69771f3d821407685ff51c3199e3d19d7b0d0e/detection/f-f8ae6655f82b1cf1d6b7d37d0d69771f3d821407685ff51c3199e3d19d7b0d0e-1591091521", "verbose_msg": "Scan finished, information embedded", "total": 64, "positives": 0, "sha256": resource, "md5": "f198bbbbd98d5b0f07e961b431454528"}
    elif len(resource) == 40:
        return {"scans": {"Bkav": {"detected": False, "version": "1.3.0.9899", "result": "null", "update": "20200601"}, "TotalDefense": {"detected": False, "version": "37.1.62.1", "result": "null", "update": "20200601"}, "MicroWorld-eScan": {"detected": False, "version": "14.0.409.0", "result": "null", "update": "20200602"}, "FireEye": {"detected": False, "version": "32.31.0.0", "result": "null", "update": "20200602"}, "CAT-QuickHeal": {"detected": False, "version": "14.00", "result": "null", "update": "20200602"}, "ALYac": {"detected": False, "version": "1.1.1.5", "result": "null", "update": "20200602"}, "Malwarebytes": {"detected": False, "version": "3.6.4.335", "result": "null", "update": "20200602"}, "Zillya": {"detected": False, "version": "2.0.0.4101", "result": "null", "update": "20200601"}, "SUPERAntiSpyware": {"detected": True, "version": "5.6.0.1032", "result": "null", "update": "20200530"}, "Sangfor": {"detected": False, "version": "1.0", "result": "null", "update": "20200423"}, "Trustlook": {"detected": False, "version": "1.0", "result": "null", "update": "20200602"}, "Alibaba": {"detected": False, "version": "0.3.0.5", "result": "null", "update": "20190527"}, "K7GW": {"detected": False, "version": "11.113.34274", "result": "null", "update": "20200602"}, "K7AntiVirus": {"detected": False, "version": "11.113.34273", "result": "null", "update": "20200602"}, "Baidu": {"detected": False, "version": "1.0.0.2", "result": "null", "update": "20190318"}, "F-Prot": {"detected": False, "version": "4.7.1.166", "result": "null", "update": "20200602"}, "SymantecMobileInsight": {"detected": False, "version": "2.0", "result": "null", "update": "20200527"}, "Symantec": {"detected": False, "version": "1.11.0.0", "result": "null", "update": "20200602"}, "ESET-NOD32": {"detected": False, "version": "21426", "result": "null", "update": "20200602"}, "TrendMicro-HouseCall": {"detected": True, "version": "10.0.0.1040", "result": "ANDROIDOS_MICG.AXM", "update": "20200602"}, "Avast": {"detected": False, "version": "18.4.3895.0", "result": "null", "update": "20200602"}, "ClamAV": {"detected": False, "version": "0.102.3.0", "result": "null", "update": "20200601"}, "Kaspersky": {"detected": False, "version": "15.0.1.13", "result": "null", "update": "20200602"}, "BitDefender": {"detected": False, "version": "7.2", "result": "null", "update": "20200602"}, "NANO-Antivirus": {"detected": False, "version": "1.0.134.25112", "result": "null", "update": "20200602"}, "AegisLab": {"detected": False, "version": "4.2", "result": "null", "update": "20200602"}, "Tencent": {"detected": False, "version": "1.0.0.1", "result": "null", "update": "20200602"}, "Ad-Aware": {"detected": False, "version": "3.0.5.370", "result": "null", "update": "20200602"}, "Emsisoft": {"detected": False, "version": "2018.12.0.1641", "result": "null", "update": "20200602"}, "Comodo": {"detected": False, "version": "32497", "result": "null", "update": "20200602"}, "F-Secure": {"detected": False, "version": "12.0.86.52", "result": "null", "update": "20200602"}, "DrWeb": {"detected": False, "version": "7.0.46.3050", "result": "null", "update": "20200602"}, "VIPRE": {"detected": False, "version": "84170", "result": "null", "update": "20200602"}, "TrendMicro": {"detected": False, "version": "11.0.0.1006", "result": "ANDROIDOS_MICG.AXM", "update": "20200602"}, "McAfee-GW-Edition": {"detected": False, "version": "v2017.3010", "result": "null", "update": "20200602"}, "CMC": {"detected": False, "version": "1.1.0.977", "result": "null", "update": "20190321"}, "Sophos": {"detected": False, "version": "4.98.0", "result": "null", "update": "20200602"}, "SentinelOne": {"detected": False, "version": "4.3.0.105", "result": "null", "update": "20200601"}, "Cyren": {"detected": False, "version": "6.3.0.2", "result": "null", "update": "20200602"}, "Jiangmin": {"detected": False, "version": "16.0.100", "result": "null", "update": "20200602"}, "Avira": {"detected": False, "version": "8.3.3.8", "result": "null", "update": "20200602"}, "Fortinet": {"detected": False, "version": "6.2.142.0", "result": "null", "update": "20200602"}, "Antiy-AVL": {"detected": False, "version": "3.0.0.1", "result": "null", "update": "20200602"}, "Kingsoft": {"detected": False, "version": "2013.8.14.323", "result": "null", "update": "20200602"}, "Arcabit": {"detected": False, "version": "1.0.0.875", "result": "null", "update": "20200602"}, "ViRobot": {"detected": False, "version": "2014.3.20.0", "result": "null", "update": "20200602"}, "ZoneAlarm": {"detected": False, "version": "1.0", "result": "null", "update": "20200602"}, "Avast-Mobile": {"detected": False, "version": "200602-00", "result": "null", "update": "20200602"}, "Microsoft": {"detected": False, "version": "1.1.17100.2", "result": "null", "update": "20200602"}, "TACHYON": {"detected": False, "version": "2020-06-02.03", "result": "null", "update": "20200602"}, "AhnLab-V3": {"detected": False, "version": "3.17.6.27456", "result": "null", "update": "20200602"}, "McAfee": {"detected": False, "version": "6.0.6.653", "result": "null", "update": "20200602"}, "MAX": {"detected": False, "version": "2019.9.16.1", "result": "null", "update": "20200602"}, "VBA32": {"detected": False, "version": "4.4.1", "result": "null", "update": "20200602"}, "Zoner": {"detected": False, "version": "0.0.0.0", "result": "null", "update": "20200601"}, "Rising": {"detected": False, "version": "25.0.0.25", "result": "null", "update": "20200602"}, "Yandex": {"detected": False, "version": "5.5.2.24", "result": "null", "update": "20200602"}, "Ikarus": {"detected": False, "version": "0.1.5.2", "result": "null", "update": "20200601"}, "MaxSecure": {"detected": False, "version": "1.0.0.1", "result": "null", "update": "20200602"}, "GData": {"detected": False, "version": "A:25.25812B:26.18948", "result": "null", "update": "20200602"}, "BitDefenderTheta": {"detected": False, "version": "7.2.37796.0", "result": "null", "update": "20200521"}, "AVG": {"detected": False, "version": "18.4.3895.0", "result": "null", "update": "20200602"}, "Panda": {"detected": False, "version": "4.6.4.2", "result": "null", "update": "20200601"}, "Qihoo-360": {"detected": False, "version": "1.0.0.1120", "result": "null", "update": "20200602"}}, "scan_id": "a56237c1ec79a67f6f56aaa7c3311719745225162856ca945a7547f4fa502e09-1591090684", "sha1": resource, "resource": resource, "response_code": 1, "scan_date": "2020-06-02 09:38:04", "permalink": "https://www.virustotal.com/gui/file/a56237c1ec79a67f6f56aaa7c3311719745225162856ca945a7547f4fa502e09/detection/f-a56237c1ec79a67f6f56aaa7c3311719745225162856ca945a7547f4fa502e09-1591090684", "verbose_msg": "Scan finished, information embedded", "total": 64, "positives": 2, "sha256": "a56237c1ec79a67f6f56aaa7c3311719745225162856ca945a7547f4fa502e09", "md5": "db380eae19543eb800167c792a3e4c60"}
    elif len(resource) == 32:
        return {"scans": {"Bkav": {"detected": False, "version": "1.3.0.9899", "result": "null", "update": "20200602"}, "TotalDefense": {"detected": False, "version": "37.1.62.1", "result": "null", "update": "20200601"}, "MicroWorld-eScan": {"detected": False, "version": "14.0.409.0", "result": "null", "update": "20200602"}, "FireEye": {"detected": False, "version": "32.31.0.0", "result": "null", "update": "20200602"}, "CAT-QuickHeal": {"detected": False, "version": "14.00", "result": "null", "update": "20200602"}, "McAfee": {"detected": False, "version": "6.0.6.653", "result": "null", "update": "20200602"}, "Malwarebytes": {"detected": False, "version": "3.6.4.335", "result": "null", "update": "20200602"}, "Zillya": {"detected": False, "version": "2.0.0.4101", "result": "null", "update": "20200601"}, "SUPERAntiSpyware": {"detected": False, "version": "5.6.0.1032", "result": "null", "update": "20200530"}, "Sangfor": {"detected": False, "version": "1.0", "result": "null", "update": "20200423"}, "Trustlook": {"detected": False, "version": "1.0", "result": "null", "update": "20200602"}, "Alibaba": {"detected": False, "version": "0.3.0.5", "result": "null", "update": "20190527"}, "K7GW": {"detected": False, "version": "11.113.34274", "result": "null", "update": "20200602"}, "K7AntiVirus": {"detected": False, "version": "11.113.34276", "result": "null", "update": "20200602"}, "BitDefenderTheta": {"detected": False, "version": "7.2.37796.0", "result": "null", "update": "20200521"}, "F-Prot": {"detected": False, "version": "4.7.1.166", "result": "null", "update": "20200602"}, "SymantecMobileInsight": {"detected": False, "version": "2.0", "result": "null", "update": "20200527"}, "Symantec": {"detected": False, "version": "1.11.0.0", "result": "null", "update": "20200602"}, "ESET-NOD32": {"detected": False, "version": "21427", "result": "null", "update": "20200602"}, "Baidu": {"detected": False, "version": "1.0.0.2", "result": "null", "update": "20190318"}, "TrendMicro-HouseCall": {"detected": True, "version": "10.0.0.1040", "result": "ANDROIDOS_MICG.AXM", "update": "20200602"}, "Avast": {"detected": False, "version": "18.4.3895.0", "result": "null", "update": "20200602"}, "ClamAV": {"detected": False, "version": "0.102.3.0", "result": "null", "update": "20200601"}, "Kaspersky": {"detected": False, "version": "15.0.1.13", "result": "null", "update": "20200602"}, "BitDefender": {"detected": False, "version": "7.2", "result": "null", "update": "20200602"}, "NANO-Antivirus": {"detected": False, "version": "1.0.134.25112", "result": "null", "update": "20200602"}, "ViRobot": {"detected": False, "version": "2014.3.20.0", "result": "null", "update": "20200602"}, "Rising": {"detected": False, "version": "25.0.0.25", "result": "null", "update": "20200602"}, "Ad-Aware": {"detected": False, "version": "3.0.5.370", "result": "null", "update": "20200602"}, "Emsisoft": {"detected": False, "version": "2018.12.0.1641", "result": "null", "update": "20200602"}, "Comodo": {"detected": False, "version": "32497", "result": "null", "update": "20200602"}, "F-Secure": {"detected": False, "version": "12.0.86.52", "result": "null", "update": "20200602"}, "DrWeb": {"detected": False, "version": "7.0.46.3050", "result": "null", "update": "20200602"}, "VIPRE": {"detected": False, "version": "84170", "result": "null", "update": "20200602"}, "TrendMicro": {"detected": True, "version": "11.0.0.1006", "result": "ANDROIDOS_MICG.AXM", "update": "20200602"}, "McAfee-GW-Edition": {"detected": False, "version": "v2017.3010", "result": "null", "update": "20200602"}, "CMC": {"detected": False, "version": "1.1.0.977", "result": "null", "update": "20190321"}, "Sophos": {"detected": False, "version": "4.98.0", "result": "null", "update": "20200602"}, "SentinelOne": {"detected": False, "version": "4.3.0.105", "result": "null", "update": "20200601"}, "Cyren": {"detected": False, "version": "6.3.0.2", "result": "null", "update": "20200602"}, "Jiangmin": {"detected": False, "version": "16.0.100", "result": "null", "update": "20200602"}, "Avira": {"detected": False, "version": "8.3.3.8", "result": "null", "update": "20200602"}, "Fortinet": {"detected": False, "version": "6.2.142.0", "result": "null", "update": "20200602"}, "Antiy-AVL": {"detected": False, "version": "3.0.0.1", "result": "null", "update": "20200602"}, "Kingsoft": {"detected": False, "version": "2013.8.14.323", "result": "null", "update": "20200602"}, "Arcabit": {"detected": False, "version": "1.0.0.875", "result": "null", "update": "20200602"}, "AegisLab": {"detected": False, "version": "4.2", "result": "null", "update": "20200602"}, "ZoneAlarm": {"detected": False, "version": "1.0", "result": "null", "update": "20200602"}, "Avast-Mobile": {"detected": False, "version": "200602-00", "result": "null", "update": "20200602"}, "Microsoft": {"detected": False, "version": "1.1.17100.2", "result": "null", "update": "20200602"}, "TACHYON": {"detected": False, "version": "2020-06-02.03", "result": "null", "update": "20200602"}, "AhnLab-V3": {"detected": False, "version": "3.17.6.27456", "result": "null", "update": "20200602"}, "VBA32": {"detected": False, "version": "4.4.1", "result": "null", "update": "20200602"}, "ALYac": {"detected": False, "version": "1.1.1.5", "result": "null", "update": "20200602"}, "MAX": {"detected": False, "version": "2019.9.16.1", "result": "null", "update": "20200602"}, "Zoner": {"detected": False, "version": "0.0.0.0", "result": "null", "update": "20200601"}, "Tencent": {"detected": False, "version": "1.0.0.1", "result": "null", "update": "20200602"}, "Yandex": {"detected": False, "version": "5.5.2.24", "result": "null", "update": "20200602"}, "Ikarus": {"detected": False, "version": "0.1.5.2", "result": "null", "update": "20200602"}, "MaxSecure": {"detected": False, "version": "1.0.0.1", "result": "null", "update": "20200602"}, "GData": {"detected": False, "version": "A:25.25812B:26.18948", "result": "null", "update": "20200602"}, "AVG": {"detected": False, "version": "18.4.3895.0", "result": "null", "update": "20200602"}, "Panda": {"detected": False, "version": "4.6.4.2", "result": "null", "update": "20200601"}, "Qihoo-360": {"detected": False, "version": "1.0.0.1120", "result": "null", "update": "20200602"}}, "scan_id": "a56237c1ec79a67f6f56aaa7c3311719745225162856ca945a7547f4fa502e09-1591092190", "sha1": "6cd3d0b140bf27e6b4e7019649e786e4455723b3", "resource": resource, "response_code": 1, "scan_date": "2020-06-02 10:03:10", "permalink": "https://www.virustotal.com/gui/file/a56237c1ec79a67f6f56aaa7c3311719745225162856ca945a7547f4fa502e09/detection/f-a56237c1ec79a67f6f56aaa7c3311719745225162856ca945a7547f4fa502e09-1591092190", "verbose_msg": "Scan finished, information embedded", "total": 64, "positives": 2, "sha256": "a56237c1ec79a67f6f56aaa7c3311719745225162856ca945a7547f4fa502e09", "md5": resource}
    else:
        return {"response_code": 0, "resource": "c1fc8cf4d9a2e29fbb79ebcd8b279d439b89fe49", "verbose_msg": "The requested resource is not among the finished, queued or pending scans"}

@VT_api.route(f'/{BASE_URL}/url/report', methods = ['GET', 'POST'])
def urls():
    resource = request.args.get('resource')
    return {"scan_id": "585b4177ee3f4fefbd14344f96139c5fced7e68d2c7261c447a4e6f86ebc4533-1590569619", "resource": resource, "url": resource, "response_code": 1, "scan_date": "2020-05-27 08:53:39", "permalink": "https://www.virustotal.com/gui/url/585b4177ee3f4fefbd14344f96139c5fced7e68d2c7261c447a4e6f86ebc4533/detection/u-585b4177ee3f4fefbd14344f96139c5fced7e68d2c7261c447a4e6f86ebc4533-1590569619", "verbose_msg": "Scan finished, scan information embedded in this object", "filescan_id": "null", "positives": 2, "total": 80, "scans": {"Botvrij.eu": {"detected": True, "result": "malware site"}, "Feodo Tracker": {"detected": True, "result": "malware site"}, "CLEAN MX": {"detected": False, "result": "clean site"}, "DNS8": {"detected": False, "result": "clean site"}, "NotMining": {"detected": False, "result": "unrated site"}, "VX Vault": {"detected": False, "result": "clean site"}, "securolytics": {"detected": False, "result": "clean site"}, "Tencent": {"detected": False, "result": "clean site"}, "MalwarePatrol": {"detected": False, "result": "clean site"}, "MalSilo": {"detected": False, "result": "clean site"}, "Comodo Valkyrie Verdict": {"detected": False, "result": "unrated site"}, "PhishLabs": {"detected": False, "result": "unrated site"}, "EmergingThreats": {"detected": False, "result": "clean site"}, "Sangfor": {"detected": False, "result": "clean site"}, "K7AntiVirus": {"detected": False, "result": "clean site"}, "Spam404": {"detected": False, "result": "clean site"}, "Virusdie External Site Scan": {"detected": False, "result": "clean site"}, "Artists Against 419": {"detected": False, "result": "clean site"}, "IPsum": {"detected": False, "result": "clean site"}, "Cyren": {"detected": False, "result": "clean site"}, "Quttera": {"detected": False, "result": "clean site"}, "CINS Army": {"detected": False, "result": "clean site"}, "AegisLab WebGuard": {"detected": False, "result": "clean site"}, "MalwareDomainList": {"detected": False, "result": "clean site", "detail": "http://www.malwaredomainlist.com/mdl.php?search=www.google.fi"}, "Lumu": {"detected": False, "result": "unrated site"}, "zvelo": {"detected": False, "result": "clean site"}, "Google Safebrowsing": {"detected": False, "result": "clean site"}, "Kaspersky": {"detected": False, "result": "clean site"}, "BitDefender": {"detected": False, "result": "clean site"}, "GreenSnow": {"detected": False, "result": "clean site"}, "G-Data": {"detected": False, "result": "clean site"}, "OpenPhish": {"detected": False, "result": "clean site"}, "Malware Domain Blocklist": {"detected": False, "result": "clean site"}, "AutoShun": {"detected": False, "result": "unrated site"}, "Trustwave": {"detected": False, "result": "clean site"}, "Web Security Guard": {"detected": False, "result": "clean site"}, "Cyan": {"detected": False, "result": "unrated site"}, "CyRadar": {"detected": False, "result": "clean site"}, "desenmascara.me": {"detected": False, "result": "clean site"}, "ADMINUSLabs": {"detected": False, "result": "clean site"}, "Malwarebytes hpHosts": {"detected": False, "result": "clean site"}, "Dr.Web": {"detected": False, "result": "clean site"}, "AlienVault": {"detected": False, "result": "clean site"}, "Emsisoft": {"detected": False, "result": "clean site"}, "Spamhaus": {"detected": False, "result": "clean site"}, "malwares.com URL checker": {"detected": False, "result": "clean site"}, "Phishtank": {"detected": False, "result": "clean site"}, "EonScope": {"detected": False, "result": "clean site"}, "Malwared": {"detected": False, "result": "clean site"}, "Avira": {"detected": False, "result": "clean site"}, "Cisco Talos IP Blacklist": {"detected": False, "result": "clean site"}, "CyberCrime": {"detected": False, "result": "clean site"}, "Antiy-AVL": {"detected": False, "result": "clean site"}, "Forcepoint ThreatSeeker": {"detected": False, "result": "clean site"}, "SCUMWARE.org": {"detected": False, "result": "clean site"}, "Certego": {"detected": False, "result": "clean site"}, "Yandex Safebrowsing": {"detected": False, "result": "clean site", "detail": "http://yandex.com/infected?l10n=en&url=http://www.google.fi/"}, "ESET": {"detected": False, "result": "clean site"}, "Threatsourcing": {"detected": False, "result": "clean site"}, "URLhaus": {"detected": False, "result": "clean site"}, "SecureBrain": {"detected": False, "result": "clean site"}, "Nucleon": {"detected": False, "result": "clean site"}, "PREBYTES": {"detected": False, "result": "clean site"}, "Sophos": {"detected": False, "result": "unrated site"}, "Blueliv": {"detected": False, "result": "clean site"}, "BlockList": {"detected": False, "result": "clean site"}, "Netcraft": {"detected": False, "result": "unrated site"}, "CRDF": {"detected": False, "result": "clean site"}, "ThreatHive": {"detected": False, "result": "clean site"}, "BADWARE.INFO": {"detected": False, "result": "clean site"}, "FraudScore": {"detected": False, "result": "clean site"}, "Quick Heal": {"detected": False, "result": "clean site"}, "Rising": {"detected": False, "result": "clean site"}, "StopBadware": {"detected": False, "result": "unrated site"}, "Sucuri SiteCheck": {"detected": False, "result": "clean site"}, "Fortinet": {"detected": False, "result": "clean site"}, "StopForumSpam": {"detected": False, "result": "clean site"}, "ZeroCERT": {"detected": False, "result": "clean site"}, "Baidu-International": {"detected": False, "result": "clean site"}, "Phishing Database": {"detected": False, "result": "clean site"}}}

@VT_api.route(f'/{BASE_URL}/domain/report')
def domains():
    resource = request.args.get('domain')
    return {
    "https_certificate_date": 1591155097,
    "undetected_downloaded_samples": [
        {
            "date": "2018-09-14 11:14:47",
            "positives": 0,
            "total": 70,
            "sha256": "7d04f7431bbfa41a04bcc7e6b98b9de0d919756c4c671c5785c99fff45f16402"
        }
    ],
    "whois_timestamp": 1590270517,
    "domain_siblings": [],
    "detected_downloaded_samples": [],
    "detected_referrer_samples": [
        {
            "date": "2020-06-03 03:22:32",
            "positives": 56,
            "total": 75,
            "sha256": "5acb8388f3ac3f2083c4dab4cdba95621d23f81645f9a534440f4c23827b9c38"
        },
        {
            "date": "2020-06-02 05:04:40",
            "positives": 56,
            "total": 75,
            "sha256": "c20882f200cbb8c3c44704136ed92a982140cfc8e7e940f6037ca44dbb151b99"
        },
        {
            "date": "2020-05-30 21:15:39",
            "positives": 6,
            "total": 74,
            "sha256": "d33abf78aa958e5a3e199a66f098e62cd7d237bcc9b66741d5990e1602831d98"
        },
        {
            "date": "2020-05-18 20:52:42",
            "positives": 2,
            "total": 75,
            "sha256": "83d846c0205b29bd2475adb5981d11fe4fab91e7605d9bf54ef82f9107bc710c"
        },
        {
            "date": "2020-04-30 04:25:47",
            "positives": 19,
            "total": 75,
            "sha256": "6f3643706c4a92700cc92d52ad87108cae863a1ab896a7dccd3a98b0191c57b4"
        },
        {
            "date": "2020-04-27 11:54:07",
            "positives": 53,
            "total": 75,
            "sha256": "20f41b550740796ad2962eb4e395b9296c1bed48cd74611f0a03ab5398cb27e9"
        },
        {
            "date": "2020-04-26 21:39:28",
            "positives": 62,
            "total": 74,
            "sha256": "0ace6d6882fa84f53b326e28a24e516722dcb4b9ee28faae4da81c426810a07b"
        },
        {
            "date": "2020-04-25 04:46:55",
            "positives": 62,
            "total": 74,
            "sha256": "a61cde464831e82662e53766d8cd15178f8786edbe148101021c24167ba9db6c"
        },
        {
            "date": "2020-04-13 02:38:57",
            "positives": 13,
            "total": 75,
            "sha256": "54476b502ccd2c35f7c1642c20480e65310d51fc3e46abd01870c9bda5f5797e"
        },
        {
            "date": "2020-04-09 02:14:56",
            "positives": 64,
            "total": 75,
            "sha256": "300c5ae564fa1bf56dba6af107cb138283405d0ddb9a4900fe78574c52e39ecf"
        },
        {
            "date": "2020-04-08 09:15:36",
            "positives": 64,
            "total": 75,
            "sha256": "b45d10cfdbea1052dc44b8249a8019e08f660fd1aa47726449168c6c5429e09a"
        },
        {
            "date": "2020-04-07 23:06:58",
            "positives": 7,
            "total": 74,
            "sha256": "5b729480083ea9d753815d1a0a208c4d673a00fce96297fb9f49b2869f751f2e"
        },
        {
            "date": "2020-04-06 19:19:01",
            "positives": 61,
            "total": 75,
            "sha256": "da31b86a03c04b87303d14205e8029e0791494b511266bdbbd0ae5ffe5deb449"
        },
        {
            "date": "2020-04-06 04:02:24",
            "positives": 64,
            "total": 74,
            "sha256": "bd8901d2a81fb2090761410f2c664deeb194bd36509675bfae0eb59b6485ad39"
        },
        {
            "date": "2020-04-04 20:11:14",
            "positives": 65,
            "total": 75,
            "sha256": "df48465cf812a0389db0d1d66a1006cc82f91495cdd0777c0a0e72ce59b25473"
        },
        {
            "date": "2020-04-04 15:47:04",
            "positives": 64,
            "total": 75,
            "sha256": "6f3173d25e488be67432c59dbcac7a54946cc5a8d56f137afb1376ccfdfc8b5e"
        },
        {
            "date": "2020-04-04 11:15:02",
            "positives": 64,
            "total": 75,
            "sha256": "6b5ad1d02863eaceb447b632dd3b088e0b70d5138246f1c83ecffd039c5bc401"
        },
        {
            "date": "2020-04-04 08:09:00",
            "positives": 63,
            "total": 74,
            "sha256": "ab6d0e72b74ef5af7c99ba7be126cac6aa54fb286ababf6086416b631c64af3f"
        },
        {
            "date": "2020-04-04 08:02:45",
            "positives": 64,
            "total": 75,
            "sha256": "e81a37e5daa0563f365cdbec7c05aec4e62e3d05ce226f9fbc59c2cfb6853130"
        },
        {
            "date": "2020-04-04 06:53:37",
            "positives": 57,
            "total": 75,
            "sha256": "c2cd78915567547a66def50d6b4792054340d88bef61f6a9d9597b596146423c"
        },
        {
            "date": "2020-04-04 06:42:36",
            "positives": 58,
            "total": 75,
            "sha256": "afaa5314a747ede3c038385ba009579a399734be808bb5305a545382cd59bb67"
        },
        {
            "date": "2020-04-04 05:53:33",
            "positives": 58,
            "total": 75,
            "sha256": "0cf8d8f3b6f61168fd623b73d70c3e2f75f524cedb049e59f28a1fbc547c55cf"
        },
        {
            "date": "2020-04-04 05:17:33",
            "positives": 56,
            "total": 74,
            "sha256": "5056d9ff2d975cd576708dc5676268f65910bceb5753a7e85e82a1726f8be168"
        },
        {
            "date": "2020-04-04 03:21:42",
            "positives": 7,
            "total": 74,
            "sha256": "b518983267452b97c48184dd74d77f85ec3514cbe9c27b8de89c92e6694ec12c"
        },
        {
            "date": "2020-04-03 19:26:23",
            "positives": 65,
            "total": 75,
            "sha256": "69dcbb2f3553061c797cfe6c53001e850707c2b268b0044b793cc5f588338ef0"
        },
        {
            "date": "2020-04-03 19:25:30",
            "positives": 63,
            "total": 73,
            "sha256": "3b2760d231b42d492f38185efebbd1a51f1cdebb7f669441808fd57ac79c9436"
        },
        {
            "date": "2020-04-03 19:26:16",
            "positives": 62,
            "total": 73,
            "sha256": "4572cee3ccf1be18b5a7aa5da9fd7ec0c69741429c3e1600cad5c902f0a18335"
        },
        {
            "date": "2020-04-03 17:02:50",
            "positives": 64,
            "total": 75,
            "sha256": "5ca6d460ef2450d3b03c3e108767572777c7cbf0128e599cf0c087478140b5f5"
        },
        {
            "date": "2020-04-03 11:05:47",
            "positives": 60,
            "total": 75,
            "sha256": "166bc6744bd23545070dc4d771d1b053fe64a17dd316e8849a93f154e2565ecb"
        },
        {
            "date": "2020-04-03 03:24:20",
            "positives": 63,
            "total": 75,
            "sha256": "638bc85153699ea6d2034a0e434999a6be265f5bc26b2df13f09f8d680150332"
        },
        {
            "date": "2020-04-03 00:49:19",
            "positives": 67,
            "total": 75,
            "sha256": "349e6fc93d6b10c4f7bb2bbfad405722650534d24629cb4b5354b2304dc948e1"
        },
        {
            "date": "2020-04-02 15:00:28",
            "positives": 63,
            "total": 73,
            "sha256": "168be8f64fa89d94d429f6cc82a4ad79797c805a69b3e8a3e81e8ab7b205bf22"
        },
        {
            "date": "2020-04-01 20:07:24",
            "positives": 65,
            "total": 75,
            "sha256": "f7c2489a6f26701b3296ef511debecc35b69b330051b6864c711ef4f2f1367be"
        },
        {
            "date": "2020-04-01 17:38:49",
            "positives": 59,
            "total": 75,
            "sha256": "2b1ebc41b0b7544da4cb44aaa22d79ba380404a699d6cb2552e3d04113d8c352"
        },
        {
            "date": "2020-04-01 10:40:06",
            "positives": 58,
            "total": 75,
            "sha256": "568c93705a9b5f6a6c0e8535c45c3200f839b39abbdd117c7a7bb7469cb98bbe"
        },
        {
            "date": "2020-04-01 09:11:13",
            "positives": 62,
            "total": 75,
            "sha256": "7ae6dae1fa3266d78fe496a327a2ea6347063e785da705e100f12a6502a6c607"
        },
        {
            "date": "2020-04-01 01:39:15",
            "positives": 55,
            "total": 75,
            "sha256": "efae51c7a252379dd9a3e13caa59c3fa90278aae0767c7191ea8ef07f87e05af"
        },
        {
            "date": "2020-03-31 13:17:08",
            "positives": 64,
            "total": 75,
            "sha256": "c621056bff7f096b880d907b42e7418b19436a2874cf84ebdb8100eacdff240c"
        },
        {
            "date": "2020-03-31 09:21:02",
            "positives": 64,
            "total": 75,
            "sha256": "7722f8598bcab656950d968b4579b2971ec33713caafbf61919f0f3308418576"
        },
        {
            "date": "2020-03-31 02:14:09",
            "positives": 64,
            "total": 74,
            "sha256": "1bb15fa16163a762dcec609630699e2294ae1ddf6ad759c33a79d4211efa6cb8"
        },
        {
            "date": "2020-03-31 02:14:12",
            "positives": 64,
            "total": 75,
            "sha256": "38a7bbd98c7063bdf8fdf5b6c91a84439ceebe9b80ee814db7813a28f41cc580"
        },
        {
            "date": "2020-03-30 19:39:42",
            "positives": 58,
            "total": 75,
            "sha256": "c1bf9ff921bae305c02f74f11ed39df42bbbd34e3ecce08f903afbc4e7c6f94b"
        },
        {
            "date": "2020-03-30 18:53:09",
            "positives": 61,
            "total": 75,
            "sha256": "7c1ea4b91ac4dbe34d3740cdb4517b55661c09a857a93a4a3f1279c712160ccd"
        },
        {
            "date": "2020-03-30 18:53:19",
            "positives": 61,
            "total": 75,
            "sha256": "13fd6b0873483fc8b83bfaee66a43afd82f345329046cf2f213043f28f4d44cb"
        },
        {
            "date": "2020-03-30 11:48:31",
            "positives": 61,
            "total": 75,
            "sha256": "8de9aab62fd03955e4ca8b39c5a784289f4b08f0319f4751a960a9d54c6c68af"
        },
        {
            "date": "2020-03-30 11:23:20",
            "positives": 61,
            "total": 75,
            "sha256": "d7187c945cb7a3f2c7da5b48bf55280be6916e471e8d686136652d6948e8c8ee"
        },
        {
            "date": "2020-03-30 11:03:54",
            "positives": 61,
            "total": 75,
            "sha256": "2d451f02c54cb2f29796aaafdf9e2c9665a58c7e5c6b6b6eea9c4bada6df3bda"
        },
        {
            "date": "2020-03-30 08:18:34",
            "positives": 62,
            "total": 75,
            "sha256": "52eb8ec84c3d2eee3be2f3e2cf978e94621c9b9c139cad9372488f47f0f46c72"
        },
        {
            "date": "2020-03-30 07:17:45",
            "positives": 63,
            "total": 74,
            "sha256": "948615be662eba3a64cd63539c67d68e9ecca78059c893cf0e71d7e5d964bef5"
        },
        {
            "date": "2020-03-30 07:17:41",
            "positives": 63,
            "total": 75,
            "sha256": "59008183bd28e6f57b3e6fef6c5cc4f8565cf3cbeb19385daa243b057e04724d"
        },
        {
            "date": "2020-03-30 07:18:16",
            "positives": 63,
            "total": 74,
            "sha256": "b7eb4dc62aaee2bcfaa9e94103f299954a2476d8ebdb05b6295b5936a631e92a"
        },
        {
            "date": "2020-03-30 06:32:57",
            "positives": 64,
            "total": 75,
            "sha256": "b7223f18972d940c254b664cd7eae6ba6ef51d75b7ef4c9ea471bdccffe8b3ac"
        },
        {
            "date": "2020-03-30 06:37:14",
            "positives": 58,
            "total": 75,
            "sha256": "72a0efa5cc634dc783ecddd36040286635fd7ef30ee316c43b16f06bc4993382"
        },
        {
            "date": "2020-03-30 02:50:41",
            "positives": 63,
            "total": 75,
            "sha256": "14a677721cbb5f849d3c4abaf052c2baecc386ab9cf10c51b4dedebed556d2ac"
        },
        {
            "date": "2020-03-30 02:50:23",
            "positives": 64,
            "total": 75,
            "sha256": "da1120bf510b821585903d1726637ebb14685caa73486b40d1ce78276df3a285"
        },
        {
            "date": "2020-03-29 17:12:42",
            "positives": 59,
            "total": 74,
            "sha256": "9cdf7ffd21e506f675807ccd20c61455e5ddcba70c817f7afbcfbeddca31f3fd"
        },
        {
            "date": "2020-03-29 16:27:15",
            "positives": 64,
            "total": 75,
            "sha256": "b6d5b2969a0661c17358bb5c307b14555116a74eef080d246e02d3ddf45b884e"
        },
        {
            "date": "2020-03-29 03:20:54",
            "positives": 62,
            "total": 75,
            "sha256": "ab686d0debb40ad0f084c915de161b28c5ded3a8f3350834fba949e2c4c1c8d8"
        },
        {
            "date": "2020-03-27 23:31:53",
            "positives": 61,
            "total": 74,
            "sha256": "f070ed8099dfe170f76d6793ce6fb692c7bb284960b9a01568b14aab6387cf14"
        },
        {
            "date": "2020-03-27 16:30:00",
            "positives": 58,
            "total": 74,
            "sha256": "707e3b774cbd803e4cfe4f557ff773f5f5f9c7831fe764821016274c9c34dc6a"
        },
        {
            "date": "2020-03-27 05:50:27",
            "positives": 63,
            "total": 75,
            "sha256": "78686feffe40581f7d0df50e5a0beffb56026c45f934164f8adc1e97b0113c4c"
        },
        {
            "date": "2020-03-27 04:17:30",
            "positives": 62,
            "total": 74,
            "sha256": "5a1717a6af99ed766a87d41536ed98a957574d63b0a1987018eb166f9f35af19"
        },
        {
            "date": "2020-03-27 04:17:01",
            "positives": 64,
            "total": 75,
            "sha256": "b96acabd088436b840c08f8879855f25a8d9b9fe90e648c21c8c6ad3ec58d466"
        },
        {
            "date": "2020-03-27 04:01:36",
            "positives": 61,
            "total": 74,
            "sha256": "71d55a4670122e7af7ee9437c807e81c39742a66e81f87da840faef4c54a63af"
        },
        {
            "date": "2020-03-27 04:01:17",
            "positives": 61,
            "total": 74,
            "sha256": "8428a53a24abc8d1fd941fcbf198b770e7d5a6ea76663cd1542653e13473ac01"
        },
        {
            "date": "2020-03-27 03:58:38",
            "positives": 60,
            "total": 74,
            "sha256": "738561bb251e47b54ce881e1f8988fe3b7b8617247303184fd2c152f15dc213b"
        },
        {
            "date": "2020-03-27 01:57:34",
            "positives": 3,
            "total": 75,
            "sha256": "19c00d96e8d49b328374ade4d03df707f3b293a93e4e188635dbb81d43812f15"
        },
        {
            "date": "2020-03-26 19:26:34",
            "positives": 64,
            "total": 75,
            "sha256": "18b542389825e22964e20e70a8d5ea2a9027a0b466cb0305b8da8ca5618df563"
        },
        {
            "date": "2020-03-26 18:55:14",
            "positives": 55,
            "total": 75,
            "sha256": "a129130102572ac4f8f52b27d242da9571a65c4a5362da260b06676971586ebe"
        },
        {
            "date": "2020-03-26 18:54:31",
            "positives": 55,
            "total": 75,
            "sha256": "5979f6cb2baef04ed315b8a9da9c316a59e0eb2e89bc2c58d5e7f008e56fc023"
        },
        {
            "date": "2020-03-26 18:52:31",
            "positives": 55,
            "total": 75,
            "sha256": "421a975995248f434e7f0d923ce30f52e6522831a8d0709021752b025e5cf6f6"
        },
        {
            "date": "2020-03-26 16:03:06",
            "positives": 61,
            "total": 74,
            "sha256": "1615953b51d2e1e343006a9d8f44f1298221bcbd7ec5f15f6e02ab4f07cbd8b8"
        },
        {
            "date": "2020-03-26 16:00:27",
            "positives": 61,
            "total": 75,
            "sha256": "42f19e0709961417295a8edd5a2f42f0a8a7808de75e1d743d12db1444825ce8"
        },
        {
            "date": "2020-03-26 05:26:08",
            "positives": 55,
            "total": 75,
            "sha256": "72549d82455774b4b56650fd60d3fb7b82c41e12b0841113931d97b81f17b388"
        },
        {
            "date": "2020-03-26 04:33:36",
            "positives": 64,
            "total": 75,
            "sha256": "2ef74d2c00c7b9ae0882e56622f43476d53535f20ccf478d996f0dabef5bb17c"
        },
        {
            "date": "2020-03-26 03:02:34",
            "positives": 59,
            "total": 75,
            "sha256": "c198f213f35753aabdb9f8e8cb1e083a015a707ba7d88f0ca24684115e20c405"
        },
        {
            "date": "2020-03-25 21:08:40",
            "positives": 63,
            "total": 74,
            "sha256": "c221e326f5740f5ca7d98011140117ac0bc3be4e76a30f81fd8989fb8df6c14c"
        },
        {
            "date": "2020-03-25 20:02:50",
            "positives": 62,
            "total": 75,
            "sha256": "af687f105d1fcf397337532ec43b8970e49c05e2b498b8c07ab148b1b4a598ed"
        },
        {
            "date": "2020-03-25 15:27:52",
            "positives": 62,
            "total": 75,
            "sha256": "99b249dddb0d1d2f078af5aeac9ff50a2bf0dd661e71309b555eb4584dbd9f81"
        },
        {
            "date": "2020-03-25 15:27:35",
            "positives": 60,
            "total": 73,
            "sha256": "c6fa78e36b939920672863b13f45c9d49523634bb6408d1ef16804a0cac7ae5d"
        },
        {
            "date": "2020-03-25 02:09:34",
            "positives": 64,
            "total": 75,
            "sha256": "9842b819dfaf84088b1535773011cab0a3d3a6f0cc9074e205052d7433650a9a"
        },
        {
            "date": "2020-03-25 02:09:31",
            "positives": 64,
            "total": 75,
            "sha256": "e12599c04d7c57bcc23dc076ce4010d8b3b5e3e512ffc76d63e8bf1e30ec785d"
        },
        {
            "date": "2020-03-25 02:09:19",
            "positives": 63,
            "total": 74,
            "sha256": "92f618b8b24833bd414c26d56bb9b8f6861725484567cfdafc003e026a512a9d"
        },
        {
            "date": "2020-03-23 12:19:10",
            "positives": 64,
            "total": 75,
            "sha256": "36ddcfce87b4b3e2d1c375bafae8e9e1c35207ee09c0046d602565421d17d065"
        },
        {
            "date": "2020-03-23 12:17:49",
            "positives": 64,
            "total": 75,
            "sha256": "14d05352a7ce8d9642d2d2588acd37bd124014f39a7d91d33e1e12292636e120"
        },
        {
            "date": "2020-03-23 12:15:03",
            "positives": 65,
            "total": 75,
            "sha256": "5e532179a881670dd86745269b101d874ba607b131f59cb9982b24f282d2bef2"
        },
        {
            "date": "2020-03-23 07:03:51",
            "positives": 59,
            "total": 75,
            "sha256": "0a9aa33897be5968072bb019fb2dec72b21067c0de276c96747a2a9429566ca7"
        },
        {
            "date": "2020-03-23 03:21:28",
            "positives": 63,
            "total": 75,
            "sha256": "cf9ee5bb640487f356065bda4d7548f72ce4742e35593f2d3bfeb4891c710d00"
        },
        {
            "date": "2020-03-23 02:22:40",
            "positives": 56,
            "total": 75,
            "sha256": "cd21c13ccff171bc8df5aa5d19fd370483d4f4071b9cbb4a160bdbd552bb29c6"
        },
        {
            "date": "2020-03-23 02:06:25",
            "positives": 64,
            "total": 75,
            "sha256": "202444f0640fc99535c492ae1090cef1f385d2dd46aba8c2bad4672eb73903f0"
        },
        {
            "date": "2020-03-23 00:04:15",
            "positives": 65,
            "total": 75,
            "sha256": "e205bdfcfe35398e63532358b2544330a87bc392cf9bb5326d6b515b643830d1"
        },
        {
            "date": "2020-03-23 00:02:59",
            "positives": 65,
            "total": 75,
            "sha256": "3c8366c4b0dc01a9528187e3b39aacea2c56c97b67eda77ae9207b235422a60d"
        },
        {
            "date": "2020-03-23 00:03:28",
            "positives": 63,
            "total": 73,
            "sha256": "5d71365ce78c1c0e525372919d73f5901acb334c78ad42474e907bc1d05aca79"
        },
        {
            "date": "2020-03-23 00:02:15",
            "positives": 64,
            "total": 73,
            "sha256": "9e7c4c5e4245c01ad0b079469a78b51a1399eaf77ecc68543ad4ec79b7581e88"
        },
        {
            "date": "2020-03-22 17:12:54",
            "positives": 64,
            "total": 75,
            "sha256": "4ee710b126904c4cdc7453f9ab281184d936f6e98f2406b26f0ef441274263bc"
        },
        {
            "date": "2020-03-22 17:11:56",
            "positives": 64,
            "total": 74,
            "sha256": "f38de3da919afc5d54e7bf93d06e6f266f5892bf13864135a910d2f656b6091f"
        },
        {
            "date": "2020-03-22 11:54:30",
            "positives": 65,
            "total": 75,
            "sha256": "cce510adea3c6bc7386f874ca18a63727b354c459970549b1b27230c27e6ef35"
        },
        {
            "date": "2020-03-22 03:59:11",
            "positives": 63,
            "total": 75,
            "sha256": "c9be0b850dcb19d832dd457995c92267f6dc62d39a1fccc8010a061fd41e4cc3"
        },
        {
            "date": "2020-03-22 00:15:16",
            "positives": 65,
            "total": 75,
            "sha256": "dda5769133654f3257e2e0c1a2ad812bc2397c17895e1c8141c5a6a33da29f31"
        },
        {
            "date": "2020-03-21 04:45:54",
            "positives": 62,
            "total": 74,
            "sha256": "4277a15f608bffcefa956bfc70653f83f82bcc0f0c5ab1a7a6eac110e7a96142"
        }
    ],
    "favicon": {
        "raw_md5": "6073942b1f46f875ce6707b7443fa277",
        "dhash": "2636369693133331"
    },
    "Webutation domain info": {
        "Safety score": 100,
        "Adult content": "no",
        "Verdict": "safe"
    },
    "entropy": "null",
    "subdomains": [
        "www."+resource,
        "plus"+resource,
        "app"+resource,
        "api"+resource
    ],
    "undetected_referrer_samples": [
        {
            "date": "2020-06-02 10:32:27",
            "positives": 0,
            "total": 75,
            "sha256": "8e317ff076357a67170867e6ae962fdfdddb80d3220d604617d28c4ab7915759"
        },
        {
            "date": "2020-05-26 19:21:35",
            "positives": 0,
            "total": 75,
            "sha256": "f28baab5aee2b690d7ae053830060b49b048558f08dfd020a23de6eef1b1c080"
        },
        {
            "date": "2020-05-25 03:37:39",
            "positives": 0,
            "total": 75,
            "sha256": "ebb72fd7e2603958614c91310613b41c37fe1100f9a2ae28d5490fa6ca2985f3"
        },
        {
            "date": "2020-05-24 08:34:10",
            "positives": 0,
            "total": 75,
            "sha256": "0f89aaade5f753d98121b8add8452898ed5d76dde5267a34920cf29fce5ebe94"
        },
        {
            "date": "2020-05-15 06:08:17",
            "positives": 0,
            "total": 74,
            "sha256": "ca30a546ab42adb21254bb4b30763237006faef033c4aa981cb023233538f426"
        },
        {
            "date": "2020-05-11 13:47:06",
            "positives": 0,
            "total": 73,
            "sha256": "9296c5dd6d26414a83b32d64bea83bf6a9b85b4122ad6a67187a135622f1cffd"
        },
        {
            "date": "2020-05-10 16:19:20",
            "positives": 0,
            "total": 73,
            "sha256": "f37947e6179ce457e24f12211c2dcb96da8fe93f08a6445f1b7923474904b3be"
        },
        {
            "date": "2020-05-09 04:09:09",
            "positives": 0,
            "total": 73,
            "sha256": "38234e5a11e056c4c2f3f67974ea93c72ab208336e3dc7099281765ae6f5e6fa"
        },
        {
            "date": "2020-05-07 19:18:00",
            "positives": 0,
            "total": 75,
            "sha256": "d8f03863c3a42fd02e5b141c155458cf9e5fc842ca50a3b3706a64c94169e261"
        },
        {
            "date": "2020-05-05 13:27:12",
            "positives": 0,
            "total": 73,
            "sha256": "15c6d0c63dd561d6f138c759ab6a7a5a150c2d1e3b8741ab8409fde296690e41"
        },
        {
            "date": "2020-05-05 02:31:45",
            "positives": 0,
            "total": 75,
            "sha256": "046e7d0bd8a3b23c0ec64263847e62a76c8ec06e89d68e23a8fef8faa1fd33f7"
        },
        {
            "date": "2020-05-02 19:39:11",
            "positives": 0,
            "total": 75,
            "sha256": "b8e107f9e1d3822b2d2f6c47ae8e31f6c79c91a6bd780b6fc315174d075131c1"
        },
        {
            "date": "2020-05-01 01:57:24",
            "positives": 0,
            "total": 74,
            "sha256": "9281552961d2b1d147d6ce85a19e2fe72980e544fa04d22cd0230f63f2b7a928"
        },
        {
            "date": "2020-04-30 11:32:38",
            "positives": 0,
            "total": 73,
            "sha256": "37a5c15538f291facd7f1ef65eef2ec12467d1085d32af9bf9b8999aaca9d9f3"
        },
        {
            "date": "2020-04-30 09:54:21",
            "positives": 0,
            "total": 72,
            "sha256": "bcb4fd842fcd331ffc6688db7b1f450e5bf623a7e4b2f7ff4bebc9ef04c4bfee"
        },
        {
            "date": "2020-04-29 02:57:18",
            "positives": 0,
            "total": 75,
            "sha256": "2550986970ba0d2f0212d7d15f2b1ce7c418e2ef5c933839e86cc6e140ac04df"
        },
        {
            "date": "2020-04-25 20:52:54",
            "positives": 0,
            "total": 74,
            "sha256": "8444121fb217edc291c611d26831083da1a94922da126fdaa46ddebc06396b54"
        },
        {
            "date": "2020-04-24 22:04:27",
            "positives": 0,
            "total": 74,
            "sha256": "1a4ae6d7b309c57d8557405156324a3689c92dcb2b57826e852abd1618a8d902"
        },
        {
            "date": "2020-04-21 04:13:56",
            "positives": 0,
            "total": 75,
            "sha256": "4df4022d963cf6ab0625867242cdd877737748b4002e44952aa393886169e5d5"
        },
        {
            "date": "2020-04-13 11:38:08",
            "positives": 0,
            "total": 75,
            "sha256": "324d3d5f90bc2651672a89e5d0f2c59f74f394badc75f8846dd1922d404900d8"
        },
        {
            "date": "2020-04-13 00:58:00",
            "positives": 0,
            "total": 75,
            "sha256": "eda234d5c59283c29ea10bf2476a2829ff8211cf61152e73caf1cc7eea2a5d24"
        },
        {
            "date": "2020-03-28 02:16:00",
            "positives": 0,
            "total": 75,
            "sha256": "e0923679ad3e8087d95e02c4a36a44955c0ef5b36f4df1b4827248f1fc437f06"
        },
        {
            "date": "2020-03-25 14:07:03",
            "positives": 0,
            "total": 75,
            "sha256": "efc8a3aee31923b4a297d3c4021179cfa748cd643d3abb84547dbcc5fea39179"
        },
        {
            "date": "2020-03-19 10:20:59",
            "positives": 0,
            "total": 74,
            "sha256": "5b3a732661ae13ad6ca87fc888107fdee772e837d6c8374011f11257cca23188"
        },
        {
            "date": "2020-03-09 17:12:37",
            "positives": 0,
            "total": 74,
            "sha256": "f0cf15ff5c8bedb922572e6fb769055f0eb035993227ca82f1329e560696b521"
        },
        {
            "date": "2020-02-21 13:14:26",
            "positives": 0,
            "total": 75,
            "sha256": "223bb809444dde0e0e1a9abc6ecc323e84dc37a705052e1f83bedad3c84366d3"
        },
        {
            "date": "2020-02-21 09:54:16",
            "positives": 0,
            "total": 74,
            "sha256": "156443a888ab47e25aaf3537a8820029fdc18492530c7ae6dbdc0c652954a226"
        },
        {
            "date": "2020-02-17 01:09:40",
            "positives": 0,
            "total": 75,
            "sha256": "7271d92bda1dc7175c74b16f34533cf805856d006f224932986a7b0aefee3979"
        },
        {
            "date": "2020-02-11 17:04:43",
            "positives": 0,
            "total": 74,
            "sha256": "3cf9bd49b311790874dc4595a0325ced3f946b91dc2a6d3469415682c9f50f78"
        },
        {
            "date": "2020-01-16 00:33:46",
            "positives": 0,
            "total": 75,
            "sha256": "312d76a151f07f8e49814b914ceeb81d522405f97e54da063d5f89825388a7e7"
        },
        {
            "date": "2020-01-07 01:00:11",
            "positives": 0,
            "total": 73,
            "sha256": "d3653fd3f2f275d316e12d0966bd91e24ec6cbd9c990a680dd5b67ad5d323878"
        },
        {
            "date": "2019-12-27 15:02:52",
            "positives": 0,
            "total": 75,
            "sha256": "1659cdd09f500500a5950f070984e32e3c485b30345b44cc2d22a11df8cbe957"
        },
        {
            "date": "2019-12-26 08:14:56",
            "positives": 0,
            "total": 74,
            "sha256": "796993cedb8eb3a5085ea0a191225cdd51ca1ff20634c3e2a2bf24dd23d03a59"
        },
        {
            "date": "2019-11-22 11:09:55",
            "positives": 0,
            "total": 71,
            "sha256": "5dd5a02c216ae97b80c26c62935f4aded35d1f95c58c4a0a3f58e5a0398b8a99"
        },
        {
            "date": "2019-10-19 20:06:49",
            "positives": 0,
            "total": 71,
            "sha256": "dcaffba8d1abf6b91fd60f9042dddc47910b7ac4929bc30560f5e64ad4a86ee3"
        },
        {
            "date": "2019-10-18 09:49:15",
            "positives": 0,
            "total": 72,
            "sha256": "1a0ccb25c095645045ec1a3f29b65de441361c62122a48d13a40e1df186c4bc1"
        },
        {
            "date": "2019-09-24 08:12:51",
            "positives": 0,
            "total": 69,
            "sha256": "8a76130210537d9399947e6060f92514b2d04c821ceb1b7cd549ea1e5dd27ee8"
        },
        {
            "date": "2019-09-15 19:34:06",
            "positives": 0,
            "total": 71,
            "sha256": "b96ba4a6e3a31ffca1a9fb2c521782ec0a9e3eaccd169f355fbb9353e6c68642"
        },
        {
            "date": "2019-09-13 23:38:05",
            "positives": 0,
            "total": 73,
            "sha256": "3241b038c54cc67ac5b5927d015755171630ff5507177925cbf0294b2ec2baed"
        },
        {
            "date": "2019-09-13 23:34:00",
            "positives": 0,
            "total": 67,
            "sha256": "f5f7017cb6555def3da328b47740ee569d19371ef4eb48d734ca48cfbd4354a4"
        },
        {
            "date": "2019-08-21 17:54:17",
            "positives": 0,
            "total": 70,
            "sha256": "65286ddd4fb542500622d5fdb20070b42c6d7535e6f9c34a6686eba05e00c660"
        },
        {
            "date": "2019-08-12 11:28:09",
            "positives": 0,
            "total": 66,
            "sha256": "4fa4208323300529186caf46788c5aa6caa27c6e305fc64a4073612bc31c354d"
        },
        {
            "date": "2019-08-11 02:48:48",
            "positives": 0,
            "total": 66,
            "sha256": "d4e1b8f52dc7862f2fa533e62a52fff51c0ab8ce27edad6789c759c23503ac9a"
        },
        {
            "date": "2019-08-09 17:21:34",
            "positives": 0,
            "total": 71,
            "sha256": "af2c6b89b023eec18ac1ec9f3082761d6f79a54b2deaf469d28240beff21d957"
        },
        {
            "date": "2019-08-07 05:16:34",
            "positives": 0,
            "total": 72,
            "sha256": "d5d09b2da1ba1db44b50248dfc1090ebc4e38366d78f8c7f8874536e956bd290"
        },
        {
            "date": "2019-08-07 05:13:25",
            "positives": 0,
            "total": 73,
            "sha256": "61d15b198e7637e7072ab82a004ff8e9f435df0da76653ecca1fc66fbaa7403f"
        },
        {
            "date": "2019-08-07 05:16:45",
            "positives": 0,
            "total": 73,
            "sha256": "067aa62d79f9ed00a39e0fcaedf499eba7386756de943befe98d48d73f593cfa"
        },
        {
            "date": "2019-08-07 05:16:45",
            "positives": 0,
            "total": 71,
            "sha256": "7612ba2c27712ef9ae5c34d9d605f793c9a4acd27330246d437834e95d7d1d67"
        },
        {
            "date": "2019-08-07 05:13:34",
            "positives": 0,
            "total": 70,
            "sha256": "2cae9f3592fbd4bdaa23732d4f3be981638c3e92ffc7603a1c6b7629d35951ad"
        },
        {
            "date": "2019-08-04 13:26:18",
            "positives": 0,
            "total": 72,
            "sha256": "4983c2036a43d807043552cc2f001b01ce814b0fd77b459be655ac301cd01d46"
        },
        {
            "date": "2019-07-28 08:11:35",
            "positives": 0,
            "total": 71,
            "sha256": "07181612cc7208b5d7453befa9dcc72e9d81691db40348582ac39dc6183c1249"
        },
        {
            "date": "2019-07-27 08:11:39",
            "positives": 0,
            "total": 72,
            "sha256": "1115759301cf01ee0529bc23f3c45409f505cc3814b6bbbf22b1cebde842f1aa"
        },
        {
            "date": "2019-07-25 08:06:23",
            "positives": 0,
            "total": 70,
            "sha256": "f06483f15ff869f0798432baadd0dec31f9d4b29c28f5779c186fb2523861a3d"
        },
        {
            "date": "2019-07-23 08:13:22",
            "positives": 0,
            "total": 71,
            "sha256": "0ddfa8099412c8ad69e964ce32a1a050a747f70823dca75ed8b8258c26ee34f8"
        },
        {
            "date": "2019-07-21 03:00:06",
            "positives": 0,
            "total": 71,
            "sha256": "511f89cf39ae65050db7b43be09130463793dc38468b48fe27f97c53ea21813f"
        },
        {
            "date": "2019-07-19 20:43:41",
            "positives": 0,
            "total": 71,
            "sha256": "420b655e4b55effb492130a49b9497e62e3a022e1325b393877122daad13a4f3"
        },
        {
            "date": "2019-07-19 08:29:35",
            "positives": 0,
            "total": 71,
            "sha256": "f78dfe73a3547d159e0e8302a322ce0ed71846a83883dcf6d47632cc1e4c94bd"
        },
        {
            "date": "2019-07-10 03:52:09",
            "positives": 0,
            "total": 71,
            "sha256": "79e6a125418925126d25563937aa75e85c1760e60193f69bb439cbedcb3b00ea"
        },
        {
            "date": "2019-07-09 08:11:22",
            "positives": 0,
            "total": 72,
            "sha256": "4731aad7f47d97c315b5bdfb572d00e1b75429f614db606be29072af85b4d540"
        },
        {
            "date": "2019-06-30 09:17:13",
            "positives": 0,
            "total": 70,
            "sha256": "e86abfcc56bf119a2bf134213b45f5df9e3e0fc89a5611c9e5ca0449aaa71c2a"
        },
        {
            "date": "2019-06-01 08:10:29",
            "positives": 0,
            "total": 73,
            "sha256": "678646b7086a37c65d1362310cb9a1421f42327af59f89e13b06f15c1a947733"
        },
        {
            "date": "2019-05-28 14:05:34",
            "positives": 0,
            "total": 72,
            "sha256": "7d110f744793eac7a137559ca37c92de5602948fed7394761bb82eda1fa45bc7"
        },
        {
            "date": "2019-05-25 10:25:40",
            "positives": 0,
            "total": 72,
            "sha256": "bf115d2bd2bd5cde354458ed15c97b51e505a9b915f3232a666f0649a23495d1"
        },
        {
            "date": "2019-05-18 09:14:28",
            "positives": 0,
            "total": 73,
            "sha256": "c1826febc1f97a8a80a344f85a154e884318d229645d66bf6c73e5d0b60e11df"
        },
        {
            "date": "2019-05-14 22:51:29",
            "positives": 0,
            "total": 68,
            "sha256": "2362378871b40a7cc1f1fed20968ef6e257c9024a88eadd05bf79a606c9c59c5"
        },
        {
            "date": "2019-05-13 18:08:20",
            "positives": 0,
            "total": 73,
            "sha256": "a4e0f71f2cab53907c504ea033a6f7d58d6d3dc180aff59e925d643f69c60c6b"
        },
        {
            "date": "2019-05-06 00:13:07",
            "positives": 0,
            "total": 71,
            "sha256": "b69e242595ee32f73619fac35caea9b789470712194505de6d562ffacdd23c12"
        },
        {
            "date": "2019-04-10 15:52:39",
            "positives": 0,
            "total": 71,
            "sha256": "7dbccd2dc9af2accdd3fe548b126ee316ceb04ab3bbddbe1cde4ef0fce57fb04"
        },
        {
            "date": "2019-04-09 19:05:55",
            "positives": 0,
            "total": 70,
            "sha256": "e4a2b52d712cd8e8e57403756cbae8670dc75bc86853ba0a585744c4c20a7280"
        },
        {
            "date": "2019-04-07 12:35:36",
            "positives": 0,
            "total": 67,
            "sha256": "d37629e2e09ad77cb9603e776f53bf31855998cd71bfa579ff22c333269ef7c4"
        },
        {
            "date": "2019-04-03 16:45:50",
            "positives": 0,
            "total": 66,
            "sha256": "75a07f941471335a37a1aa4989096d507af73f56ebe6782f5ad06f88c42e3f83"
        },
        {
            "date": "2019-03-27 14:43:46",
            "positives": 0,
            "total": 62,
            "sha256": "039e10830e252a2b48c95f524c8ed1e30c398d8da3cece7f50f5a39f66fa935c"
        },
        {
            "date": "2019-03-27 08:36:23",
            "positives": 0,
            "total": 67,
            "sha256": "5006de515fcdefa3dc3cb46a329bf722a1a8ab1af0ed5c7a798a6ad8ce532703"
        },
        {
            "date": "2019-03-26 12:47:40",
            "positives": 0,
            "total": 67,
            "sha256": "e99e674b78dff7bfd25c148e9287235d008fab84ccfbdf738e10ed9b124f42fe"
        },
        {
            "date": "2019-03-26 09:35:19",
            "positives": 0,
            "total": 67,
            "sha256": "496507a205947893b27d88964f405cdf21189ab2dd452665d8529eb415e25488"
        },
        {
            "date": "2019-03-26 08:21:51",
            "positives": 0,
            "total": 71,
            "sha256": "583ed7a7f7131c4c16c2c0ceb3c8248c5e7f513d6eabaca868128670c4ec15a2"
        },
        {
            "date": "2019-03-26 00:15:07",
            "positives": 0,
            "total": 70,
            "sha256": "782feac65cf5033c17027c6194dec9c3d486684df4755064d6bc285f640fce5a"
        },
        {
            "date": "2019-03-25 08:17:16",
            "positives": 0,
            "total": 67,
            "sha256": "962558af379872e5c2207e51d49bc0b906bc1f5e267673d4456c743b564de679"
        },
        {
            "date": "2019-03-15 16:01:37",
            "positives": 0,
            "total": 67,
            "sha256": "d60aa1006939c24a996dd036c04618cc671b374f821e04e98297f101c7259cec"
        },
        {
            "date": "2019-03-10 09:16:18",
            "positives": 0,
            "total": 65,
            "sha256": "021df4ba612375e889b1a5f44a2fe97ff3a3ea91012677e1faf334946326b005"
        },
        {
            "date": "2019-03-09 04:06:16",
            "positives": 0,
            "total": 66,
            "sha256": "ede99b0098a1c52e8b80d67154e53bc6d4371f2b5c80624cacfb16e9689920ea"
        },
        {
            "date": "2019-03-08 13:33:06",
            "positives": 0,
            "total": 69,
            "sha256": "51632324e133a13be76585e609405f44e75124990b3b87f0a30530de47625da8"
        },
        {
            "date": "2019-03-05 13:00:10",
            "positives": 0,
            "total": 70,
            "sha256": "ca2ac8d39c5ea0e90cb62f1b0867d5ce138bd880764acbe12c465bf1012223f2"
        },
        {
            "date": "2019-02-26 16:54:28",
            "positives": 0,
            "total": 71,
            "sha256": "9f6979bd32e2ceedfc57fad42a72dd86be12af79c3eb7aa0340f2e6c7a398eae"
        },
        {
            "date": "2019-02-20 15:18:49",
            "positives": 0,
            "total": 66,
            "sha256": "a3fc38727e811ab095e021e2ab74b89506c7f6a03f4168aeb6a49e7adb046c44"
        },
        {
            "date": "2019-02-13 15:37:04",
            "positives": 0,
            "total": 71,
            "sha256": "d8ea43101361539fdf93df214846d985987ec9f5a0d71703b87bd3e036430c46"
        },
        {
            "date": "2019-02-01 02:18:24",
            "positives": 0,
            "total": 70,
            "sha256": "7ba337e432ad7f0f2788b3617032ba97bdfa8e0feef3f0ca2c3fc7951adfce37"
        },
        {
            "date": "2019-01-17 11:15:59",
            "positives": 0,
            "total": 69,
            "sha256": "144a87af5360f9312053a148daeb8cbb83e066570c229308b9e770287abd5918"
        },
        {
            "date": "2019-01-12 06:44:20",
            "positives": 0,
            "total": 71,
            "sha256": "404e4b682afdd8ede8191a9b82de926d82e7875fd8e3ccf313c93897a883c869"
        },
        {
            "date": "2019-01-10 21:08:39",
            "positives": 0,
            "total": 70,
            "sha256": "df89743fe00e759c3d53adaf8b588a8a870aec99d8da6de0dc473170273bdb2b"
        },
        {
            "date": "2019-01-08 13:41:49",
            "positives": 0,
            "total": 68,
            "sha256": "a363e04d4d2d070050b8c458e14e26b724ebbd6a377e0f52df8016b96d8d5708"
        },
        {
            "date": "2018-12-14 10:26:34",
            "positives": 0,
            "total": 71,
            "sha256": "36e3405ae1b3ead0e3fb1eec5dbcbf2906042ecb5fa2c0d125f138ddcdc9d7bb"
        },
        {
            "date": "2018-12-11 23:16:29",
            "positives": 0,
            "total": 71,
            "sha256": "dcbde3918ea3353d99afb330e688425c7aeffc7f08a29edd3ab2dc7623e1da27"
        },
        {
            "date": "2018-11-20 18:58:54",
            "positives": 0,
            "total": 67,
            "sha256": "da106c9d071662ac424906fd518b589638e2584512cd9de7598c44f8375a8f73"
        },
        {
            "date": "2018-11-17 03:22:44",
            "positives": 0,
            "total": 68,
            "sha256": "6043a3140fba7f4b84a33f25d69c0cb258590f9cfb47a95c43f2787533bba92f"
        },
        {
            "date": "2018-11-09 15:12:52",
            "positives": 0,
            "total": 68,
            "sha256": "24662aa4698f2286e0b5b38c53e51a59d1f36da9891fbe760567d058dd0b6f8f"
        },
        {
            "date": "2018-11-04 21:37:25",
            "positives": 0,
            "total": 68,
            "sha256": "c9b04de200dcae009a78a52ae326558dd409364ff18161435261fde9a20ee958"
        },
        {
            "date": "2018-10-20 22:38:57",
            "positives": 0,
            "total": 67,
            "sha256": "29e6e9af25e29d03db6d6887bdda60b4b72ecd8f54c02a07dffa8e0be6a837e6"
        },
        {
            "date": "2018-10-13 18:54:14",
            "positives": 0,
            "total": 70,
            "sha256": "01f0842bfeeaa8b493a766639730fe6dda94e678813aa6d3c61331be8a5cd795"
        },
        {
            "date": "2018-10-09 16:52:59",
            "positives": 0,
            "total": 71,
            "sha256": "ce2d8d0f5da0593bcc7a533d0ad7590208dcfe58ba91881b4d7477bbe00581cf"
        }
    ],
    "resolutions": [
        {
            "last_resolved": "2019-12-07 09:05:58",
            "ip_address": "123.123.123.123"
        }
    ],
    "detected_communicating_samples": [
        {
            "date": "2020-01-09 08:02:11",
            "positives": 53,
            "total": 73,
            "sha256": "35a7108f1e7700adb041a17d4be115c1577d74c9652095c43707e299864f7d86"
        },
        {
            "date": "2019-11-19 02:04:55",
            "positives": 46,
            "total": 70,
            "sha256": "115ac6db98cb4e48aa2eaecdbae5d9b938b3432fd606d7ea0562f31efa98c6f0"
        },
        {
            "date": "2019-09-22 23:21:41",
            "positives": 57,
            "total": 69,
            "sha256": "751ac2eb414eba0c3f93245c865f2162e328c461c5c844271ffb299df5d1e4df"
        },
        {
            "date": "2019-09-08 07:37:39",
            "positives": 52,
            "total": 73,
            "sha256": "01b4ee2ae15e9d39c319a31c08ceaa6039022d841fb47e5e55d20d41e4fdf197"
        },
        {
            "date": "2019-08-01 23:34:53",
            "positives": 53,
            "total": 71,
            "sha256": "973a8584a53bcfd22e26f393b21ee28fdaf08c68b54f1548dc05b6569b3ee033"
        }
    ],
    "last_https_certificate": {
        "public_key": {
            "rsa": {
                "key_size": 2048,
                "modulus": "00c5f78863a015a352039ad2b3afcb0db4412da58ddb6bcd576254ed2deef5987141c2eb886b661fca6c2aeeb8d193303c23fc10b9ea8dee45913c099f348135744452edd60395a8876c4864ac68f7914736c39404bbad9e4a32f37e4497731de798fbac26f095f4863f9c983e0a29b74bedaf55aad063dd544da706e1416f1537ad2e8cdb27938ad5fcabcf71179110accc72cc39fff98e126c65e1ad2c95f57f1c9814550c221dd21f92cf38aaf2117b6904bfb35df4b6679f9f4e85f3d626eed9fb0b215eeee35e8500d6ce8fab4c886c90b2efa6a8b3b7ee7c92aab0d43e92b8aa0f9f1a266490591df0319ffe29a142f35ae0570661d56b6b23352339f253",
                "exponent": "010001"
            },
            "algorithm": "RSA"
        },
        "thumbprint_sha256": "b62afefa11dab4b3d2b1bc50d7d1bab8d98501eeafa518b3bd2fdac433f44d31",
        "tags": [],
        "signature_algorithm": "sha256RSA",
        "subject": {
            "OU": "PositiveSSL Wildcard",
            "CN": "*."+resource
        },
        "validity": {
            "not_after": "2022-01-14 23:59:59",
            "not_before": "2018-01-15 00:00:00"
        },
        "version": "V3",
        "extensions": {
            "certificate_policies": [
                "1.3.6.1.4.1.6449.1.2.2.7",
                "2.23.140.1.2.1"
            ],
            "extended_key_usage": [
                "serverAuth",
                "clientAuth"
            ],
            "authority_key_identifier": {
                "keyid": "90af6a3a945a0bd890ea125673df43b43a28dae7"
            },
            "subject_alternative_name": [
                "*."+resource,
                resource
            ],
            "tags": [],
            "subject_key_identifier": "81559154db8e60b4654f174f3e4f29cde3bb89c4",
            "crl_distribution_points": [
                "http://crl.comodoca.com/COMODORSADomainValidationSecureServerCA.crl"
            ],
            "key_usage": [
                "ff"
            ],
            "CA": True,
            "ca_information_access": {
                "CA Issuers": "http://crt.comodoca.com/COMODORSADomainValidationSecureServerCA.crt",
                "OCSP": "http://ocsp.comodoca.com"
            }
        },
        "cert_signature": {
            "signature": "8aa7f7b3dfc444ec88103b149348ca1e35c0abb7ccc641f0f8ee0720b369b081360d1dda6a5241c2441bc86105019fa0d33fcbe0e2e8647afdb3f31a7c1c5f931679d2d07f69e6499e9d88b63e2ed8a209c03d90486ffdc12a852b785b8362aa2a29c5ff9237202c6fa1ea52c80d094212bee6388d508391a82d8a1d97b21ab71ba80c1bb045bf26b017f29e8a45e3168cafeb733ecc4b5abfa85a9b3336cddf05800edf948560c7b9b102be11af294e6a723e4e190b206759f1d8afc4b717e5f0185e8466f9f5b69f2601e6ac3d2741e43675d754487de6b71762bef8b7a30bd3feee42d42a59c6352f8baf47b3a46ecd1e692ee61bf83c137468fac1d9aafb",
            "signature_algorithm": "sha256RSA"
        },
        "serial_number": "5a6f82c33536946d56e81e05c749e4f9",
        "thumbprint": "4d75e60975123ecb76ed6ac278994ac2bdd2ae63",
        "issuer": {
            "C": "GB",
            "ST": "Greater Manchester",
            "CN": "COMODO RSA Domain Validation Secure Server CA",
            "O": "COMODO CA Limited",
            "L": "Salford"
        },
        "size": 1365
    },
    "dns_records": [
        {
            "type": "TXT",
            "value": "google-site-verification=7Hz2-6sSH_3g204K9Z4JM9T2W8LqMQPNcH0zfol9gIA",
            "ttl": 299
        },
        {
            "type": "TXT",
            "value": "DEMO INFO",
            "ttl": 299
        },
        {
            "type": "NS",
            "value": "b.ns-sec.net",
            "ttl": 299
        },
        {
            "rname": "hostmaster.demo.com",
            "retry": 600,
            "value": "c.demo.com",
            "minimum": 600,
            "refresh": 1800,
            "expire": 2419200,
            "ttl": 3599,
            "serial": 2020021213,
            "type": "SOA"
        },
        {
            "priority": 10,
            "type": "MX",
            "value": "demo.com",
            "ttl": 299
        },
        {
            "type": "TXT",
            "value": "MS=ms36730209",
            "ttl": 299
        },
        {
            "type": "TXT",
            "value": "v=spf1 include:spf.protection.outlook.com include:smtp.logium.com include:spf.lianamailer.com include:mail.zendesk.com -all",
            "ttl": 299
        },
        {
            "type": "NS",
            "value": "c.demo.com",
            "ttl": 299
        },
        {
            "type": "TXT",
            "value": "detectify-verification=143aeb30f954974544b9bae85296af3d",
            "ttl": 299
        },
        {
            "type": "A",
            "value": "123.123.123.123",
            "ttl": 299
        },
        {
            "type": "NS",
            "value": "a.ns-sec.com",
            "ttl": 299
        },
        {
            "type": "AAAA",
            "value": "2001:aac:124:91::2",
            "ttl": 299
        },
        {
            "type": "NS",
            "value": "d.ns-sec.org",
            "ttl": 299
        }
    ],
    "categories": [
        "news",
        "news and media"
    ],
    "dns_records_date": 1591155097,
    "undetected_urls": [
        [
            "http://"+resource,
            "65b4085da0a13629826551b9cd288815f4c9721628520ba3a35aae60678c601e",
            0,
            80,
            "2020-05-18 10:10:15"
        ]
    ],
    "whois": "country: DEMO\ncreated: 1.1.1991 00:00:00\ndnssec: no\ndomain: "+resource+"\nexpires: 31.8.2022 00:00:00\nmodified: 6.9.2017\nnserver: a.ns-sec.com [Technical Error]\nnserver: b.ns-sec.net [OK]\nnserver: c.ns-sec.com [178.217.128.53] [2001:67c:224:53::53:1] [OK]\nnserver: d.ns-sec.org [OK]\nregistrar: Cybercom Finland Oy\nstatus: Registered",
    "Alexa domain info": "DEMO",
    "response_code": 1,
    "WOT domain info": {
        "Vendor reliability": "Good",
        "Child safety": "Good",
        "Trustworthiness": "Good",
        "Privacy": "Good"
    },
    "verbose_msg": "Domain found in dataset",
    "popularity_ranks": {
        "Majestic": {
            "timestamp": 1590939362,
            "rank": 13838
        },
        "Statvoo": {
            "timestamp": 1591025761,
            "rank": 3733
        },
        "Alexa": {
            "timestamp": 1591112161,
            "rank": 10859
        },
        "Cisco Umbrella": {
            "timestamp": 1591112166,
            "rank": 397118
        },
        "Quantcast": {
            "timestamp": 1585668964,
            "rank": 38582
        }
    },
    "detected_urls": [],
    "undetected_communicating_samples": [
        {
            "date": "2019-10-12 21:05:40",
            "positives": 0,
            "total": 69,
            "sha256": "b2cd52020cb428e2361904badafebd1f27e11f46c42e2827235389a741357298"
        },
        {
            "date": "2019-10-04 03:18:05",
            "positives": 0,
            "total": 73,
            "sha256": "9d7fcdec4cc09d3ddfa3f47a6fd84cdce94ad130853e2b2e9423aee982b30e04"
        },
        {
            "date": "2019-08-06 13:40:40",
            "positives": 0,
            "total": 70,
            "sha256": "38a912ab87e7bae6cceddcfeda41f6383221b1e0f3301b811dc30617f5507033"
        },
        {
            "date": "2019-03-05 13:00:10",
            "positives": 0,
            "total": 70,
            "sha256": "ca2ac8d39c5ea0e90cb62f1b0867d5ce138bd880764acbe12c465bf1012223f2"
        },
        {
            "date": "2018-12-06 07:15:37",
            "positives": 0,
            "total": 71,
            "sha256": "9a1c08058a0a6b99b6bd23d713146ea67233eae60110a04a92e92c7288777255"
        }
    ]
}
@VT_api.route(f'/{BASE_URL}/ip-address/report')
def ips():
    resource = request.args.get('ip')
    return {
    "https_certificate_date": 1590486322,
    "undetected_urls": [
    ],
    "undetected_downloaded_samples": [
        {
            "date": "2020-05-18 16:05:42",
            "positives": 0,
            "total": 75,
            "sha256": "a49848357622c6843abd61a2c466514edd2a4c0c44837ec417d7ce493d2a8d9f"
        }
    ],
    "network": str(resource)+"/20",
    "whois_timestamp": 1589210820,
    "detected_downloaded_samples": [],
    "response_code": 1,
    "as_owner": "Akamai Technologies, Inc.",
    "detected_urls": [],
    "verbose_msg": "IP address in dataset",
    "resolutions": [
        {
            "last_resolved": "2020-05-18 16:08:04",
            "hostname": "www.demo.corp"
        }
    ],
    "last_https_certificate": {
        "public_key": {
            "rsa": {
                "key_size": 2048,
                "modulus": "00cec1f025977c766d83d58af3545ee46919c47b57c9c99dbdda23ad98015d907aa1a09a2229220c18fa723df7081ae7ad6ae1d7d5697f2982e285d04ffc6e4b0a625272f803ddc5d93dab17d2f5d3420364f61fc7e824ba8003cdc8692238079b3559a6b530ce07f63fe14ea06913fbe7deb02887326109351a1e0139a8a4a6f1a3c9a313b165cee39efb58c49e1cdbb30beec229ef8fba87f029f1137819b473a460b3bb81c10d8695e6073444ccbbcee47762b3d38ff46fcf7dc592b8bf0c2f15d9292caa149a6a2ef99ef5fb52ba96e330e17c4f8d8f75deebb05790d22b1ca3aa48dcef54f2705f72843c5ec14e61d70a294d8e47e9c3610c87f284d54f27",
                "exponent": "010001"
            },
            "algorithm": "RSA"
        },
        "thumbprint_sha256": "0b44c27b7e8cee9ac5827f0c04782f8f09b5f7eb8c194017ec1634b7ef4bee51",
        "tags": [],
        "signature_algorithm": "sha256RSA",
        "subject": {
            "C": "US",
            "CN": "*.demo.corp",
            "L": "Santa Clara",
            "O": "Demo, Inc.",
            "ST": "California",
            "OU": "IT"
        },
        "validity": {
            "not_after": "2025-12-10 12:00:00",
            "not_before": "2019-09-11 00:00:00"
        },
        "version": "V3",
        "extensions": {
            "certificate_policies": [
                "2.16.840.1.114412.1.1",
                "2.23.140.1.2.2"
            ],
            "extended_key_usage": [
                "serverAuth",
                "clientAuth"
            ],
            "authority_key_identifier": {
                "keyid": "0f80611c823161d52f28e78d4638b42ce1c6d9e2"
            },
            "subject_alternative_name": [
                "*.demo.corp",
                "demo.corp"
            ],
            "tags": [],
            "subject_key_identifier": "8fd1bf3bf9fe7b9bd809f49a263197010715ec84",
            "crl_distribution_points": [
                "http://crl3.digicert.com/ssca-sha2-g6.crl",
                "http://crl4.digicert.com/ssca-sha2-g6.crl"
            ],
            "key_usage": [
                "ff"
            ],
            "1.3.6.1.4.1.11129.2.4.2": "0481f000ee007500ee4bbdb775ce60bae142691fabe19e66a30f7e5fb072d883",
            "CA": True,
            "ca_information_access": {
                "CA Issuers": "http://cacerts.digicert.com/DigiCertSHA2SecureServerCA.crt",
                "OCSP": "http://ocsp.digicert.com"
            }
        },
        "cert_signature": {
            "signature": "933eae7e4255615813ccc22887d2c21ee3eeab4a13332ebfed8e4eec259d59356136565b85e85df1a3918d78ab977dbf14ed13526df6e419867d9c9a74217604615313cf9bda47dd5303a95896376d636f2ff0e698f3da3c3a75da13a918eb4cdb7aca04a9d47163eae7c6f72b1b59648f7e5a2f5c350b2bc8f5293530501b8a64b23df6cdc0dd3a6ca49c8946f7dd33f503cfaecae6d25e70210a94aa799e8f40c2e11954833503895912d3168823a4bf27637a487cb7795989c3fa16ff0084490e7634ede42fd46a9884bab89bfe7421eb114f9a79f76be149eed6e5e9bc703870010664711edea2d19c81fd3f21fa296fc8d37aa28b2c18ac201ff32d5726",
            "signature_algorithm": "sha256RSA"
        },
        "serial_number": "19f55a288d53938f0b1f7f93766a262",
        "thumbprint": "003d61084257ee6a9a8774b54aba22d6ec212de0",
        "issuer": {
            "C": "US",
            "CN": "DigiCert SHA2 Secure Server CA",
            "O": "DigiCert Inc"
        },
        "size": 1629
    },
    "asn": 16625,
    "whois": "NetRange: 2.0.0.0 - 2.255.255.255\nCIDR: 2.0.0.0/8\nNetName: 2-RIPE\nNetHandle: NET-2-0-0-0-1\nParent: ()\nNetType: Allocated to RIPE NCC\nOriginAS: \nOrganization: RIPE Network Coordination Centre (RIPE)\nRegDate: 2009-09-28\nUpdated: 2009-09-30\nComment: These addresses have been further assigned to users in\nComment: the RIPE NCC region. Contact information can be found in\nComment: the RIPE database at http://www.ripe.net/whois\nRef: https://rdap.arin.net/registry/ip/2.0.0.0\nResourceLink: https://apps.db.ripe.net/search/query.html\nResourceLink: whois.ripe.net\nOrgName: RIPE Network Coordination Centre\nOrgId: RIPE\nAddress: P.O. Box 10096\nCity: Amsterdam\nStateProv: \nPostalCode: 1001EB\nCountry: NL\nRegDate: \nUpdated: 2013-07-29\nRef: https://rdap.arin.net/registry/entity/RIPE\nReferralServer: whois://whois.ripe.net\nResourceLink: https://apps.db.ripe.net/search/query.html\nOrgAbuseHandle: ABUSE3850-ARIN\nOrgAbuseName: Abuse Contact\nOrgAbusePhone: +31205354444 \nOrgAbuseEmail: abuse@ripe.net\nOrgAbuseRef: https://rdap.arin.net/registry/entity/ABUSE3850-ARIN\nOrgTechHandle: RNO29-ARIN\nOrgTechName: RIPE NCC Operations\nOrgTechPhone: +31 20 535 4444 \nOrgTechEmail: hostmaster@ripe.net\nOrgTechRef: https://rdap.arin.net/registry/entity/RNO29-ARIN\ninetnum: 2.23.64.0 - 2.23.79.255\nnetname: AKAMAI-PA\ndescr: Akamai Technologies\ncountry: EU\nadmin-c: NARA1-RIPE\ntech-c: NARA1-RIPE\nstatus: ASSIGNED PA\nmnt-by: AKAM1-RIPE-MNT\nmnt-routes: TISCALI-INT-ROUTE\ncreated: 2011-07-14T13:21:19Z\nlast-modified: 2011-07-14T13:21:19Z\nsource: RIPE\nrole: Network Architecture Role Account\naddress: Akamai Technologies\naddress: 8 Cambridge Center\naddress: Cambridge, MA 02142\nphone: +1-617-938-3130\nabuse-mailbox: abuse@akamai.com\nadmin-c: NF1714-RIPE\nadmin-c: CKAK-RIPE\ntech-c: NF1714-RIPE\ntech-c: JP1944-RIPE\ntech-c: APB15-RIPE\ntech-c: CKAK-RIPE\ntech-c: TBAK-RIPE\ntech-c: NB782-RIPE\ntech-c: RM4844-RIPE\ntech-c: AKAY-RIPE\nnic-hdl: NARA1-RIPE\nmnt-by: AKAM1-RIPE-MNT\ncreated: 2002-03-06T09:02:17Z\nlast-modified: 2019-04-15T17:17:53Z\nsource: RIPE # Filtered\nroute: 2.23.64.0/20\ndescr: Akamai Technologies\norigin: AS16625\nmnt-by: AKAM1-RIPE-MNT\ncreated: 2020-02-05T19:50:46Z\nlast-modified: 2020-02-05T19:50:46Z\nsource: RIPE\n"
}