from flask import Blueprint, request, Response
import json


from flask import json
import time
from datetime import datetime, timedelta, timezone
import logging



BASE_URL = '/rs/esm/'.strip('/')
INTEGRATION = 'mcafee_api'

mcafee_api = Blueprint(f'{INTEGRATION}', __name__)
logger = logging.getLogger(__name__)

@mcafee_api.route(f'/{BASE_URL}/test') #test
def test():
    return {'result': 'it works'}


@mcafee_api.route(f'/{BASE_URL}/login', methods=['GET', 'POST']) #login maybe change to coockies return
def login():
    res = Response('hello')
    res.headers['Xsrf-Token'] = "token"
    res.set_cookie('JWTToken', 'cookie')
    return res



@mcafee_api.route(f'/{BASE_URL}/v2/logout', methods=['GET', 'POST', 'DELETE']) #logout
def logout():
    res = Response('hello')
    return res



@mcafee_api.route(f'/{BASE_URL}/alarmGetTriggeredAlarms', methods=['GET', 'POST'])  #route for fetch_alarms for version 11.X
def fetch_alarms11x():
   body = { 'return' :
   [
        {"openTime": "12/04/2019 14:00:05",
        "summary": "Access alert incident \"2019-12-04T14:00:00.123080163Z\"",
        "statusId": {"value": 1}, 
        "id": {"value": 30}, 
        "severity": 1},
        {"openTime": "03/11/2019 07:30:00",
        "summary": "Malware alert incident \"2019-11-03T07:30:00.123080163Z\"",
        "statusId": {"value": 1}, 
        "id": {"value": 31}, 
        "severity": 2},
        {"openTime": "31/12/1999 23:59:59:59",
        "summary": "Y2K the world is going to end. All panic!! alert incident \"1900-01-01T00:00:00.000000Z\"",
        "statusId": {"value": 666}, 
        "id": {"value": 33}, 
        "severity": 'Nuke'},
        ]
   }
   jbody = json.dumps(body)
   res = Response(jbody)
   return res

@mcafee_api.route(f'/{BASE_URL}/alarmGetTriggeredAlarmsPaged', methods=['GET', 'POST']) #route for fetch_alarms for version before 11.X
def fetch_alarms():
   body = { 'return' :
   [
        {"openTime": "12/04/2019 14:00:05",
        "summary": "Access alert incident \"2019-12-04T14:00:00.123080163Z\"",
        "statusId": {"value": 1}, 
        "id": {"value": 30}, 
        "severity": 1},
        {"openTime": "03/11/2019 07:30:00",
        "summary": "Malware alert incident \"2019-11-03T07:30:00.123080163Z\"",
        "statusId": {"value": 1}, 
        "id": {"value": 31}, 
        "severity": 2},
        {"openTime": "31/12/1999 23:59:59:59",
        "summary": "Y2K the world is going to end. All panic!! alert incident \"1900-01-01T00:00:00.000000Z\"",
        "statusId": {"value": 666}, 
        "id": {"value": 33}, 
        "severity": 'Nuke'},
        ]
   }
   jbody = json.dumps(body)
   res = Response(jbody)
   return res
   

@mcafee_api.route(f'/{BASE_URL}/caseGetCaseList', methods = ['POST', 'GET'])  #route for fetch_incidents when incident set to cases 
def get_cases():
    body = { 'return':
    [
    {
    "openTime": "12/04/2019 13:00:04", 
    "summary": "Malicious hashes MD5 81c8e6e6c2cb543f736d6c17fff31c3d 8653dcccc1ae9cb38956ff9c24ecaf8d 9763e01d945b4f54e2d5324e21e7d1aa 138.68.73.49 128.199.239.180 23.129.64.102 23.129.64.162  31.7.63.194 66.146.193.33 99.50.120.174 130.185.250.76 hostname WIN-AQ0LQQOG4",
    "statusId": {"value": 1},
    "id": {"value": 18}, 
    "severity": 1
    },
    {
    "openTime": "17/11/2019 17:30:04", 
    "summary": "C2Communication alert incident 2020-01-08T09:30:00.060989202Z",
    "statusId": {"value": 5},
    "id": {"value": 20}, 
    "severity": 5
    }
    ]}
    jbody = json.dumps(body)
    res = Response(jbody)
    return res


@mcafee_api.route(f'/{BASE_URL}/alarmAcknowledgeTriggeredAlarm', methods=['GET','POST'])  #route for esm-acknowledge-alarms
def acknowledge_alarms():
    return {'result': 'Alarms has been Acknowledged.'}

@mcafee_api.route(f'/{BASE_URL}/alarmUnacknowledgeTriggeredAlarm', methods=['GET','POST'])  #route for esm-acknowledge-alarms
def unacknowledge_alarms():
    return {'result': 'Alarms has been Unacknowledged.'}

@mcafee_api.route(f'/{BASE_URL}/caseAddCase', methods=['GET','POST'])  #route to create a case in esm
def add_case():
    return { "return":{ "value" : 46 } }

@mcafee_api.route(f'/{BASE_URL}/caseAddCaseStatus', methods=['GET','POST'])  #route to create a new cases status
def add_case_status():
    return {'return': 'Added case status : test'}



@mcafee_api.route(f'/{BASE_URL}/alarmDeleteTriggeredAlarm', methods=['GET','POST'])  #route to delete specific alarm
def delete_alarms():
    return {'result': 'Alarms has been Deleted.'}

@mcafee_api.route(f'/{BASE_URL}/caseDeleteCaseStatus', methods=['GET','POST'])  #route to delete specific case status by name
def delete_case_status():
    return {'result': 'Deleted case status with ID: 58'}

@mcafee_api.route(f'/{BASE_URL}/caseEditCase', methods=['GET','POST'])  #route to edit specific case by id
def edit_case():
    return {'result': 'Case edited'}

@mcafee_api.route(f'/{BASE_URL}/caseEditCaseStatus', methods=['GET','POST'])  #route to edit specific case status by id
def edit_case_status():
    return {'result': 'Edit case status with ID: 60'}

@mcafee_api.route(f'/{BASE_URL}/qryGetFilterFields', methods=['GET','POST'])  #route to fetch_all_fields, before version 10.2
def fetch_all_fields_old():
    result = [
                {
                "name": 'AppID',
                "types": 'STRING',
            },
                {
                "name": "CommandID",
                "types": "STRING",
            },   
                {
                "name": "DomainID",
                "types": "STRING",
            },
                {
                "name": "HostID",
                "types": "STRING",
            }, 
                {
                "name": "UserIDDst",
                "types": "STRING",
            },
                {
                "name": "UserIDSrc",
                "types": "STRING",
            },    
                {
                "name": "URL",
                "types": "STRING",
            },
                {
                "name": "Database_Name",
                "types": "STRING",
            },    
                {
                "name": "Message_Text",
                "types": "STRING",
            },
                {
                "name": "Response_Time",
                "types": "UINT32",
                }
        ]
    return json.dumps(result)
    

@mcafee_api.route(f'/{BASE_URL}/v2/qryGetFilterFields', methods=['GET','POST'])  #route to fetch_all_fields, after version 10.2
def fetch_all_fields():
   result = [ {
            "types" : [ "STRING" ],
            "name" : "AppID"
            }, {
            "types" : [ "STRING" ],
            "name" : "CommandID"
            }, {
            "types" : [ "STRING" ],
            "name" : "DomainID"
            }, {
            "types" : [ "STRING" ],
            "name" : "HostID"
            }, {
            "types" : [ "STRING" ],
            "name" : "ObjectID"
            }, {
            "types" : [ "STRING" ],
            "name" : "UserIDDst"
            }, {
            "types" : [ "STRING" ],
            "name" : "UserIDSrc"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "URL"
            }, {
            "types" : [ "STRING" ],
            "name" : "Database_Name"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Message_Text"
            }, {
            "types" : [ "UINT32", "UINT32" ],
            "name" : "Response_Time"
            }, {
            "types" : [ "STRING" ],
            "name" : "Application_Protocol"
            }, {
            "types" : [ "STRING" ],
            "name" : "Object_Type"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Filename"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "From"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "To"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Cc"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Bcc"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Subject"
            }, {
            "types" : [ "STRING" ],
            "name" : "Method"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "User_Agent"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Cookie"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Referer"
            }, {
            "types" : [ "STRING" ],
            "name" : "File_Operation"
            }, {
            "types" : [ "STRING" ],
            "name" : "File_Operation_Succeeded"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Destination_Filename"
            }, {
            "types" : [ "STRING" ],
            "name" : "User_Nickname"
            }, {
            "types" : [ "STRING" ],
            "name" : "Contact_Name"
            }, {
            "types" : [ "STRING" ],
            "name" : "Contact_Nickname"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Client_Version"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Job_Name"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Language"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "SWF_URL"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "TC_URL"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "RTMP_Application"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Version"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Local_User_Name"
            }, {
            "types" : [ "IPV4", "UINT16", "UINT16" ],
            "name" : "NAT_Details"
            }, {
            "types" : [ "SIGID" ],
            "name" : "Network_Layer"
            }, {
            "types" : [ "SIGID" ],
            "name" : "Transport_Layer"
            }, {
            "types" : [ "SIGID" ],
            "name" : "Session_Layer"
            }, {
            "types" : [ "SIGID" ],
            "name" : "Application_Layer"
            }, {
            "types" : [ "SIGID" ],
            "name" : "HTTP_Layer"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "HTTP_Req_URL"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "HTTP_Req_Cookie"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "HTTP_Req_Referer"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "HTTP_Req_Host"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "HTTP_Req_Method"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "HTTP_User_Agent"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "DNS_Name"
            }, {
            "types" : [ "STRING" ],
            "name" : "DNS_Type"
            }, {
            "types" : [ "STRING" ],
            "name" : "DNS_Class"
            }, {
            "types" : [ "STRING" ],
            "name" : "Query_Response"
            }, {
            "types" : [ "STRING" ],
            "name" : "Authoritative_Answer"
            }, {
            "types" : [ "STRING" ],
            "name" : "SNMP_Operation"
            }, {
            "types" : [ "STRING" ],
            "name" : "SNMP_Item_Type"
            }, {
            "types" : [ "STRING" ],
            "name" : "SNMP_Version"
            }, {
            "types" : [ "STRING" ],
            "name" : "SNMP_Error_Code"
            }, {
            "types" : [ "STRING" ],
            "name" : "NTP_Client_Mode"
            }, {
            "types" : [ "STRING" ],
            "name" : "NTP_Server_Mode"
            }, {
            "types" : [ "STRING" ],
            "name" : "NTP_Request"
            }, {
            "types" : [ "STRING" ],
            "name" : "NTP_Opcode"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "SNMP_Item"
            }, {
            "types" : [ "STRING" ],
            "name" : "Interface"
            }, {
            "types" : [ "STRING" ],
            "name" : "Direction"
            }, {
            "types" : [ "STRING" ],
            "name" : "Sensor_Name"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Sensor_UUID"
            }, {
            "types" : [ "STRING" ],
            "name" : "Sensor_Type"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Signature_Name"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Threat_Name"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Destination_Hostname"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Category"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Process_Name"
            }, {
            "types" : [ "IP" ],
            "name" : "Grid_Master_IP"
            }, {
            "types" : [ "STRING" ],
            "name" : "Response_Code"
            }, {
            "types" : [ "UINT64" ],
            "name" : "Device_Port"
            }, {
            "types" : [ "IP" ],
            "name" : "Device_IP"
            }, {
            "types" : [ "UINT64" ],
            "name" : "PID"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Target_Context"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Source_Context"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Target_Class"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Policy_Name"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Destination_Zone"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Source_Zone"
            }, {
            "types" : [ "STRLIT" ],
            "name" : "Queue_ID"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Delivery_ID"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Recipient_ID"
            }, {
            "types" : [ "FLOAT" ],
            "name" : "Spam_Score"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Mail_ID"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "To_Address"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "From_Address"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Message_ID"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Request_Type"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "SQL_Statement"
            }, {
            "types" : [ "UINT64" ],
            "name" : "External_EventID"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Event_Class"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Description"
            }, {
            "types" : [ "GUID" ],
            "name" : "File_Hash"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Mainframe_Job_Name"
            }, {
            "types" : [ "UINT64" ],
            "name" : "External_SubEventID"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Destination_UserID"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Source_UserID"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Volume_ID"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Step_Name"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Step_Count"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "LPAR_DB2_Subsystem"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Logical_Unit_Name"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Job_Type"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "FTP_Command"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "File_Type"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "DB2_Plan_Name"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Catalog_Name"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Access_Resource"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Table_Name"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "External_DB2_Server"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "External_Application"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Creator_Name"
            }, {
            "types" : [ "STRING" ],
            "name" : "Return_Code"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Database_ID"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Incoming_ID"
            }, {
            "types" : [ "UINT64" ],
            "name" : "Handle_ID"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Destination_Network"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Source_Network"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Malware_Insp_Result"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Malware_Insp_Action"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "External_Hostname"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Privileged_User"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Facility"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Area"
            }, {
            "types" : [ "GUID" ],
            "name" : "Instance_GUID"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Logon_Type"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Operating_System"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "File_Path"
            }, {
            "types" : [ "GUID" ],
            "name" : "Agent_GUID"
            }, {
            "types" : [ "UINT64" ],
            "name" : "Reputation"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "URL_Category"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Session_Status"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Destination_Logon_ID"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Source_Logon_ID"
            }, {
            "types" : [ "GUID" ],
            "name" : "UUID"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "External_SessionID"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Management_Server"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Detection_Method"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Target_Process_Name"
            }, {
            "types" : [ "FLOAT" ],
            "name" : "Analyzer_DAT_Version"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Forwarding_Status"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Reason"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Threat_Handled"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Threat_Category"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Device_Action"
            }, {
            "types" : [ "GUID" ],
            "name" : "Database_GUID"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "SQL_Command"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Destination_Directory"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Directory"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Mailbox"
            }, {
            "types" : [ "UINT64" ],
            "name" : "Handheld_ID"
            }, {
            "types" : [ "UINT64" ],
            "name" : "Policy_ID"
            }, {
            "types" : [ "UINT64" ],
            "name" : "Server_ID"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Registry_Value"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Registry_Key"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Caller_Process"
            }, {
            "types" : [ "FLOAT" ],
            "name" : "DAT_Version"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Interface_Dest"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Datacenter_Name"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Datacenter_ID"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Virtual_Machine_ID"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Virtual_Machine_Name"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "PCAP_Name"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Search_Query"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Service_Name"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "External_Device_Name"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "External_Device_ID"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "External_Device_Type"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Organizational_Unit"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Privileges"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Reputation_Name"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Vulnerability_References"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Web_Domain"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Sub_Status"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Status"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Access_Privileges"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Rule_Name"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "App_Layer_Protocol"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Group_Name"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Authentication_Type"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "New_Value"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Old_Value"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Security_ID"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "SHA1"
            }, {
            "types" : [ "FLOAT" ],
            "name" : "Reputation_Score"
            }, {
            "types" : [ "GUID" ],
            "name" : "Parent_File_Hash"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "File_ID"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Engine_List"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Device_URL"
            }, {
            "types" : [ "IPV4" ],
            "name" : "Attacker_IP"
            }, {
            "types" : [ "IPV4" ],
            "name" : "Victim_IP"
            }, {
            "types" : [ "INT64" ],
            "name" : "Incident_ID"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Attribute_Type"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Access_Mask"
            }, {
            "types" : [ "GUID" ],
            "name" : "Object_GUID"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "VPN_Feature_Name"
            }, {
            "types" : [ "IP" ],
            "name" : "Reputation_Server_IP"
            }, {
            "types" : [ "IP" ],
            "name" : "DNS_Server_IP"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Hash_Type"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Hash"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Subcategory"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Wireless_SSID"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "Share_Name"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "CnC_Host"
            }, {
            "types" : [ "UINT64" ],
            "name" : "Device_Confidence"
            }, {
            "types" : [ "SSTRING" ],
            "name" : "SHA256"
            }, {
            "types" : [ "SIGID" ],
            "name" : "DSIDSigID"
            }, {
            "types" : [ "UINT16" ],
            "name" : "ZoneSrc"
            }, {
            "types" : [ "UINT8" ],
            "name" : "Action"
            }, {
            "types" : [ "UINT64" ],
            "name" : "ASNGeoDst"
            }, {
            "types" : [ "UINT32" ],
            "name" : "FirstTime"
            }, {
            "types" : [ "UINT16" ],
            "name" : "SrcPort"
            }, {
            "types" : [ "FLOAT" ],
            "name" : "AvgSeverity"
            }, {
            "types" : [ "UINT64" ],
            "name" : "DSID"
            }, {
            "types" : [ "UINT16" ],
            "name" : "DstPort"
            }, {
            "types" : [ "IP" ],
            "name" : "SrcIP"
            }, {
            "types" : [ "UINT16" ],
            "name" : "ZoneDst"
            }, {
            "types" : [ "SIGID" ],
            "name" : "SigID"
            }, {
            "types" : [ "GUID" ],
            "name" : "GUIDSrc"
            }, {
            "types" : [ "GUID" ],
            "name" : "GUIDDst"
            }, {
            "types" : [ "IP" ],
            "name" : "DstIP"
            }, {
            "types" : [ "UINT64" ],
            "name" : "ID"
            }, {
            "types" : [ "UINT8" ],
            "name" : "Protocol"
            }, {
            "types" : [ "UINT32" ],
            "name" : "NormID"
            }, {
            "types" : [ "MAC_ADDRESS" ],
            "name" : "SrcMac"
            }, {
            "types" : [ "UINT64" ],
            "name" : "SessionID"
            }, {
            "types" : [ "UINT64" ],
            "name" : "ASNGeoSrc"
            }, {
            "types" : [ "MAC_ADDRESS" ],
            "name" : "DstMac"
            }, {
            "types" : [ "UINT32" ],
            "name" : "LastTime"
            } ]
   return json.dumps(result)
'''
    body = { 'return' :
            [   
                {
                "name": "AppID",
                "types": 'STRING',
            },
                {
                "name": "CommandID",
                "types": "STRING",
            },   
                {
                "name": "DomainID",
                "types": "STRING",
            },
                {
                "name": "HostID",
                "types": "STRING",
            }, 
                {
                "name": "UserIDDst",
                "types": "STRING",
            },
                {
                "name": "UserIDSrc",
                "types": "STRING",
            },    
                {
                "name": "URL",
                "types": "STRING",
            },
                {
                "name": "Database_Name",
                "types": "STRING",
            },    
                {
                "name": "Message_Text",
                "types": "STRING",
            },
                {
                "name": "Response_Time",
                "types": "UINT32",
            }
        ]
   }
    jbody = json.dumps(body)
    res = Response(jbody)
    return res
'''
@mcafee_api.route(f'/{BASE_URL}/ipsGetAlertData', methods=['GET','POST'])  #route to get_alarm_event_details, before version 10.2
def get_alarm_event_details_old():
    body = {"return" : 
                    [
                    {
                                    "destIp":"219.94.250.151",
                                    "destMac":"00:25:96:FF:FE:12:34:56",
                                    "destPort":"443",
                                    "eventCount":"10",
                                    "firstTime":"1587712352012",
                                    "flowSessionId":"22",
                                    "ipsId":"1234",
                                    "lastTime":"1587712352012",
                                    "note":"xmocky incident",
                                    "protocol":"HTTPS",
                                    "reviewed":"NO",
                                    "srcIp":"172.16.10.56",
                                    "srcMac":"22:14:A6:3B:2D:0A",
                                    "srcPort":"3674",
                                    "subtype":"Access",
                                    "vLAN":"45",
                                    "sigId":"4321",
                                    "sigDesc":"This is a xmocky alert",
                                    "sigText":"xxxxxxxxxx",
                                    "ruleName":"xmocky",
                                    "duration":"100",
                                    "deviceName":"Xmocky device",
                                    "severity":1,
                                    "normId":"4536",
                                    "host":"xmocky host",
                                    "domain":"xmocky",
                                    "srcUser":"xmocky.perez",
                                    "destUser":"xmocky.sanchez",
                                    "srcNetworkDevice":"WIN",
                                    "destNetworkDevice":"Android",
                                    "srcInterface":"Unknown",
                                    "destInterface":"Unknown",
                                    "srcNetworkDeviceId":"6785",
                                    "destNetworkDeviceId":"9347",
                                    "srcInterfaceId":"9999",
                                    "destInterfaceId":"9374",
                                    "remedyCaseId":"4532",
                                    "remedyTicketTime":"1587712352012",
                                    "deviceTime":"1587712352012",
                                    "remedyAnalyst":"Pedro",
                                    "command":"ls",
                                    "object":"Unknown",
                                    "sequence":"1",
                                    "trusted":"1",
                                    "sessionId":"7789",
                                    "asnGeoSrcId":"7876",
                                    "srcAsnGeo":"9595",
                                    "asnGeoDestId":"4533",
                                    "destAsnGeo":"3456",
                                    "normMessage":"Norm",
                                    "normDesc":"Norm",
                                    "archiveId":"1378",
                                    "srcZone":"4",
                                    "destZone":"6",
                                    "flowId":"43",
                                    "alertId":"76",
                                    "srcGuid":"32",
                                    "destGuid":"54",
                                    "agg1Name":"Access",
                                    "agg1Value":"4",
                                    "agg2Name":"Network",
                                    "agg2Value":"3",
                                    "agg3Name":"Malware",
                                    "agg3Value":"6",
                                    "iocName":"iocName",
                                    "iocId":"5",
                                    "cases":"34",
                                    "customTypes":"None",
                                    },
                                    {
                                    "destIp":"230.65.87.78",
                                    "destMac":"00:25:97:FE:FF:16:64:76",
                                    "destPort":"80",
                                    "eventCount":"10",
                                    "firstTime":"1587802352012",
                                    "flowSessionId":"23",
                                    "ipsId":"5645",
                                    "lastTime":"1587712982012",
                                    "note":"xmocky incident",
                                    "protocol":"HTTP",
                                    "reviewed":"YES",
                                    "srcIp":"10.10.16.34",
                                    "srcMac":"00:43:90:FF:FE:23:72:80",
                                    "srcPort":"2312",
                                    "subtype":"Phishing",
                                    "vLAN":"21",
                                    "sigId":"879",
                                    "sigDesc":"This is a xmocky alert",
                                    "sigText":"kdkdkd",
                                    "ruleName":"xmocky",
                                    "duration":"500",
                                    "deviceName":"Xmocky device",
                                    "severity": 1,
                                    "normId":"987",
                                    "host":"xmocky host",
                                    "domain":"xmocky",
                                    "srcUser":"xmocky.mendez",
                                    "destUser":"xmocky.bon",
                                    "srcNetworkDevice":"Linux",
                                    "destNetworkDevice":"iOS",
                                    "srcInterface":"Unknown",
                                    "destInterface":"Unknown",
                                    "srcNetworkDeviceId":"4",
                                    "destNetworkDeviceId":"4234",
                                    "srcInterfaceId":"3342",
                                    "destInterfaceId":"2232",
                                    "remedyCaseId":"2344",
                                    "remedyTicketTime":"1587712352012",
                                    "deviceTime":"1587712352012",
                                    "remedyAnalyst":"Pablo",
                                    "command":"wmi",
                                    "object":"Unknown",
                                    "sequence":"4",
                                    "trusted":"3",
                                    "sessionId":"1344",
                                    "asnGeoSrcId":"3234",
                                    "srcAsnGeo":"2324",
                                    "asnGeoDestId":"2345",
                                    "destAsnGeo":"6533",
                                    "normMessage":"Norm",
                                    "normDesc":"Norm",
                                    "archiveId":"653",
                                    "srcZone":"6",
                                    "destZone":"4",
                                    "flowId":"43",
                                    "alertId":"456",
                                    "srcGuid":"25",
                                    "destGuid":"24",
                                    "agg1Name":"Exfiltration",
                                    "agg1Value":"8",
                                    "agg2Name":"Lateral",
                                    "agg2Value":"7",
                                    "agg3Name":"Access",
                                    "agg3Value":"6",
                                    "iocName":"iocName",
                                    "iocId":"7",
                                    "cases":"32",
                                    "customTypes":"None",

                    },
                    ]
                    }

    jbody = json.dumps(body)
    res = Response(jbody)
    return res
    
@mcafee_api.route(f'/{BASE_URL}/v2/ipsGetAlertData', methods=['GET','POST'])  #route to get_alarm_event_details, after version 10.2
def get_alarm_event_details():
    body = {'ipsId':67,'eventId':15,"alertId": 24, "destIp": "200.23.76.154", "destPort": 23, "lastTime": "12/12/2019 10:22:45:32", 
    "severity": 1, "ruleMessage": "This is a xmocky event", "srcIp": "172.16.14.25", "srcPort": 1345, "subtype": "Malware",
    'raw_event':[{'eventId':15}, {'ipsId':67},{'ID':46}]}
    
    jbody = json.dumps(body)
    res = Response(jbody)
    return res



@mcafee_api.route(f'/{BASE_URL}/caseGetCaseDetail', methods=['GET','POST'])  #route to get_case_detail
def get_case_detail():
    case_id = request.args.get('id')
    summary = request.args.get('summary')
    if not case_id :
        case_id = 30
    if not summary:
        summary = 'Access alert incident \"2019-12-04T14:00:00.123080163Z\"'
    body =   { "return":
                            {
                            "notes" : [ {
                                "content" : "",
                                "changes" : [ ],
                                "timestamp" : "12/04/2019 14:00:05(GMT)",
                                "action" : "Open",
                                "username" : "NGCP"
                            } ],
                            "assignedTo" : 1,
                            "orgId" : 1,
                            "closeTime" : "12/04/2019 14:00:05",
                            "eventList" : [ ],
                            "deviceList" : "Null",
                            "dataSourceList" : "Null",
                            "noteAdded" : "",
                            "history" : [ {
                                "content" : "",
                                "changes" : [ ],
                                "timestamp" : "05/28/2020 06:44:12(GMT)",
                                "action" : "Viewed",
                                "username" : "NGCP"
                            }, {
                                "content" : "",
                                "changes" : [ ],
                                "timestamp" : "05/26/2020 19:43:41(GMT)",
                                "action" : "Viewed",
                                "username" : "NGCP"
                            }, {
                                "content" : "",
                                "changes" : [ ],
                                "timestamp" : "12/04/2019 14:00:06(GMT)",
                                "action" : "Viewed",
                                "username" : "NGCP"
                            } ],
                            "id" :  { "value" : case_id },
                            "severity" : 1,
                            "summary" : summary,
                            "openTime" : "12/04/2019 14:00:05",
                            "statusId" : {
                                "value" : 1
                            }
                            } }
    jbody = json.dumps(body)
    res = Response(jbody)
    return res
    



@mcafee_api.route(f'/{BASE_URL}/caseGetCaseEventsDetail', methods=['GET','POST'])  #route to get_case_event_list
def get_case_event_list():
    event_ids = [request.args.get('event_ids')]
    for event_id in event_ids:
        if event_id == None:
            event_id = 64
        body = {
            "return":
            [
            {
            "id" : {"value": [event_id]},
            "message" : "Xmocly event",
            "lastTime" : "15/02/2020 10:50:04",
            },
            {
            "id" : {"value": 89},
            "message" : "Xmocly event",
            "lastTime" : "15/02/2020 10:50:04",
            },
            {
            "id" : {"value": 123},
            "message" : "Xmocly event",
            "lastTime" : "15/02/2020 10:50:04",
            },
            ]
            }
        jbody = json.dumps(body)
        res = Response(jbody)
        return res

@mcafee_api.route(f'/{BASE_URL}/caseGetCaseStatusList', methods=['GET','POST'])  #route to get_case_statuses
def get_case_statuses():
    body = { 
        "return":
        [
        {
            "id" : 5,
            "name" : "Closed",
            "default" : False,
            "showInCasePane" : False
        },
        {
            "id" : 1,
            "name" : "Open",
            "default" : True,
            "showInCasePane" : True
        },
        {
            "id" : 6,
            "name" : "test",
            "default" : False,
            "showInCasePane" : True
        }
        ]
        }
    jbody = json.dumps(body)
    res = Response(jbody)
    return res



@mcafee_api.route(f'/{BASE_URL}/caseGetOrganizationList', methods=['GET','POST'])  #route to get_organizations
def get_organizations():
    body = { 
        "return": 
        [ 
            {
            "name" : "Xmocky 1",
            "id" : 1
        },
        {
            "name" : "Xmocky 2",
            "id" : 2
        },
        {
            "name" : "Xmocky 3",
            "id" : 3
            } 
            ]
        }
    jbody = json.dumps(body)
    res = Response(jbody)
    return res

@mcafee_api.route(f'/{BASE_URL}/userGetUserList', methods=['GET','POST'])  #route to get_users
def get_users():
    body = { 
        "return": 
        [ 
            {
                "id" :  { "value" : 1 },
                "master" : True,
                "groups" : [ ],
                "email" : "",
                "alias" : "",
                "loggedInCount" : 1,
                "emailId" :  { "value" : 0 },
                "sms" : "",
                "smsId" :  { "value" : 0 },
                "admin" : False,
                "type" : "POWER",
                "locked" : False,
                "username" : "NGCP"
                }, {
                "id" :  { "value" : 3 },
                "master" : False,
                "groups" : [  { "value" : 2 } ],
                "email" : "",
                "alias" : "",
                "loggedInCount" : 0,
                "emailId" :  { "value" : 0 },
                "sms" : "",
                "smsId" :  { "value" : 0 },
                "admin" : False,
                "type" : "POWER",
                "locked" : False,
                "username" : "POLICY"
                }, {
                "id" :  { "value" : 2 },
                "master" : False,
                "groups" : [  { "value" : 1 } ],
                "email" : "",
                "alias" : "",
                "loggedInCount" : 0,
                "emailId" :  { "value" : 0 },
                "sms" : "",
                "smsId" :  { "value" : 0 },
                "admin" : False,
                "type" : "POWER",
                "locked" : False,
                "username" : "xmockyuser"
                } 
                ] 
                }
    jbody = json.dumps(body)
    res = Response(jbody)
    return res 
    

    

@mcafee_api.route(f'/{BASE_URL}/notifyGetTriggeredNotificationDetail', methods=['GET','POST'])  #route to list_alarm_events
def list_alarm_events():
    body = {'return': 
    {
     'events':
            [
                {'ipsId':67,'eventId':15,"alertId": 24, "destIp": "200.23.76.154", "destPort": 23, "lastTime": "12/12/2019 10:22:45:32", 
                "severity": 1, "ruleMessage": "This is a xmocky event", "srcIp": "172.16.14.25", "srcPort": 1345, "subtype": "Malware",
                'raw_event':[{'eventId':15}, {'ipsId':67},{'ID':46},{'severity':1}], 'return':[{'severity':{'value':1}},{'events':{'value':1}}]}
            ]
        }
    }
    
    jbody = json.dumps(body)
    res = Response(jbody)
    return res



    '''
    return { 'severity':1, 
    'raw_event':{'severity':1}, 
    'case':{'severity':1},
    'cases':{'severity':1},
    'event':{'severity':1}, 
    "return": { 'event':{'severity':1}, 'severity':1,
    "events": [
      {
        "eventId": 23
      }, 
      {
        "eventSubType": "test"
      }, 
      {
        'severity': 1
      }
    ], 
    'severity': 1
  }
}
'''




    

@mcafee_api.route(f'/{BASE_URL}/qryExecuteDetail', methods=['GET','POST'])  #route to execute query for esm-search, before version 10.2
def execute_querys_old():
    result = [
        {
            "resultID" : 152
        }
    ]
    return json.dumps(result)


@mcafee_api.route(f'/{BASE_URL}/v2/qryExecuteDetail', methods=['GET','POST'])  #route to execute query for esm-search, after version 10.2
def execute_querys():
    return {'resultID' : 152}

    

@mcafee_api.route(f'/{BASE_URL}/qryGetStatus', methods=['GET','POST'])  #route to get query status for esm-search, before version 10.2
def get_query_result_old():
    return {"complete" : True}

@mcafee_api.route(f'/{BASE_URL}/v2/qryGetStatus', methods=['GET','POST'])  #route to get query status for esm-search, after version 10.2
def get_query_result():
    return {"complete" : True}

@mcafee_api.route(f'/{BASE_URL}/qryGetResults', methods=['GET','POST'])  #route to fetch query results for esm-search, before version 10.2
def fetch_results_old():
        result = { 'columns' : [{'name':'ID'},{'name':'Alert Name'},{'name':'Severity'}], 
                    'rows': [{'values':['22','Xmocky query results','1',]},{'values':['54','Xmocky query results','1']},
                       {'values':['64','Xmocky query results','1',]},{'values':['98','Xmocky query results','1']}]}
        return json.dumps(result)

@mcafee_api.route(f'/{BASE_URL}/v2/qryGetResults', methods=['GET','POST'])  #route to fetch query results for esm-search, after version 10.2
def fetch_results():
        result = { 'columns' : [{'name':'ID'},{'name':'Alert Name'},{'name':'Severity'}], 
                    'rows': [{'values':['22','Xmocky query results','1',]},{'values':['54','Xmocky query results','1']},
                       {'values':['64','Xmocky query results','1',]},{'values':['98','Xmocky query results','1']}]}
        return json.dumps(result)



