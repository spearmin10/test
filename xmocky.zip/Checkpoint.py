from flask import Blueprint, request
import logging
import json

checkpoint_api = Blueprint('checkpoint_api', __name__)
logger = logging.getLogger(__name__)

true = True
false = False
null = None

@checkpoint_api.route('/web_api/login', methods=['POST', 'GET'])
def login():
    return {
        "sid" : "97BVpRfN4j81ogN-V2XqGYmw3DDwIhoSn0og8PiKDiM",
        "url" : "https://192.0.2.1:443/web_api",
        "uid" : "7a13a360-9b24-40d7-acd3-5b50247be33e",
        "session-timeout" : 600,
        "last-login-was-at" : {
            "posix" : 1430032266851,
            "iso-8601" : "2015-04-26T10:11+0300"
        }
    }
@checkpoint_api.route('/web_api/logout', methods=['POST', 'GET'])
def logout():
    return {
        "sid" : "97BVpRfN4j81ogN-V2XqGYmw3DDwIhoSn0og8PiKDiM",
        "url" : "https://192.0.2.1:443/web_api",
        "uid" : "7a13a360-9b24-40d7-acd3-5b50247be33e",
        "session-timeout" : 600,
        "last-login-was-at" : {
            "posix" : 1430032266851,
            "iso-8601" : "2015-04-26T10:11+0300"
        }
    }


@checkpoint_api.route('/web_api/add-host', methods=['POST', 'GET'])
def add_host():
    logger.info("Request Headers %s", request.data)
    return {
        "uid" : "9423d36f-2d66-4754-b9e2-e7f4493756d4",
        "folder" : {
            "uid" : "feb54da1-c5e2-4e83-a3ed-d0601ba5ccb9",
            "name" : "/Global Objects"
        },
        "domain" : {
            "domain-type" : "local domain",
            "uid" : "41e821a0-3720-11e3-aa6e-0800200c9fde",
            "name" : "SMC User"
        },
        "meta-info" : {
            "lock" : "unlocked",
            "validation-state" : "ok",
            "read-only" : False,
            "last-modify-time" : {
            "posix" : 1429440561055,
            "iso-8601" : "2015-04-19T13:49+0300"
            },
            "last-modifier" : "aa",
            "creation-time" : {
            "posix" : 1429440561055,
            "iso-8601" : "2015-04-19T13:49+0300"
            },
            "creator" : "aa"
        },
        "tags" : [ ],
        "name" : "New Host 4",
        "comments" : "",
        "color" : "black",
        "icon" : "Objects/host",
        "groups" : [ ],
        "nat-settings" : {
            "auto-rule" : False
        },
        "ipv4-address" : "192.0.2.1",
        "ipv6-address" : ""
        }

@checkpoint_api.route('/web_api/set-group', methods=['POST', 'GET'])
def set_group():
    logger.info(f"Request Details {request.data}")
    return {'task-id': 'feb54da1-c5e2-4e83-a3ed-d0601ba5ccb9'}
    
@checkpoint_api.route('/web_api/publish', methods=['POST', 'GET'])
def publish():
    return {'task-id': 'feb54da1-c5e2-4e83-a3ed-d0601ba5ccb9'}

@checkpoint_api.route('/web_api/install-policy', methods=['POST', 'GET'])
def install_policy():
    return {'task-id': 'feb54da1-c5e2-4e83-a3ed-d0601ba5ccb9'}

@checkpoint_api.route('/web_api/show-task', methods=['POST', 'GET'])
def show_task():
    return {
        "tasks":{
        "progress-percentage": 100,
        "status": "succeeded",
        "suppressed": "false",
        "task-details":	{"publishResponse":{"numberOfPublishedChanges":1,"mode":"async"},"revision":"6a51a0ed-0e92-4e29-a329-88fad8d7f504"},
        "task-id": "01234567-89ab-cdef-8847-bb7be5efd04c",
        "task-name": "Publish operation"
        }
    }

@checkpoint_api.route('/web_api/show-hosts', methods=['POST', 'GET'])
def show_hosts():
    return {
        "from": 1,
        "objects": [
            {
                "name": 1,
                "uid": "223232323",
                "type": "device",
                "domain":
                    {
                        "name": "blocklist",
                        "uid": "234asdf351",
                        "domain-type": "domain"
                    }
                ,
                "ipv4-address": "1.1.1.1",
                "to": 2,
                "total": 1
            }
        ]
    }

@checkpoint_api.route('/web_api/add-access-rule', methods=['POST'])
def add_access_rule():
    return {
  "uid" : "1df8a4b0-fa8b-428b-b649-626b74bf7f81",
  "name" : "Rule 1",
  "type" : "access-rule",
  "domain" : {
    "uid" : "41e821a0-3720-11e3-aa6e-0800200c9fde",
    "name" : "SMC User",
    "domain-type" : "domain"
  },
  "enabled" : true,
  "comments" : "",
  "meta-info" : {
    "lock" : "locked by current session",
    "validation-state" : "ok",
    "last-modify-time" : {
      "posix" : 1482659046483,
      "iso-8601" : "2016-12-25T11:44+0200"
    },
    "last-modifier" : "aa",
    "creation-time" : {
      "posix" : 1482659046483,
      "iso-8601" : "2016-12-25T11:44+0200"
    },
    "creator" : "aa"
  },
  "install-on" : [ {
    "uid" : "6c488338-8eec-4103-ad21-cd461ac2c476",
    "name" : "Policy Targets",
    "type" : "Global",
    "domain" : {
      "uid" : "a0bbbc99-adef-4ef8-bb6d-defdefdefdef",
      "name" : "Check Point Data",
      "domain-type" : "data domain"
    }
  } ],
  "source" : [ {
    "uid" : "97aeb369-9aea-11d5-bd16-0090272ccb30",
    "name" : "Any",
    "type" : "CpmiAnyObject",
    "domain" : {
      "uid" : "a0bbbc99-adef-4ef8-bb6d-defdefdefdef",
      "name" : "Check Point Data",
      "domain-type" : "data domain"
    }
  } ],
  "source-negate" : false,
  "destination" : [ {
    "uid" : "97aeb369-9aea-11d5-bd16-0090272ccb30",
    "name" : "Any",
    "type" : "CpmiAnyObject",
    "domain" : {
      "uid" : "a0bbbc99-adef-4ef8-bb6d-defdefdefdef",
      "name" : "Check Point Data",
      "domain-type" : "data domain"
    }
  } ],
  "destination-negate" : false,
  "service" : [ {
    "uid" : "97aeb3d9-9aea-11d5-bd16-0090272ccb30",
    "name" : "smtp",
    "type" : "service-tcp",
    "domain" : {
      "uid" : "a0bbbc99-adef-4ef8-bb6d-defdefdefdef",
      "name" : "Check Point Data",
      "domain-type" : "data domain"
    },
    "port" : "25"
  }, {
    "uid" : "97aeb44f-9aea-11d5-bd16-0090272ccb30",
    "name" : "AOL",
    "type" : "service-tcp",
    "domain" : {
      "uid" : "a0bbbc99-adef-4ef8-bb6d-defdefdefdef",
      "name" : "Check Point Data",
      "domain-type" : "data domain"
    },
    "port" : "5190"
  } ],
  "service-negate" : false,
  "vpn" : [ {
    "uid" : "8fcd975f-33b1-4322-b033-6fb251554d45",
    "name" : "MyIntranet",
    "type" : "vpn-community-meshed",
    "domain" : {
      "uid" : "41e821a0-3720-11e3-aa6e-0800200c9fde",
      "name" : "SMC User",
      "domain-type" : "domain"
    }
  } ],
  "action" : {
    "uid" : "6c488338-8eec-4103-ad21-cd461ac2c473",
    "name" : "Drop",
    "type" : "RulebaseAction",
    "domain" : {
      "uid" : "a0bbbc99-adef-4ef8-bb6d-defdefdefdef",
      "name" : "Check Point Data",
      "domain-type" : "data domain"
    }
  },
  "action-settings" : {
    "enable-identity-captive-portal" : false
  },
  "content" : [ {
    "uid" : "97aeb369-9aea-11d5-bd16-0090272ccb30",
    "name" : "Any",
    "type" : "CpmiAnyObject",
    "domain" : {
      "uid" : "a0bbbc99-adef-4ef8-bb6d-defdefdefdef",
      "name" : "Check Point Data",
      "domain-type" : "data domain"
    }
  } ],
  "content-negate" : false,
  "content-direction" : "any",
  "track" : {
    "uid" : "29e53e3d-23bf-48fe-b6b1-d59bd88036f9",
    "name" : "None",
    "type" : "Track",
    "domain" : {
      "uid" : "a0bbbc99-adef-4ef8-bb6d-defdefdefdef",
      "name" : "Check Point Data",
      "domain-type" : "data domain"
    }
  },
  "track-alert" : "none",
  "time" : [ {
    "uid" : "97aeb369-9aea-11d5-bd16-0090272ccb30",
    "name" : "Any",
    "type" : "CpmiAnyObject",
    "domain" : {
      "uid" : "a0bbbc99-adef-4ef8-bb6d-defdefdefdef",
      "name" : "Check Point Data",
      "domain-type" : "data domain"
    }
  } ],
  "custom-fields" : {
    "field-1" : "",
    "field-2" : "",
    "field-3" : ""
  }
}

@checkpoint_api.route('/web_api/delete-access-rule', methods=['POST'])
def delete_access_rule(): 
    data = request.json
    if 'name' in data:
        result = data['name']
    else:
        result = data['uid']
    return {
            "message": f"Rule {data['name'] if 'name' in data else data['uid']} deleted"
        }

@checkpoint_api.route('/web_api/set-access-rule', methods=['POST'])
def set_access_rule():
    return {
        "name": "access-rule-test",
        "uid": "uid",
        "type": "rule",
        "action": {"name":"Drop"},
        "content-direction": "any",
        "destination": 'blocklist',
        "content-negate": False,
        "enabled": True,
        "service": {"name": "any"}
    }

@checkpoint_api.route('/web_api/show-access-rulebase', methods=['POST'])
def show_access_rulebase():
    return {
  "uid" : "aa7b850a-db90-4e5e-91c1-cb21bced1a93",
  "name" : "Network",
  "from" : 1,
  "to" : 1,
  "total" : 1,
  "rulebase" : [ {
    "uid" : "be146170-a996-47c8-acfd-2b7dfb9e6d0f",
    "name" : "Rule1",
    "type" : "access-rule",
    "domain" : {
      "uid" : "41e821a0-3720-11e3-aa6e-0800200c9fde",
      "name" : "SMC User",
      "domain-type" : "domain"
    },
    "enabled" : true,
    "comments" : "",
    "meta-info" : {
      "lock" : "unlocked",
      "validation-state" : "ok",
      "last-modify-time" : {
        "posix" : 1482658663305,
        "iso-8601" : "2016-12-25T11:37+0200"
      },
      "last-modifier" : "aa",
      "creation-time" : {
        "posix" : 1482150758417,
        "iso-8601" : "2016-12-19T14:32+0200"
      },
      "creator" : "aa"
    },
    "install-on" : [ "6c488338-8eec-4103-ad21-cd461ac2c476" ],
    "source" : [ "237a4cbc-7fb6-4d50-872a-4904468271c4" ],
    "source-negate" : false,
    "destination" : [ "97aeb369-9aea-11d5-bd16-0090272ccb30" ],
    "destination-negate" : false,
    "service" : [ "97aeb369-9aea-11d5-bd16-0090272ccb30" ],
    "service-negate" : false,
    "vpn" : [ "97aeb369-9aea-11d5-bd16-0090272ccb30" ],
    "action" : "6c488338-8eec-4103-ad21-cd461ac2c472",
    "action-settings" : {
      "enable-identity-captive-portal" : false
    },
    "content" : [ "97aeb369-9aea-11d5-bd16-0090272ccb30" ],
    "content-negate" : false,
    "content-direction" : "any",
    "track" : "29e53e3d-23bf-48fe-b6b1-d59bd88036f9",
    "track-alert" : "none",
    "time" : [ "97aeb369-9aea-11d5-bd16-0090272ccb30" ],
    "custom-fields" : {
      "field-1" : "",
      "field-2" : "",
      "field-3" : ""
    },
    "rule-number" : 1
  } ],
  "objects-dictionary" : [ {
    "uid" : "6c488338-8eec-4103-ad21-cd461ac2c472",
    "name" : "Accept",
    "type" : "RulebaseAction",
    "domain" : {
      "uid" : "a0bbbc99-adef-4ef8-bb6d-defdefdefdef",
      "name" : "Check Point Data",
      "domain-type" : "data domain"
    }
  }, {
    "uid" : "97aeb369-9aea-11d5-bd16-0090272ccb30",
    "name" : "Any",
    "type" : "CpmiAnyObject",
    "domain" : {
      "uid" : "a0bbbc99-adef-4ef8-bb6d-defdefdefdef",
      "name" : "Check Point Data",
      "domain-type" : "data domain"
    }
  }, {
    "uid" : "237a4cbc-7fb6-4d50-872a-4904468271c4",
    "name" : "ExternalZone",
    "type" : "security-zone",
    "domain" : {
      "uid" : "a0bbbc99-adef-4ef8-bb6d-defdefdefdef",
      "name" : "Check Point Data",
      "domain-type" : "data domain"
    }
  }, {
    "uid" : "29e53e3d-23bf-48fe-b6b1-d59bd88036f9",
    "name" : "None",
    "type" : "Track",
    "domain" : {
      "uid" : "a0bbbc99-adef-4ef8-bb6d-defdefdefdef",
      "name" : "Check Point Data",
      "domain-type" : "data domain"
    }
  }, {
    "uid" : "6c488338-8eec-4103-ad21-cd461ac2c476",
    "name" : "Policy Targets",
    "type" : "Global",
    "domain" : {
      "uid" : "a0bbbc99-adef-4ef8-bb6d-defdefdefdef",
      "name" : "Check Point Data",
      "domain-type" : "data domain"
    }
  } ]
}

