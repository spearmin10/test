'''
This is v3.0.1  
parameters supported except for audit logs and reports. minor fix

Check with Bertrand Le Bail, EMEA Cortex SA for additional information about that XMocky module

'''

from flask import Blueprint, request
import json
import logging
import time
import random
import hashlib
import string

BASE_URL = '/public_api/v1'.strip('/')
INTEGRATION = 'cortexxdr_api'

cortexxdr_api = Blueprint(f'{INTEGRATION}', __name__)
logger = logging.getLogger(__name__)

TIME_FORMAT = "%Y-%m-%dT%H:%M:%S"

class xdrMocky:
	def __init__(self,init=True):
		self.init=init

	def username(self):
		username_list=[{'username':'Xmocky Analyst','email':'xmocky_analyst@xmocky'},{'username':'Xmocky Viewer','email':'xmocky_viewer@xmocky'},{'username':'Xmocky Admin','email':'xmocky_admin@xmocky'}]
		return(random.choice(username_list))

	def localip(self):
		return('192.168.{}.{}'.format(random.randint(1,254),random.randint(1,254)))

	def remoteip(self):
		return('{}.{}.{}.{}'.format(random.randint(11,200),random.randint(1,254),random.randint(1,254),random.randint(1,254)))

	def count(self):
		return(random.randint(1,6))

	def source(self):
		source_list=['Custom CEF Alert','XDR Agent','PAN NGFW','XDR BIOC','XDR Analytics BIOC','XDR Analytics','XDR IOC']
		return(random.choice(source_list))

	def sourceport(self):
		return(random.randint(1024,65535))

	def remoteport(self):
		return(random.randint(10,65535))

	def hostname(self):
		hostname_list=['Xmocky_Office','Xmocky_Home','Xmocky_Host']
		return(random.choice(hostname_list))

	def hash(self,type):
		if type ==256:
			m=hashlib.sha256()
		else:
			m=hashlib.md5()
		seed=self.filename(34)
		m.update(seed.encode())
		return(m.hexdigest())

	def fileverdict(self):
		verdict_list=['BENIGN','MALWARE','UNKNOWN']
		return(random.choice(verdict_list))

	def filename(self,length):
		return(''.join(random.choices(string.ascii_uppercase + string.ascii_lowercase, k=length)))

	def endpoint(self):
		return(''.join(random.choices(string.digits + string.ascii_lowercase, k=32)))

def convert_epoch_to_milli(timestamp):
	if timestamp is None:
		return None
	if 9 < len(str(timestamp)) < 13:
		timestamp = int(timestamp) * 1000
	return int(timestamp)

def convert_datetime_to_epoch(the_time=0):
	if the_time is None:
		return None
	try:
		if isinstance(the_time, datetime):
			return int(the_time.strftime('%s'))
	except Exception as err:
		print(err)
		return 0

def convert_datetime_to_epoch_millis(the_time=0):
	return convert_epoch_to_milli(convert_datetime_to_epoch(the_time=the_time))

def create_incident(since_modification_time,incident_id):
	xdr=xdrMocky()
	vendor_list=['Palo Alto Networks Cortex XDR Agent','Checkpoint FW-1','Fortinet Fortigate','Palo Alto Networks PAN-OS firewall','Checkpoint Sandblast','Custom Produc','Palo Alto Networks Analytics']
	vendor=random.choice(vendor_list)
	alert_count= xdr.count()
	med_alert_count= random.randint(1,alert_count)
	if med_alert_count != alert_count:
		high_alert_count = random.randint(1,alert_count - med_alert_count)
	else:
		high_alert_count = 0
	if high_alert_count+med_alert_count != alert_count:
		low_alert_count=alert_count - high_alert_count - med_alert_count
	else:
		low_alert_count = 0
	user_count = xdr.count()
	host_count = xdr.count()
	incident_description='This XMocky incident is the result of {} alerts coming from {}. Do not pull the alerts, they do not exist'.format(alert_count,vendor)
	manual_severity=random.choice(['medium','high'])
	if high_alert_count >0:
		severity='high'
	else:
		severity='medium'
	if since_modification_time != None:
		since_modification_time=convert_datetime_to_epoch_millis(since_modification_time)
		modification_time=random.randint(since_modification_time+1500,since_modification_time+10000)
		creation_time=since_modification_time - 10000
	else:
		modification_time=None
		creation_time=random.randint(1577276587937,1590656388000)
	user=xdr.username()
	status_list=['NEW', 'UNDER_INVESTIGATION', 'RESOLVED_THREAT_HANDLED', 'RESOLVED_KNOWN_ISSUE', 'RESOLVED_DUPLICATE', 'RESOLVED_False_POSITIVE', 'RESOLVED_OTHER']
	status=random.choice(status_list).lower()
	if status not in ['new','under_investigation']:
		resolve_comment='This incident has been closed by {} using Xmocky'.format(user['username'])
	else:
		resolve_comment=None
	
	incident = {
			"host_count": host_count, 
			"incident_id": incident_id, 
			"manual_severity": manual_severity, 
			"description": incident_description, 
			"severity": severity, 
			"modification_time": modification_time, 
			"assigned_user_pretty_name": user['username'], 
			"notes": 'This incident has been created by Xmocky', 
			"creation_time": creation_time, 
			"alert_count": alert_count, 
			"med_severity_alert_count": med_alert_count, 
			"detection_time": None, 
			"assigned_user_mail": user['email'], 
			"resolve_comment": resolve_comment, 
			"status": status, 
			"user_count": user_count, 
			"xdr_url": "https://xmocky.xdr.url.com/incident-view/{}".format(incident_id), 
			"starred": random.choice([True,False]), 
			"low_severity_alert_count": low_alert_count, 
			"high_severity_alert_count": high_alert_count, 
			"manual_description": 'This description has been added by Xmocky to highlight a manual description',
			"hosts": [
			"xmocky.test.demo:aew10ea9d9740818079b4ff8c7dae79"
			],
			"users": [
				"Xmocky User"
			],
			"incident_sources": [
				"XDR Agent"
			]
		}
	return (incident)

def create_alert(alert_id,detection_timestamp):
	xdr=xdrMocky()
	fw_app_id=None
	action_remote_port=None
	severity_list=['low','medium','high']
	severity=random.choice(severity_list)
	action_local_ip=xdr.localip()
	action_remote_ip=None
	source=xdr.source()
	action_local_port=None
	hostname=None
	category=None
	action=[
		  "VALUE_NA",
		  "N/A"
		]
	action_pretty=[
		  "VALUE_NA",
		  "N/A"
		]
	action_file_md5=None
	action_file_sha256=None
	action_process_image_sha256=None
	detection_timestamp=detection_timestamp+1000*random.randint(1,10)
	user_name=None
	host_ip=None

	if source in ['XDR Agent','XDR BIOC','XDR Analytics BIOC']:
		event_type='Process Execution'
	else:
		event_type='Network Event'

	if event_type =='Network Event':
		action_remote_port=xdr.remoteport()
		action_remote_ip=xdr.remoteip()
		action_local_port=xdr.sourceport()
		if source == 'PAN NGFW':
			fw_app_id=random.choice(['web-browsing','ssl','ssh','custom App-ID','google-base','xmocky'])
	else:
		action_process_image_sha256=xdr.hash(256)
		action_file_sha256=xdr.hash(256)
		action_file_md5=xdr.hash(0)
		hostname=xdr.hostname()
		host_ip=action_local_ip
		if source !='XDR Agent':
			action_local_port=xdr.sourceport()
			action_remote_port=xdr.remoteport()
			action_remote_ip=xdr.remoteip()
		else:
			category='Malware'
			action='BLOCKED'
			action_pretty='Prevented (Blocked)'
		
		user_name=xdr.username()
	alert = {
		"action_process_signature_status": "N/A",
		"action_pretty": action_pretty,
		"event_type": event_type,
		"alert_id": alert_id,
		"action_file_sha256": action_file_sha256,
		"action_external_hostname": None,
		"causality_actor_process_command_line": None,
		"description": "Test - alert generated by Xmocky",
		"category": category,
		"severity": severity,
		"source": source,
		"action_remote_port": action_remote_port,
		"causality_actor_process_signature_status": "N/A",
		"fw_app_id": fw_app_id,
		"is_whitelisted": random.choice(['Yes',"No"]),
		"action_local_ip": action_local_ip,
		"action_registry_data": None,
		"action_process_image_sha256": None,
		"user_name": user_name,
		"action_remote_ip": action_remote_ip,
		"action_process_signature_vendor": "N/A",
		"actor_process_signature_status": "N/A",
		"name": "Test - alert generated by Xmocky",
		"causality_actor_causality_id": None,
		"host_ip": host_ip,
		"action_process_image_name": None,
		"detection_timestamp": detection_timestamp,
		"action_file_md5": action_file_md5,
		"causality_actor_process_image_name": None,
		"action_file_path": None,
		"action_process_image_command_line": None,
		"action_local_port": action_local_port,
		"actor_process_image_name": None,
		"action_registry_full_key": None,
		"actor_process_signature_vendor": "N/A",
		"actor_process_command_line": None,
		"host_name": hostname,
		"action": action,
		"starred": random.choice([True,False]),
		"causality_actor_process_signature_vendor": "N/A"
	  }
	return (alert)

def create_artifact(artifact_type,event_type):
	xdr=xdrMocky()
	if artifact_type=='file':
		if event_type!='Network Event':
			artifact={
			"type": "HASH",
			"alert_count": xdr.count(),
			"is_manual": random.choice(['False','True']),
			"is_malicious": random.choice(['False','True']),
			"is_process": True,
			"file_name": xdr.filename(xdr.count()*2),
			"file_sha256": xdr.hash(256),
			"file_signature_status": "SIGNATURE_UNAVAILABLE",
			"file_signature_vendor_name": None,
			"file_wildfire_verdict": xdr.fileverdict()
			}
		else:
			artifact=None

	elif artifact_type=='network':
		if event_type == 'Network Event':
			artifact={
			"type": "IP",
			"alert_count": xdr.count(),
			"is_manual": random.choice(['False','True']),
			"network_domain": None,
			"network_remote_ip": xdr.remoteip(),
			"network_remote_port": xdr.remoteport(),
			"network_country": None
			}
		else:
			artifact=None
	return (artifact)

def create_endpoint(endpoint_id,dist,ip,group,platform,alias,isolate,hostname,factor):
	xdr=xdrMocky()
	domain=''
	status=random.choice(['CONNECTED','DISCONNECTED'])
	endpoint_type='AGENT_TYPE_SERVER'
	if platform=='windows':
		os_type='AGENT_OS_WINDOWS'
		domain='Xmocky'
		endpoint_type=random.choice(['AGENT_TYPE_SERVER','AGENT_TYPE_WORKSTATION'])
	elif platform=='linux':
		os_type='AGENT_OS_LINUX'
	elif platform=='macos':
		os_type='AGENT_OS_MACOS'
	else:
		os_type='AGENT_OS_ANDROID'
	if isolate=='isolate':
		isolate='AGENT_ISOLATED'
	else:
		isolate='AGENT_UNISOLATED'

	endpoint=	{
			"domain": domain, 
			"users": [
				xdr.username()['username']
			], 
			"endpoint_name": "{}.xmocky.internal".format(hostname), 
			"ip": [
				ip
			], 
			"install_date": 1575795969644+factor*343, 
			"endpoint_version": "7.0.0.1915", 
			"group_name": group, 
			"installation_package": platform, 
			"alias": alias, 
			"active_directory": None, 
			"endpoint_status": status, 
			"os_type": os_type, 
			"endpoint_id": endpoint_id,
			"content_version": "111-17757", 
			"first_seen": 1575795969644+factor*343, 
			"endpoint_type": endpoint_type, 
			"is_isolated": isolate, 
			"last_seen": 1575795969644+4*factor*343
		} 
	return(endpoint)		

@cortexxdr_api.route(f'/{BASE_URL}/test')
def test():
	return {'result': 'it works'}

@cortexxdr_api.route(f'/{BASE_URL}/incidents/get_incidents/',methods=['GET','POST','DELETE'])
def get_incidents_command():
	requested_data = request.json.get('request_data').get('filters')
	lte_creation_time=None
	gte_creation_time=None
	lte_modification_time=None
	gte_modification_time=None
	since_creation_time=None
	since_modification_time=None
	incident_id_list=['4','3','2']
	for entry in requested_data:
		if entry['field']=='lte_creation_time':
			lte_creation_time=entry['value'] 
		elif entry['field']=='gte_creation_time':
			gte_creation_time=entry['value'] 
		elif entry['field']=='lte_modification_time':
			lte_modification_time=entry['value'] 
		elif entry['field']=='since_creation_time':
			since_creation_time=entry['value']
		elif entry['field']=='since_modification_time':
			since_modification_time=entry['value'] 
		elif entry['field']=='incident_id_list':
			incident_id_list=entry['value'] 


	incident_response=[]
	for i in range(0,len(incident_id_list)):
		incident_response.append(create_incident(since_modification_time,incident_id_list[i]))
	res={
	'reply':{"incidents": incident_response
			}
		}
	return(res)

@cortexxdr_api.route(f'/{BASE_URL}/incidents/get_incident_extra_data/',methods=['GET','POST','DELETE'])
def get_incident_extra_data_command():
	alert_list=[]
	file_artifact_list=[]
	network_artifact_list=[]
	incident_id=request.args.get('incident_id')	
	incident=create_incident(None,incident_id)
	alert_count=incident['alert_count']
	alert_idx=random.randint(56,3452)
	for i in range(0,alert_count):
		alert_list.append(create_alert((i+1)*alert_idx*37,incident['creation_time']))
		file_artifact=create_artifact('file',alert_list[i])
		network_artifact=create_artifact('network',alert_list[i])
		if file_artifact != None:
			file_artifact_list.append(file_artifact)
		if network_artifact != None:
			network_artifact_list.append(network_artifact)
	res={'reply':{
	"incident":incident,
	"file_artifacts": {
		'data':file_artifact_list
		},
	"network_artifacts":{
		'data':network_artifact_list
		},
	"alerts": {
	"data":alert_list
		},
	}
	}
	return(res)


@cortexxdr_api.route(f'/{BASE_URL}/incidents/update_incident/',methods=['GET','POST','DELETE'])
def update_incident_command():
	requested_data = request.json.get('request_data')

	incident_id=requested_data['incident_id']	
	requested_data=requested_data['update_data']

	status=requested_data.get('status', 'NEW')
	severity=requested_data.get('manual_severity', 'MEDIUM')
	user_email=requested_data.get('assigned_user_mail', 'xmocky@Cortex-SA-Group')
	user=requested_data.get('assigned_user_pretty_name', 'XMocky')
	resolve_comment=requested_data.get('resolve_comment', 'XMocky has been closing this')
	
	res={'reply':
		{
			"incident_id": incident_id, 
			"manual_severity": severity, 
			"description": "5 'This alert from content  TestXDRPlaybook' alerts detected by Checkpoint - SandBlast  ", 
			"severity": "medium", 
			"assigned_user_pretty_name": user, 
			"assigned_user_mail": user_email, 
			"resolve_comment": resolve_comment, 
			"status": status, 
			"manual_description": None
		}
		} 
	return(res)

@cortexxdr_api.route(f'/{BASE_URL}/endpoints/get_endpoints/',methods=['GET','POST','DELETE'])
def get_endpoints_command():
	xdr=xdrMocky()
	endpoint_count=xdr.count()
	endpoint_list=[]
	for i in range(1,2*endpoint_count):
		endpoint_id=xdr.endpoint()
		dist=''
		ip=xdr.localip()
		group=random.choice(['Xmocky','','Xmocky_Grp'])
		platform=random.choice(['windows','linux','macos','android'])
		alias=''
		hostname=xdr.hostname()
		isolate=random.choice(['isolate','unisolate'])
		endpoint_list.append(create_endpoint(endpoint_id,dist,ip,group,platform,alias,isolate,hostname,i))
	res={'reply':endpoint_list
			}
	return(res)	

@cortexxdr_api.route(f'/{BASE_URL}/endpoints/get_endpoint/',methods=['GET','POST','DELETE'])
def get_endpoint():
	xdr=xdrMocky()
	requested_data = request.json.get('request_data').get('filters')
	endpoint_count=xdr.count()
	endpoint_list=[]
	for i in range(1,endpoint_count):
		endpoint_id=xdr.endpoint()
		dist=''
		ip=xdr.localip()
		group=''
		platform='windows'
		alias=''
		hostname=xdr.hostname()
		isolate=random.choice(['isolate','unisolate'])
		for entry in requested_data:
			if entry['field']=='endpoint_id_list':
				endpoint_id=random.choice(entry['value'])	
			if entry['field']=='dist_name':
				dist=random.choice(entry['value'])
			if entry['field']=='ip_list':
				ip=random.choice(entry['value'])
			if entry['field']=='group_name':
				group=random.choice(entry['value'])
			if entry['field']=='platform':
				platform=random.choice(entry['value'])
			if entry['field']=='alias_name':
				alias=random.choice(entry['value'])
			if entry['field']=='isolate':
				isolate=entry['value']
			if entry['field']=='hostname':
				hostname=random.choice('hostname')
			endpoint_list.append(create_endpoint(endpoint_id,dist,ip,group,platform,alias,isolate,hostname,i))

	res={'reply':{'endpoints':endpoint_list	
				}
			}

	return(res)	


@cortexxdr_api.route(f'/{BASE_URL}/alerts/insert_parsed_alerts/',methods=['GET','POST','DELETE'])
def insert_parsed_alert_command():
	return({},None,None)

@cortexxdr_api.route(f'/{BASE_URL}/alerts/insert_cef_alerts/',methods=['GET','POST','DELETE'])
def insert_cef_alerts_command():
	return({},None,None)

@cortexxdr_api.route(f'/{BASE_URL}/endpoints/isolate',methods=['GET','POST','DELETE'])
def isolate_endpoint_command():	
	return(get_endpoints_command())

@cortexxdr_api.route(f'/{BASE_URL}/endpoints/unisolate',methods=['GET','POST','DELETE'])
def unisolate_endpoint_command():
	return(get_endpoints_command())

@cortexxdr_api.route(f'/{BASE_URL}/distributions/get_dist_url/',methods=['GET','POST','DELETE'])
def get_distribution_url_command():
	res={'reply':{'distribution_url':'https//xmocky/distribution_url.xmocky'}}
	return(res)

@cortexxdr_api.route(f'/{BASE_URL}/distributions/get_status/',methods=['GET','POST','DELETE'])
def get_distribution_status_command():
	res={'reply':{'status':'Xmocky is pleased you asked and everything is fine'}}
	return(res)

@cortexxdr_api.route(f'/{BASE_URL}/distributions/get_versions/',methods=['GET','POST','DELETE'])
def get_distribution_versions_command():
	res={
	"reply": {
		"windows": [
			"5.0.8.29673", 
			"5.0.9.30963", 
			"6.1.4.28751", 
			"7.0.0.28644"
		], 
		"macos": [
			"6.1.4.1681", 
			"7.0.0.1914"
		], 
		"linux": [
			"6.1.4.1680", 
			"7.0.0.1916"
		]
	}
}
	return(res)

@cortexxdr_api.route(f'/{BASE_URL}/distributions/create/',methods=['GET','POST','DELETE'])
def create_distribution_command():
	xdr=Xmoxky()
	distribution_id=xdr.endpoint()
	name=request.args.get('name')
	platform=request.args.get('platform')
	package_type=request.args.get('package_type')
	agent_version=request.args.get('agent_version')
	description=request.args.get('description') if request.args.get('description') else 'XMocky added a nice comment here'
	res={
	"reply": {
		'distribution_id':distribution_id,
		"description": description, 
		"package_type": package_type, 
		"platform": platform, 
		"agent_version": agent_version, 
		"id": distribution_id, 
		"name": name
	}
}
	return(res)

@cortexxdr_api.route(f'/{BASE_URL}/audits/management_logs/',methods=['GET','POST','DELETE'])
def get_audit_management_logs_command():
	res={
	'reply':{'data':[
	{
			"AUDIT_OWNER_EMAIL": "", 
			"AUDIT_SESSION_ID": None, 
			"AUDIT_ID": 217, 
			"AUDIT_REASON": None, 
			"AUDIT_CASE_ID": None, 
			"AUDIT_DESCRIPTION": "Created a Linux Standalone installer installation package 'dist_1' with agent version 6.1.4.1680", 
			"AUDIT_INSERT_TIME": 1579287926547, 
			"AUDIT_ENTITY": "DISTRIBUTIONS", 
			"AUDIT_OWNER_NAME": "Public API - 1", 
			"AUDIT_ASSET_JSON": "{}", 
			"AUDIT_RESULT": "SUCCESS", 
			"AUDIT_ASSET_NAMES": "", 
			"AUDIT_HOSTNAME": None, 
			"AUDIT_ENTITY_SUBTYPE": "Create"
		}, 
		{
			"AUDIT_OWNER_EMAIL": "", 
			"AUDIT_SESSION_ID": None, 
			"AUDIT_ID": 214, 
			"AUDIT_REASON": None, 
			"AUDIT_CASE_ID": None, 
			"AUDIT_DESCRIPTION": "Created a Linux Standalone installer installation package 'ddd' with agent version 6.1.4.1680", 
			"AUDIT_INSERT_TIME": 1579121478199, 
			"AUDIT_ENTITY": "DISTRIBUTIONS", 
			"AUDIT_OWNER_NAME": "Public API - 1", 
			"AUDIT_ASSET_JSON": "{}", 
			"AUDIT_RESULT": "SUCCESS", 
			"AUDIT_ASSET_NAMES": "", 
			"AUDIT_HOSTNAME": None, 
			"AUDIT_ENTITY_SUBTYPE": "Create"
		}]}
	}
	return(res)

@cortexxdr_api.route(f'/{BASE_URL}/audits/agents_reports/',methods=['GET','POST','DELETE'])
def get_audit_agent_reports_command():
	res={
	"reply":{"data": [
		{
			"CATEGORY": "Audit", 
			"DOMAIN": "", 
			"DESCRIPTION": "XDR Agent policy updated on aaaaa.compute.internal", 
			"TIMESTAMP": 1579284369143.7048, 
			"RECEIVEDTIME": 1579286565904.3281, 
			"REASON": None, 
			"SUBTYPE": "Policy Update", 
			"ENDPOINTNAME": "aaaaa.compute.internal", 
			"RESULT": "Success", 
			"ENDPOINTID": "ea303670c76e4ad09600c8b346f7c804", 
			"TRAPSVERSION": "7.0.0.1915", 
			"TYPE": "Policy"
		}, 
		{
			"CATEGORY": "Audit", 
			"DOMAIN": "", 
			"DESCRIPTION": "XDR Agent policy updated on aaaaa.compute.internal", 
			"TIMESTAMP": 1579280769141.43, 
			"RECEIVEDTIME": 1579282965742.36, 
			"REASON": None, 
			"SUBTYPE": "Policy Update", 
			"ENDPOINTNAME": "aaaaa.compute.internal", 
			"RESULT": "Success", 
			"ENDPOINTID": "ea303670c76e4ad09600c8b346f7c804", 
			"TRAPSVERSION": "7.0.0.1915", 
			"TYPE": "Policy"
		}
	]}
}
	return(res)

def fetch_incidents():
	return( get_incidents())
