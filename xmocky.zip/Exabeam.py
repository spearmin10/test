from flask import Blueprint, request
import json
import logging
from datetime import datetime

mock_assset = {
    "asset": {
        "assetType": "Windows",
        "firstSeen": "1588845612000",
        "hostName": "",
        "ipAddress": "10.14.10.128",
        "labels": "Windows",
        "lastSeen": "1588845612000"
    }
}
mock_user_count = 2
mock_notables = {
    "users": [
        {
            "user": {
                "department": "IT",
                "firstSeen": 1588845612000,
                "highestRiskSession": {
                    "accounts": ["account_name"],
                    "endTime": 1535991695000,
                    "initialRiskScore": 9,
                    "label": "",
                    "loginHost": "login_host",
                    "numOfAccounts": 1,
                    "numOfAssets": 5,
                    "numOfEvents": 6,
                    "numOfReasons": 9,
                    "numOfSecurityEvents": 0,
                    "numOfZones": 0,
                    "riskScore": 265,
                    "sessionId": "session_id",
                    "startTime": 1535973498000,
                    "username": "username",
                    "zones": []
                },
                "labels": ["privileged_user"],
                "lastActivityType": "Account is active",
                "lastSeen": 1588845612000,
                "notableSessionIds": ["9872345hsdufgIUG986"],
                "notableUser": True,
                "userFullName": "Joe Bloggs",
                "userName": "joe.bloggs"
            },
            "info": {
                "riskScore": 2.56,
                "location": "Atlanta",
                "employeeType": "employee",
                "title": "Network Engineer",
            }
        },
        {
            "user": {
                "department": "Sales",
                "firstSeen": 1588845612000,
                "highestRiskSession": {
                    "accounts": ["account_name"],
                    "endTime": 1535991695000,
                    "initialRiskScore": 9,
                    "label": "",
                    "loginHost": "login_host",
                    "numOfAccounts": 1,
                    "numOfAssets": 5,
                    "numOfEvents": 6,
                    "numOfReasons": 9,
                    "numOfSecurityEvents": 0,
                    "numOfZones": 0,
                    "riskScore": 265,
                    "sessionId": "session_id",
                    "startTime": 1535973498000,
                    "username": "username",
                    "zones": []
                },
                "labels": ["standard_user"],
                "lastActivityType": "Account is active",
                "lastSeen": 1588845612000,
                "notableSessionIds": ["aa76525hasdfgIUG986"],
                "notableUser": True,
                "userFullName": "Jill Bloggs",
                "userName": "jill.bloggs"
            },
            "info": {
                "riskScore": 7.89,
                "location": "California",
                "employeeType": "employee",
                "title": "Regional Sales Director",
            }
        }
    ]
}
mock_peer_groups = ["Marketing",
"usa",
"101",
"Program Manager",
"Channel Administrator",
"Chief Marketing Officer",
"Chief Strategy Officer",
"CN=Andrew Bautista,OU=Users,OU=Ktenergy,DC=ktenergy,DC=local",
"BitLockerUsersComputers",
"trinet",
"Admin Operations",
"118",
"Corp",
"102",
"CN=Emery Santiago,OU=Users,OU=Ktenergy,DC=ktenergy,DC=local",
"105",
"Computer Scientist",
"Electrical Engineer",
"VP Business Development",
"Hardware Engineer",
"Executive Assistant",
"GenCouncil",
"Consulting",
"109",
"Legal Secretary",
"VP Operations",
"106",
"Washington",
"Operations Director",
"Process Engineer",
"104",
"Account Manager",
"Shop Floor Supervisor",
"IT Operations",
"VP Marketing",
"HR",
"design,milling",
"superUsers",
"WIFI IL",
"ProgramMgmt",
"Engagement Manager",
"InfoSec",
"Sales Operations",
"Security Systems Engineer",
"design",
"CN=Tracee Weber,OU=Users,OU=Ktenergy,DC=ktenergy,DC=local",
"sap",
"CN=May Mcconnell,OU=Users,OU=Ktenergy,DC=ktenergy,DC=local",
"jobvite",
"Sales",
"partners",
"CN=Emely Blanchard,OU=Users,OU=Ktenergy,DC=ktenergy,DC=local",
"Corporate Marketing Strategist",
"Web Developer",
"Domain Admins",
"VP Information Systems",
"CN=Raelene Thompson,OU=Users,OU=Ktenergy,DC=ktenergy,DC=local",
"VP Engineering",
"Marketing Coordinator",
"VP Sales",
"103",
"Product Manager",
"Welder",
"milling",
"VP Human Resources",
"Partner Corrdinator",
"execs",
"117",
"Engineering",
"Seattle",
"107",
"Program Director",
"Chief Council",
"Machinist",
"Software Developer",
"Office365-Users",
"CN=Harris Oliver,OU=Users,OU=Ktenergy,DC=ktenergy,DC=local",
"CN=Tu Petersen,OU=Users,OU=Ktenergy,DC=ktenergy,DC=local",
"ITServiceUsersDomainAdmins",
"root",
"IT",
"Atlanta",
"autocad",
"Building Engineer",
"Dallas",
"Security Security Coordinator",
"salesforce",
"Software Engineer",
"110",
"Saless",
"CN=Marianne Hughes,OU=Users,OU=Ktenergy,DC=ktenergy,DC=local",
"Civil Engineer",
"CN=Vince Andrade,OU=Users,OU=Ktenergy,DC=ktenergy,DC=local",
"Security Analyst",
"Sales Representative",
"Operations",
"Jobvite-users",
"Chicago",
"Los Angeles",
"New York",
"councilApp",
"VP Information Security",
"Direct Support",
"MA/DCG",
"orch_admins",
"Chief Operating Officer",
"ITInfraAdmins",
"Manager, IT Corporate Services",
"VP Council",
"CN=Felipe Pennington,OU=Users,OU=Ktenergy,DC=ktenergy,DC=local",
"CN=May Mcconnell,OU=US,OU=Users,OU=Ktenergy,DC=ktenergy,DC=local",
"Public Relations Officer",
"Human Resources Coordinator",
"Chief Information Secuity Officer",
"Marketing Strategist",
"Front Desk Receptionist",
"CEO",
"IT Administrator",
"Sales Coordinator",
"Network Engineer",
"108"]
mock_user = {
    "username": "",
    "accountNames": "",
    "peerGroupDisplayName": "Channel Administrator",
    "peerGroupType": "Custom",
    "peerGroupFieldName": "GroupName",
    "peerGroupFieldValue": "Channel Administrator",
    "userInfo": {
        "averageRiskScore": 7.9,
        "department": "IT",
        "firstSeen": 1588845612000,
        "highestRiskSession": {
            "accounts": ["account_name"],
            "endTime": 1535991695000,
            "initialRiskScore": 9,
            "label": "",
            "loginHost": "login_host",
            "numOfAccounts": 1,
            "numOfAssets": 5,
            "numOfEvents": 6,
            "numOfReasons": 9,
            "numOfSecurityEvents": 0,
            "numOfZones": 0,
            "riskScore": 265,
            "sessionId": "session_id",
            "startTime": 1535973498000,
            "username": "username",
            "zones": []
        },
        "labels": ["privileged_user"],
        "lastActivityType": "Account is active",
        "lastSeen": 1588845612000,
        "notableSessionIds": ["9872345hsdufgIUG986"],
        "notableUser": True,
        "riskScore": 8.98,
        "userFullName": "",
    }
}
mock_user_labels = [
    "privileged_user",
    "service_account",
    "standard_account"
]
mock_user_sessions = {
    "sessions": [
        {
            "endTime": 2,
            "initialRiskScore": 6,
            "label": "Email",
            "loginHost": "",
            "riskScore": 7.8,
            "sessionId": "fjdt87dgiug8asd",
            "startTime": 1
        },
        {
            "endTime": 2,
            "initialRiskScore": 8,
            "label": "vpn-in",
            "loginHost": "",
            "riskScore": 6.2,
            "sessionId": "875w3asdiug8976",
            "startTime": 1
        },
    ],
    "Username": "username"
}
mock_watchlists = [
        {
            "category": "UserLabels",
            "title": "Executive Users",
            "watchlistId": "5c869ab0315c745d905a26d9"
        },
        {
            "category": "UserLabels",
            "title": "Service Accounts",
            "watchlistId": "5c869ab0315c745d905a26da"
        },
        {
            "category": "Users",
            "title": "user watchlist",
            "watchlistId": "5dbaba2dd4e62a0009dd7ae4"
        },
        {
            "category": "PeerGroups",
            "title": "VP Operations",
            "watchlistId": "5d8751723b72ea000830066a"
        }
    ]

BASE_URL = ''.strip('/')
INTEGRATION = 'exabeam_api'
exabeam_api = Blueprint(f'{INTEGRATION}', __name__)
logger = logging.getLogger(__name__)

@exabeam_api.route(f'/{BASE_URL}/api/auth/login', methods=['GET', 'POST'])
def auth():
    method = request.method
    if method == 'POST':
        return json.dumps({"result": "ok"})
    else:
        return json.dumps({"result": "ok"})


@exabeam_api.route(f'/{BASE_URL}/uba/api/ping', methods=['GET'])
def ping():
    method = request.method
    return json.dumps({"result": "ok"})


@exabeam_api.route(f'/{BASE_URL}/uba/api/watchlist/<watchid>/', methods=['GET', 'DELETE'])
def watchlist(watchid):
    method = request.method
    if method == 'DELETE':
        return json.dumps({})
    else:
        return json.dumps({})


@exabeam_api.route(f'/{BASE_URL}/uba/api/asset/<asset_name>/data', methods=['GET'])
def get_asset(asset_name):
    method = request.method
    now = datetime.now()
    if method == 'GET':
        asset = mock_assset
        asset['asset']['hostName'] = asset_name
        asset['asset']['lastSeen'] = str(int(now.timestamp()) * 1000)
        return json.dumps(asset)
    else:
        return json.dumps({})


@exabeam_api.route(f'/{BASE_URL}/uba/api/users/notable', methods=['GET'])
def get_notables():
    now = datetime.now()
    method = request.method
    limit = int(request.args.get('numberOfResults'))
    limit = mock_user_count if limit > mock_user_count or limit == 0 else limit
    now = datetime.now()
    if method == 'GET':
        notables = mock_notables
        for item in notables['users']:
            item['user']['lastSeen'] = int(now.timestamp() * 1000)
        if limit and limit < mock_user_count:
            notables['users'] = notables['users'][0:limit]

        return json.dumps(notables)
    else:
        return json.dumps({})


@exabeam_api.route(f'/{BASE_URL}/uba/api/peerGroup', methods=['GET'])
def get_peergroups():
    method = request.method
    if method == 'GET':
        return json.dumps(mock_peer_groups)
    else:
        return json.dumps({})


@exabeam_api.route(f'/{BASE_URL}/uba/api/user/<username>/info', methods=['GET'])
def get_user(username):
    method = request.method
    if method == 'GET':
        user = mock_user
        user['username'] = user['userFullName'] = username
        return json.dumps(user)
    else:
        return json.dumps({})


@exabeam_api.route(f'/{BASE_URL}/uba/api/userLabel', methods=['GET'])
def get_user_labels():
    method = request.method
    if method == 'GET':
        return json.dumps(mock_user_labels)
    else:
        return json.dumps({})


@exabeam_api.route(f'/{BASE_URL}/uba/api/user/<username>/sequences', methods=['GET'])
def get_user_sessions(username):
    method = request.method
    start_time = int(request.args.get('startTime'))
    end_time = int(request.args.get('endTime'))
    if method == 'GET':
        sessions = mock_user_sessions
        for session in sessions['sessions']:
            session['startTime'] = start_time + 520000
            session['endTime'] = end_time - 5200000
            session['loginHost'] = username
        return json.dumps(sessions)
    else:
        return json.dumps({})


@exabeam_api.route(f'/{BASE_URL}/uba/api/watchlist', methods=['GET'])
def get_watchlists():
    method = request.method
    if method == 'GET':
        return json.dumps(mock_watchlists)
    else:
        return json.dumps({})