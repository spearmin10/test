import requests

true = True
false = False
null = None

remote_url = "https://xmocky.demisto.works:3000/test"
local_url = "https://localhost:3000/test"

headers = {
    "Authorization": "AF27B0D2370998DC74E1EE9519DEEA11",
    "Content-Type": "application/json",
}

# xmocky = "https://192.168.1.9:3000"
# url = "https://192.168.1.13/settings/integration/test"

# def test_remote():
#     headers = {"User-Agent": "Go-http-client/1.1"}
#     res = requests.get(remote_url, verify=False, headers=headers)
#     assert "it works" in res.json().get("result")


def test_local():
    headers = {"User-Agent": "Go-http-client/1.1"}
    res = requests.get(local_url, verify=False, headers=headers)
    assert "it works" in res.json().get("result")


# def prepare_data(brand, id=None, server="server", secure="insecure", new_data=None):
#     content = {
#         "data": [
#             {"name": server, "value": xmocky},
#             {
#                 "name": "credentials",
#                 "value": {"credential": "", "credentials": {}},
#                 "type": 9,
#             },
#             {"name": secure, "value": true},
#         ],
#         "brand": brand,
#         "isIntegrationScript": True,
#     }
#     if id:
#         content["id"] = id
#     if new_data:
#         for entry in new_data:
#             content["data"].append(entry)
#     return content


# def http_request(data):
#     res = requests.post(url, headers=headers, json=data, verify=False)
#     result = res.json()
#     return result.get("success")


# def is_up(data):
#     return http_request(data)


# def test_arcsight():
#     data = prepare_data("ArcSight ESM v2")
#     result = is_up(data)
#     assert result is True


# def test_hx():
#     data = prepare_data("FireEye HX")
#     result = is_up(data)
#     assert result is True


# def test_fortisiem():
#     data = prepare_data("FortiSIEM", server="host", secure="unsecure")
#     result = is_up(data)
#     assert result is True


# def test_qradar():
#     new_data = [
#         {"name": "server", "value": "https://192.168.1.5:3000"},
#         {"name": "credentials", "value": {"credential": "", "credentials": {}}},
#         {"name": "token", "value": ""},
#         {"name": "insecure", "value": true},
#         {"name": "proxy", "value": false},
#     ]
#     data = prepare_data(
#         "QRadar", id="9a53ce15-074b-4ed4-8841-7627b6bbd68a", new_data=new_data
#     )
#     print(data)
#     result = is_up(data)
#     assert result is True


# def test_logrhythm():
#     new_data = [
#         {
#             "name": "Credentials",
#             "value": {"credential": "", "credentials": {}},
#             "type": 9,
#         }
#     ]
#     data = prepare_data(
#         "LogRhythm", server="Host", secure="Insecure", new_data=new_data
#     )
#     result = is_up(data)
#     assert result is True


# def test_logrhythmrest():
#     new_data = [
#         {
#             "name": "Credentials",
#             "value": {"credential": "", "credentials": {}},
#             "type": 9,
#         },
#         {"name": "token", "value": ""},
#     ]
#     data = prepare_data(
#         "LogRhythm", server="Host", secure="Insecure", new_data=new_data
#     )
#     result = is_up(data)
#     assert result is True


# def test_mcafeeesm():
#     new_data = [
#         {"name": "ip", "value": "192.168.1.5"},
#         {"name": "port", "value": "3000"},
#         {
#             "name": "credentials",
#             "value": {"credential": "", "credentials": {}},
#             "type": 9,
#         },
#         {"name": "insecure", "value": True},
#     ]
#     data = prepare_data("McAfee ESM-v10", new_data=new_data)
#     result = is_up(data)
#     assert result is True


# def test_msftgraphsec():
#     data = prepare_data("Microsoft Graph Security Xmocky", server="host")
#     result = is_up(data)
#     assert result is True


# def test_rsanetwpacketslogs():
#     new_data = [
#         {"name": "port", "value": "/rsa"},
#         {"name": "password", "value": ""},
#         {"name": "secure", "value": false},
#         {"name": "token", "value": ""},
#         {"name": "insecure"},
#     ]
#     data = prepare_data(
#         "RSA NetWitness Packets and Logs", server="url", new_data=new_data,
#     )
#     result = is_up(data)
#     assert result is True


# def test_rsanetwitness():
#     new_data = [{"name": "isFetch", "value": false}]
#     data = prepare_data("RSA NetWitness v11.1", new_data=new_data)
#     result = is_up(data)
#     assert result is True
