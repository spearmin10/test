from flask import Blueprint, request

backstory_api = Blueprint('backstory_api', __name__)

# Set to True for the integration to fetch incidents
FETCH = True

@backstory_api.route('/backstory/v1/artifact/listiocdetails')
def ip_domain_command():
  ip = request.args.get('artifact.destination_ip_address')
  domain = request.args.get('artifact.domain_name')
  return {
      "sources": [
        {
          "addresses": [
            {
              "ipAddress": ip,
              "domain": domain,
              "port": "80"
            }
          ],
          "category": "Known CnC for Mobile specific Family",
          "confidenceScore": {
            "strRawConfidenceScore": "70",
          },
          "firstActiveTime": "2018-12-05T00:00:00Z",
          "lastActiveTime": "2019-04-10T00:00:00Z",
          "rawSeverity": "High"
        },
        {
          "addresses": [
            {
              "ipAddress": ip,
              "domain": domain,
              "port": "80"
            }
          ],
          "category": "Known CnC for Android Family",
          "confidenceScore": {
            "strRawConfidenceScore": "90",
          },
          "firstActiveTime": "2018-12-05T00:00:00Z",
          "lastActiveTime": "2019-04-10T00:00:00Z",
          "rawSeverity": "High"
        }
      ]
    }

@backstory_api.route('/backstory/v1/ioc/listiocs')
def get_ioc_list():
  return {
  "response": {
    "matches": [
                {
                "artifact": {
                  "domainName": "test.com"
                },
                "sources": [
                              {
                                "source": "3rd Party",
                                "confidenceScore": {
                                  "normalizedConfidenceScore": "Low",
                                  "intRawConfidenceScore": 0
                                },
                                "rawSeverity": "Low",
                                "category": "Not Known"
                              },
                              {
                                "source": "3rd Party",
                                "confidenceScore": {
                                  "normalizedConfidenceScore": "Low",
                                  "intRawConfidenceScore": 0
                                },
                                "rawSeverity": "Low",
                                "category": "Not Known"
                              }
                            ],
                "iocIngestTime": "2019-03-31T18:00:00Z",
                "firstSeenTime": "2020-01-20T12:10:26Z",
                "lastSeenTime": "2020-03-21T12:10:26Z"
                },
                    {
                  "artifact": {
                    "domainName": "secondtest.com"
                  },
                  "sources": [
                                {
                                  "source": "3rd Party",
                                  "confidenceScore": {
                                    "normalizedConfidenceScore": "Low",
                                    "intRawConfidenceScore": 0
                                  },
                                  "rawSeverity": "Low",
                                  "category": "Not Known"
                                }
                            ],
                  "iocIngestTime": "2019-03-30T18:00:00Z",
                  "firstSeenTime": "2020-01-21T12:10:26Z",
                  "lastSeenTime": "2020-01-21T12:10:26Z"
                  }
                ]
            }
        }

@backstory_api.route('/backstory/v1/alert/listalerts')
def get_alerts():
  # fetch = False
  if not FETCH:
    return {"nothing": "to return"}
  return {
        "alerts": [
          {
            "asset": {
              "hostname": "svetla"
            },
            "alertInfos": [
              {
                "name": "Command Shell Launched by Office Applications",
                "sourceProduct": "Tanium",
                "severity": "Medium",
                "timestamp": "2019-08-12T20:25:57Z"
              },
              {
                "name": "Suspicious PowerShell Process Ancestry",
                "sourceProduct": "Tanium",
                "severity": "Unspecified",
                "timestamp": "2019-08-12T20:24:31Z"
              },
              {
                "name": "Suspicious PowerShell Process Ancestry",
                "sourceProduct": "Tanium",
                "severity": "Unspecified",
                "timestamp": "2019-08-12T21:24:31Z"
              }
            ]
          },
          {
            "asset": {
              "hostname": "dc12"
            },
            "alertInfos": [
              {
                "name": "Possible Bitsadmin Exfiltration",
                "sourceProduct": "Tanium",
                "severity": "Unspecified",
                "timestamp": "2019-12-30T18:49:33.923249Z"
              },
              {
                "name": "Possible Bitsadmin Exfiltration",
                "sourceProduct": "Tanium",
                "severity": "Unspecified",
                "timestamp": "2020-01-16T18:49:33.923249Z"
              },
              {
                "name": "Possible Bitsadmin Exfiltration",
                "sourceProduct": "Tanium",
                "severity": "Unspecified",
                "timestamp": "2020-02-16T18:49:33Z",
              },
              {
                "name": "Suspicious PowerShell Process Ancestry",
                "sourceProduct": "Tanium",
                "severity": "Unspecified",
                "timestamp": "2019-08-12T21:24:31Z"
              }
            ]
          }
        ]
      }

@backstory_api.route('/backstory/v1/artifact/listassets')
def get_assets():
  ioc = request.args.get('artifact.destination_ip_address')
  return {
          "assets": [
              {
                "asset": {
                  "assetIpAddress": "10.0.9.117"
                },
                "firstSeenArtifactInfo": {
                  "artifactIndicator": {
                    "domainName": "www.google.com"
                  },
                  "seenTime": "2020-01-22T07:08:39.930255Z"
                },
                "lastSeenArtifactInfo": {
                  "artifactIndicator": {
                    "domainName": "www.google.com"
                  },
                  "seenTime": "2020-01-24T07:51:25.083668Z"
                }
              },
              {
                "asset": { "unknownIdentifier":  "Unknown Identifier"},
                "firstSeenArtifactInfo": {
                  "artifactIndicator": {
                    "domainName": "www.google.com"
                  },
                  "seenTime": "2020-01-22T07:08:39.930255Z"
                },
                "lastSeenArtifactInfo": {
                  "artifactIndicator": {
                    "domainName": "www.google.com"
                  },
                  "seenTime": "2020-01-24T07:51:25.083668Z"
                }
              },
              {
                "firstSeenArtifactInfo": {
                  "artifactIndicator": {
                    "domainName": "www.google.com"
                  },
                  "seenTime": "2020-01-22T07:08:39.930255Z"
                },
                "lastSeenArtifactInfo": {
                  "artifactIndicator": {
                    "domainName": "www.google.com"
                  },
                  "seenTime": "2020-01-24T07:51:25.083668Z"
                }
              },
              {
                "asset": {
                  "assetIpAddress": "10.0.9.117"
                },
                "lastSeenArtifactInfo": {
                  "artifactIndicator": {
                    "domainName": "www.google.com"
                  }
                }
              },
              {
                "asset": {
                  "assetMACAddress": "00:1B:44:11:3A:B7"
                },
                "firstSeenArtifactInfo": {
                  "artifactIndicator": {
                    "domainName": "www.google.com"
                  },
                  "seenTime": "2020-01-12T07:08:39.930255Z"
                },
                "lastSeenArtifactInfo": {
                  "artifactIndicator": {
                    "domainName": "www.google.com"
                  },
                  "seenTime": "2020-01-14T07:51:25.083668Z"
                }
              },
              {
                "asset": {
                  "product_id": "B17"
                },
                "firstSeenArtifactInfo": {
                  "artifactIndicator": {
                    "domainName": "www.google.com"
                  },
                  "seenTime": "2020-01-10T07:08:39.930255Z"
                },
                "lastSeenArtifactInfo": {
                  "artifactIndicator": {
                    "domainName": "www.google.com"
                  },
                  "seenTime": "2020-01-11T07:51:25.083668Z"
                  }
                }
            ]
        }
        