from flask import Blueprint, request, Response, make_response
import random
import string
import datetime
import base64

csfalcon_api = Blueprint('csfalcon', __name__)

ACCESS_TOKEN = 'CS_MOCK_TOKEN'
USER_ID = '18d0b7381ca077e5f1083b1a957207d4'
TRACE_ID = '07kk11c3-496g-42df-9157-834e499e279d'
HOST_ID = '284771ee197e422d5176d6634a62b934'
DEVICE_ID = HOST_ID
HOST_NAME = 'XSJOHNDOE'
USER_NAME = 'jdoe'
CUSTOMER_ID = 'f84ff1aa387e466d71a6d9936a12bb33'
BEHAVIOR_ID = '5728'
BATCH_ID = '14ee0d51-f477-3621-adea-b0e886144bb2'
SESSION_ID = '1113b475-2c28-4486-8617-d000b8f3bc8d'
TASK_ID = 'e579eee6-ce7a-487c-8fef-439ebc9c3bc0'
CLOUD_REQUEST_ID = 'b5c8f140-280b-43fd-8501-9900f837510b'
BATCH_GET_CMD_REQ_ID = '84ee4d50-f499-482e-bac6-b0e296149bbf'


def random_hex(n):
  return ''.join(random.choices(string.hexdigits, k=n)).lower()


def now_isoformat():
  return datetime.datetime.utcnow().isoformat() + 'Z'


def get_device_info():
  iso_now = now_isoformat()
  
  return {
    "agent_load_flags": "1",
    "agent_local_time": iso_now,
    "agent_version": "5.19.10102.0",
    "bios_manufacturer": "VMware, Inc.",
    "bios_version": "VMW71.00V.12343141.B64.1902160724",
    "cid": CUSTOMER_ID,
    "config_id_base": "65994753",
    "config_id_build": "10102",
    "config_id_platform": "3",
    "device_id": DEVICE_ID,
    "external_ip": "111.234.5.66",
    "first_seen": "2019-10-18T05:56:29Z",
    "hostname": HOST_NAME,
    "last_seen": iso_now,
    "local_ip": "192.168.7.66",
    "mac_address": "00-11-22-33-44-55",
    "major_version": "10",
    "minor_version": "0",
    "modified_timestamp": iso_now,
    "os_version": "Windows 10",
    "platform_id": "0",
    "platform_name": "Windows",
    "product_type": "1",
    "product_type_desc": "Workstation",
    "status": "normal",
    "system_manufacturer": "VMware, Inc.",
    "system_product_name": "VMware7,1"
  }


def gen_detection_behaviors():
  behaviors_list = [
    [
      {
        "alleged_filetype": "exe",
        "behavior_id": BEHAVIOR_ID,
        "cmdline": f"\"C:\\Users\\{USER_NAME}\\Downloads\\DriverUpdate-setup-aca8173b-cf14-4484-9bb2-eb8012434fe1.exe\" ",
        "confidence": 100,
        "control_graph_id": "ctg:3ccdffe165ee488365a2da431eaaa8d5:8593094679",
        "device_id": DEVICE_ID,
        "filename": "scpD82.tmp.exe",
        "ioc_description": f"\\??\\C:\\Users\\{USER_NAME}\\AppData\\Local\\Temp\\scpD82.tmp.exe",
        "ioc_source": "library_load",
        "ioc_type": "hash_sha256",
        "ioc_value": "e0fa487db23be0a4d33076cab697e2bad2bdf3268e17754a1bd288cc90fd6046",
        "md5": "6221fc3919884e263033a8844eb76f44",
        "objective": "Falcon Detection Method",
        "parent_details": {
          "parent_cmdline": f"\"C:\\Users\\{USER_NAME}\\Downloads\\DriverUpdate-setup-aca8173b-cf14-4484-9bb2-eb8012434fe1.exe\" ",
          "parent_md5": "29b2146324ffb2260d6b3c81a945bc77",
          "parent_process_graph_id": "pid:3ccdffe165ee488365a2da431eaaa8d5:9185153754",
          "parent_sha256": "35c3408395039bb9f73a4f581dda77ee30178ad3d1b65105088517824635d535"
        },
        "pattern_disposition": 2304,
        "pattern_disposition_details": {
          "detect": False,
          "inddet_mask": False,
          "indicator": False,
          "kill_parent": False,
          "kill_process": False,
          "kill_subprocess": False,
          "operation_blocked": False,
          "policy_disabled": True,
          "process_blocked": True,
          "quarantine_file": False,
          "quarantine_machine": False,
          "registry_operation_blocked": False,
          "rooting": False,
          "sensor_only": False
        },
        "scenario": "NGAV",
        "severity": 30,
        "sha256": "e0fa487db23be0a4d33076cab697e2bad2bdf3268e17754a1bd288cc90fd6046",
        "tactic": "Malware",
        "technique": "PUP",
        "timestamp": "2019-10-21T06:15:58Z",
        "triggering_process_graph_id": "pid:3ccdffe165ee488365a2da431eaaa8d5:9193633644",
        "user_id": "S-1-5-21-1749990491-6506580880-7740138123-1000",
        "user_name": USER_NAME
      }
    ],
    [
      {
        "alleged_filetype": "exe",
        "behavior_id": BEHAVIOR_ID,
        "cmdline": f"\"C:\\Users\\{USER_NAME}\\AppData\\Local\\Temp\\xke012.exe\" ",
        "confidence": 100,
        "control_graph_id": "ctg:3ccdffe165ee488365a2da431eaaa8d5:8593094679",
        "device_id": DEVICE_ID,
        "filename": "scpD82.tmp.exe",
        "ioc_description": f"\\??\\C:\\Users\\{USER_NAME}\\AppData\\Local\\Temp\\xke012.exe",
        "ioc_source": "library_load",
        "ioc_type": "hash_sha256",
        "ioc_value": "a008765da6e64e1390c6f829857926c0c51d1c160c055a305b8b34088e227565",
        "md5": "6e5f8cfc40c5d75a59058fb6066ccc50",
        "objective": "Falcon Detection Method",
        "parent_details": {
          "parent_cmdline": f"\"C:\Program Files (x86)\Microsoft Office\Office15\\OUTLOOK.EXE\" ",
          "parent_md5": "78a43b9b4692f146e18be69a87c3ae82",
          "parent_process_graph_id": "pid:3ccdffe165ee488365a2da431eaaa8d5:9185153754",
          "parent_sha256": "127e6ecf2866ec6447eb9237b7c106c6fa9756c67759bb7bb62e8a759d673b8e"
        },
        "pattern_disposition": 2304,
        "pattern_disposition_details": {
          "detect": False,
          "inddet_mask": False,
          "indicator": False,
          "kill_parent": False,
          "kill_process": False,
          "kill_subprocess": False,
          "operation_blocked": False,
          "policy_disabled": True,
          "process_blocked": False,
          "quarantine_file": False,
          "quarantine_machine": False,
          "registry_operation_blocked": False,
          "rooting": False,
          "sensor_only": False
        },
        "scenario": "NGAV",
        "severity": 30,
        "sha256": "a008765da6e64e1390c6f829857926c0c51d1c160c055a305b8b34088e227565",
        "tactic": "Malware",
        "technique": "PUP",
        "timestamp": "2019-10-21T06:15:58Z",
        "triggering_process_graph_id": "pid:3ccdffe165ee488365a2da431eaaa8d5:9193633644",
        "user_id": "S-1-5-21-1749990491-6506580880-7740138123-1000",
        "user_name": USER_NAME
      }
    ]
  ]
  return random.choice(behaviors_list)


def gen_detection_details(detection_id):
  details = {
    "adversary_ids": [],
    "assigned_to_name": "",
    "assigned_to_uid": "",
    "behaviors": gen_detection_behaviors(),
    "cid": CUSTOMER_ID,
    "created_timestamp": now_isoformat(),
    "detection_id": detection_id,
    "device": get_device_info(),
    "email_sent": True,
    "first_behavior": "2020-08-04T05:47:40.036Z",
    "hostinfo": {
      "active_directory_dn_display": [
        ""
      ],
      "domain": "cortex.com"
    },
    "last_behavior": "2020-08-04T05:47:40.036Z",
    "max_confidence": 0,
    "max_severity": 0,
    "max_severity_displayname": random.choice(['Critical','High','Medium']),
    "overwatch_notes": "",
    "quarantined_files": [],
    "seconds_to_resolved": 0,
    "seconds_to_triaged": 0,
    "show_in_ui": True,
    "status": "new"
  }
  return details


@csfalcon_api.route('/oauth2/token', methods=['POST'])
def get_access_token():
  return {
    'access_token': ACCESS_TOKEN
  }

@csfalcon_api.route('/detects/queries/detects/v1', methods=['GET'])
def search_detection_ids():
  detection_id = random_hex(32) + ':' + random_hex(10)
  
  out = {
    "meta": {
      "pagination": {
        "limit": 0,
        "offset": 0,
        "total": 0
      },
      "powered_by": "empower-api",
      "query_time": 0.782968846,
      "trace_id": TRACE_ID,
      "writes": {
        "resources_affected": 1
      }
    },
    "resources": [
      detection_id
    ]
  }
  return out


@csfalcon_api.route('/detects/entities/summaries/GET/v1', methods=['POST'])
def view_detection_info():
  detection_ids = request.json.get('ids', [])
  
  resources = [gen_detection_details(detection_id) for detection_id in detection_ids]
  
  out = {
    "meta": {
      "pagination": {
        "limit": 0,
        "offset": 0,
        "total": 0
      },
      "powered_by": "empower-api",
      "query_time": 0.782968846,
      "trace_id": TRACE_ID,
      "writes": {
        "resources_affected": 1
      }
    },
    "resources": resources
  }
  return out


@csfalcon_api.route('/devices/queries/devices/v1', methods=['GET'])
def search_hosts():
  out = {
    "meta": {
      "pagination": {
        "limit": 0,
        "offset": 0,
        "total": 0
      },
      "powered_by": "empower-api",
      "query_time": 0.782968846,
      "trace_id": TRACE_ID,
      "writes": {
        "resources_affected": 1
      }
    },
    "resources": [
      HOST_ID
    ]
  }
  return out


@csfalcon_api.route('/devices/entities/devices/v1', methods=['GET'])
def get_host_details():
  host_ids = request.args.get('ids')
  host_id = host_ids[0] if host_ids else HOST_ID
  
  out = {
    "meta": {
      "pagination": {
        "limit": 0,
        "offset": 0,
        "total": 0
      },
      "powered_by": "empower-api",
      "query_time": 0.782968846,
      "trace_id": TRACE_ID,
      "writes": {
        "resources_affected": 0
      }
    },
    "resources": [
      get_device_info()
    ]
  }
  return out


@csfalcon_api.route('/detects/entities/detects/v2', methods=['PATCH'])
def modify_state():
  user_id = request.json.get('assigned_to_uuid') or USER_ID
  
  out = {
    "meta": {
      "pagination": {
        "limit": 0,
        "offset": 0,
        "total": 0
      },
      "powered_by": "empower-api",
      "query_time": 0.782968846,
      "trace_id": TRACE_ID,
      "writes": {
        "resources_affected": 1
      }
    }
  }
  return out


@csfalcon_api.route('/devices/entities/devices-actions/v2', methods=['POST'])
def manage_hosts():
  action_name = request.args.get('action_name')
  agent_ids = request.json.get('ids', [])
  
  resources = [{
    "id": agent_id,
    "path": ""
  } for agent_id in agent_ids]
  
  out = {
    "meta": {
      "pagination": {
        "limit": 0,
        "offset": 0,
        "total": 0
      },
      "powered_by": "empower-api",
      "query_time": 0.782968846,
      "trace_id": TRACE_ID,
      "writes": {
        "resources_affected": 1
      }
    },
    "resources": resources
  }
  return out, 202


@csfalcon_api.route('/real-time-response/combined/batch-init-session/v1', methods=['POST'])
def batch_init_session():
  host_ids = request.json.get('host_ids', [])
  existing_batch_id = request.json.get('existing_batch_id')
  
  out = {
    "batch_id": BATCH_ID,
    "meta": {
      "pagination": {
        "limit": 0,
        "offset": 0,
        "total": 0
      },
      "powered_by": "empower-api",
      "query_time": 0.782968846,
      "trace_id": TRACE_ID,
      "writes": {
        "resources_affected": 1
      }
    },
    "resources": {
    }
  }
  return out, 201


@csfalcon_api.route('/real-time-response/combined/batch-command/v1', methods=['POST'])
def batch_command():
  base_command = request.json.get('base_command', '')
  batch_id = request.json.get('batch_id')
  command_string = request.json.get('command_string')
  
  props = {
    base_command: {
      "aid": HOST_ID,
      "base_command": base_command,
      "complete": True,
      "query_time": 0.782968846,
      "sequence_id": 0,
      "session_id": SESSION_ID,
      "stderr": "string",
      "stdout": 'Directory listing for C:\\ -\n\n'
                'Name                                     Type         Size (bytes)    Size (MB)       '
                'Last Modified (UTC-5)     Created (UTC-5)          \n----                             '
                '        ----         ------------    ---------       ---------------------     -------'
                '--------          \n$Recycle.Bin                             <Directory>  --          '
                '    --              11/27/2018 10:54:44 AM    9/15/2017 3:33:40 AM     \nITAYDI       '
                '                            <Directory>  --              --              11/19/2018 1:'
                '31:42 PM     11/19/2018 1:31:42 PM    ',
      "task_id": TASK_ID
    }
  }
  
  out = {
    "combined": {
      "resources": props
    },
    "meta": {
      "pagination": {
        "limit": 0,
        "offset": 0,
        "total": 0
      },
      "powered_by": "empower-api",
      "query_time": 0.782968846,
      "trace_id": TRACE_ID,
      "writes": {
        "resources_affected": 1
      }
    }
  }
  return out, 201


@csfalcon_api.route('/real-time-response/combined/batch-active-responder-command/v1', methods=['POST'])
def batch_active_responder_command():
  return batch_command()


@csfalcon_api.route('/real-time-response/combined/batch-admin-command/v1', methods=['POST'])
def batch_admin_command():
  return batch_command()


@csfalcon_api.route('/real-time-response/entities/sessions/v1', methods=['POST'])
def init_new_session():
  device_id = request.json.get('device_id', '')
  
  out = {
    "meta": {
      "pagination": {
        "limit": 0,
        "offset": 0,
        "total": 0
      },
      "powered_by": "empower-api",
      "query_time": 0.782968846,
      "trace_id": TRACE_ID,
      "writes": {
        "resources_affected": 1
      }
    },
    "resources": [
      {
        "created_at": now_isoformat(),
        "existing_aid_sessions": 0,
        "previous_commands": [
        ],
        "pwd": "string",
        "scripts": [
        ],
        "session_id": SESSION_ID
      }
    ]
  }
  return out, 201


@csfalcon_api.route('/real-time-response/entities/command/v1', methods=['POST'])
def execute_command():
  base_command = request.json.get('base_command', '')
  command_string = request.json.get('command_string', '')
  device_id = request.json.get('device_id', '')
  id = request.json.get('id', '')
  session_id = request.json.get('session_id', '')
  
  out = {
    "meta": {
      "pagination": {
        "limit": 0,
        "offset": 0,
        "total": 0
      },
      "powered_by": "empower-api",
      "query_time": 0.782968846,
      "trace_id": TRACE_ID,
      "writes": {
        "resources_affected": 1
      }
    },
    "resources": [
      {
        "cloud_request_id": CLOUD_REQUEST_ID,
        "session_id": SESSION_ID
      }
    ]
  }
  return out, 201


@csfalcon_api.route('/real-time-response/entities/active-responder-command/v1', methods=['POST'])
def execute_active_responder_command():
  return execute_command()


@csfalcon_api.route('/real-time-response/entities/admin-command/v1', methods=['POST'])
def execute_admin_command():
  return execute_command()


@csfalcon_api.route('/real-time-response/entities/scripts/v1', methods=['POST'])
def upload_script():
  out = {
    "meta": {
      "pagination": {
        "limit": 0,
        "offset": 0,
        "total": 0
      },
      "powered_by": "empower-api",
      "query_time": 0.782968846,
      "trace_id": TRACE_ID,
      "writes": {
        "resources_affected": 1
      }
    }
  }
  return out


@csfalcon_api.route('/real-time-response/entities/scripts/v1', methods=['GET'])
def get_script():
  
  resources = [
    {
      "bucket": "",
      "cid": CUSTOMER_ID,
      "content": "scripts",
      "created_by": "jdoe@cortex.com",
      "created_by_uuid": "",
      "created_timestamp": "2020-08-04T11:18:34.055Z",
      "description": "",
      "file_type": "script",
      "id": "le10098bf0e311e989190662caec3daa_94cc8c55556741faa1d82bd1faabfb4a",
      "modified_by": "jdoe@cortex.com",
      "modified_by_uuid": "",
      "modified_timestamp": "2020-08-04T11:18:34.055Z",
      "name": "jdoe",
      "path": "",
      "permission_type": "private",
      "platform": [
        "Windows"
      ],
      "run_attempt_count": 0,
      "run_success_count": 0,
      "sha256": "5a4440f2b9ce60b070e98c304370050446a2efa4b3850550a99e4d7b8f447fcc",
      "size": 123,
      "write_access": True
    }
  ]
  out = {
    "meta": {
      "pagination": {
        "limit": 0,
        "offset": 0,
        "total": 0
      },
      "powered_by": "empower-api",
      "query_time": 0.782968846,
      "trace_id": TRACE_ID,
      "writes": {
        "resources_affected": 1
      }
    },
    "resources": resources
  }
  return out


@csfalcon_api.route('/real-time-response/entities/scripts/v1', methods=['DELETE'])
def delete_scripts():
  
  out = {
    "meta": {
      "pagination": {
        "limit": 0,
        "offset": 0,
        "total": 0
      },
      "powered_by": "empower-api",
      "query_time": 0.782968846,
      "trace_id": TRACE_ID,
      "writes": {
        "resources_affected": 1
      }
    }
  }
  return out


@csfalcon_api.route('/real-time-response/entities/put-files/v1', methods=['DELETE'])
def delete_put_files():
  
  out = {
    "meta": {
      "pagination": {
        "limit": 0,
        "offset": 0,
        "total": 0
      },
      "powered_by": "empower-api",
      "query_time": 0.782968846,
      "trace_id": TRACE_ID,
      "writes": {
        "resources_affected": 1
      }
    }
  }
  return out


@csfalcon_api.route('/real-time-response/entities/put-files/v1', methods=['GET'])
def get_put_files():
  
  resources = [
    {
      "bucket": "",
      "cid": CUSTOMER_ID,
      "content": "scripts",
      "created_by": "jdoe@cortex.com",
      "created_by_uuid": "",
      "created_timestamp": "2020-08-04T11:18:34.055Z",
      "description": "",
      "file_type": "script",
      "id": "le10098bf0e311e989190662caec3daa_94cc8c55556741faa1d82bd1faabfb4a",
      "modified_by": "jdoe@cortex.com",
      "modified_by_uuid": "",
      "modified_timestamp": "2020-08-04T11:18:34.055Z",
      "name": "jdoe",
      "path": "",
      "permission_type": "private",
      "platform": [
        "Windows"
      ],
      "run_attempt_count": 0,
      "run_success_count": 0,
      "sha256": "5a4440f2b9ce60b070e98c304370050446a2efa4b3850550a99e4d7b8f447fcc",
      "size": 123,
      "write_access": True
    }
  ]
  
  out = {
    "meta": {
      "pagination": {
        "limit": 0,
        "offset": 0,
        "total": 0
      },
      "powered_by": "empower-api",
      "query_time": 0.782968846,
      "trace_id": TRACE_ID,
      "writes": {
        "resources_affected": 1
      }
    },
    "resources": resources
  }
  return out


@csfalcon_api.route('/real-time-response/combined/batch-get-command/v1', methods=['POST'])
def batch_get_command():
  batch_id = request.json.get('batch_id')
  file_path = request.json.get('file_path', '')
  
  resources = {
    TASK_ID : {
      "aid": HOST_ID,
      "base_command": "get",
      "complete": True,
      "query_time": 0.782968846,
      "sequence_id": 0,
      "session_id": SESSION_ID,
      "stderr": "",
      "stdout": file_path,
      "task_id": TASK_ID
    }
  }
  out = {
    "batch_get_cmd_req_id": BATCH_GET_CMD_REQ_ID,
    "combined": {
      "resources": resources
    },
    "meta": {
      "pagination": {
        "limit": 0,
        "offset": 0,
        "total": 0
      },
      "powered_by": "empower-api",
      "query_time": 0.782968846,
      "trace_id": TRACE_ID,
      "writes": {
        "resources_affected": 1
      }
    }
  }
  return out, 201


@csfalcon_api.route('/real-time-response/combined/batch-get-command/v1', methods=['GET'])
def status_get_command():
  batch_get_cmd_req_id  = request.args.get('batch_get_cmd_req_id')
  
  resources = {
    batch_get_cmd_req_id : {
      "cloud_request_id": batch_get_cmd_req_id,
      "created_at": "2020-08-04T11:53:24.919Z",
      "deleted_at": None,
      "id": 1234,
      "name": "\\Device\\HarddiskVolume2\\Windows\\notepad.exe",
      "session_id": SESSION_ID,
      "sha256": "f1d62648ef915d85cb4fc140359e925395d315c70f3566b63bb3e21151cb2ce3",
      "size": 0,
      "updated_at": "2020-08-04T11:53:24.919Z"
    }
  }
  out = {
    "meta": {
      "pagination": {
        "limit": 0,
        "offset": 0,
        "total": 0
      },
      "powered_by": "empower-api",
      "query_time": 0.782968846,
      "trace_id": TRACE_ID,
      "writes": {
        "resources_affected": 1
      }
    },
    "resources": resources
  }
  return out



@csfalcon_api.route('/real-time-response/entities/command/v1', methods=['GET'])
def status_command():
  cloud_request_id  = request.args.get('cloud_request_id')
  sequence_id  = request.args.get('sequence_id', 0)
  
  out = {
    "meta": {
      "pagination": {
        "limit": 0,
        "offset": 0,
        "total": 0
      },
      "powered_by": "empower-api",
      "query_time": 0.782968846,
      "trace_id": TRACE_ID,
      "writes": {
        "resources_affected": 1
      }
    },
    "resources": [
      {
        "base_command": "ls",
        "complete": True,
        "sequence_id": sequence_id,
        "session_id": SESSION_ID,
        "stderr": "",
        "stdout": "",
        "task_id": TASK_ID
      }
    ]
  }
  return out


@csfalcon_api.route('/real-time-response/entities/admin-command/v1', methods=['GET'])
def status_admin_command():
  return status_command()


@csfalcon_api.route('/real-time-response/entities/active-responder-command/v1', methods=['GET'])
def status_active_responder_command():
  return status_command()


@csfalcon_api.route('/real-time-response/entities/extracted-file-contents/v1', methods=['GET'])
def get_file_contents():
  
  file_content = (b'N3q8ryccAATt0MriCgAAAAAAAABaAAAAAAAAAHYRaMwBAAVzYW1wbGUAAQQGAAEJCgAHCwEA'
                  b'ASEhAQAMBgAICgHDdgvxAAAFARkMAAAAAAAAAAAAAAAAERUAZgBpAGwAZQAxAC4AdAB4AHQA'
                  b'AAAUCgEAk/B+CMxq1gEVBgEAIAAAAAAA')
               
  resp = make_response()
  resp.data = base64.b64decode(file_content)
  resp.headers['Content-Type'] = 'application/x-7z-compressed'
  resp.headers['Content-Disposition'] = 'attachment; filename=file1.7z'
  return resp


@csfalcon_api.route('/real-time-response/entities/file/v1', methods=['GET'])
def list_files():
  session_id  = request.args.get('session_id')
  
  if hasattr(csfalcon_api, 'sessions'):
    csfalcon_api.sessions += 1
  else:
    csfalcon_api.sessions = 0
  print(csfalcon_api.sessions)
  
  out = {
    "meta": {
      "pagination": {
        "limit": 0,
        "offset": 0,
        "total": 0
      },
      "powered_by": "empower-api",
      "query_time": 0.782968846,
      "trace_id": TRACE_ID,
      "writes": {
        "resources_affected": 1
      }
    },
    "resources": [
      {
        "cloud_request_id": CLOUD_REQUEST_ID,
        "created_at": "2020-08-05T02:14:43.279Z",
        "deleted_at": "2020-08-05T02:14:43.279Z",
        "id": 0,
        "name": "file1.txt",
        "session_id": SESSION_ID,
        "sha256": "af2bdbe1aa9b6ec1e2ade1d694f41fc71a831d0268e9891562113d8a62add1bf",
        "size": 6,
        "updated_at": "2020-08-05T02:14:43.279Z"
      }
    ]
  }
  return out


@csfalcon_api.route('/real-time-response/entities/refresh-session/v1', methods=['POST'])
def refresh_session():
  device_id  = request.json.get('device_id')
  
  out = {
    "meta": {
      "pagination": {
        "limit": 0,
        "offset": 0,
        "total": 0
      },
      "powered_by": "empower-api",
      "query_time": 0.782968846,
      "trace_id": TRACE_ID,
      "writes": {
        "resources_affected": 1
      }
    },
    "resources": [
      {
        "created_at": "2020-08-05T02:37:02.680Z",
        "existing_aid_sessions": 0,
        "previous_commands": [
        ],
        "pwd": "string",
        "scripts": [
        ],
        "session_id": SESSION_ID
      }
    ]
  }
  return out


