#!/usr/bin/env python3

from flask import Flask, Response, jsonify, request, make_response
from werkzeug.routing import BaseConverter
import converters
import logging
import ua


# Integrations Imports
from HX import hx_api
from Anomali import anomali_api
from Backstory import backstory_api
from Checkpoint import checkpoint_api
from Exabeam import exabeam_api
from QRadar import qradar_api
from Rapid7 import rapid7_api
from SumoLogic import sumologic_api
from Panorama.Panorama import panorama_api
from Servicenow import servicenow_api
from FortiSIEM.FortiSIEM import fortisiem_api
from RSANetWitness.RSANetWitness_v11_1 import rsa_netwitness_v11_1_api
from RSANetWitness.RSA_NW_Logs_Packets import rsa_nw_logs_packets_api
from Splunk import splunk_api
from LogRhythmREST import logrhythm_rest_api
from Elasticsearch import elasticsearch_api
from JoeSecurity.joesecurity import joesecurity_api
from msgraphmail import msgraphmail_api
from qualys import qualys_api
from tenableio import tenableio_api
from Arcsight import arcsight_api
from CbResponse import cbresponse_api
from Jira import jira_api
from RedLock import redlock_api
from CortexXDR import cortexxdr_api
from wildfirev2 import wildfire_api
from Archer import archer_api
from ews import ews_api
from LogRhythmSOAP import logrhythm_soap_api
from McAfee import mcafee_api
from nessus import nessus_api
from VT import VT_api
from Forescout import forescout_api
from MSGraphSecurity import msgraphsecurity_api
from ews_xdr_demo import ews_demo_api
from Mirror_Demo import mirror_demo_api
from CSFalcon import csfalcon_api
from ETP import etp_api
from SymantecATP import satp_api

# Default to JSON response
class DefaultResponse(Response):
    @classmethod
    def force_type(cls, rv, environ=None):
        if isinstance(rv, dict):
            rv = jsonify(rv)
        return super(DefaultResponse, cls).force_type(rv, environ)


app = Flask(__name__)
app.response_class = DefaultResponse

app.url_map.converters["mans"] = converters.MansConverter


class ValidationError(ValueError):
    pass


@app.errorhandler(ValidationError)
def bad_request(e):
    response = jsonify({"status": 400, "error": "bad request", "message": e.args[0]})
    response.status_code = 400
    return response


@app.errorhandler(404)
def not_found(e):
    response = jsonify({"status": 404, "error": "not found", "message": "invalid resource URI"})
    response.status_code = 404
    return response


@app.errorhandler(405)
def method_not_supported(e):
    response = jsonify({"status": 405, "error": "method not supported", "message": "the method is not supported"})
    response.status_code = 405
    return response


@app.errorhandler(500)
def internal_server_error(e):
    response = jsonify({"status": 500, "error": "internal server error", "message": e.args[0]})
    response.status_code = 500
    return response


# Blueprints registration
app.register_blueprint(hx_api)
app.register_blueprint(anomali_api)
app.register_blueprint(backstory_api)
app.register_blueprint(checkpoint_api)
app.register_blueprint(qradar_api)
app.register_blueprint(rapid7_api)
app.register_blueprint(sumologic_api)
app.register_blueprint(panorama_api)
app.register_blueprint(servicenow_api)
app.register_blueprint(exabeam_api)
app.register_blueprint(fortisiem_api)
app.register_blueprint(rsa_netwitness_v11_1_api)
app.register_blueprint(rsa_nw_logs_packets_api)
app.register_blueprint(splunk_api)
app.register_blueprint(logrhythm_rest_api)
app.register_blueprint(elasticsearch_api)
app.register_blueprint(joesecurity_api)
app.register_blueprint(msgraphmail_api)
app.register_blueprint(qualys_api)
app.register_blueprint(tenableio_api)
app.register_blueprint(arcsight_api)
app.register_blueprint(cbresponse_api)
app.register_blueprint(jira_api)
app.register_blueprint(redlock_api)
app.register_blueprint(cortexxdr_api)
app.register_blueprint(wildfire_api)
app.register_blueprint(nessus_api)
app.register_blueprint(archer_api)
app.register_blueprint(ews_api)
app.register_blueprint(logrhythm_soap_api)
app.register_blueprint(mcafee_api)
app.register_blueprint(VT_api)
app.register_blueprint(forescout_api)
app.register_blueprint(msgraphsecurity_api)
app.register_blueprint(ews_demo_api)
app.register_blueprint(mirror_demo_api)
app.register_blueprint(csfalcon_api)
app.register_blueprint(etp_api)
app.register_blueprint(satp_api)


@app.route("/json")
def test_json():
    return {"code": 1, "message": "XMocky is alive", "status": 200}


@app.before_request
def before_request():
    # print(request.user_agent)
    agent = request.user_agent.string.split("/")[0]
    if request.endpoint and "exabeam" in request.endpoint:
        return
    elif agent not in ua.ua or None:
        return Response(headers={"Server": ""}, status=500)
    return


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=3000, debug=True, ssl_context="adhoc")

