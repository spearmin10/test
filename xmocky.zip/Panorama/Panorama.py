from flask import Blueprint, request, Response, make_response
import json
import logging
import random
import re
import os
import base64

BASE_URL = 'api'.strip('/')
INTEGRATION = 'panorama_api'

panorama_api = Blueprint(f'{INTEGRATION}', __name__)
logger = logging.getLogger(__name__)
def testing():
	xmlresponse = ("""<response status="success">
					<result>
					<system>
					<hostname>PA-7080</hostname>
					<ip-address>192.168.1.99</ip-address>
					<public-ip-address>unknown</public-ip-address>
					<netmask>255.255.255.0</netmask>
					<default-gateway>192.168.1.1</default-gateway>
					<is-dhcp>no</is-dhcp>
					<ipv6-address>unknown</ipv6-address>
					<ipv6-link-local-address>fe80::ea98:6dff:fe54:8200/64</ipv6-link-local-address>
					<mac-address>be:ef:ca:ce:00:00</mac-address>
					<time>Wed May 6 21:34:08 2020 </time>
					<uptime>223 days, 0:56:12</uptime>
					<devicename>PA-7080</devicename>
					<family>7000</family>
					<model>PA-7080</model>
					<serial>01123123123</serial>
					<cloud-mode>non-cloud</cloud-mode>
					<sw-version>9.2.0</sw-version>
					<global-protect-client-package-version>5.1.1</global-protect-client-package-version>
					<iot-version>0</iot-version>
					<app-version>8267-6070</app-version>
					<app-release-date>2020/05/06 05:12:12 EEST</app-release-date>
					<av-version>3340-3851</av-version>
					<av-release-date>2020/05/06 14:00:11 EEST</av-release-date>
					<threat-version>8267-6070</threat-version>
					<threat-release-date>2020/05/06 05:12:12 EEST</threat-release-date>
					<wf-private-version>0</wf-private-version>
					<wf-private-release-date>unknown</wf-private-release-date>
					<url-db>paloaltonetworks</url-db>
					<wildfire-version>451549-454482</wildfire-version>
					<wildfire-release-date>2020/05/06 20:57:09 EEST</wildfire-release-date>
					<wildfire-rt>Enabled</wildfire-rt>
					<url-filtering-version>20200506.20279</url-filtering-version>
					<global-protect-datafile-version>unknown</global-protect-datafile-version>
					<global-protect-datafile-release-date>unknown</global-protect-datafile-release-date>
					<global-protect-clientless-vpn-version>0</global-protect-clientless-vpn-version>
					<logdb-version>9.2.18</logdb-version>
					<platform-family>220</platform-family>
					<vpn-disable-mode>off</vpn-disable-mode>
					<multi-vsys>off</multi-vsys>
					<operational-mode>normal</operational-mode>
					<device-certificate-status>None</device-certificate-status>
					</system>
					</result>
					</response>""")
	return Response(xmlresponse, mimetype='text/xml')

def commitstatusresponse(command):
	result = re.search('<show><jobs><id>(.*)</id></jobs></show>', command)
	xmlresponse = """<response status="success">
						<result>
						<job>
						<tenq>2020/05/07 11:29:48</tenq>
						<tdeq>11:29:48</tdeq>
						<id>"""+str(result.group(1))+"""</id>
						<user>admin</user>
						<type>Commit</type>
						<status>FIN</status>
						<queued>NO</queued>
						<stoppable>no</stoppable>
						<result>OK</result>
						<tfin>11:34:12</tfin>
						<description/>
						<positionInQ>0</positionInQ>
						<progress>100</progress>
						<details>
						<line>Configuration committed successfully</line>
						</details>
						</job>
						</result>
						</response>"""
	return Response(xmlresponse, mimetype='text/xml')

def downloadcontentupgrade(command):
	xmlresponse = """<response status="success" code="19">
						<result>
						<msg>
						<line>Download job enqueued with jobid 50</line>
						</msg>
						<job>50</job>
						</result>
						</response>"""
	return Response(xmlresponse, mimetype='text/xml')

def installcontentupgrade(command):
	xmlresponse = """<response status="success" code="19">
						<result>
						<msg>
						<line>Content install job enqueued with jobid 51</line>
						</msg>
						<job>51</job>
						</result>
						</response>"""
	return Response(xmlresponse, mimetype='text/xml')

def panosupgradecheck(command):
	xmlresponse = """<response status="success">
							<result>
							<sw-updates last-updated-at="2020/04/22 09:52:50">
							<msg/>
							<versions>
							<entry>
							<version>9.1.2-h1</version>
							<filename>PanOS_220-9.1.2-h1</filename>
							<size>277</size>
							<size-kb>283789</size-kb>
							<released-on>2020/04/29 08:01:29</released-on>
							<release-notes>
							<![CDATA[
							https://prod.itpdownloads.paloaltonetworks.com/software/PAN-OS-9.1.2-h1-RN.pdf?Expires=1589107118&KeyName=contentupdates-prod&Signature=fV7QnxUrqFQ5w7Zfe6MQtKRFxvE=
							]]>
							</release-notes>
							<downloaded>no</downloaded>
							<current>no</current>
							<latest>no</latest>
							<uploaded>no</uploaded>
							</entry>
							<entry>
							<version>9.1.2</version>
							<filename>PanOS_220-9.1.2</filename>
							<size>277</size>
							<size-kb>283775</size-kb>
							<released-on>2020/04/08 10:49:11</released-on>
							<release-notes>
							<![CDATA[
							https://www.paloaltonetworks.com/documentation/91/pan-os/pan-os-release-notes
							]]>
							</release-notes>
							<downloaded>no</downloaded>
							<current>no</current>
							<latest>no</latest>
							<uploaded>no</uploaded>
							</entry>
							<entry>
							<version>9.1.1</version>
							<filename>PanOS_220-9.1.1</filename>
							<size>277</size>
							<size-kb>283762</size-kb>
							<released-on>2020/02/10 14:10:23</released-on>
							<release-notes>
							<![CDATA[
							https://www.paloaltonetworks.com/documentation/91/pan-os/pan-os-release-notes
							]]>
							</release-notes>
							<downloaded>no</downloaded>
							<current>no</current>
							<latest>no</latest>
							<uploaded>no</uploaded>
							</entry>
							<entry>
							<version>9.1.0</version>
							<filename>PanOS_220-9.1.0</filename>
							<size>421</size>
							<size-kb>431135</size-kb>
							<released-on>2019/12/13 12:51:48</released-on>
							<release-notes>
							<![CDATA[
							https://www.paloaltonetworks.com/documentation/91/pan-os/pan-os-release-notes
							]]>
							</release-notes>
							<downloaded>yes</downloaded>
							<current>no</current>
							<latest>no</latest>
							<uploaded>no</uploaded>
							</entry>
							</versions>
							</sw-updates>
							</result>
							</response>"""
	return Response(xmlresponse, mimetype='text/xml')

def panosupgradedownload(command):
	xmlresponse = """<response status="success" code="19">
						<result>
						<msg>
						<line>Download job enqueued with jobid 52</line>
						</msg>
						<job>52</job>
						</result>
						</response>"""
	return Response(xmlresponse, mimetype='text/xml')

def panosupgradeinstall(command):
	xmlresponse = """<response status="success" code="19">
						<result>
						<msg>
						<line>Install job enqueued with jobid 54</line>
						</msg>
						<job>54</job>
						</result>
						</response>"""
	return Response(xmlresponse, mimetype='text/xml')

def restartfw(command):
	xmlresponse = """<response status="success">
						<result>Command succeeded with no output</result>
						</response>"""
	return Response(xmlresponse, mimetype='text/xml')

def testsecuritypolicy(command):
	xmlresponse = """<response cmd="status" status="success">
						<result>
							<rules>
								<entry name='FromTrust'>
									<index>1</index>
									<from>Trust-L3</from>
									<source>any</source>
									<source-region>none</source-region>
									<to>
										<member>Untrust-L3</member>
									</to>
									<destination>any</destination>
									<destination-region>none</destination-region>
									<user>any</user>
									<source-device>any</source-device>
									<destinataion-device>any</destinataion-device>
									<category>any</category>
									<application_service>0:any/any/any/any</application_service>
									<action>allow</action>
									<icmp-unreachable>no</icmp-unreachable>
									<terminal>yes</terminal>
								</entry>
							</rules>
						</result>
					</response>""" 
	return Response(xmlresponse, mimetype='text/xml')


def geturlinfofromhost(command):
	url = re.search('<test><url-info-host>(.*)</url-info-host></test>', command)
	xmlresponse = """<response cmd="status" status="success"><result>
						"""+str(url.group(1))+""": Doesn't exist in the URL DB
					</result></response>"""
	return Response(xmlresponse, mimetype='text/xml')


def geturlinfofromcloud(command):
	url = re.search('<test><url-info-cloud>(.*)</url-info-cloud></test>', command)
	xmlresponse = """<response cmd="status" status="success"><result>BM:
						"""+str(url.group(1))+""",9,5,malware,high-risk
					</result></response>"""
	return Response(xmlresponse, mimetype='text/xml')


def testurl(command):
	url = re.search('<test><url>(.*)</url></test>', command)
	xmlresponse = """<response cmd="status" status="success"><result>"""+str(url.group(1))+""" malware high-risk (Base db) mlav_flag=0 expires in 0 seconds
						"""+str(url.group(1))+""" malware high-risk (Cloud db)
						</result></response>"""
	return Response(xmlresponse, mimetype='text/xml')


def prismaaccesslogout(command):
	
	comp_start = command.find('<computer>') + 10
	comp_end = command.find('</computer>', comp_start)
	computer = base64.b64decode(command[comp_start:comp_end]).decode('utf-8')
	dom_start = command.find('<domain>') + 8
	dom_end = command.find('</domain>', dom_start)
	domain = command[dom_start:dom_end]
	user_start = command.find('<user>') + 6
	user_end = command.find('</user>', user_start)
	user = base64.b64decode(command[user_start:user_end]).decode('utf-8')	
	
	xmlresponse = """<response status="success">
						<result>User: """ + user + " successfully logged out of computer: " + domain + "/" + computer + """</result>
						</response>"""
	return Response(xmlresponse, mimetype='text/xml')



def opcommands(command,action):
	print(command)
	if '<show><jobs><id>' in command:
		return commitstatusresponse(command)
	elif '<request><content><upgrade><download><latest/>' in command:
		return downloadcontentupgrade(command)
	elif '<request><content><upgrade><install' in command:
		return installcontentupgrade(command)
	elif '<request><system><software><check>' in command:
		return panosupgradecheck(command)
	elif '<request><system><software><download>' in command:
		return panosupgradedownload(command)
	elif '<request><system><software><install>' in command:
		return panosupgradeinstall(command)
	elif '<request><restart><system>' in command:
		return restartfw(command)
	elif '<test><security-policy-match>' in command:
		return testsecuritypolicy(command)
	elif '<show><objects>' in command:
		return showobjects(command)
	elif '<test><url-info-host>' in command:
		return geturlinfofromhost(command)
	elif '<test><url-info-cloud>' in command:
		return geturlinfofromcloud(command)
	elif '<test><url>' in command:
		return testurl(command)
	elif '<request><plugins><cloud_services>' in command:
		return prismaaccesslogout(command)	
	else:
		return testing()

def logresults(jobid):
	xmlresponse = """<response status="success">
					<result>
					  <job>
						<tenq>15:25:48</tenq>
						<tdeq>15:25:48</tdeq>
						<tlast>15:25:48</tlast>
						<status>FIN</status>
						<id>"""+str(jobid)+"""</id>
					  </job>
					  <log>
						<logs count="3" progress="100">
						  <entry logid="6780097220994662620">
							<domain>1</domain>
							<receive_time>2020/01/10 10:24:21</receive_time>
							<serial>015351000024631</serial>
							<seqno>1468</seqno>
							<actionflags>0x0</actionflags>
							<is-logging-service>no</is-logging-service>
							<type>TRAFFIC</type>
							<subtype>end</subtype>
							<config_ver>2304</config_ver>
							<time_generated>2020/01/10 10:24:21</time_generated>
							<src>192.168.35.103</src>
							<dst>64.233.162.94</dst>
							<natsrc>192.168.55.156</natsrc>
							<natdst>64.233.162.94</natdst>
							<rule>Out</rule>
							<srcuser>John</srcuser>
							<srcloc code="192.168.0.0-192.168.255.255" cc="192.168.0.0-192.168.255.255">192.168.0.0-192.168.255.255</srcloc>
							<dstloc code="United States" cc="US">United States</dstloc>
							<app>quic</app>
							<vsys>vsys1</vsys>
							<from>Inside</from>
							<to>Outside</to>
							<inbound_if>ethernet1/2</inbound_if>
							<outbound_if>ethernet1/1</outbound_if>
							<logset>ToPanorama</logset>
							<time_received>2020/01/10 10:24:21</time_received>
							<sessionid>229</sessionid>
							<repeatcnt>1</repeatcnt>
							<sport>57771</sport>
							<dport>443</dport>
							<natsport>6898</natsport>
							<natdport>443</natdport>
							<flags>0x600041</flags>
							<flag-pcap>no</flag-pcap>
							<flag-flagged>no</flag-flagged>
							<flag-proxy>no</flag-proxy>
							<flag-url-denied>no</flag-url-denied>
							<flag-nat>yes</flag-nat>
							<captive-portal>yes</captive-portal>
							<non-std-dport>no</non-std-dport>
							<transaction>no</transaction>
							<pbf-c2s>no</pbf-c2s>
							<pbf-s2c>no</pbf-s2c>
							<temporary-match>no</temporary-match>
							<sym-return>no</sym-return>
							<decrypt-mirror>no</decrypt-mirror>
							<credential-detected>no</credential-detected>
							<flag-mptcp-set>no</flag-mptcp-set>
							<flag-tunnel-inspected>no</flag-tunnel-inspected>
							<flag-recon-excluded>no</flag-recon-excluded>
							<flag-wf-channel>no</flag-wf-channel>
							<proto>udp</proto>
							<action>allow</action>
							<tunnel>N/A</tunnel>
							<tpadding>0</tpadding>
							<cpadding>0</cpadding>
							<rule_uuid>ed594104-992b-4486-8cfd-fdddc07a4d3a</rule_uuid>
							<dg_hier_level_1>0</dg_hier_level_1>
							<dg_hier_level_2>0</dg_hier_level_2>
							<dg_hier_level_3>0</dg_hier_level_3>
							<dg_hier_level_4>0</dg_hier_level_4>
							<device_name>PA-VM</device_name>
							<vsys_id>1</vsys_id>
							<tunnelid_imsi>0</tunnelid_imsi>
							<parent_session_id>0</parent_session_id>
							<bytes>7066</bytes>
							<bytes_sent>7066</bytes_sent>
							<bytes_received>0</bytes_received>
							<packets>6</packets>
							<start>2020/01/10 10:22:18</start>
							<elapsed>4</elapsed>
							<category>any</category>
							<traffic_flags>0x64</traffic_flags>
							<flag-decrypt-forwarded>no</flag-decrypt-forwarded>
							<pkts_sent>6</pkts_sent>
							<pkts_received>0</pkts_received>
							<session_end_reason>aged-out</session_end_reason>
							<action_source>from-policy</action_source>
							<assoc_id>0</assoc_id>
							<chunks>0</chunks>
							<chunks_sent>0</chunks_sent>
							<chunks_received>0</chunks_received>
							<http2_connection>0</http2_connection>
							<tunnelid>0</tunnelid>
							<imsi/>
							<monitortag/>
							<imei/>
						  </entry>
						  <entry logid="6780097220994662619">
							<domain>1</domain>
							<receive_time>2020/01/10 10:24:20</receive_time>
							<serial>015351000024631</serial>
							<seqno>1467</seqno>
							<actionflags>0x0</actionflags>
							<is-logging-service>no</is-logging-service>
							<type>TRAFFIC</type>
							<subtype>end</subtype>
							<config_ver>2304</config_ver>
							<time_generated>2020/01/10 10:24:20</time_generated>
							<src>192.168.35.103</src>
							<dst>173.194.73.95</dst>
							<natsrc>192.168.55.156</natsrc>
							<natdst>173.194.73.95</natdst>
							<rule>Out</rule>
							<srcuser>Mike</srcuser>
							<srcloc code="192.168.0.0-192.168.255.255" cc="192.168.0.0-192.168.255.255">192.168.0.0-192.168.255.255</srcloc>
							<dstloc code="United States" cc="US">United States</dstloc>
							<app>quic</app>
							<vsys>vsys1</vsys>
							<from>Inside</from>
							<to>Outside</to>
							<inbound_if>ethernet1/2</inbound_if>
							<outbound_if>ethernet1/1</outbound_if>
							<logset>ToPanorama</logset>
							<time_received>2020/01/10 10:24:20</time_received>
							<sessionid>212</sessionid>
							<repeatcnt>1</repeatcnt>
							<sport>50239</sport>
							<dport>443</dport>
							<natsport>7876</natsport>
							<natdport>443</natdport>
							<flags>0x80600041</flags>
							<flag-pcap>yes</flag-pcap>
							<flag-flagged>no</flag-flagged>
							<flag-proxy>no</flag-proxy>
							<flag-url-denied>no</flag-url-denied>
							<flag-nat>yes</flag-nat>
							<captive-portal>yes</captive-portal>
							<non-std-dport>no</non-std-dport>
							<transaction>no</transaction>
							<pbf-c2s>no</pbf-c2s>
							<pbf-s2c>no</pbf-s2c>
							<temporary-match>no</temporary-match>
							<sym-return>no</sym-return>
							<decrypt-mirror>no</decrypt-mirror>
							<credential-detected>no</credential-detected>
							<flag-mptcp-set>no</flag-mptcp-set>
							<flag-tunnel-inspected>no</flag-tunnel-inspected>
							<flag-recon-excluded>no</flag-recon-excluded>
							<flag-wf-channel>no</flag-wf-channel>
							<pcap-file>20200110-192.168.35.103-50239-173.194.73.95-443-212.pcap</pcap-file>
							<proto>udp</proto>
							<action>allow</action>
							<tunnel>N/A</tunnel>
							<tpadding>0</tpadding>
							<cpadding>0</cpadding>
							<rule_uuid>ed594104-992b-4486-8cfd-fdddc07a4d3a</rule_uuid>
							<dg_hier_level_1>0</dg_hier_level_1>
							<dg_hier_level_2>0</dg_hier_level_2>
							<dg_hier_level_3>0</dg_hier_level_3>
							<dg_hier_level_4>0</dg_hier_level_4>
							<device_name>PA-VM</device_name>
							<vsys_id>1</vsys_id>
							<tunnelid_imsi>0</tunnelid_imsi>
							<parent_session_id>0</parent_session_id>
							<bytes>7066</bytes>
							<bytes_sent>7066</bytes_sent>
							<bytes_received>0</bytes_received>
							<packets>6</packets>
							<start>2020/01/10 10:22:17</start>
							<elapsed>4</elapsed>
							<category>any</category>
							<traffic_flags>0x64</traffic_flags>
							<flag-decrypt-forwarded>no</flag-decrypt-forwarded>
							<pkts_sent>6</pkts_sent>
							<pkts_received>0</pkts_received>
							<session_end_reason>aged-out</session_end_reason>
							<action_source>from-policy</action_source>
							<assoc_id>0</assoc_id>
							<chunks>0</chunks>
							<chunks_sent>0</chunks_sent>
							<chunks_received>0</chunks_received>
							<http2_connection>0</http2_connection>
							<tunnelid>0</tunnelid>
							<imsi/>
							<monitortag/>
							<imei/>
						  </entry>
						  <entry logid="6918883076210691119">
							<domain>1</domain>
							<receive_time>2021/01/19 00:34:01</receive_time>
							<serial>015351000057872</serial>
							<seqno>405432</seqno>
							<actionflags>0x0</actionflags>
							<is-logging-service>no</is-logging-service>
							<type>THREAT</type>
							<subtype>spyware</subtype>
							<config_ver>2560</config_ver>
							<time_generated>2021/01/19 00:34:01</time_generated>
							<high_res_timestamp>2021-01-19T00:34:02.304+09:00</high_res_timestamp>
							<src>192.168.1.43</src>
							<dst>117.18.232.240</dst>
							<rule>Any</rule>
							<srcloc code="192.168.0.0-192.168.255.255" cc="192.168.0.0-192.168.255.255">192.168.0.0-192.168.255.255</srcloc>
							<dstloc code="Australia" cc="AU">Australia</dstloc>
							<app>ms-update</app>
							<vsys>vsys1</vsys>
							<from>cortex.lan</from>
							<to>cortex.lan</to>
							<inbound_if>ethernet1/1</inbound_if>
							<outbound_if>ethernet1/1</outbound_if>
							<logset>Send to CDL</logset>
							<time_received>2021/01/19 00:34:01</time_received>
							<sessionid>34331</sessionid>
							<repeatcnt>1</repeatcnt>
							<sport>50665</sport>
							<dport>80</dport>
							<natsport>0</natsport>
							<natdport>0</natdport>
							<flags>0x80002000</flags>
							<flag-pcap>yes</flag-pcap>
							<flag-flagged>no</flag-flagged>
							<flag-proxy>no</flag-proxy>
							<flag-url-denied>no</flag-url-denied>
							<flag-nat>no</flag-nat>
							<captive-portal>no</captive-portal>
							<non-std-dport>no</non-std-dport>
							<transaction>no</transaction>
							<pbf-c2s>no</pbf-c2s>
							<pbf-s2c>no</pbf-s2c>
							<temporary-match>yes</temporary-match>
							<sym-return>no</sym-return>
							<decrypt-mirror>no</decrypt-mirror>
							<credential-detected>no</credential-detected>
							<flag-mptcp-set>no</flag-mptcp-set>
							<flag-tunnel-inspected>no</flag-tunnel-inspected>
							<flag-recon-excluded>no</flag-recon-excluded>
							<flag-wf-channel>no</flag-wf-channel>
							<pktlog>1610984041-34331.pcap</pktlog>
							<proto>tcp</proto>
							<action>alert</action>
							<tunnel>N/A</tunnel>
							<tpadding>0</tpadding>
							<cpadding>0</cpadding>
							<rule_uuid>ce37e1dc-2ace-4425-99b8-6383ca48c765</rule_uuid>
							<s_decrypted>0</s_decrypted>
							<s_encrypted>0</s_encrypted>
							<vpadding>0</vpadding>
							<dg_hier_level_1>0</dg_hier_level_1>
							<dg_hier_level_2>0</dg_hier_level_2>
							<dg_hier_level_3>0</dg_hier_level_3>
							<dg_hier_level_4>0</dg_hier_level_4>
							<device_name>ngfw</device_name>
							<vsys_id>1</vsys_id>
							<tunnelid_imsi>0</tunnelid_imsi>
							<parent_session_id>0</parent_session_id>
							<threatid>PE File</threatid>
							<tid>6900001</tid>
							<reportid>0</reportid>
							<category>computer-and-internet-info</category>
							<severity>informational</severity>
							<direction>client-to-server</direction>
							<url_idx>1</url_idx>
							<pcap_id>1206944500467905272</pcap_id>
							<contentver>AppThreat-0-0</contentver>
							<sig_flags>0x0</sig_flags>
							<thr_category>unknown</thr_category>
							<assoc_id>0</assoc_id>
							<ppid>4294967295</ppid>
							<http2_connection>0</http2_connection>
							<xff_ip>0.0.0.0</xff_ip>
							<threat_name>PE File</threat_name>
							<partial_hash>0</partial_hash>
							<misc>au.download.windowsupdate.com/c/msdownload/update/software/defu/2021/01/am_delta_720d4263d390e5a28546b9c9270a0ebe572fec0c.exe</misc>
							<tunnelid>0</tunnelid>
							<imsi/>
							<monitortag/>
							<imei/>
						  </entry>
						</logs>
					  </log>
					  <meta>
						<devices>
						  <entry name="localhost.localdomain">
							<hostname>localhost.localdomain</hostname>
							<vsys>
							  <entry name="vsys1">
								<display-name>vsys1</display-name>
							  </entry>
							</vsys>
						  </entry>
						</devices>
					  </meta>
					</result></response>"""
	return Response(xmlresponse, mimetype='text/xml')

def logquery(logtype):
	newjobid = str(random.randint(1,2000))
	xmlresponse = """<response status="success" code="19">
								<result>
								<msg>
								<line>query job enqueued with jobid """+newjobid+"""</line>
								</msg>
								<job>"""+newjobid+"""</job>
								</result>
								</response>"""
	return Response(xmlresponse, mimetype='text/xml')

def commitcommand():
	newjobid = str(random.randint(1,2000))
	xmlresponse = """<response status="success" code="19">
						<result>
						<msg>
						<line>Commit job enqueued with jobid """+newjobid+"""</line>
						</msg>
						<job>"""+newjobid+"""</job>
						</result>
						</response>"""
	return Response(xmlresponse, mimetype='text/xml')

def versioncommand():
	xmlresponse = """<response status="success">
						<result>
						<sw-version>9.1.0</sw-version>
						<multi-vsys>off</multi-vsys>
						<model>PA-220</model>
						<serial>123401012297</serial>
						</result>
						</response>"""
	return Response(xmlresponse, mimetype='text/xml')

def useridcommands(command):
	xmlresponse = """<response status="success">
					<result>
					<uid-response>
					<version>2.0</version>
					<payload>
					<register-user> </register-user>
					</payload>
					</uid-response>
					</result>
					</response>"""
	return Response(xmlresponse, mimetype='text/xml')

def listaddressgroups(xpath):
	try:
		groupname = xpath.split('/')[-1].split('\'')[1]
		xmlresponse = """<response status="success" code="19"><result total-count="2" count="2">
							  <entry name=\""""+groupname+"""\">
								<static>
								  <member>XSOAR-Server</member>
								</static>
							  </entry>
							</result></response>"""
		return Response(xmlresponse, mimetype='text/xml')
	except:
		xmlresponse = """<response status="success" code="19"><result total-count="2" count="2">
							  <entry name="Testing">
								<static>
								  <member>XSOAR-Server</member>
								</static>
							  </entry>
							</result></response>"""
		return Response(xmlresponse, mimetype='text/xml')

def listallrules():
	xmlresponse = """<response status="success" code="19"><result total-count="7" count="7">
					  <entry name="XDRTesting-allow-only-xdr" uuid="0c4cacb6-02e0-477c-b140-678994e2b619">
						<to>
						  <member>Untrust-L3</member>
						</to>
						<from>
						  <member>Trust-L3</member>
						</from>
						<source>
						  <member>192.168.1.9</member>
						</source>
						<destination>
						  <member>any</member>
						</destination>
						<source-user>
						  <member>any</member>
						</source-user>
						<category>
						  <member>any</member>
						</category>
						<application>
						  <member>cortex-xdr</member>
						  <member>google-base</member>
						  <member>ssl</member>
						  <member>traps-management-service</member>
						</application>
						<service>
						  <member>any</member>
						</service>
						<source-hip>
						  <member>any</member>
						</source-hip>
						<destination-hip>
						  <member>any</member>
						</destination-hip>
						<action>allow</action>
						<log-setting>default</log-setting>
						<disabled>yes</disabled>
					  </entry>
					  <entry name="XDRTesting" uuid="02957b05-c1a2-4bf0-8706-f2651fa15c93">
						<to>
						  <member>Untrust-L3</member>
						</to>
						<from>
						  <member>Trust-L3</member>
						</from>
						<source>
						  <member>192.168.1.9</member>
						</source>
						<destination>
						  <member>any</member>
						</destination>
						<source-user>
						  <member>any</member>
						</source-user>
						<category>
						  <member>any</member>
						</category>
						<application>
						  <member>any</member>
						</application>
						<service>
						  <member>application-default</member>
						</service>
						<source-hip>
						  <member>any</member>
						</source-hip>
						<destination-hip>
						  <member>any</member>
						</destination-hip>
						<action>drop</action>
						<log-setting>default</log-setting>
						<disabled>yes</disabled>
					  </entry>
					  <entry name="FromIOT" uuid="065927d5-54e2-43a1-ab4f-e9e28fbda220">
						<profile-setting>
						  <group>
							<member>Special</member>
						  </group>
						</profile-setting>
						<to>
						  <member>Trust-L3</member>
						  <member>Untrust-L3</member>
						</to>
						<from>
						  <member>IOT</member>
						</from>
						<source>
						  <member>any</member>
						</source>
						<destination>
						  <member>any</member>
						</destination>
						<source-user>
						  <member>any</member>
						</source-user>
						<category>
						  <member>any</member>
						</category>
						<application>
						  <member>any</member>
						</application>
						<service>
						  <member>any</member>
						</service>
						<source-hip>
						  <member>any</member>
						</source-hip>
						<destination-hip>
						  <member>any</member>
						</destination-hip>
						<action>allow</action>
						<log-setting>default</log-setting>
					  </entry>
					</result></response>"""
	return Response(xmlresponse, mimetype='text/xml')

def listcustomurl(xpath):
	categoryname = xpath.split('/')[-1].split('\'')[1]
	xmlresponse = """<response status="success" code="19"><result total-count="1" count="1">
					  <entry name=\""""+categoryname+"""\">
						<list>
						  <member>xsoar.pan.dev/</member>
						  <member>pan.dev/</member>
						</list>
						<type>URL List</type>
					  </entry>
					</result></response>"""
	return Response(xmlresponse, mimetype='text/xml')

def listaddress(xpath):
	try:
		addressname = xpath.split('/')[-1].split('\'')[1]
		xmlresponse = """<response status="success" code="19"><result total-count="1" count="1">
						  <entry name=\""""+addressname+"""\">
							<ip-netmask>192.168.1.240</ip-netmask>
							<tag>
							  <member>Infra</member>
							</tag>
						  </entry>
						</result></response>"""
		return Response(xmlresponse, mimetype='text/xml')
	except:
		xmlresponse = """<response status="success" code="19"><result total-count="1" count="1">
						  <entry name="Host1">
							<ip-netmask>192.168.1.240</ip-netmask>
							<tag>
							  <member>Infra</member>
							</tag>
						  </entry>
						</result></response>"""
		return Response(xmlresponse, mimetype='text/xml')

def listedl(xpath):
	try:
		edlname = xpath.split('/')[-1].split('\'')[1]
		xmlresponse = """<response status="success" code="19">
						<result total-count="1" count="1">
						<entry name=\""""+edlname+"""\">
						<type>
						<ip>
						<recurring>
						<five-minute/>
						</recurring>
						<url>http://1.2.3.4</url>
						</ip>
						</type>
						</entry>
						</result>
						</response>"""
		return Response(xmlresponse, mimetype='text/xml')
	except:
		xmlresponse = """<response status="success" code="19">
						<result total-count="1" count="1">
						<entry name="default">
						<type>
						<ip>
						<recurring>
						<five-minute/>
						</recurring>
						<url>http://1.2.3.4</url>
						</ip>
						</type>
						</entry>
						</result>
						</response>"""
		return Response(xmlresponse, mimetype='text/xml')

def liststaticroutes(xpath):
	try:
		routename = xpath.split('/')[-1].split('\'')[1]
		xmlresponse = """<response status="success" code="19"><result total-count="1" count="1">
						  <entry name=\""""+routename+"""\">
							<path-monitor>
							  <enable>no</enable>
							  <failure-condition>any</failure-condition>
							  <hold-time>2</hold-time>
							</path-monitor>
							<nexthop>
							  <ip-address>192.168.99.1</ip-address>
							</nexthop>
							<interface>ethernet1/4</interface>
							<metric>10</metric>
							<destination>0.0.0.0/0</destination>
							<route-table>
							  <unicast/>
							</route-table>
						  </entry>
						</result></response>"""
		return Response(xmlresponse, mimetype='text/xml')
	except:
		xmlresponse = """<response status="success" code="19"><result total-count="1" count="1">
							<entry name="default">
							<path-monitor>
							  <enable>no</enable>
							  <failure-condition>any</failure-condition>
							  <hold-time>2</hold-time>
							</path-monitor>
							<nexthop>
							  <ip-address>192.168.99.1</ip-address>
							</nexthop>
							<interface>ethernet1/4</interface>
							<metric>10</metric>
							<destination>0.0.0.0/0</destination>
							<route-table>
							  <unicast/>
							</route-table>
						  </entry>
						</result></response>"""
		return Response(xmlresponse, mimetype='text/xml')

def listservices(xpath):
	try:
		servicename = xpath.split('/')[-1].split('\'')[1]
		xmlresponse = """<response status="success" code="19">
						<result total-count="1" count="1">
							<entry name=\""""+servicename+"""\" admin="admin" dirtyId="2" time="2020/05/09 12:43:41">
								<protocol admin="admin" dirtyId="2" time="2020/05/09 12:43:41">
									<tcp admin="admin" dirtyId="2" time="2020/05/09 12:43:41">
										<port admin="admin" dirtyId="2" time="2020/05/09 12:43:41">51101</port>
										<override admin="admin" dirtyId="2" time="2020/05/09 12:43:41">
											<no admin="admin" dirtyId="2" time="2020/05/09 12:43:41"/>
										</override>
									</tcp>
								</protocol>
								<description admin="admin" dirtyId="2" time="2020/05/09 12:43:41">testing</description>
							</entry>
						</result>
					</response>"""
		return Response(xmlresponse, mimetype='text/xml')
	except:
		xmlresponse = """<response status="success" code="19">
						<result total-count="1" count="1">
							<entry name="Testing" admin="admin" dirtyId="2" time="2020/05/09 12:43:41">
								<protocol admin="admin" dirtyId="2" time="2020/05/09 12:43:41">
									<tcp admin="admin" dirtyId="2" time="2020/05/09 12:43:41">
										<port admin="admin" dirtyId="2" time="2020/05/09 12:43:41">51101</port>
										<override admin="admin" dirtyId="2" time="2020/05/09 12:43:41">
											<no admin="admin" dirtyId="2" time="2020/05/09 12:43:41"/>
										</override>
									</tcp>
								</protocol>
								<description admin="admin" dirtyId="2" time="2020/05/09 12:43:41">testing</description>
							</entry>
						</result>
					</response>"""
		return Response(xmlresponse, mimetype='text/xml')

def listservicegroups(xpath):
	xmlresponse = """<response status="success">
						<result>
							<entry name="TestingGroup">
								<members>
									<member>service-http</member>
									<member>service-https</member>
								</members>
							</entry>
						</result>
					</response>"""
	return Response(xmlresponse, mimetype='text/xml')


def listurlfilters(xpath):
	xmlresponse = """<response status="success"><result>
							<entry name="Special">
								<block>
									<member>command-and-control</member>
									<member>malware</member>
									<member>phishing</member>
								</block>
							</entry>
					  </result></response>"""
	return Response(xmlresponse, mimetype='text/xml')
	

def configcommands(xpath):
	print(xpath)
	if '/address-group/entry' in xpath:
		return listaddressgroups(xpath)
	elif '/rulebase/security/rules/entry' in xpath:
		return listallrules()
	elif '/profiles/custom-url-category/' in xpath:
		return listcustomurl(xpath)
	elif '/address/entry' in xpath:
		return listaddress(xpath)
	elif '/external-list/entry' in xpath:
		return listedl(xpath)
	elif '/network/virtual-router/' in xpath:
		return liststaticroutes(xpath)
	elif '/service/entry' in xpath:
		return listservices(xpath)
	elif '/service-group/entry' in xpath:
		return listservicegroups(xpath)
	elif '/profiles/url-filtering/entry' in xpath:
		return listurlfilters(xpath)
	else:
		xmlresponse = """<response status="success" code="20">
						<msg>command succeeded</msg>
						</response>"""
		return Response(xmlresponse, mimetype='text/xml')

def pcapexports_application():
	xmlresponse = """<?xml version="1.0"?>
						<response status="success">
						  <result>
							<dir-listing>
							  <dir>/20200507</dir>
							  <dir>/20200110</dir>
							  <dir>/20200108</dir>
							  <dir>/20190506</dir>
							  <dir>/20190627</dir>
							  <dir>/20200107</dir>
							  <dir>/20200113</dir>
							</dir-listing>
						  </result>
						</response>"""
	return Response(xmlresponse, mimetype='text/xml')


def exportcommands(category):
	if 'pcap' in category:
		return pcapexports_application()
	else:
		return 'foo'

def exportcommand_threat_pcap(pcapid):
	resp = make_response()
	
	path = os.path.dirname(os.path.abspath(__file__))
	with open(f'{path}/{pcapid}.pcap', 'rb') as f:
		resp.data = f.read()
		
	resp.headers['Content-Type'] = 'application/octet-stream'
	resp.headers['Content-Disposition'] = f'attachment; filename={pcapid}.pcap'
	return resp

@panorama_api.route(f'/{BASE_URL}/', methods=['GET', 'POST', 'DELETE'])
def beginning():
	commandtype = request.args.get('type')
	command = request.args.get('cmd')
	apikey = request.args.get('key')
	logtype = request.args.get('log-type')
	query = request.args.get('query')
	action = request.args.get('action')
	jobid = request.args.get('job-id')
	xpath = request.args.get('xpath')
	category = request.args.get('category')
	if str(commandtype) == 'op': 
		return opcommands(command,action)
	elif str(commandtype) == 'log' and logtype:
		return logquery(logtype)
	elif str(commandtype) == 'log' and jobid:
		return logresults(jobid)
	elif str(commandtype) == 'commit':
		return commitcommand()
	elif str(commandtype) == 'version':
		return versioncommand()
	elif str(commandtype) == 'user-id':
		return useridcommands(command)
	elif str(commandtype) == 'config':
		return configcommands(xpath)
	elif str(commandtype) == 'export':
		if 'threat-pcap' == category:
			return exportcommand_threat_pcap(request.args.get('pcap-id'))
		else:
			return exportcommands(category)
	else:
		return str(commandtype)
