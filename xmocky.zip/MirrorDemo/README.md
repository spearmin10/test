### Features

- Mirror-in. It pulls changes to a number of ticket fields from ServiceNow mock into XSOAR (see supported fields below)
- Mirror-out. It synchronizes notes tagged with "ForServiceNow" in XSOAR incident War Room to ServiceNow mock
- XMocky Setter. Make changes to ServiceNow mock from XSOAR (see details below)

### Configuration steps

- Upload the custom integration "Mirror_Demo.yml" to XSOAR
- Upload the mapper "mapper-ServiceNow_Mirror_demo.json" to XSOAR
- Upload the classifier "classifier-ServiceNow_Classifier.json" to XSOAR
- Upload the integration file "XMocky_Setter.yml" to XSOAR
- Create a new instance of Demo_Mirror integration in XSOAR
    - Select "ServiceNow Classifier" in Classifier
    - Select "ServiceNow_Mirror_Demo" in Mapper (incoming)
    - URL: https://xmocky.demisto.works:3000

### Run XMocky

Point the Mirror Demo integration instance to https://xmocky.demisto.works:3000

### Change parameters in ServiceNow Mock

- Configure an instance with Server URL "https://xmocky.demisto.works:3000/api/now/mirror/set"
- Run commands to make changes to ServiceNow Mirror mock

Example commands:
```bash
!xmocky-mirror-fetch
!xmocky-mirror-severity
!xmocky-mirror-description
!xmocky-mirror-note
!xmocky-mirror-close
!xmocky-mirror-set
```

    Params:
    close: boolean, closes the ticket in ServiceNow
    fetch: boolean, fetch ticket from ServiceNow
    name: string, modifies the description of the ticket in ServiceNow
    note: string, adds a note to the ticket in ServiceNow
    severity: 1-4 (1-Low .. 4-Critical), modifies the severity in ServiceNow

### Synchronize notes from XSOAR to ServiceNow

- Enter new note in the War Room
- Add the tag "ForServiceNow" to the note
- Wait for max one minute
- Run the following command to verify the note in the War Room has been syncronized to ServiceNow

```bash
!xmocky-mirror-get-note
```