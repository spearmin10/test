from flask import Blueprint, request, Response
import json
import logging

BASE_URL = '/'.strip('/')
INTEGRATION = 'arcsight_api'

arcsight_api = Blueprint(f'{INTEGRATION}', __name__, static_folder='files')
logger = logging.getLogger(__name__)

@arcsight_api.route(f'{BASE_URL}/www/core-service/rest/LoginService/login', methods=['POST', 'GET'])
def login():
    return {
        "log.loginResponse": {
            "log.return": "token1092803981305947830958309"
        }
    }

@arcsight_api.route(f'{BASE_URL}/www/manager-service/rest/QueryViewerService/getMatrixData', methods=['POST', 'GET'])
def fetch_incidents():
    token = request.args.get('token')
    id = request.args.get('id')
    return {
            "qvs.getMatrixDataResponse": {
                "qvs.return": {
                    "endTimestamp": 1589511318966,
                    "startTimestamp": 1589424918966,
                    "timestamp": 1589511430935,
                    "colHeaderTS": 1589511430936,
                    "columnHeaders": [
                        "Name",
                        "End Time",
                        "Attacker Zone URI",
                        "Attacker Address",
                        "Event ID",
                        "Start Time"
                    ],
                    "maxColumns": 6,
                    "properties": "",
                    "rows": [
                        {
                            "@xsi.type": "listWrapper",
                            "value": [
                                {
                                    "@xsi.type": "xs:string",
                                    "$": "Login succeeded for user name 'admin'"
                                },
                                {
                                    "@xsi.type": "xs:string",
                                    "$": "1589424954535"
                                },
                                {
                                    "@xsi.type": "xs:string",
                                    "$": "/All Zones/ArcSight System/Public Address Space Zones/E.I. duPont de Nemours and Co. Inc."
                                },
                                {
                                    "@xsi.type": "xs:string",
                                    "$": "52.213.8.14"
                                },
                                {
                                    "@xsi.type": "xs:string",
                                    "$": "54885808"
                                },
                                {
                                    "@xsi.type": "xs:string",
                                    "$": "1589424954535"
                                }
                            ]
                        },
                        {
                            "@xsi.type": "listWrapper",
                            "value": [
                                {
                                    "@xsi.type": "xs:string",
                                    "$": "Login succeeded for user name 'admin'"
                                },
                                {
                                    "@xsi.type": "xs:string",
                                    "$": "1589425014693"
                                },
                                {
                                    "@xsi.type": "xs:string",
                                    "$": "/All Zones/ArcSight System/Public Address Space Zones/E.I. duPont de Nemours and Co. Inc."
                                },
                                {
                                    "@xsi.type": "xs:string",
                                    "$": "52.213.8.14"
                                },
                                {
                                    "@xsi.type": "xs:string",
                                    "$": "54885883"
                                },
                                {
                                    "@xsi.type": "xs:string",
                                    "$": "1589425014693"
                                }
                            ]
                        },
                        {
                            "@xsi.type": "listWrapper",
                            "value": [
                                {
                                    "@xsi.type": "xs:string",
                                    "$": "Login succeeded for user name 'admin'"
                                },
                                {
                                    "@xsi.type": "xs:string",
                                    "$": "1589425074866"
                                },
                                {
                                    "@xsi.type": "xs:string",
                                    "$": "/All Zones/ArcSight System/Public Address Space Zones/E.I. duPont de Nemours and Co. Inc."
                                },
                                {
                                    "@xsi.type": "xs:string",
                                    "$": "52.213.8.14"
                                },
                                {
                                    "@xsi.type": "xs:string",
                                    "$": "54885966"
                                },
                                {
                                    "@xsi.type": "xs:string",
                                    "$": "1589425074866"
                                }
                            ]
                        },
                        {
                            "@xsi.type": "listWrapper",
                            "value": [
                                {
                                    "@xsi.type": "xs:string",
                                    "$": "Login succeeded for user name 'admin'"
                                },
                                {
                                    "@xsi.type": "xs:string",
                                    "$": "1589425134733"
                                },
                                {
                                    "@xsi.type": "xs:string",
                                    "$": "/All Zones/ArcSight System/Public Address Space Zones/E.I. duPont de Nemours and Co. Inc."
                                },
                                {
                                    "@xsi.type": "xs:string",
                                    "$": "52.213.8.14"
                                },
                                {
                                    "@xsi.type": "xs:string",
                                    "$": "54886042"
                                },
                                {
                                    "@xsi.type": "xs:string",
                                    "$": "1589425134733"
                                }
                            ]
                        },
                        {
                            "@xsi.type": "listWrapper",
                            "value": [
                                {
                                    "@xsi.type": "xs:string",
                                    "$": "Login succeeded for user name 'admin'"
                                },
                                {
                                    "@xsi.type": "xs:string",
                                    "$": "1589425194493"
                                },
                                {
                                    "@xsi.type": "xs:string",
                                    "$": "/All Zones/ArcSight System/Public Address Space Zones/E.I. duPont de Nemours and Co. Inc."
                                },
                                {
                                    "@xsi.type": "xs:string",
                                    "$": "52.213.8.14"
                                },
                                {
                                    "@xsi.type": "xs:string",
                                    "$": "54886117"
                                },
                                {
                                    "@xsi.type": "xs:string",
                                    "$": "1589425194493"
                                }
                            ]
                        },
                        {
                            "@xsi.type": "listWrapper",
                            "value": [
                                {
                                    "@xsi.type": "xs:string",
                                    "$": "Login succeeded for user name 'admin'"
                                },
                                {
                                    "@xsi.type": "xs:string",
                                    "$": "1589425254506"
                                },
                                {
                                    "@xsi.type": "xs:string",
                                    "$": "/All Zones/ArcSight System/Public Address Space Zones/E.I. duPont de Nemours and Co. Inc."
                                },
                                {
                                    "@xsi.type": "xs:string",
                                    "$": "52.213.8.14"
                                },
                                {
                                    "@xsi.type": "xs:string",
                                    "$": "54886215"
                                },
                                {
                                    "@xsi.type": "xs:string",
                                    "$": "1589425254506"
                                }
                            ]
                        }
                    ]
                }
            }
        }

@arcsight_api.route(f'{BASE_URL}/www/manager-service/rest/CaseService/getCaseEventIDs', methods=['POST', 'GET'])
def get_case_event_ids():
    token = request.args.get('token')
    id = request.args.get('id')
    return {
        "cas.getCaseEventIDsResponse": {
            "cas.return": [
                "53170362",
                "53170370"
            ]
        }
    }

@arcsight_api.route(f'{BASE_URL}/www/manager-service/rest/ActiveListService/addEntries', methods=['POST', 'GET'])
def add_entries():
    token = request.args.get('token')
    id = request.args.get('id')
    entries = request.args.get('entries')
    return 'The force is strong with this one. Entries for ID {} have been added successfully.'.format(id)

@arcsight_api.route(f'{BASE_URL}/www/manager-service/rest/ActiveListService/clearEntries', methods=['POST', 'GET'])
def clear_entries():
    token = request.args.get('token')
    id = request.args.get('id')
    entries = request.args.get('entries')
    return 'The force is strong with this one. Entries for {} have been cleared successfully.'.format(id)

@arcsight_api.route(f'{BASE_URL}/www/manager-service/services/ActiveListService/', methods=['POST'])
def get_entries():
    token = request.args.get('token')
    id = request.args.get('id')
    return arcsight_api.send_static_file("arcsight.xml")  

@arcsight_api.route(f'{BASE_URL}/www/manager-service/rest/QueryViewerService/getMatrixData', methods=['POST', 'GET'])
def get_matrix_data():
    token = request.args.get('token')
    id = request.args.get('id')
    return {
        "qvs.getMatrixDataResponse":{
            "qvs.return":{
                "endTimestamp":1589515903192,
                "startTimestamp":1589515903192,
                "timestamp":1589515914836,
                "colHeaderTS":1589515914836,
                "columnHeaders":[
                    "Connector Name",
                    "Connector Type",
                    "Connector Host Name",
                    "Logger Host Name",
                    "Support Information",
                    "Connector URI",
                    "Down Since:"
                ],
                "maxColumns":0,
                "properties":""
            }
        }
    }

@arcsight_api.route(f'{BASE_URL}/www/manager-service/rest/SecurityEventService/getSecurityEvents', methods=['POST', 'GET'])
def get_security_events():
    test = json.loads(request.data)
    event_id = test.get('sev.getSecurityEvents').get('sev.ids')
    result = {u'sev.getSecurityEventsResponse': {u'sev.return': {u'sessionId': -9223372036854775808, u'domainNumber5': -9223372036854775808, u'domainIpv4addr4': -9223372036854775808, u'domainIpv4addr3': -9223372036854775808, u'domainDate5': -9223372036854775808, u'domainIpv4addr1': -9223372036854775808, u'agentSeverity': 1, u'domainNumber12': -9223372036854775808, u'domainNumber13': -9223372036854775808, u'domainNumber10': -9223372036854775808, u'domainNumber11': -9223372036854775808, u'finalDevice': {u'macAddress': -9223372036854775808, u'product': u'ArcSight', u'translatedAddress': -9223372036854775808, u'vendor': u'ArcSight', u'zone': {u'referenceID': 1102, u'uri': u'/All Zones/ArcSight System/Private Address Space Zones/RFC1918: 192.168.0.0-192.168.255.255', u'referenceString': u'<Resource URI="/All Zones/ArcSight System/Private Address Space Zones/RFC1918: 192.168.0.0-192.168.255.255" ID="M-fU32AABABCDVFpYAT3UdQ=="/>', u'isModifiable': False, u'referenceName': u'Zone', u'referenceType': 29, u'managerID': u'V6xxqmYBABCAXZPTkLg+BA==', u'id': u'M-fU32AABABCDVFpYAT3UdQ=='}, u'addressAsBytes': u'wKgBRQ==', u'assetId': u'4Q6xxqmYBABCAWiGUuYaX-w==', u'hostName': u'content.demisto.works', u'version': u'7.0.0.2436.1', u'address': 3232235845, u'assetName': u'content.demisto.works', u'mutable': True, u'assetLocalId': 17179869185}, u'agent': {u'macAddress': -9223372036854775808, u'translatedAddress': -9223372036854775808, u'name': u'Manager Internal Agent', u'zone': {u'referenceID': 1102, u'uri': u'/All Zones/ArcSight System/Private Address Space Zones/RFC1918: 192.168.0.0-192.168.255.255', u'referenceString': u'<Resource URI="/All Zones/ArcSight System/Private Address Space Zones/RFC1918: 192.168.0.0-192.168.255.255" ID="M-fU32AABABCDVFpYAT3UdQ=="/>', u'isModifiable': False, u'referenceName': u'Zone', u'referenceType': 29, u'managerID': u'V6xxqmYBABCAXZPTkLg+BA==', u'id': u'M-fU32AABABCDVFpYAT3UdQ=='}, u'addressAsBytes': u'wKgBRQ==', u'assetId': u'4Q6xxqmYBABCAWiGUuYaX-w==', u'hostName': u'content.demisto.works', u'version': u'7.0.0.2436.1', u'address': 3232235845, u'assetName': u'content.demisto.works', u'mutable': True, u'type': u'arcsight_security_manager', u'id': u'3c6xxqmYBABCAY8SQ92zN9g==', u'assetLocalId': 17179869185}, u'deviceCustomFloatingPoint2': 5e-324, u'flexDate1': -9223372036854775808, u'flexNumber2': -9223372036854775808, u'ttl': 10, u'deviceCustomFloatingPoint1': 5e-324, u'domainNumber6': -9223372036854775808, u'eventId': event_id, u'deviceCustomNumber3': -9223372036854775808, u'deviceCustomDate1': -9223372036854775808, u'deviceCustomNumber1': 0, u'domainIpv4addr2': -9223372036854775808, u'category': {u'deviceGroup': u'/Application', u'object': u'/Host/Application', u'behavior': u'/Execute/Response', u'significance': u'/Informational', u'mutable': True, u'outcome': u'/Success'}, u'priority': 3, u'correlatedEventCount': 0, u'severity': 0, u'domainNumber1': -9223372036854775808, u'startTime': 1589131920000, u'destination': {u'macAddress': -9223372036854775808, u'translatedAddress': -9223372036854775808, u'zone': {u'referenceID': 1102, u'uri': u'/All Zones/ArcSight System/Private Address Space Zones/RFC1918: 192.168.0.0-192.168.255.255', u'referenceString': u'<Resource URI="/All Zones/ArcSight System/Private Address Space Zones/RFC1918: 192.168.0.0-192.168.255.255" ID="M-fU32AABABCDVFpYAT3UdQ=="/>', u'isModifiable': False, u'referenceName': u'Zone', u'referenceType': 29, u'managerID': u'V6xxqmYBABCAXZPTkLg+BA==', u'id': u'M-fU32AABABCDVFpYAT3UdQ=='}, u'addressAsBytes': u'wKgBRQ==', u'assetId': u'4Q6xxqmYBABCAWiGUuYaX-w==', u'hostName': u'content.demisto.works', u'processId': -2147483648, u'translatedPort': -2147483648, u'address': 3232235845, u'assetName': u'content.demisto.works', u'mutable': True, u'geo': {u'latitude': 0, u'mutable': True, u'longitudeLong': 0, u'longitude': 0, u'latitudeLong': 0}, u'port': -2147483648, u'assetLocalId': 17179869185}, u'domainNumber2': -9223372036854775808, u'deviceCustomNumber2': -9223372036854775808, u'domainFp3': 5e-324, u'domainFp2': 5e-324, u'domainFp1': 5e-324, u'domainNumber3': -9223372036854775808, u'domainFp7': 5e-324, u'deviceCustomDate2': -9223372036854775808, u'concentratorDevices': {u'macAddress': -9223372036854775808, u'product': u'ArcSight', u'translatedAddress': -9223372036854775808, u'vendor': u'ArcSight', u'zone': {u'referenceID': 1102, u'uri': u'/All Zones/ArcSight System/Private Address Space Zones/RFC1918: 192.168.0.0-192.168.255.255', u'referenceString': u'<Resource URI="/All Zones/ArcSight System/Private Address Space Zones/RFC1918: 192.168.0.0-192.168.255.255" ID="M-fU32AABABCDVFpYAT3UdQ=="/>', u'isModifiable': False, u'referenceName': u'Zone', u'referenceType': 29, u'managerID': u'V6xxqmYBABCAXZPTkLg+BA==', u'id': u'M-fU32AABABCDVFpYAT3UdQ=='}, u'addressAsBytes': u'wKgBRQ==', u'assetId': u'4Q6xxqmYBABCAWiGUuYaX-w==', u'hostName': u'content.demisto.works', u'version': u'7.0.0.2436.1', u'address': 3232235845, u'assetName': u'content.demisto.works', u'mutable': True, u'assetLocalId': 17179869185}, u'domainFp4': 5e-324, u'domainNumber8': -9223372036854775808, u'deviceSeverity': u'Warning', u'deviceDirection': -2147483648, u'domainFp8': 5e-324, u'type': u'BASE', u'persistence': -2147483648, u'domainFp6': 5e-324, u'originator': u'SOURCE', u'deviceCustomFloatingPoint4': 5e-324, u'concentratorAgents': {u'macAddress': -9223372036854775808, u'translatedAddress': -9223372036854775808, u'name': u'Manager Internal Agent', u'zone': {u'referenceID': 1102, u'uri': u'/All Zones/ArcSight System/Private Address Space Zones/RFC1918: 192.168.0.0-192.168.255.255', u'referenceString': u'<Resource URI="/All Zones/ArcSight System/Private Address Space Zones/RFC1918: 192.168.0.0-192.168.255.255" ID="M-fU32AABABCDVFpYAT3UdQ=="/>', u'isModifiable': False, u'referenceName': u'Zone', u'referenceType': 29, u'managerID': u'V6xxqmYBABCAXZPTkLg+BA==', u'id': u'M-fU32AABABCDVFpYAT3UdQ=='}, u'addressAsBytes': u'wKgBRQ==', u'assetId': u'4Q6xxqmYBABCAWiGUuYaX-w==', u'hostName': u'content.demisto.works', u'version': u'7.0.0.2436.1', u'address': 3232235845, u'assetName': u'content.demisto.works', u'mutable': True, u'type': u'arcsight_security_manager', u'id': u'3c6xxqmYBABCAY8SQ92zN9g==', u'assetLocalId': 17179869185}, u'domainFp5': 5e-324, u'deviceCustomFloatingPoint3': 5e-324, u'deviceCustom': {u'mutable': True, u'string1Label': u'Unit', u'number1Label': u'Temporary Active list count (Count)', u'string2Label': u'Time Frame'}, u'baseEventCount': 0, u'domainNumber7': -9223372036854775808, u'bytesOut': -2147483648, u'managerId': -128, u'deviceReceiptTime': 1589131920000, u'domainDate2': -9223372036854775808, u'domainDate1': -9223372036854775808, u'flexNumber1': -9223372036854775808, u'domainDate6': -9223372036854775808, u'aggregatedEventCount': 1, u'domainDate4': -9223372036854775808, u'device': {u'macAddress': -9223372036854775808, u'product': u'ArcSight', u'translatedAddress': -9223372036854775808, u'vendor': u'ArcSight', u'zone': {u'referenceID': 1102, u'uri': u'/All Zones/ArcSight System/Private Address Space Zones/RFC1918: 192.168.0.0-192.168.255.255', u'referenceString': u'<Resource URI="/All Zones/ArcSight System/Private Address Space Zones/RFC1918: 192.168.0.0-192.168.255.255" ID="M-fU32AABABCDVFpYAT3UdQ=="/>', u'isModifiable': False, u'referenceName': u'Zone', u'referenceType': 29, u'managerID': u'V6xxqmYBABCAXZPTkLg+BA==', u'id': u'M-fU32AABABCDVFpYAT3UdQ=='}, u'addressAsBytes': u'wKgBRQ==', u'assetId': u'4Q6xxqmYBABCAWiGUuYaX-w==', u'hostName': u'content.demisto.works', u'version': u'7.0.0.2436.1', u'address': 3232235845, u'assetName': u'content.demisto.works', u'mutable': True, u'assetLocalId': 17179869185}, u'deviceEventClassId': u'monitor:118', u'deviceCustomString2': u'current value', u'deviceCustomString1': u'Count', u'eventAnnotation': {u'eventId': 54501359, u'stageUpdateTime': 1589131920000, u'modificationTime': 1589131920000, u'version': 1, u'flags': 0, u'auditTrail': u'1,1590051653867,root,Queued,,,,', u'managerReceiptTime': 1589131920000, u'endTime': 1589131920000, u'stage': {u'referenceID': 2209, u'uri': u'/All Stages/Queued', u'referenceString': u'<Resource URI="/All Stages/Queued" ID="R9MHiNfoAABCASsxbPIxG0g=="/>', u'isModifiable': False, u'referenceName': u'Stage', u'referenceType': 34, u'managerID': u'V6xxqmYBABCAXZPTkLg+BA==', u'id': u'R9MHiNfoAABCASsxbPIxG0g=='}}, u'domainDate3': -9223372036854775808, u'domainNumber4': -9223372036854775808, u'name': u'Monitor Event', u'relevance': 10, u'deviceEventCategory': u'/Monitor/ActiveLists/TemporaryListCount', u'agentReceiptTime': -9223372036854775808, u'locality': 0, u'assetCriticality': 0, u'deviceProcessId': -2147483648, u'originalAgent': {u'macAddress': -9223372036854775808, u'translatedAddress': -9223372036854775808, u'name': u'Manager Internal Agent', u'zone': {u'referenceID': 1102, u'uri': u'/All Zones/ArcSight System/Private Address Space Zones/RFC1918: 192.168.0.0-192.168.255.255', u'referenceString': u'<Resource URI="/All Zones/ArcSight System/Private Address Space Zones/RFC1918: 192.168.0.0-192.168.255.255" ID="M-fU32AABABCDVFpYAT3UdQ=="/>', u'isModifiable': False, u'referenceName': u'Zone', u'referenceType': 29, u'managerID': u'V6xxqmYBABCAXZPTkLg+BA==', u'id': u'M-fU32AABABCDVFpYAT3UdQ=='}, u'addressAsBytes': u'wKgBRQ==', u'assetId': u'4Q6xxqmYBABCAWiGUuYaX-w==', u'hostName': u'content.demisto.works', u'version': u'7.0.0.2436.1', u'address': 3232235845, u'assetName': u'content.demisto.works', u'mutable': True, u'type': u'arcsight_security_manager', u'id': u'3c6xxqmYBABCAY8SQ92zN9g==', u'assetLocalId': 17179869185}, u'modelConfidence': 4, u'domainNumber9': -9223372036854775808, u'managerReceiptTime': 1589131920000, u'endTime': 1589131920000, u'bytesIn': -2147483648}}}    
    return json.dumps(result)

@arcsight_api.route(f'{BASE_URL}/www/manager-service/rest/CaseService/update', methods=['POST', 'GET'])
def update_case():
    token = request.args.get('token')
    id = request.args.get('id')
    return {
        "cas.updateResponse": {
                "cas.return": {
                    "attributeInitializationInProgress":False,
                    "createdTime": {
                        "day":10,
                        "hour":5,
                        "milliSecond":811,
                        "minute":37,
                        "month":4,
                        "second":26,
                        "timezoneID":"America/New_York",
                        "year":2020 },
                    "createdTimestamp":1589103446811,
                    "creatorName":"admin",
                    "deprecated":False,
                    "disabled":False,
                    "inCache":True,
                    "inactive":False,
                    "initialized":True,
                    "isAdditionalLoaded":False,
                    "localID":30064771095,
                    "modificationCount":0,
                    "modifiedTime":{
                        "day":10,
                        "hour":5,
                        "milliSecond":811,
                        "minute":37,
                        "month":4,
                        "second":26,
                        "timezoneID":"America/New_York",
                        "year":2020},
                    "modifiedTimestamp":1589103446811,
                    "modifierName":"admin",
                    "name":"BarC_case",
                    "reference":{
                        "id":"7bgfy-XEBABCAD7Y9AVwrTA==",
                        "isModifiable":True,
                        "managerID":"V6xxqmYBABCAXZPTkLg+BA==",
                        "referenceName":"Case",
                        "referenceString":"<Resource URI=\"/All Cases/All Cases/Personal/admin's Cases/BarC_case\" ID=\"7bgfy-XEBABCAD7Y9AVwrTA==\"/>",
                        "referenceType":7,
                        "uri":"/All Cases/All Cases/Personal/admin's Cases/BarC_case"},
                    "resourceid":"7bgfy-XEBABCAD7Y9AVwrTA==",
                    "state":2,
                    "type":7,
                    "typeName":"Case",
                    "URI":"/All Cases/All Cases/Personal/admin's Cases/BarC_case",
                    "action":"BLOCK_OR_SHUTDOWN",
                    "actionsTaken":"",
                    "affectedElements":"",
                    "affectedServices":"",
                    "affectedSites":"",
                    "associatedImpact":"AVAILABILITY",
                    "attackAddress":"",
                    "attackAgent":"INSIDER",
                    "attackImpact":"",
                    "attackLocationID":"",
                    "attackMechanism":"PHYSICAL",
                    "attackNode":"",
                    "attackOS":"",
                    "attackProgram":"",
                    "attackProtocol":"",
                    "attackService":"",
                    "attackTarget":"",
                    "conclusions":"",
                    "consequenceSeverity":"NONE",
                    "displayID":30003,
                    "estimatedImpact":"",
                    "finalReportAction":"",
                    "followupContact":"",
                    "frequency":"NEVER_OR_ONCE",
                    "history":"KNOWN_OCCURENCE",
                    "incidentSource1":"",
                    "incidentSource2":"",
                    "inspectionResults":"",
                    "numberOfOccurences":0,
                    "operationalImpact":"NO_IMPACT",
                    "plannedActions":"",
                    "recommendedActions":"",
                    "recordedData":"",
                    "reportingLevel":0,
                    "resistance":"HIGH",
                    "securityClassification":"UNCLASSIFIED",
                    "securityClassificationCode":"P I   D U A B ",
                    "sensitivity":"UNCLASSIFIED",
                    "sourceAddress":"",
                    "stage":"QUEUED",
                    "ticketType":"INTERNAL",
                    "vulnerability":"DESIGN",
                    "vulnerabilityData":"",
                    "vulnerabilityEvidence":"",
                    "vulnerabilitySource":"",
                    "vulnerabilityType1":"ACCIDENTAL",
                    "vulnerabilityType2":"EMI_RFI"
                }

        }
    }

@arcsight_api.route(f'{BASE_URL}/www/manager-service/rest/CaseService/deleteByUUID', methods=['POST', 'GET'])
def delete_case():
    token = request.args.get('token')
    id = request.args.get('id')
    return 'Case {} successfully deleted. May the Force be with you.'.format(id)

@arcsight_api.route(f'{BASE_URL}/www/manager-service/rest/CaseService/findAllIds', methods=['POST', 'GET'])
def get_all_cases():
    token = request.args.get('token')
    return {
      "cas.findAllIdsResponse": {
        "cas.return": [
          "7-TbDfGkBABCenF0601F2Ww==",
          "72nmUEWcBABD6cSFwTn5Fog==",
          "73lpEo2gBABCBcJbK9kU04Q==",
          "753NQAmcBABD1LUpYORm-+g==",
          "77ax-uGgBABCWb2puJdY8ZA==",
          "7A8CadWgBABDThEte7VW6Ww==",
          "7Cqfri2gBABD73Fl9NVxl-Q==",
          "7DAYkEWcBABD6GUL31fznAg==",
          "7Fst+6mYBABCSNY-P39vpWQ==",
          "7I5CREWcBABD6apuLKBkNrg==",
          "7LAULEWcBABD5uPwRG3ToQA==",
          "7Pfn9LmkBABDhwM9jlhjB4A==",
          "7RYlCo2gBABCBOqmcdMamsQ==",
          "7UKGREWcBABD6a2oi4L4CPg==",
          "7WU9Io2gBABCB5TTyD0hkcw==",
          "7ZIxZAmcBABD1OAgINnAxig==",
          "7ZTWadWgBABDTgctVuwQg-A==",
          "7aUEKhHABABDuvpXaQ497sQ==",
          "7bgfy-XEBABCAD7Y9AVwrTA==",
          "7r-lOJWoBABDbYj87Hiv4yA==",
          "7uZlqvHEBABDmMHb-MM+jnA==",
          "7yo9ZFnIBABD+-8h-A8Xawg=="
        ]
      }
    }

@arcsight_api.route(f'{BASE_URL}/www/manager-service/rest/CaseService/getResourceById', methods=['POST', 'GET'])
def get_case():
    token = request.args.get('token')
    resource = request.args.get('resourceId')
    return {
        "cas.getResourceByIdResponse": {
            "cas.return": {
                "attributeInitializationInProgress":False,
                "createdTime": {
                    "day":10,
                    "hour":5,
                    "milliSecond":811,
                    "minute":37,
                    "month":4,
                    "second":26,
                    "timezoneID":"America/New_York",
                    "year":2020 },
                "createdTimestamp":1589103446811,
                "creatorName":"admin",
                "deprecated":False,
                "disabled":False,
                "inCache":True,
                "inactive":False,
                "initialized":True,
                "isAdditionalLoaded":False,
                "localID":30064771095,
                "modificationCount":0,
                "modifiedTime":{
                    "day":10,
                    "hour":5,
                    "milliSecond":811,
                    "minute":37,
                    "month":4,
                    "second":26,
                    "timezoneID":"America/New_York",
                    "year":2020},
                "modifiedTimestamp":1589103446811,
                "modifierName":"admin",
                "name":"BarC_case",
                "reference":{
                    "id":"7bgfy-XEBABCAD7Y9AVwrTA==",
                    "isModifiable":True,
                    "managerID":"V6xxqmYBABCAXZPTkLg+BA==",
                    "referenceName":"Case",
                    "referenceString":"<Resource URI=\"/All Cases/All Cases/Personal/admin's Cases/BarC_case\" ID=\"7bgfy-XEBABCAD7Y9AVwrTA==\"/>",
                    "referenceType":7,
                    "uri":"/All Cases/All Cases/Personal/admin's Cases/BarC_case"},
                "resourceid":"7bgfy-XEBABCAD7Y9AVwrTA==",
                "state":2,
                "type":7,
                "typeName":"Case",
                "URI":"/All Cases/All Cases/Personal/admin's Cases/BarC_case",
                "action":"BLOCK_OR_SHUTDOWN",
                "actionsTaken":"",
                "affectedElements":"",
                "affectedServices":"",
                "affectedSites":"",
                "associatedImpact":"AVAILABILITY",
                "attackAddress":"",
                "attackAgent":"INSIDER",
                "attackImpact":"",
                "attackLocationID":"",
                "attackMechanism":"PHYSICAL",
                "attackNode":"",
                "attackOS":"",
                "attackProgram":"",
                "attackProtocol":"",
                "attackService":"",
                "attackTarget":"",
                "conclusions":"",
                "consequenceSeverity":"NONE",
                "displayID":30003,
                "estimatedImpact":"",
                "finalReportAction":"",
                "followupContact":"",
                "frequency":"NEVER_OR_ONCE",
                "history":"KNOWN_OCCURENCE",
                "incidentSource1":"",
                "incidentSource2":"",
                "inspectionResults":"",
                "numberOfOccurences":0,
                "operationalImpact":"NO_IMPACT",
                "plannedActions":"",
                "recommendedActions":"",
                "recordedData":"",
                "reportingLevel":0,
                "resistance":"HIGH",
                "securityClassification":"UNCLASSIFIED",
                "securityClassificationCode":"P I   D U A B ",
                "sensitivity":"UNCLASSIFIED",
                "sourceAddress":"",
                "stage":"QUEUED",
                "ticketType":"INTERNAL",
                "vulnerability":"DESIGN",
                "vulnerabilityData":"",
                "vulnerabilityEvidence":"",
                "vulnerabilitySource":"",
                "vulnerabilityType1":"ACCIDENTAL",
                "vulnerabilityType2":"EMI_RFI"
            }
        }
    }

@arcsight_api.route(f'{BASE_URL}/www/manager-service/rest/QueryViewerService/findAllIds', methods=['POST', 'GET'])
def get_all_query_viewers():
    token = request.args.get('token')
    return {
        "qvs.findAllIdsResponse":{
            "qvs.return":[
                "c-h-o7WYBABCw9lZRkCjVIQ==",
                "c-mvjrlkBABCJREkQ7PrIRg==",
                "c05DPpy4BABCN9NYml6MSoA==",
                "c0whQRz4BABCuqn4+C6HufA==",
                "c2ES6hkUBABCaEEelXejPWA==",
                "c2cgVHz4BABDjAGTT-dWLAQ==",
                "c3WQDkGgBABCSE4xTfadMeQ==",
                "c4AQK-SYBABDSpmBQmrFaig==",
                "c6apERz4BABD5KKI-ZnEOlw==",
                "c8aY3azABABCKqzOifkNMsA==",
                "c9SI-B0YBABCGa8iu+1oD-A==",
                "cAnYPEygBABCN4FaqNNfZUQ==",
                "cBKjNpy4BABCN8NYml6MSoA==",
                "cEnrMEUABABCXZXdPkoIwKg==",
                "cGDAg-SYBABDXyWBQmrFaig==",
                "cHOuDEWcBABDhXJ3Sk4O4wA==",
                "cHrC2hkUBABCZzHyy+HVfuQ==",
                "cHwS0hkUBABCZmirq-kQM8g==",
                "cI2G5EUABABCQSibG9qMVbA==",
                "cIALbCCwBABCGVWkl6Ri5Jw==",
                "cIfycGycBABCBDAhbhzzEwA==",
                "cJ37PMj4BABCWXl3XQ0hdew==",
                "cK38W-SYBABDUa2BQmrFaig==",
                "cKYc7eyUBABCKtbPQBcQE3A==",
                "cLLnu5XEBABCJHuGRQA-nwg==",
                "cLj8rSEQBABCDtiXX7k6Ojw==",
                "cMVeFhkUBABCWfUvwUQDX0Q==",
                "cMndjEygBABCXolaqNNfZUQ==",
                "cMqw4o2gBABDsHQy+rOymtg==",
                "cOXQgSEQBABCDd0-RKaaxIA==",
                "cOh3QEUABABCcR+kBIsCPhg==",
                "cOsLIFHABABCPPsony7eevw==",
                "cPFAI-SYBABDSQGBQmrFaig==",
                "cST19hkUBABCUN9LMfZe7rw==",
                "cSWuxhkUBABCZZvcgCLwm7g==",
                "cSn8Z-SYBABDVM2BQmrFaig==",
                "cTEszCSwBABCKF2kl6Ri5Jw==",
                "cTzA1Iz4BABCg5g6gT7PyyQ==",
                "cUhYeSEQBABCDZYqGTFGnBg==",
                "cVq4kSEQBABCDlKVXxzLuIw==",
                "cWKzm-CYBABDNSGBQmrFaig==",
                "cWorh9DIBABCKGFhyqwKAPQ==",
                "cXW4CClkBABCpHH-mBilbyQ==",
                "cXeV4jiUBABCtS7PQBcQE3A==",
                "cYT8sRz4BABDWUoFC-aHRug==",
                "cZ3+eej4BABDO4k-jQlxntA==",
                "cZN1fK0YBABCj+xKgOE7TYw==",
                "cacZBjyUBABC1PLPQBcQE3A==",
                "catoxazABABCGbjOifkNMsA==",
                "cc+VvEygBABC+2FaqNNfZUQ==",
                "cc0R0n2kBABDS+8y7-Jfzbw==",
                "cd0RijyUBABC56rPQBcQE3A==",
                "cdnoGZz4BABDo+lcX+VJe+A==",
                "chDynzEcBABCCWG8MJLGbIw==",
                "ciJAiSEQBABCDhV+MfrM0Bg==",
                "cjWTqz14BABCMT1VYXUiVDg==",
                "cjdwsSEQBABCDxPvEjdnG7Q==",
                "ckJH85m8BABCInqj9fwVhbw==",
                "ckWcqAScBABCM+2BQmrFaig==",
                "ckbw7Rz4BABDsdeGfhL3IJw==",
                "ckcPfo2gBABCPzbPn2goxRQ==",
                "clP0uSEQBABCD321e0-Dttg==",
                "clo6P-SYBABDhDWBQmrFaig==",
                "cm8ryR2kBABCl7bvfR8rZ-A==",
                "cmG5ZEygBABD+C1aqNNfZUQ==",
                "cpaG3wF4BABCFAd494ZudqA==",
                "cpnQX-SYBABDUfmBQmrFaig==",
                "cq-jKpy4BABCN7NYml6MSoA==",
                "csBS4hkUBABCZ5W7P6xxdow==",
                "ctAklHEABABCAPDVySXfypg==",
                "ctUWGn10BABCCTu3UVCfBCw==",
                "cuontACYBABCDQL4cHP-GTA==",
                "curmV-SYBABDjpmBQmrFaig==",
                "cwKKO-SYBABDhA2BQmrFaig==",
                "cxe9oK0YBABCs-Sfbzm6v3w==",
                "cyUJKRz4BABCFwS9iFPq+aA=="
            ]
        }
    }

@arcsight_api.route(f'{BASE_URL}/www/manager-service/rest/QueryViewerService/getMatrixData', methods=['POST', 'GET'])
def get_query_viewer_results():
    token = request.get.args('token')
    id = request.get.args('queryid')
    return {
      "qvs.getMatrixDataResponse": {
        "qvs.return": {
          "endTimestamp": 1589511318966,
          "startTimestamp": 1589424918966,
          "timestamp": 1589511430935,
          "colHeaderTS": 1589511430936,
          "columnHeaders": [
            "Name",
            "End Time",
            "Attacker Zone URI",
            "Attacker Address",
            "Event ID",
            "Start Time"
          ],
          "maxColumns": 6,
          "properties": "",
          "rows": [
            {
              "@xsi.type": "listWrapper",
              "value": [
                {
                  "@xsi.type": "xs:string",
                  "$": "Login succeeded for user name 'admin'"
                },
                {
                  "@xsi.type": "xs:string",
                  "$": "1589424954535"
                },
                {
                  "@xsi.type": "xs:string",
                  "$": "/All Zones/ArcSight System/Public Address Space Zones/E.I. duPont de Nemours and Co. Inc."
                },
                {
                  "@xsi.type": "xs:string",
                  "$": "52.213.8.14"
                },
                {
                  "@xsi.type": "xs:string",
                  "$": "54885808"
                },
                {
                  "@xsi.type": "xs:string",
                  "$": "1589424954535"
                }
              ]
            },
            {
              "@xsi.type": "listWrapper",
              "value": [
                {
                  "@xsi.type": "xs:string",
                  "$": "Login succeeded for user name 'admin'"
                },
                {
                  "@xsi.type": "xs:string",
                  "$": "1589425014693"
                },
                {
                  "@xsi.type": "xs:string",
                  "$": "/All Zones/ArcSight System/Public Address Space Zones/E.I. duPont de Nemours and Co. Inc."
                },
                {
                  "@xsi.type": "xs:string",
                  "$": "52.213.8.14"
                },
                {
                  "@xsi.type": "xs:string",
                  "$": "54885883"
                },
                {
                  "@xsi.type": "xs:string",
                  "$": "1589425014693"
                }
              ]
            },
            {
              "@xsi.type": "listWrapper",
              "value": [
                {
                  "@xsi.type": "xs:string",
                  "$": "Login succeeded for user name 'admin'"
                },
                {
                  "@xsi.type": "xs:string",
                  "$": "1589425074866"
                },
                {
                  "@xsi.type": "xs:string",
                  "$": "/All Zones/ArcSight System/Public Address Space Zones/E.I. duPont de Nemours and Co. Inc."
                },
                {
                  "@xsi.type": "xs:string",
                  "$": "52.213.8.14"
                },
                {
                  "@xsi.type": "xs:string",
                  "$": "54885966"
                },
                {
                  "@xsi.type": "xs:string",
                  "$": "1589425074866"
                }
              ]
            },
            {
              "@xsi.type": "listWrapper",
              "value": [
                {
                  "@xsi.type": "xs:string",
                  "$": "Login succeeded for user name 'admin'"
                },
                {
                  "@xsi.type": "xs:string",
                  "$": "1589425134733"
                },
                {
                  "@xsi.type": "xs:string",
                  "$": "/All Zones/ArcSight System/Public Address Space Zones/E.I. duPont de Nemours and Co. Inc."
                },
                {
                  "@xsi.type": "xs:string",
                  "$": "52.213.8.14"
                },
                {
                  "@xsi.type": "xs:string",
                  "$": "54886042"
                },
                {
                  "@xsi.type": "xs:string",
                  "$": "1589425134733"
                }
              ]
            },
            {
              "@xsi.type": "listWrapper",
              "value": [
                {
                  "@xsi.type": "xs:string",
                  "$": "Login succeeded for user name 'admin'"
                },
                {
                  "@xsi.type": "xs:string",
                  "$": "1589425194493"
                },
                {
                  "@xsi.type": "xs:string",
                  "$": "/All Zones/ArcSight System/Public Address Space Zones/E.I. duPont de Nemours and Co. Inc."
                },
                {
                  "@xsi.type": "xs:string",
                  "$": "52.213.8.14"
                },
                {
                  "@xsi.type": "xs:string",
                  "$": "54886117"
                },
                {
                  "@xsi.type": "xs:string",
                  "$": "1589425194493"
                }
              ]
            },
            {
              "@xsi.type": "listWrapper",
              "value": [
                {
                  "@xsi.type": "xs:string",
                  "$": "Login succeeded for user name 'admin'"
                },
                {
                  "@xsi.type": "xs:string",
                  "$": "1589425254506"
                },
                {
                  "@xsi.type": "xs:string",
                  "$": "/All Zones/ArcSight System/Public Address Space Zones/E.I. duPont de Nemours and Co. Inc."
                },
                {
                  "@xsi.type": "xs:string",
                  "$": "52.213.8.14"
                },
                {
                  "@xsi.type": "xs:string",
                  "$": "54886215"
                },
                {
                  "@xsi.type": "xs:string",
                  "$": "1589425254506"
                }
              ]
            }
          ]
        }
      }
    }