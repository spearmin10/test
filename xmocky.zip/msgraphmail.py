from flask import Blueprint, request
import json
import logging
from datetime import datetime

BASE_URL = 'msgraphmail/v1.0'.strip('/')
INTEGRATION = 'msgraphmail_api'

mock_folders_max = 5

mock_folders_list = [
    {
        "id": "3495875698wsdfojhfsdog097345h",
        "displayName": "Suspected spam",
        "parentFolderId": "09374598743oisdgoihfsdg",
        "childFolderCount": 0,
        "unreadItemCount": 15,
        "totalItemCount": 512
    },
    {
        "id": "09374598743oisdgoihfsdg",
        "displayName": "Suspect items",
        "parentFolderId": "908834985745sodfoihsdfg987sf",
        "childFolderCount": 1,
        "unreadItemCount": 0,
        "totalItemCount": 0
    },
    {
        "id": "908834985745sodfoihsdfg987sf",
        "displayName": "My Folders",
        "parentFolderId": "sdiufhsg76823u5r098sg87tbsf",
        "childFolderCount": 1,
        "unreadItemCount": 0,
        "totalItemCount": 0
    },
{
        "id": "sdiufhsg76823u5r098sg87tbsf",
        "displayName": "Inbox",
        "parentFolderId": "",
        "childFolderCount": 1,
        "unreadItemCount": 340,
        "totalItemCount": 10864
    }
]

mock_attachemnt_list = {
    "value": [
        {
            "id": "765457-543456-2345-2397-asdfg",
            "name": "MockAttachment.pdf",
            "contentType": "application/pdf"
        }
    ]
}

mock_attachment = {
    "name": "MockAttachment.pdf",
    "contentBytes": "JVBERi0xLjUKJb/3ov4KMiAwIG9iago8PCAvTGluZWFyaXplZCAxIC9MIDE1NjE3IC9IIFsgNjg3IDEyNiBdIC9PIDYgL0UgMTUzNDIgL04gMSAvVCAxNTM0MSA+PgplbmRvYmoKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKMyAwIG9iago8PCAvVHlwZSAvWFJlZiAvTGVuZ3RoIDUwIC9GaWx0ZXIgL0ZsYXRlRGVjb2RlIC9EZWNvZGVQYXJtcyA8PCAvQ29sdW1ucyA0IC9QcmVkaWN0b3IgMTIgPj4gL1cgWyAxIDIgMSBdIC9JbmRleCBbIDIgMTUgXSAvSW5mbyAxMSAwIFIgL1Jvb3QgNCAwIFIgL1NpemUgMTcgL1ByZXYgMTUzNDIgICAgICAgICAgICAgICAgIC9JRCBbPGZjOTYzNWY4MDFjNTcxOTE1MGQ4ODkwYzZjMWZkMGJhPjxmYzk2MzVmODAxYzU3MTkxNTBkODg5MGM2YzFmZDBiYT5dID4+CnN0cmVhbQp4nGNiZOBnYGJgOAkkmJaCWEZAgrEORNwHEceBhLETiFXMwMR4vAmkhIERGwEAGOcGMAplbmRzdHJlYW0KZW5kb2JqCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCjQgMCBvYmoKPDwgL1BhZ2VzIDE0IDAgUiAvVHlwZSAvQ2F0YWxvZyA+PgplbmRvYmoKNSAwIG9iago8PCAvRmlsdGVyIC9GbGF0ZURlY29kZSAvUyAzNiAvTGVuZ3RoIDQ5ID4+CnN0cmVhbQp4nGNgYGBlYGBazwAEFgcZ4ADKZgZiFoQoSC0YMzDcZ+BjYODriTgwhU2GAQCrOgYPCmVuZHN0cmVhbQplbmRvYmoKNiAwIG9iago8PCAvQ29udGVudHMgNyAwIFIgL01lZGlhQm94IFsgMCAwIDYxMiA3OTIgXSAvUGFyZW50IDE0IDAgUiAvUmVzb3VyY2VzIDw8IC9FeHRHU3RhdGUgPDwgL0czIDEyIDAgUiA+PiAvRm9udCA8PCAvRjQgMTMgMCBSID4+IC9Qcm9jU2V0IFsgL1BERiAvVGV4dCAvSW1hZ2VCIC9JbWFnZUMgL0ltYWdlSSBdID4+IC9TdHJ1Y3RQYXJlbnRzIDAgL1R5cGUgL1BhZ2UgPj4KZW5kb2JqCjcgMCBvYmoKPDwgL0ZpbHRlciAvRmxhdGVEZWNvZGUgL0xlbmd0aCAzODQgPj4Kc3RyZWFtCnicxVRRSwMxDH7vr+izsC5pk7QFEdyce1YO/AHqBsIE5/8He71zd4MFt8n0CnclX/Ml6X0JWihrguUVs7fPG/NhWougr4btq3m6su/F6iLXs9/fchRtux6Xttts12a6DHb9WRkSikVgaSlWR1keyhpHR+f59wnwBcizVPYscC55TzVrzPSeLJITzuVJtlkZHP4J2GZjSrQJYtm+2GuAEG9s82aSy+zFY8vYATTrAeRyOqYBmFcglKQEKYcdwFKB6IJP6AcmCNVODiLmyPESTKQkq3oEqAB65yHFCIMLe61wJStanJit7+4cwXEiHymcH5uT4sBqfaS64ABAHgeJo0IyDgV2t75oLqxYL+Q4h+I8Em5/uxcPXtsl/EtU3glmrihJbwite1WFcdCkp+lFDc5zRaxq7JNDHCXi/TLutGGjZqWUodfNPZASCPERV6jOLYoaoM5MtfDbEeDD4TIE6HC7j4E9UY2Y9nISkp/n+F8NjhQdSaqDg+FgC38B11HMuGVuZHN0cmVhbQplbmRvYmoKOCAwIG9iago8PCAvRmlsdGVyIC9GbGF0ZURlY29kZSAvTGVuZ3RoMSAyMjIyOCAvTGVuZ3RoIDEyNzc4ID4+CnN0cmVhbQp4nO18CXhURfbvqbpb7317X5O+nU53IB0SSAJZiKQDCYuRHTFBIgkQIQiSBRAUNIwiGBeQcZ8ZwR11lCYEDKhDRhnHHVxn1FFQ4zZOhJm/4oJJv1O3EwwuT//f275539yb+tWpqnPPrTp16tSpphsgACAj8ABTZ+bkbs1uvxCAGLB29uzyyVXTti75AssLASw3LFhW1wgGGA9g/QrbsxasWqHc1PjyKgBbOoA4/PzGRcsuyrgf+T2zAIT4orqWRnCDFiDAs7csWrrm/BHHu0UARQPgW7V44bLVrx2s2gkwuhVAq1lcX7fw2aITm5H/MPKPWowV1mWGIwDlm7CcvnjZitX1Ee1RLP8e+7Ri6fIFdW0tNziR347tjy2rW90ocIZfA4xXsKxcWLesvq7M4MNyDPvT1Li8ZUUiE24CqOxg7Y3N9Y2fPtT0HpZfBdD1AuE2kS0gIO9tQh6+wZfMuZfgfGrVCFQv8pRdbDSnXZOXX7gcYgm8hFf6ppM8aQxpjwHBcj8DBxxhl8BxhBICbuEf+i74SpMADWgSfagjbaIXdKBD1IMe0QAGRCMYEU0qmsGEKIMZ0YL4LVjBgmgDK6IdbIgOxJPgBDuiCxyIbsRvwAMupL3gQdoHXkS/iingQ0wFf+JrCKioQApiEAKIaaAghhC/gnQIIoYhDTGC+CVkQAhxCKQjDoUIYqaKUchInIAsGII4TMVsyETMgSjicBiGOALxC8iFbMQ8yEHMh+GJz2GkiqNgBGIB5CEWQn7iv6BIxWIYiThaxRIYhXgGFCCOgULEUihK/AtiUIxYBqMRx0IJ4jjEf0I5nIFYAWMQx0Np4jhMwBk7DhOhDHESjEU8U8VKGId4FpQjTobxiWMwRcWpMAFxGkxEnA6TEp/BDBVnwpmIs6Ay0QNnw2TE2SqeA1MQq2Bq4h9QDdMQ5yD2wLkwHem5MBOxBmYhnqfiPDg78SnUwmzEOjgHcT7i32EBVCMuhDmI9XAu4vkwN/EJLFJxMdQgNsB5iY9hCdQifYGKS6EOcRnMx/oLYQHichUbYWHiI2iCesRmWITYouIKWJz4EFZCA+IqWIJ4EeIHsBouQFwDyxAvhgsRL1FxLSxHXAeNiJdCU6IbLlOxFVoQ18MKxF/BysT7cDmsQrxCxQ1wUeI9uBJWI26ENYib4GLEq+CSxLvQBmsRr4Z1WHMN4rtwLVyKeB1chrgZ1iNuQTwK18OvELfC5Yi/hisSR+AGFW+EDYg3wUbEm2ETtt6CeARuhasQb4O2xDvwG7ga8bdwDeLvVLwdrkPcBpsRt8MWxDsQ34Y74XrEu2Ar4t3wa8R74IbE3+BeuDHxFtwHNyHugJsR71fxAbgF8UG4FfH38BvEh1R8GH6LuBN+hxiH2xF3Ib4J7bANcTdsR+yAOxNvwB64K/FX2KviI3A3Yifcg7gP7kXcr+KjsAPxMbg/8Rd4HB5A/IOKB+BBxC74PeIf4SHEJ+BhxCdhZ+J1OAhxxD/BrsRr8JSKf4Z2xKdhd+JVeAY6EJ+FPYjPwV7E5+ERxBegE/FF2Id4SMXDsB/xJXgM8WV4PPEKvIL4MrwKf0B8DQ4gvg5diZfgLyr+FZ5AfAOeRHwTDiK+peLf4E+Ib8NTiO/AnxOH4YiKR+GZxCF4F55FfA+eQ3xfxW54HvEDeAHxQ3gR8SM4nHgRPlbxE3gJ8e/wcuIF+BReQfyHij3wKuJn8HrieTgGf0E8ruI/4a+I/4I3EP8L3kT8XMUv4G+J5+AEvI34JbyD+BXis/A1HEH8Bo4inoR3Eb9VsRfeTzwDfdCNmIAPEP/j0//P+/R//pv79E9/sU//5Cd8+ic/8Okf/4RP/+gHPv3DX+DTu0/59ObTfPr7P+HT31d9+vs/8OnvqT79vUE+/T3Vp7+n+vT3Bvn0d3/g04+qPv2o6tOP/hv69Df+H/n0V//j0//j0//tfPq/e5z+7+vTfypO/49P/49P/3Gf/vT/Bz4dgKqfywB6ZA6ImvPohVk9awH22Q0mbBH2gweTV7gPPHyE8eAKBFydmPc1JD5m7Synf8fHOvsToMU9RBrQsg7AE+Q4PrUTraMD59GFPu63uC5vwJUloq95GlfVDLwFrL+BeBId6IHvwD7dgbPqQu90KdqTk7jRP1wGG7hX8KkNuN+koe+chr7iWnJWYiV6qSP85eiJz0If0khaE1WJ6xJbE3fjOtjHPa3uVV70TwtwVj4T/oorYxg+cSOutiNkq3YP+uJz0B/s436HnuY2roYniUW423C4u1yEfeDRu75AumgUpdfDR8RN1nLjUMpdiXjiIHL50TsuxjW7n4wkE2hQmJuYjHPpxHesRqm34urZi3cnroE3iUE4nrgb/bUH951JOJ4OeJF0cX296/tKUWMCamko7iGTcFx/QLs/TELkj3S5YBByhZhwMVqyHXeks7G39+GTH5Iv6aV4X8Y9xY9PjMXddwP6G9Q2rp53iZfkkKlkNh1Kl9PbuWbcv7Pw2RHonxtQ37eg9HdIlOylBnqIu4t/kD8ppvQdTZhwRiLoeX4HfyRGHKlCWsivyOvkfTqOzqO/oe9xN/D38y9LdTjq89BrX4te5EtiJYVkOjmXLCZryUZyPbmVvEAOk49pGZ1FL6DHuMVcE/c4PxbvmXwLf7lwpXC1+HFfVd/Bvpf6vkzkJq7EfWot+uLrcU5ux5HtwzX8Bt5H4D0iED0x4a2QIDmbXIL3peRacifZQe4nHfiWw+Q98gn5F/mCnGSGS0Xqo0GahneINtOL6A30t/QQ3ofpP+jXnItL46LcSK6Eq+aWY682clvw3sO9y3v5Q3wC9Zwr3CRsE3YIDwpPCMdFg/QrDHye//au3szed/qgb1PfTX3tfR3o2R04h17UQgB3+Om4D9bhrrYaPfo9aOevEAPqzksyyRhyFmpmHllCmshq1OQV5DZyj9r3h8ljqKW/kGPYZyP1q33OpiPpWDoV7/NoPW2iW+hW2kFfp99wEqfnzJyDy+QmcDVcPbeCW8PdxMW557m3ufe4E9y3eCd4HR/g0/gIH+Un8PP4lfzt/Ef8R8Jc4TnhA1EnLhOvFDvFf0qjpDHSNGm6VCNtlvZKr2pq0TqfRI/+yOBPdMlRbj1Xwe2B62ge76Ev0hfRnufBQm4yRUulO8gmuo500HRhtTiajiZT4DgfQV0/RbfRE3Q0N5lUkpmwhI5IShPt/AOYlfBPQg//GI7tRZS8WjSQS+kx0QDtBGgRvvNP3HA+yj0Hb3JHiMTfAW/xOuIiPfQ+bhpaweP8GKEKgtxv4WGuiayDPbQCQHdScw3a8RTyAPqFWSSXfMUlgKNT0IoKOLanX0D/it71Ity/byYL+UW4R+eRteiT78VVMVS4UMwUHeQZ2sC3URvpAMrfj6MrIumEE+xwBanhbhOP0Tcw3jjE6+Ad7vfY+0P0YW4yf1yYQRbjCliHUUJTYj2sEar4l8ki4MhsCPNsn1/L5fJBzDHeQG+Tg1p2oyfrhDJuMta40XLOQrs4Gz3EbXjfgn6CRwtqwDV+DnqxF6FDnEU7YZFgIuh1APjn+mZgbHUv7tqLMLLZipHpqxg/rEWJO3C/2Qw7yIa+SzBuSsWV8w45SxhPDwnjE8NoG32DzqQ3nT6/qO0wceNO9Hfc9cfDGOFRaOP/gjFiaeIa3HMdGC+nYc/mY6zZjaP8DN8wkeuCvL4pdFdiPNeI4z2C8eF9iQDRYUS2FKPOx+AeSYA6KRorK4uVjjmjZHRxUWHByPy83BHDc7KHZUUzhw7JiITTQ2lBJZCa4vd5PW6X02G3WS2y2WQ06HVajSQKPEcJZFWExtcq8UhtnI+EJk4cxsqhOqyoG1RRG1ewavzpPHGlVmVTTueMIef53+OMJTljpziJrJRAybAspSKkxF8oDymdZM70KqSvLQ9VK/EelZ6s0ltU2oh0MIgPKBXuxeVKnNQqFfHxqxa3VdSWo7hdet240Lh63bAs2KXTI6lHKu4KNe4irjFEJairongXBY0ROxX3hsor4p5QOetBnAtX1C2MT5teVVHuCwarh2XFybgFoflxCI2Nm6MqC4xTXxMXx8Ul9TVKAxsNXK3syupqu6ZThvm1UcPC0MK6uVVxrq6avcMSxfeWx10Xd7u/K6Jw67iqjYNbfVxbhbtBYcW2to1KfPv0qsGtQYbV1SgDn6Xh8bVt4/HV16ASK2cq+Da6oboqTjbgKxU2Ejaq5PjqQxWspnaJEteGxoYWty2pxanxtsVhxppgu9cb24fBsLdCaZtVFQrGS32h6rpy/y47tM1Ys9sTUzyntwzL2iVbkordZTL3EwbjYKL+VJtKqeyMqpxxSrOE9Sg0CQ0irixQsCdVIRxTIYP6QmhbUIhseFUTfCq+EGekIa4dV9smF7N69nxcCMshpe0LQAsI9fzj9Jq6/hoxLH8BjGR2csrUsH2Ajkej8cxMZiLSOJxT7OMYtTxyWNaqThoKNcoKZqg+mIa6rasuzkH1B4Nsgq/ujMF8LMRbp1clywrM97VDLCdaHae1rKVroMVxNmtpHWg59XhtCC25Qw0FHXFN5NSfWXbaKhYXx4nzf9Jcn2yvnBmqnD6nSqloq+3XbeWs00rJ9sJTbf1U3DauivPRfor6OLUVjXLuKWZWqDLE+TD+iapRL+yUNGiVag1Rxsfl2olJrNYFg7/woc7EcfaUmn33WH8348XR08ujTyuf1j1DG4cdxk2wctactjbdaW1oaskXTurP0OJhVlVQGReHs3FlhvGvM9FVyFK1Lx5DlY1jDGh/yar+4mmMvn66Gi9mncOyxqOja2sbH1LGt9W21XUmWueHFDnUto8+QZ9oa6yoHTCczsT+q33x8ddUo64Wk+Jh6jlAg8GThf2TrXomGNV/r/nfcvcM3GRc8sZoZ/B97k/dGKeVcIf4BsGE91NiTNwqgYbgfYs2Tfuwbjze9+rfMpQZ/py8jY+q9klf+ofXWPjwPHPJFxqfRt3t7nw/I5Ple85of/qbnb2L5GLNWVjUqvzsokQNwAWmCwnGdlDSLUqd9NaYDQS+mwOdxHcT8GhEoZtyj2Fgo8UwNxvcUflESW/JFPnzksm9JVCKtPwtwojhQUvQEkYguK1/q3Bd38YEPJIpfBc7YcVx/92M5yYBe3DOLr/QSXfGIpoSkYKo0z/HaYuFQr4ECsViwpVQqhBCntPp9OuDd9zijkbxZTUlk+Ueubu7t7tb/gxKSyfLvR9WzqzaLfBAiFwil1SPGG7jLHkWjhuZ5/io4Ej+XYfIUk5LKvoe/fbLvhteeIH14nYc8RzshRlS4IpYRAmQcRp/Siol1CKnmkHjiihaovUGUmSFKKipmtTRc9mAa9goT9T0qMMtVUc7bk1sFOeTNKJG0PAaXvS4vW4q6nUGnVHHiQ6n3WlzcqKPcwWJ1YTg1viDxKmzBCEaJdFoJl7rSU2eJZjrcrqcVoedmmgoHMwdVTBq1Mj8SEYkFLydfP3gnEurV7RMufj6Fzb07SJF198zomLyzUunPNT3vLDfkXLW/L5DB+/r67u/LvehUSMqPrn3wy8zU1HReCYCsh7HycENewhutlTAhbO78Ix8Nc/LT+bDhifzIUOTeSiczFNSk7nbq+axHKOcrwhbhJ0CxyloNZthO84nn4PHyGl4ZDkOglXByi34ujv516tVhaEXam/Fqampbmou6a2J9l9oMKUjhufhPB14Qtj/zXjs6y0YLZuxrzJZGbsMqFljpz4Nv8pwpeFpA6c1TDJMMnND+bAxy1TFncuvMq42bTRq9FTQFBlHmabSSq5cimkmG8eadLfQW7mbpJs0O7j7JNFKzSbTcIHaBYFqDEbjcEGDpMYwwzyDxAilGo1Wp9cbjSaTDBotrbW2Wql1P90BRjKiXVA0nWRETGfQ6pSY4TI90e+ns8FE9NhCO4k+pjUTUMyNMpE76exHFKFWaBU4NOoduy2jUQEeNFg0WTdaTY/XI/cg7T1V6K4Bd2lpSYk86PbKPT0bhezoxnUHN2a7WTZiOFTG9TMr46nohx8HQ+IkaBKvA028XlhYWE0q4wZsG4Jt+8CY+GqXScdqUeus+OreYJEpK1hk7ESyoMiUW6CSe4Zh7bCi5ExUNzfVQFONaoLE6RpVQIKWkAXP35Zb8DBw7nCnZyQe44RH+2bv7KsS9p/81/UTp/2G+/ab8fxzJ0fyR08qzM6GY5S+H+dOgqkxo0BTMZQFNaTVdtKW3QpP+E5CHhEVQnM4wiG9h6jrirVq9t6aXFpsccu93TUfMkWgfQw4k5FBR9BCbX0pfFufTzA+9NA3/8XW8JmJj3k/Pwbj9QKSErtOa9RmeozezKHGzEy0CEeBrzhzUmaNsSZzibEhs3Z4m/HKobc5f+O93+i41/PAkL2eR4cc9Bwa8rLj7SGacicJuALuaFZmfhFflDWJn5g1W1MdPV/TEF1l2Gh4xvC18euopSDfRHg5Jz3flRu0u+cNXT6UDvXnmEpNm03bTAmTsM2003TMxJlMfs7VSR+IOd032v1+CSoydLl+Tj+0Tq6DcDC9k54bkzNiEJEjSmR4ZGdEiIwoYssrkBrKH17UVUS3F5EiV9idlpN+QDwk0oBYKlJxRCHqqKnn8x65pimKLujzkt4PPoDSntLu0p7ebou1KAdbmzDHvyJisbqK0HJqCJvcsCiG0iIj80ehT2H3yHz0KmmilDGG5uU60es4HHanKxThRMlEkcxjzmckV7Jw35Kdj01omTjygjcXkbyKTZetSYm7Lzx81aYHpslaV9pjftf8g8vn5i5rWHxnJOXys8c/uGHK+il2k9GbHtZdOOyM6iZ309WVsbozs1cfP7nhjELy9hC/PGRyzsTac6eecRHO/rTEx1wPzqAXXohN0BpIwD/ONs410zbTVWurdf2G/oa7zXi3fLfXoDF6dEtoA7dEWGloNLYa7zXs0e7V7TEYnOgd3qecKW2eebn5MjNnJkzxk4arHqkWj4Rb0EUdRc+kBbNZj0Zq9eslt5/X+83EnG5K82Ev0vXRACHoosgkvyP9kEQCUqlEpRG+/IOqXTb1IDT3B0L7MFDAyKOn+fOeZqb8HtS7pShHrunGP6bwJoJ/LqZwsORbR6F+XVKEaTupV65kV8qxh9/s+7L5k6se+ltgp+eyOZseuPuKJdeRDa5HDpEUovs9oet33uG7YOmTr7z+xK/Qzsejlo7g2rLgXvV67EEd5Y1hY76x3CiMtI/0n0Nn6WbYZ/oX0YVCvXaBvdbfFXhVeM32tucD2wf2Y65PPR+kHA0kAs5AIOotcZZ4K72NgS0BKZumG7OdxXSksZJWGMfbJ/nP0c02LjJ+IH7k/IZ8bpKJgzPpZTP4UGMW0DnQgt15BMIWc1iWD1uIbIlZai2tFt6ywpp+QDokHZESEs90N1XiJE9q/jS3ul83Te7prWlClyf3lnQzlZWwZGFmespAgyOZgaKFJhWGuwJRtYX7H2qOK6w/eNlrK5e8enntTTm7e5Xfr1x1z45LVt9x5e3XnLxrG+HappdR0zfjqfX5Z//41JvPH0SdVaJvSEXLcqDO3oktDIDfQc/maoQa7dn6eu4CYbm2Xq+RcauRaYb1DeEb+wmvNMJa7BnhL7NO9pb5p1vnemb466zLvHX+1eJqxwl6wi2Dk5iNLtc0Z62z0ck5/eYt8naZyjLv8+skYIanJTfa0LhcMSNbz9qMzPy4kRi9AbaJhiP5LI+lsFUeIAFnnpwuxdIz8weprCCpsujk3u4pclM0eqIpOhljDVzfqqFh9NFUQtj6ZrojNUx7zQPGJkNeLljsUtDJNEeCEXWNc+ftz/ps3yd9x4j9b68RE/n2Y137hgXX9L5JpxsKZ1+19n4y23VXBwkQjhjIkL53+r6WlZ37F5Mbrxy3+F7mZcf2Tef+jppMhUw4HqvV6wV7lj5sP0tfYRe1KZ6ULH3EnhUq0o+yn6kfb58tVekX67/RfeEwZYeyMsaExmSclbEla3uWNCo4amhp1nj9+GDF0FnBWUMbpAXBBUNrs1qz3sz4OPhZ6FiGxeUUHZ10V8cQv01S17Gs4MbCVnErdMFhYDpeFysT/H6zriLNb9A5HXnhPF3Y7T7sIrIr5qp1tbp41wozCUNaIP2A+ZD5iDlh5gPmUvNU9A2eaNaKIDPL6BTVLNGVqpbZ230Ct5se5kdrullewpTbhGvZxUIy1RtmoI5p0j5dI/MsdtWj2gYZ6fk79bnjVqzb5DaRVfG3jl/40rWPXXxv/Vvb//D3W+9dt3bHQxev3lHlnR7OXTinIH41KXn7FkKuuaX12yVfHVr9IJf5UteB55986kn0RhsxDGf/rmCHXfvAifZidLjyw/xIroLbb+S5zsTRWLrLk+/SWAwWOycQMPsFyY7hZlgbyxuVn9CSLoxcpziZqbnyR+XHncedtNG53Rl3Jpy8k9rDuOtimwOZj7MzgALsn3R4mOKYMC3p76IsyMUMlRRlkS6uV1yuRYQZHUa7JtEkhU2iwUeMGrOPAIti10O0hkRZOMcWsNOBEYSqFdFh2dhxadeqhys7Vl4w7doSYX/vv7bW3P3b3nn0jo2XzLxuXe+jaGObMIQoUaNUCdbFaqZqt2i3a+PaLu0R7XGtBNqAtlHbqt3WX3VUm9DqAlr02BJPOa3IXUpAFEReJ0phAfht/HY+znfxR3mxiz/OU+AV/jCWeH6KZmCEGImqAUZpj7qaWGJT3txkwzMDOzxs6ujo4D89dOikg4+cfBPXQeLOvumkWO2jFW6NTeaFsDCazxOuFASXRhAknqe8YANi1FPObuAtgl5i/dKLkt9i3mIndpfLazAYwzrdFj0J6Ev1U/Wc3mOzPxScMGCQeLBhx6mK+vIPm6B0ck9paQ92zFp0qouWvLyNsiZ55DBpZHNEI+t8RGuSfJCcBFLD+k8KVKvEUdgltNIrO/oWp40KFIzqyCu7eRL/yUsvfX3JraZJW/m5J7cfnLyQRW+of+4rHJuePB/zSuJscY6WMxv/SzghcmdzF+moVVRswXxNZ+L4bmtGvhbzDsytgloRVCtiV2CNyPMCLxZoJ6B2xGG6Kt1F3Erdm9z7onSvSEJiRAprisRCbalxqrGarxarpGrtOn6NcKv2KfFl/nWxW/xE+lL8WuOw6nR4wuCpKEparQYLWo0mLIl2SRI5ng8LOgzgdTqceV6DhxpeECWNRq8HHQaZ5nYhDUN2cyykqLu4dws6YH0YaJiQLUBKYSram8dgfDc44fzv9N4j96C/PVHDfAIaPIs/0ThKLK4iFovz6+SDmLujJiQknAFNCaci2gwG2jGdNiulSKtJSSkROxPvtKcUYfZqu6Jmu4LJMLtajbGb8MynhuZioqs9WISruavdybJ32uUiMZmpJYOa7dIPxOg4u+zBmPVtnmjsTnyb3V6iAj51ot3NHv7HLl+SHc9auDPUNLHlSPIIhvISGjR54JO+JeTAO313XCbs//YxEu9b1buQBi7uOzfpdcQIevkQPLUPtIm/xsr0RvQ63Xy39l3XB4rwmnBCoS6NEtK6fYqW40KpftHh16N5EzGEZxnd4TDZEt4epmG0c1N4i4VYOknNHnd4i4/4kIp5gOaFwuQwEBaR0QCwmeDAkx7uJKt3f7cImktw78MtEE9KvVPUpYBhVklJCS5WdZpwSoi6KpKrwGC3RewGi49YjY4BV8T2ReaKHKPUYIJB0h+pUdhgz3RH7r1LVt0cuPTZ2x/YHZo7pvGGjqqFZ60v5iM3Tpk3v2r/zr29GfR3S+cV33h37820ffXqabdd3/tGv4/+ELXlhOdjNoETbXSH3Cm/z31kO86dsIk8Ww8jUIFrZHKLfNh91J1w84rGbrI7reisieg06owmgyldr3psPcE//RQ388pe5rHdx9200b3dHXd3uXk3R/Mczn6nbf2B03YNOOzPS5LnAnTZ6umphLmPUz7bKVq0Oo1O0nGiHLGIJh8x66z9CmMfP6BhqvbiGNV/IBiksI13rny79o5psq4j84KJLffxkZt3VjROzl3X20KvvHBZ2dbnex/DNVWOEVcG6sQIHvhjrMYq6TyGCeJEzWyxWrNIbNBo8uVia7FzpLtCrrRWOivcc4W52hlyjbXGOcO9TFimXSgvsy5zLnRfRBxaUTCey80SZunONSzl6oV63VKDzuXnJQuanD1dYqqwpYfzh0sEJFlSMHgacYQZGtZ7WHiFtCkdYsjCDI3CCC8LrVBV0R4Mq2pO1NSwjQ2jd1zBLP5kS0s7U5ipnS/M1/K4fmxyAWoCHOo+D4P3+fK7r/rTW8R5yadXH+nr2de+8cr23Rs2tlMbybhuVd+7vS98+iuSSozPP/f8S3967ll89ca+Bj6IerFiBHUodo9BHiafIVfKfKkSV2hAGWoIpeQ6clPGpjQqWxRNsavYd6brTF+15lzDXNdc3xLNBYYGeZnrAl+X8or9bffb3ldSu+3dqUeVhOIM8VE56hjJF8vj+TPlOfIH+k9T+mS9xYSxqZ+tTKffpAeTJ/2wjsi6mK5W16rjdSuILY/mWcMAXegSyXYSJ8cJHyClZCoGgZ7AhAI3SQbuzWxH+rybBUmorVJ1Qyrqj9qxFZpsA4vM6bBTFhBlWLhBqtp4d/HWxZsOL1l55JI5m7Mt965a/eB9K1p29TUIj7dNn35N4pa7+k5efVZx70nu7hcOPvfac8/+BU17A262T6G+LHB5bHSOjcg8CfH5/Dh+Jn8+v4IXtRaNVqM12ixaI3AaolcHCjrtkC0aoklTbMRG0yw/GeNYJxw8FePgie3zZjyRqMPC+Ca50YL8zEaT+qlLTTP7TCQ5QjzDsQMzroYNd45pKD33vDFjx44+z57KR+5omlh8X8aE0trm3lfZXlqKp7Vd2P/h5I3YJXyaPa1Ye6a2PH12Wn3aWu112ivS77U9mPUEZ9S6vG7X8Mqs112Cj55NqZxLdO65mrnaubq5+rmGucYlmiXaJbol+iWGJcaOSEeGOSOSnpE+dFT6HF21fmFk4ZAVoRXprem/1v3WsHXIzVk3Dr9bd7/hroy7h+yO/CniTMHtI2ZNLZqjyQgbdLxXiTh4fXaKl4XV/oCn1DPVM8+z03PII5o9Ac9yzxEPH/Bs9lDPo/RsPDUBi75l9vmYTA7jHktkQgk7xdid+SyPpZos+YRkz01ZmkJT/A6J92frA17iTffEbO58Tyc9t11Kz0TOR/xFhzNJpjeXPRXBE1FtblcuLc1tzaW5Mp6500FJN6cdObU1jxg4BDVNxvi8p3mK6tbYOejzaP+RuwmPQlH0V82qaTZ3Jz/z6P/IA51dLGNYagiPKRGLbJVtMiemGRUfaIdIPiIMQ0i1YzFoCvkgLWQ0aIZiEDUkQ6sTo7wPAnIKc4tRFgIkgW290czo+vUsxm1iQWKNrcCZtPKMSEY2ngrYR7Wq3xw46bNjgyuVJt1HpLTdfNUla1ePDP/6qVunlhVmXj9z3eNzLHFDS8PaJU5nju+KAzfPbnhq3aE3yBn+C5rry88IucO5k9ZPmbBmSCA68ZJF7hlzZxSE/Ck2XXpe2dq5c7adw34EB+mJf9FM4VZwQes+0LGPbSMsFOuKlSHR6sH42GDUEQ6csjZq1qEz4PRmOQ3SiNEaNpCEpKnQVtRKjVKrtEXiAb3odikudUmHJVHaT5eAm4zadX5ysaAP6GFngu7PS9QDfG8J8wMYjsrPsLA5Gg27kud3SwjPRgW4ZkIWO1MRlb1nlcxfmnXFFbv37LFFh6TesU0eU38nXXANkZb2XXtN768nZ3nZWC7HVXNU/YbV4/vAy87OeOqhis2Zb2ab6VCrPT9qI+kam9NAbE49LngLDgfynGG3S91EXaTLRVxTvOqyZ5uo97iXNnq3e+PehJf34unolEPAk4NW0R7GcwSvneI5dejpGdg/0TOwUZaWJD2CalJeXjYZzUYqJj/nx12UN/jAqLEkQ+/MzPXoE9FO+j/IyIio4bdLNRM1FOdK17523l1TZX2H3nLh9OnXje74bcfEZVNHttCtvbuvHTFh+szNm2gRHjUIBPHE/Rnqwks27jb7iZmt5Lv9RUPss807dVzMGDNTszJkeL7MQDJorU6j25qhzzBkGEcZRhlHmm616IdYh9gmOqut1bZqR4O1wdbgWCOuMq6xXGy/2LHB2Ga5xnqN7Sr7Lbod+sfkRy377X/XfWT/wtgrf21P+FOtZrNBtlitOuA8dpstbNXZsWA2mC2GsF5n1+t1NqvVYNCLnN9jBr/spzn+A37q76Sle8y2mDVm76SzYvpSa8xK51kPWKm1k4zdayZpUOHTsSarWdHHYophuGGqgZtmSBioATl255hxsLS0w6esRcPDqLK3Cd2A161+WO6WP+/2yN24FXndco9KgZsZI1ukLErXDI7SASduo0kuKdEcrIybZlbG3dPnVD0KhsTHoE98TAoLq5Ox+z6wJ97ZW1CkSysoMnUmPt7jKLKkOYqSEXtTNIpBO4bTtozkhwB4kzwb+4zclkdwN8C5vsw+OqtkossSEfR9y554O5oWiL7f0be0LH342tn5fYvul4ek+y4wp/BDem9duX7tKnrByad3jq2emfyXN/adw1q9RoPhJP3+D0t/eEnQ/9VFTf9XiwY3iiCKLFEqgIaRvMiJar1Br0X53M/L1wIkvxapHfS+714uShJIEodS9RKSPAZd6r8bGvU6AP6/I1//o/KlfvnSgHxeUuvNRva5rfDz8vXfk68d3KgBjYYlJt/ISPaPdap82Wj4ZfINA/KNPyJfCxqtFrQantOgfCRPybcYkV/4pfKFn5SvZfK1qnxGihpeq9bbZBM+Jn5f2g8vEwPGZx70voFLBzo8Qet1PEqVGSnqBJ0q32GR8bFfIN88IN/yI/INoNezJPA6kPUGPUh6kc2THtx2K6pJ8/PyLQPybYPGM3AZwWAygskkiAawm4wm0Bgkk/pen8uO0/8L5LNfkqtry5Usy6cPzmQ2g9ksiiZwmpHUmjRmtRMpHic+pv2+tB9eDgbSd/JtgxtlMMsyyLKEvfbISOrMGlkdl+JDN6HV/7x8VSzrh+9H5FtAtljQK0qSDD4rknpZa1XHFfR5fpl89/fkO06Xb7FawDog3wp6S7/8cMCP5vUL5PsG5AcGjWfgsoPNYQeHQ9LaIOBwOMBg1TnU92amKzjNJvjZK5UBM8pQsuwd3OgCh8sFLpcOpaa7kDTZDS51kNkR5Df+AvnBAfnhZNk/uNELLq8XvF6dzgURL5Jml9Grvjd3aATNSP6+tB9e6QxYP4Ymy4HBjX7w+P3g9xt0HhjiR9LiMbEOeGDUMOQ3W35efgYDZtPDBo1n4EoFX2oqpKYYjT4YloKk1WdOATZpxSOy0Hxt35f2wytzQH7OoPEMXAqkKAooitGYCiMUJG0psqLKH1eUi7bs/Hn5wxmwfhQky0MHN4YhLRyGcNhsToOiMJLONFtYHWRlaSFOs+v70n54jWLAbO6MZHnY6YOLZGZCZqbFEoHSTCQ9EUem+t6ZE8bgNHt+Xn4JA9aPimQ5f3BjNmRmZ0N2ttUWhQnZSPozXdnAJm3uZOT3er8v7YfXWAaMrzJZLhrcmAfZeXmQn2d35MDkPCQD2d48dZALZyG/3/99aT+8JjJgfP3RzZjBjYWQW1gIBYVOZy7MKkQymOtHvcMIFv2DNKZvCoyT4ZudfXly8alvJg1cNeKgKvZ9aUzxn+/Q/51L+DP7NtHpF/bvwOCy+AD7dsuPX/z7Scv971x8C5yp5gDTkB6PqbK/fiymjeTPsIn8OXEntm/qf/9GVo+pnOVqHx+ADdhein1Nx7rLT5PPFgZTeQ1CKSzAsITiFpXDbIg36HoxDGKBaDZlJpgM/frYd9JVmoCOju6nKZjosH6ag/PIoX6aH8Qj4FHzkX5aBBO5/9RkX0Yy+2kCAgn30xQkktpPc9inY/00P4hHQEf8fj8t4qb7N/ZLH5712gCHVTo5oi6VFtX6DpWW1Pq7VVqj0jeotLZ/jEk6OcYknRxjkk6OMUnzg3iSY0zSyTEyWjeoP3r1XVeotGFQvUmlV6u0zN4FS1TahrQVqlTaPojfocqZqNLOQfUe9dlilfapPJkqnTKIJzCITlf5/SqdqdImlR6m0kzzRDOo/5pB7zIMqjcMjKUMmvFeCRfCCqhjv2UkcXIHTvmFsAimYM0qTAuxtBxLy5FzGbwLS7Fcz6fyI/hKfgJ/BmLRqdY6tXUNOhsm70J8lv0SpRnzwRz1p0n7roW1NXC3cbu4x7kDmPZx+7nfnyarub83A5KWw3xYQ4wocQnWfzL4LWXNDXVLJ8+aXd/c0rD8QiU3uzCX/bdAK9Y01herbcqM+kUrl9Y1Fw9mUYZMbljQvLxl+fkrhva3q8yz8LHz6xbUK/crsxbXKwOSlHHLmxuXN9etYM83Ll2QrZTXraj7GaYcJkyZuXzpSlbToky6EJ8bUVQ0fBhCbrZSthT71rBo8YoW7GJLffOq+oXqRDWoQ54Ms2A2DrgZWrBmOQ5bYT8IZr4c25ar6lmBU9CIPMWDnlNgBtYswsleqiqy+CelKDAEJTWgg2nGlhZM56PEod97/jvJs/rfdj6WFmCuwP2YZsFilf5+nxQYp05So4rM6Abe34iyFmAfFChX6+v+FyXlnOqZgka0HOtWnuJpwbpJ7Ae+6vtG4LZbxH5i3U/lqrVl+ERSbw047sX4bEu/FltUza1CXAinfC0kMtj/ZfXDqywEZs4FxzAlMHEQQMzBNBXTPEybMW3DJKp8rGY5psswHcB0XG2Jca72rXmxTsyuVrPdS5bmqsW6ZHFujVrcfU51Mp88PZmXT0qyFSfZRuQnq7PHJvOMrGRuDee2slxnzO0qc3JOOMwx59GISOhBMBOCoe12zgFxTJQT+2tinHV3eiR32wGOB8JRjqBGAokujrQbLbllOpqgx9AhBuhntCfZQnt2myy528rOpO/BTkwHMHH0Pbzfpe/CZfQoenEzYimmbZgOYDqE6RgmkR7F+wje79B3kOttyMFUimkepm2YDmA6hkmibyPK9G9st1GR0aWYKP0bokzfwmG9hWimbyL1Jn0Tu/ZKe0FR7j6ViOb0E4FwP+Hy9RNWZ24nfbn966GBTvr+biUa2F42nL4KcUy4/SLKmBRM0zDVYmrEJCL1OlKvQyumLZi2Y4pjwrMzooxJoc9ieh7T6zAcUwzTNEwaergdX9NJD7VHxgbKnPRF+mcMSQP0Bfq0mj9Pn1Lz5+if1PwZzFMxf5Y+1Z4agDI9tgM+I2MuY56D7QL94+50ayBRZqEHUD0BxBxMpZimYpqHaTMmkR6gae0LA1YU8ig8iwfxAG2HT9T8XrhTA7ElgVhkHNqYwiBSfAZSCNuUbREai9x0KxYZRK7bihSDyBXXIMUgcvF6pBhElq5CikFk4RKkGETmzEOKQWTqLKQQOuntj6RnBAqmXkCUMjO9CLV0EWrpItTSRcDTi9gNX/Osb79pz8xEjd0Wiw7NDLTuJ62PkdYZpPVO0lpPWi8lretJawlpPY+0Rkmrn7SmktYYaX2UFKIqWkms47RiUcxNWp8lrQ+R1hbSGiGtYdKaTloVUhDrpMH2SXlqVqFmu8vYusL8jDG5ZuxjEDUaRLMO4rI/gHgIU0ItxZBJSUsye1JZnrY7szRZzi7OXV42kT6JDz6J0/AkHMHE4wQ9iWb0JAp5EgWYEUsxzcPUhekYpgQmEbnTsOObVTQj5mAqxTQP02WYjmES1e4cw0RheX8Xd6ody+nv9FRWok/izX69GqTBWIrsl6PyRG6zn5hTydTURCotACc7BFotGksnMe790vjVl0bQlmnpdXQzpOBEbOnPN7d/nRLoJLe0Rx4NlDnIzZDKo9WRIohgeBhATbeo5ZHg17A8H/z0Qcxz2/2zA+wLJJGswH5iYk/tDXzt7w584u+kSH7sfzTwF6WTJ+2B17Dmwb2BV/1XBZ7J6dRgzWORToLZfkVl3ecvDDz0rMq6Hhtuaw9cyrK9gXX+CYEL/GpDfbLhvBYsxcyBGZE5gYkor9w/PxBrQZl7A6X+8wIlSa6R7Jm9geHYhWiSzMTODvWrLw2lqgLPLugki2NZ0k1SlTRVGiXlSllSUApIKZJPsmusGllj0hg0Oo1GI2p4DdWAxs6+TBZlwbVdlFkm8gx5lZYpQ6rG3kCJhuKJI27jKmnlzLGkMt61ACrnK/ETM0OdRDd9TlwIjSVxayVUzhobL4xWdkqJGfGCaGVcmnZu1S5CrqvG2jjd1ElgVlUnSbCqDT7207t9QIhlw7U+lg/ZcG11Nbidq0rdpdYxlqLx5T8Ctf0Y/e5yn0anxG+qnFkVfyClOp7LiERKdWX81+y3efvIv8jxivJ95J8sq67ax40h/6qYweq5MeXV1ZWdZLbKBwr5J/KhxfxT5dOkgsL4QNGkJvluS/KF8XnkS2cZ8mm1EFb5wlqtyscTxrerJb2ifFd6usrjUqBF5WlxKYN5ng0jTzis8jhb4VmV51lnK+OJj1FZ/H5kSfWrLMQLfpXFT7wqy+zvWHL6Wa46xXKV+iaOfMfjT/IYjw7wGI8iT/SXXvVjo1Gye3T1grnsd421oYp6TLXxq1ctdsdb5yvKrgXV/T94jNTOX7CY5XX18epQfXl8Qahc2TV67o80z2XNo0Plu2BuxayqXXNj9eXto2OjK0J15dW7J0zLLzjtXVedelf+tB8RNo0Jy2fvmlDwI80FrHkCe1cBe1cBe9eE2AT1XaDa+LSqXRoYWz1ubjLfTfU6tNdaX7B6rFNuHKMa7+ig+1LffgxIdoA+Wh03hMbGjZhY07CyYWWsCdcUazKxH6/2N7kvHR307Sc7+ptkrLaExkJ0xcqWleCuaChP/rXghVUrVjKFJzHa8lMXtlXEY3XlLSsAKuOZMyvjpdPnVO2SJKytZUOKFw/U6fUVnYmuZGU2VhazSo47xcjqSlidVtvP+MP5X9mfq/+G1kof3U1iqQTD1mounlo5i6IrmNX/K8H9GC6x7aGlGgfYQqKkZUCG2m1I0sDGO5BWrOyn+vWwoj9PPoWPtAyo49SFz6Cr+h8ctJJJZW5kc3RyZWFtCmVuZG9iago5IDAgb2JqCjw8IC9GaWx0ZXIgL0ZsYXRlRGVjb2RlIC9MZW5ndGggMzAwID4+CnN0cmVhbQp4nF1Ry2rDMBC86yv2mB6CZTu2GzCG4LTgQx/U7Qc40joV1LKQlYP/vpI2TaACG2Z3ZneYTdru2GnlIHm3s+jRwai0tLjMFysQTnhWmqUZSCXcFcW/mAbDEi/u18Xh1OlxZnUNkHz47uLsCpuDnE/4wJI3K9EqfYbNV9t73F+M+cEJtQPOmgYkjn7Sy2BehwkhibJtJ31fuXXrNXfG52oQsohTciNmiYsZBNpBn5HV3L8G6mf/GoZa/uuXpDqN4nuwgZ1Vns35btdE1BLaR5RzQkdCxCyI6QUBlWlEBemqfdx5nV787bpbyyONkzbjNKmkLY80MKfigYpPVKxoC/kpaEpJtoqCiiSvsqsD2hkCCIe6pSsu1vpg4zVjoiFLpfF2cDOboArfL9N4mrhlbmRzdHJlYW0KZW5kb2JqCjEwIDAgb2JqCjw8IC9UeXBlIC9PYmpTdG0gL0xlbmd0aCA1MTMgL0ZpbHRlciAvRmxhdGVEZWNvZGUgL04gNiAvRmlyc3QgMzggPj4Kc3RyZWFtCnicfVLLbtswELz3K/YYHyy+RQoIAthx3RiFUyN2m0PgA2OxqlBZFCQaqP++SzmR1RwKQa/l7M5whowBBcZBMGAClAImgWl8KeAsA5aClPTT7S2QTevz08G1cLP9XVqyWSzhaOQE7u765fkayKNvj7YCcrDAhrrt3NLXAcisLW213gFZuO7g6tzWIS508BJpKDzBHsjn+uDzsi6ArHJXhzKcpw9AtqfXcG4ckB0+Kb7897pEoIOsb+zrQHqeN957f8IfBuRrmUeKgeEC3djCde/YWdQTIKMq4VpIid22eXBl8SuAZioxnKI/b7oDTDljScYkTZGyskUH8sI9n/s/SDVNU5koRbWBqeAy0VRTAZxykwicBIwKnTCaCRP1xMZlWTkO5rKXWHi0RzdybBVsVR5mdVE5xJBtcMcfIFFYZiROGW0/amzLJvj2PwHcrxbbc4dDVvVPDxH0rc1dG22/ebd9AuTJFWUX2jPczHL/6iYxh6ap3DGaQHF+P2nnv6wWa9tcE0OnnqPMD3rwSPX7G8LE5giJ4vk/EZJndJHirRWFeHGtE9N7d/3ag8gihPOEpTrTWMDkXkaIS68RIqGYBUMAnm88CYwiAJ3DQmqwoFSaMMWFRLSiFMuaIfWorlPQGvhApfs2+nE8PowYtZlIJwZAbLiqG7PSgXkfY/sLmsPutWVuZHN0cmVhbQplbmRvYmoKMSAwIG9iago8PCAvVHlwZSAvWFJlZiAvTGVuZ3RoIDE2IC9GaWx0ZXIgL0ZsYXRlRGVjb2RlIC9EZWNvZGVQYXJtcyA8PCAvQ29sdW1ucyA0IC9QcmVkaWN0b3IgMTIgPj4gL1cgWyAxIDIgMSBdIC9TaXplIDIgL0lEIFs8ZmM5NjM1ZjgwMWM1NzE5MTUwZDg4OTBjNmMxZmQwYmE+PGZjOTYzNWY4MDFjNTcxOTE1MGQ4ODkwYzZjMWZkMGJhPl0gPj4Kc3RyZWFtCnicY2IAAiZG63cMAAK5AS8KZW5kc3RyZWFtCmVuZG9iagogICAgICAgICAgICAgICAKc3RhcnR4cmVmCjIxNgolJUVPRgo="
}

mock_email = {
    "id": "64a9c7e3-ed4d-5b4d-f228-86a722f8e969@adomain.com",
    "createdDateTime": "",
    "lastModifiedDateTime": "",
    "receivedDateTime": "",
    "sentDateTime": "",
    "categories": "Mock",
    "hasAttachments": True,
    "subject": "A new email for you",
    "isDraft": False,
    "internetMessageHeaders": None,
    "flag": None,
    "importance": None,
    "sender": {
        "emailAddress": {
            "name": "Someone",
            "address": "someone@adomain.com"
        }
    },
    "from": {
        "emailAddress": {
            "name": "Someone",
            "address": "someone@adomain.com"
        }
    },
    "to": {
        "emailAddress": {
            "name": "Someone Else",
            "address": "someoneelse@adomain.com"
        }
    },
    "ccRecipients": "",
    "bccRecipients": "",
    "replyTo": {
        "emailAddress": {
            "name": "Someone",
            "address": "someone@adomain.com"
        }
    },
    "body": {
        "content": "This is a mock email for the use in XSOAR. It really does not contain much.\n\nThank you.\n\nRegards\n\nXmocky\n\n\n\n"
    }
}

mock_email_eml = """Return-Path: <someone@adomain.com>
Delivered-To: someoneelse@adomain.com
Received: from box51.bluehost.com
	by box51.bluehost.com with LMTP
	id CP90FCdow16nEQQAbNeJLw
	(envelope-from <someone@adomain.com>)
	for <someoneelse@adomain.com>; Tue, 19 May 2020 08:10:11 -0600
Return-path: <someone@adomain.com>
Envelope-to: someoneelse@adomain.com
Delivery-date: Tue, 19 May 2020 08:10:11 -0600
Received: from host2-33-24-269.range27-36.btcentralplus.com ([17.3.24.29]:39549 helo=[192.168.10.98])
	by box5781.bluehost.com with esmtpsa (TLSv1.2:ECDHE-RSA-AES128-GCM-SHA256:128)
	(Exim 4.92)
	(envelope-from <someone@adomain.com>)
	id 1fg2wb-001VWQ-6j
	for someoneelse@adomain.com; Tue, 19 May 2020 08:10:11 -0600
To: Someone Else <someoneelse@adomain.com>
From: Someone <someone@adomain.com>
Subject: A new email for you
Message-ID: <$MESSAGEID$>
Date: Tue, 19 May 2020 15:10:12 +0100
User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64; rv:52.0) Gecko/20100101
 Outlook/6.1.18
MIME-Version: 1.0
Content-Type: text/plain; charset=utf-8; format=flowed
Content-Transfer-Encoding: 7bit
Content-Language: en-US

This is a mock email for the use in XSOAR. It really does not contain much.

Thank you.

Regards

Xmocky




"""

msgraphmail_api = Blueprint(f'{INTEGRATION}', __name__)
logger = logging.getLogger(__name__)


@msgraphmail_api.route(f'/{BASE_URL}/incidents', methods=['GET'])
def fetch_incidents():
    if request.method == 'GET':
        now = datetime.now().isoformat()
        incident = dict()
        new_mock = mock_email
        new_mock['createdDateTime'] = now
        new_mock['lastModifiedDateTime'] = now
        new_mock['receivedDateTime'] = now
        new_mock['sentDateTime'] = now
        new_mock['attachments'] = [mock_attachment]
        incident['rawjson'] = json.dumps(new_mock)
        return json.dumps([incident])
    else:
        return None


@msgraphmail_api.route(f'/{BASE_URL}/users/<email>/messages', methods=['GET', 'POST'])
def create_draft(email):
    if request.method == 'GET':
        return None
    elif request.method == 'POST':
        now = datetime.now()
        data = json.loads(request.data)
        ret = dict()
        ret['ID'] = "09734589IJGFLIHASDF98645OIHADSSOFIH"
        ret['To'] = data.get('to')
        ret['From'] = data.get('from')
        ret['Subject'] = data.get('subject')
        ret['Body'] = data.get('body')
        ret['BodyType'] = data.get('bodyType')
        ret['Cc'] = data.get('cc')
        ret['Sender'] = data.get('sender')
        ret['Bcc'] = data.get('bcc')
        ret['Headers'] = data.get('headers')
        ret['Importance'] = data.get('importance')
        ret['MessageID'] = data.get('09734589IJGFLIHASDF98645OIHADSSOFIH')
        ret['ConversationID'] = data.get('09734589IJGFLIHASDF98645OIHADSSOFIH')
        ret['CreatedTime'] = now.strftime("%Y-%m%d %H:%M:%S")
        ret['SentTime'] = ""
        ret['ReceivedTime'] = ""
        ret['ModifiedTime'] = ""
        ret['IsDraft'] = True
        ret['IsRead'] = False
        return json.dumps(ret)


@msgraphmail_api.route(f'/{BASE_URL}/users/<userID>/mailFolders', methods=['GET', 'POST'])
def create_folder_no_parent(userID):
    if request.method == 'POST':
        data = json.loads(request.data)
        return json.dumps(
            {
                "ChildFolderCount": 0,
                "DisplayName": data.get('displayName'),
                "ID": "0924395875ASDFHIUDSF9872354245",
                "TotalItemCount": 0,
                "UnreadItemCount": 0,
            }
        )
    elif request.method == 'GET':
        limit = int(request.args.get('$top'))
        limit = mock_folders_max if limit > mock_folders_max else limit
        folders = mock_folders_list[0:limit]
        return json.dumps({"value": folders})
    else:
        return None


@msgraphmail_api.route(f'/{BASE_URL}/users/<userID>/mailFolders/<folderID>/childFolders', methods=['GET'])
def list_folders_child(userID, folderID):
    if request.method == 'GET':
        limit = int(request.args.get('$top'))
        limit = mock_folders_max if limit > mock_folders_max else limit
        mock_folders = mock_folders_list[0:limit]
        return json.dumps({"value": mock_folders})
    else:
        return None


@msgraphmail_api.route(f'/{BASE_URL}/users/<userID>/mailFolders/<parentID>/childFolders', methods=['POST'])
def create_folder_with_parent(userID, parentID):
    if request.method == 'POST':
        data = json.loads(request.data)
        return json.dumps(
            {
                "ChildFolderCount": 0,
                "DisplayName": data.get('displayName'),
                "ID": "0924395875ASDFHIUDSF9872354245",
                "ParentFolderID": "345097856UIOGDSFIULGSDFGLIU986",
                "TotalItemCount": 0,
                "UnreadItemCount": 0,
            }
        )
    else:
        return None


@msgraphmail_api.route(f'/{BASE_URL}/users/<userID>/messages/<messageID>/attachments/<attachmentID>', methods=['GET'])
def get_mail_attachment(userID, messageID, attachmentID):
    if request.method == 'GET':
        return json.dumps(mock_attachment)
    else:
        return None


@msgraphmail_api.route(f'/{BASE_URL}/users/<userID>/messages/<messageID>/attachments/list', methods=['GET'])
def get_mail_attachment_list(userID, messageID):
    if request.method == 'GET':
        return json.dumps(mock_attachemnt_list)
    else:
        return "!"


@msgraphmail_api.route(f'/{BASE_URL}/users/<userID>/messages/', methods=['GET'])
def list_mails(userID):
    if request.method == 'GET':
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        search = request.args.get('search', None)
        if search:
            email = mock_email
            contents = email.get('body', {}).get('content')
            if not search in contents:
                email = None
        else:
            email = mock_email
        if email:
            email['createdDateTime'] = now
            email['lastModifiedDateTime'] = now
            email['receivedDateTime'] = now
            email['sentDateTime'] = now
        return json.dumps(email)
    else:
        return None


@msgraphmail_api.route(f'/{BASE_URL}/users/<userID>/messages/<messageID>/', methods=['GET'])
def get_mail(userID, messageID):
    if request.method == 'GET':
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        email = mock_email
        email['createdDateTime'] = now
        email['lastModifiedDateTime'] = now
        email['receivedDateTime'] = now
        email['sentDateTime'] = now

        return json.dumps(mock_email)
    else:
        return None


@msgraphmail_api.route(f'/{BASE_URL}/users/<userID>/messages/<messageID>/$value', methods=['GET'])
def get_mail_eml(userID, messageID):
    if request.method == 'GET':
        attachments = mock_attachemnt_list
        return json.dumps(attachments)
    else:
        return None
