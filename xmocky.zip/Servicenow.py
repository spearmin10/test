from flask import Blueprint, request
import json
import logging
from datetime import datetime

max_limit = 5
mock_incidents = [
        {
            "active": "true",
            "activity_due": "",
            "additional_assignee_list": "",
            "approval": "not requested",
            "approval_history": "",
            "approval_set": "",
            "assigned_to": "",
            "assignment_group": "",
            "business_duration": "",
            "business_service": "",
            "business_stc": "",
            "calendar_duration": "",
            "calendar_stc": "",
            "caller_id": {
                "link": "https://dev62495.service-now.com/api/now/table/sys_user/62826bf03710200044e0bfc8bcbe5df1",
                "value": "02826bf03710200044e0bfc8bcbe5d3f"
            },
            "category": "inquiry",
            "caused_by": "",
            "child_incidents": "0",
            "close_code": "",
            "close_notes": "",
            "closed_at": "",
            "closed_by": "",
            "cmdb_ci": "",
            "comments": "",
            "comments_and_work_notes": "",
            "company": {
                "link": "https://dev62495.service-now.com/api/now/table/core_company/227cdfb03710200044e0bfc8bcbe5d6b",
                "value": "227cdfb03710200044e0bfc8bcbe5d6b"
            },
            "contact_type": "",
            "correlation_display": "",
            "correlation_id": "",
            "delivery_plan": "",
            "delivery_task": "",
            "description": "",
            "due_date": "",
            "escalation": "0",
            "expected_start": "",
            "follow_up": "",
            "group_list": "",
            "hold_reason": "",
            "impact": "3",
            "incident_state": "1",
            "knowledge": "false",
            "location": "",
            "made_sla": "true",
            "notify": "1",
            "number": "INC0010002",
            "opened_at": "2020-05-06 09:31:56",
            "opened_by": {
                "link": "https://dev62495.service-now.com/api/now/table/sys_user/6816f79cc0a8016401c5a33be04be441",
                "value": "6816f79cc0a8016401c5a33be04be441"
            },
            "order": "",
            "parent": "",
            "parent_incident": "",
            "priority": "5",
            "problem_id": "",
            "reassignment_count": "0",
            "reopen_count": "0",
            "reopened_by": "",
            "reopened_time": "",
            "resolved_at": "",
            "resolved_by": "",
            "rfc": "",
            "severity": "3",
            "short_description": "Suspicious activity on my laptop",
            "sla_due": "",
            "state": "1",
            "subcategory": "",
            "sys_class_name": "incident",
            "sys_created_by": "admin",
            "sys_created_on": "2020-05-06 09:34:04",
            "sys_domain": {
                "link": "https://dev62495.service-now.com/api/now/table/sys_user_group/global",
                "value": "global"
            },
            "sys_domain_path": "/",
            "sys_id": "ba0d1622dbe01010cc3c112039961987",
            "sys_mod_count": "1",
            "sys_tags": "",
            "sys_updated_by": "admin",
            "sys_updated_on": "2020-05-06 11:31:58",
            "time_worked": "",
            "upon_approval": "proceed",
            "upon_reject": "cancel",
            "urgency": "3",
            "user_input": "",
            "watch_list": "",
            "work_end": "",
            "work_notes": "",
            "work_notes_list": "",
            "work_start": ""
            },
        {
            "active": "false",
            "activity_due": "",
            "additional_assignee_list": "",
            "approval": "not requested",
            "approval_history": "",
            "approval_set": "",
            "assigned_to": "",
            "assignment_group": "",
            "business_duration": "1970-01-01 00:00:00",
            "business_service": "",
            "business_stc": "0",
            "calendar_duration": "1970-01-01 00:01:54",
            "calendar_stc": "114",
            "caller_id": {
                "link": "https://dev62495.service-now.com/api/now/table/sys_user/77ad8176731313005754660c4cf6a7de",
                "value": "02826bf03710200044e0bfc8bcbe5d55"
            },
            "category": "Hardware",
            "caused_by": "",
            "child_incidents": "1",
            "close_code": "Solved (Permanently)",
            "close_notes": "This is not an issue with the USB port. Replaced the headset to resolve the issue.",
            "closed_at": "2018-12-10 03:29:08",
            "closed_by": {
                "link": "https://dev62495.service-now.com/api/now/table/sys_user/6816f79cc0a8016401c5a33be04be441",
                "value": "6816f79cc0a8016401c5a33be04be441"
            },
            "cmdb_ci": "",
            "comments": "",
            "comments_and_work_notes": "",
            "company": "",
            "contact_type": "",
            "correlation_display": "",
            "correlation_id": "",
            "delivery_plan": "",
            "delivery_task": "",
            "description": "My computer is not detecting the headphone device. It could be an issue with the USB port.",
            "due_date": "",
            "escalation": "0",
            "expected_start": "",
            "follow_up": "",
            "group_list": "",
            "hold_reason": "",
            "impact": "2",
            "incident_state": "7",
            "knowledge": "false",
            "location": "",
            "made_sla": "true",
            "notify": "1",
            "number": "INC0009002",
            "opened_at": "2018-09-16 12:49:23",
            "opened_by": {
                "link": "https://dev62495.service-now.com/api/now/table/sys_user/6816f79cc0a8016401c5a33be04be441",
                "value": "6816f79cc0a8016401c5a33be04be441"
            },
            "order": "",
            "parent": "",
            "parent_incident": "",
            "priority": "3",
            "problem_id": "",
            "reassignment_count": "0",
            "reopen_count": "0",
            "reopened_by": "",
            "reopened_time": "",
            "resolved_at": "2018-09-16 12:51:17",
            "resolved_by": {
                "link": "https://dev62495.service-now.com/api/now/table/sys_user/6816f79cc0a8016401c5a33be04be441",
                "value": "6816f79cc0a8016401c5a33be04be441"
            },
            "rfc": "",
            "severity": "3",
            "short_description": "My computer is not detecting the headphone device",
            "sla_due": "",
            "state": "7",
            "subcategory": "",
            "sys_class_name": "incident",
            "sys_created_by": "admin",
            "sys_created_on": "2018-09-16 12:50:05",
            "sys_domain": {
                "link": "https://dev62495.service-now.com/api/now/table/sys_user_group/global",
                "value": "global"
            },
            "sys_domain_path": "/",
            "sys_id": "1c832706732023002728660c4cf6a7b9",
            "sys_mod_count": "9",
            "sys_tags": "",
            "sys_updated_by": "system",
            "sys_updated_on": "2020-01-09 21:11:56",
            "time_worked": "",
            "upon_approval": "proceed",
            "upon_reject": "cancel",
            "urgency": "2",
            "user_input": "",
            "watch_list": "",
            "work_end": "",
            "work_notes": "",
            "work_notes_list": "",
            "work_start": ""
        },
        {
            "active": "false",
            "activity_due": "",
            "additional_assignee_list": "",
            "approval": "not requested",
            "approval_history": "",
            "approval_set": "",
            "assigned_to": "",
            "assignment_group": "",
            "business_duration": "1970-01-02 00:00:00",
            "business_service": "",
            "business_stc": "86400",
            "calendar_duration": "1970-01-04 01:26:57",
            "calendar_stc": "264417",
            "caller_id": {
                "link": "https://dev62495.service-now.com/api/now/table/sys_user/46d44a23a9fe19810012d100cca80666",
                "value": "02826bf03710200044e0bfc8bcbe5d5e"
            },
            "category": "hardware",
            "caused_by": "",
            "child_incidents": "0",
            "close_code": "Solved (Work Around)",
            "close_notes": "As this is intermittent. Restarting the PC fixes this.",
            "closed_at": "2020-05-05 22:17:48",
            "closed_by": {
                "link": "https://dev62495.service-now.com/api/now/table/sys_user/62d78687c0a8010e00b3d84178adc913",
                "value": "62d78687c0a8010e00b3d84178adc913"
            },
            "cmdb_ci": {
                "link": "https://dev62495.service-now.com/api/now/table/cmdb_ci/affd3c8437201000deeabfc8bcbe5dc3",
                "value": "affd3c8437201000deeabfc8bcbe5dc3"
            },
            "comments": "",
            "comments_and_work_notes": "",
            "company": {
                "link": "https://dev62495.service-now.com/api/now/table/core_company/31bea3d53790200044e0bfc8bcbe5dec",
                "value": "31bea3d53790200044e0bfc8bcbe5dec"
            },
            "contact_type": "walk-in",
            "correlation_display": "",
            "correlation_id": "",
            "delivery_plan": "",
            "delivery_task": "",
            "description": "",
            "due_date": "",
            "escalation": "0",
            "expected_start": "",
            "follow_up": "",
            "group_list": "",
            "hold_reason": "",
            "impact": "3",
            "incident_state": "7",
            "knowledge": "false",
            "location": "",
            "made_sla": "true",
            "notify": "1",
            "number": "INC0000601",
            "opened_at": "2020-01-04 09:42:59",
            "opened_by": {
                "link": "https://dev62495.service-now.com/api/now/table/sys_user/6816f79cc0a8016401c5a33be04be441",
                "value": "6816f79cc0a8016401c5a33be04be441"
            },
            "order": "",
            "parent": "",
            "parent_incident": "",
            "priority": "5",
            "problem_id": {
                "link": "https://dev62495.service-now.com/api/now/table/problem/8f74a828532023004247ddeeff7b1295",
                "value": "8f74a828532023004247ddeeff7b1295"
            },
            "reassignment_count": "0",
            "reopen_count": "0",
            "reopened_by": "",
            "reopened_time": "",
            "resolved_at": "2020-01-07 11:09:56",
            "resolved_by": {
                "link": "https://dev62495.service-now.com/api/now/table/sys_user/62d78687c0a8010e00b3d84178adc913",
                "value": "62d78687c0a8010e00b3d84178adc913"
            },
            "rfc": "",
            "severity": "3",
            "short_description": "The USB port on my PC stopped working",
            "sla_due": "",
            "state": "7",
            "subcategory": "",
            "sys_class_name": "incident",
            "sys_created_by": "admin",
            "sys_created_on": "2020-01-04 09:43:10",
            "sys_domain": {
                "link": "https://dev62495.service-now.com/api/now/table/sys_user_group/global",
                "value": "global"
            },
            "sys_domain_path": "/",
            "sys_id": "9e7f9864532023004247ddeeff7b121f",
            "sys_mod_count": "2",
            "sys_tags": "",
            "sys_updated_by": "system",
            "sys_updated_on": "2020-05-05 22:17:48",
            "time_worked": "",
            "upon_approval": "proceed",
            "upon_reject": "cancel",
            "urgency": "3",
            "user_input": "",
            "watch_list": "",
            "work_end": "",
            "work_notes": "",
            "work_notes_list": "",
            "work_start": ""
        },
        {
            "active": "false",
            "activity_due": "",
            "additional_assignee_list": "",
            "approval": "not requested",
            "approval_history": "",
            "approval_set": "",
            "assigned_to": "",
            "assignment_group": "",
            "business_duration": "1970-01-01 00:00:00",
            "business_service": "",
            "business_stc": "0",
            "calendar_duration": "1970-01-01 00:31:45",
            "calendar_stc": "1905",
            "caller_id": {
                "link": "https://dev62495.service-now.com/api/now/table/sys_user/77ad8176731313005754660c4cf6a7de",
                "value": "02826bf03710200044e0bfc8bcbe5d64"
            },
            "category": "inquiry",
            "caused_by": "",
            "child_incidents": "0",
            "close_code": "Solved (Work Around)",
            "close_notes": "Reinstalled the app",
            "closed_at": "2018-08-30 09:49:17",
            "closed_by": {
                "link": "https://dev62495.service-now.com/api/now/table/sys_user/6816f79cc0a8016401c5a33be04be441",
                "value": "6816f79cc0a8016401c5a33be04be441"
            },
            "cmdb_ci": "",
            "comments": "",
            "comments_and_work_notes": "",
            "company": "",
            "contact_type": "",
            "correlation_display": "",
            "correlation_id": "",
            "delivery_plan": "",
            "delivery_task": "",
            "description": "Having an issue with users trying to access the company portal app",
            "due_date": "",
            "escalation": "0",
            "expected_start": "",
            "follow_up": "",
            "group_list": "",
            "hold_reason": "",
            "impact": "2",
            "incident_state": "7",
            "knowledge": "false",
            "location": "",
            "made_sla": "true",
            "notify": "1",
            "number": "INC0009003",
            "opened_at": "2018-08-30 09:17:32",
            "opened_by": {
                "link": "https://dev62495.service-now.com/api/now/table/sys_user/6816f79cc0a8016401c5a33be04be441",
                "value": "6816f79cc0a8016401c5a33be04be441"
            },
            "order": "",
            "parent": "",
            "parent_incident": "",
            "priority": "3",
            "problem_id": "",
            "reassignment_count": "0",
            "reopen_count": "0",
            "reopened_by": "",
            "reopened_time": "",
            "resolved_at": "2018-08-30 09:49:17",
            "resolved_by": {
                "link": "https://dev62495.service-now.com/api/now/table/sys_user/6816f79cc0a8016401c5a33be04be441",
                "value": "6816f79cc0a8016401c5a33be04be441"
            },
            "rfc": "",
            "severity": "3",
            "short_description": "Cannot sign into the company portal app",
            "sla_due": "",
            "state": "7",
            "subcategory": "",
            "sys_class_name": "incident",
            "sys_created_by": "admin",
            "sys_created_on": "2018-08-30 09:18:00",
            "sys_domain": {
                "link": "https://dev62495.service-now.com/api/now/table/sys_user_group/global",
                "value": "global"
            },
            "sys_domain_path": "/",
            "sys_id": "9fffc328731823002728660c4cf6a742",
            "sys_mod_count": "4",
            "sys_tags": "",
            "sys_updated_by": "admin",
            "sys_updated_on": "2018-12-13 07:39:53",
            "time_worked": "",
            "upon_approval": "proceed",
            "upon_reject": "cancel",
            "urgency": "2",
            "user_input": "",
            "watch_list": "",
            "work_end": "",
            "work_notes": "",
            "work_notes_list": "",
            "work_start": ""
        },
        {
            "active": "false",
            "activity_due": "",
            "additional_assignee_list": "",
            "approval": "not requested",
            "approval_history": "",
            "approval_set": "",
            "assigned_to": "",
            "assignment_group": "",
            "business_duration": "1970-01-01 00:00:00",
            "business_service": "",
            "business_stc": "0",
            "calendar_duration": "1970-01-01 00:05:23",
            "calendar_stc": "323",
            "caller_id": {
                "link": "https://dev62495.service-now.com/api/now/table/sys_user/77ad8176731313005754660c4cf6a7de",
                "value": "02826bf03710200044e0bfc8bcbe5d6d"
            },
            "category": "software",
            "caused_by": "",
            "child_incidents": "0",
            "close_code": "Solved (Work Around)",
            "close_notes": "Reverted to a previous version.",
            "closed_at": "2018-12-10 03:29:09",
            "closed_by": {
                "link": "https://dev62495.service-now.com/api/now/table/sys_user/6816f79cc0a8016401c5a33be04be441",
                "value": "6816f79cc0a8016401c5a33be04be441"
            },
            "cmdb_ci": "",
            "comments": "",
            "comments_and_work_notes": "",
            "company": "",
            "contact_type": "",
            "correlation_display": "",
            "correlation_id": "",
            "delivery_plan": "",
            "delivery_task": "",
            "description": "While launching the defect tracking base URL, it is redirecting to an error page.",
            "due_date": "",
            "escalation": "0",
            "expected_start": "",
            "follow_up": "",
            "group_list": "",
            "hold_reason": "",
            "impact": "3",
            "incident_state": "7",
            "knowledge": "false",
            "location": "",
            "made_sla": "true",
            "notify": "1",
            "number": "INC0009004",
            "opened_at": "2018-09-01 13:13:30",
            "opened_by": {
                "link": "https://dev62495.service-now.com/api/now/table/sys_user/6816f79cc0a8016401c5a33be04be441",
                "value": "6816f79cc0a8016401c5a33be04be441"
            },
            "order": "",
            "parent": "",
            "parent_incident": "",
            "priority": "3",
            "problem_id": "",
            "reassignment_count": "0",
            "reopen_count": "0",
            "reopened_by": "",
            "reopened_time": "",
            "resolved_at": "2018-09-01 13:18:53",
            "resolved_by": {
                "link": "https://dev62495.service-now.com/api/now/table/sys_user/6816f79cc0a8016401c5a33be04be441",
                "value": "6816f79cc0a8016401c5a33be04be441"
            },
            "rfc": "",
            "severity": "3",
            "short_description": "Defect tracking tool is down.",
            "sla_due": "",
            "state": "7",
            "subcategory": "",
            "sys_class_name": "incident",
            "sys_created_by": "admin",
            "sys_created_on": "2018-09-01 13:14:04",
            "sys_domain": {
                "link": "https://dev62495.service-now.com/api/now/table/sys_user_group/global",
                "value": "global"
            },
            "sys_domain_path": "/",
            "sys_id": "e329de99731423002728660c4cf6a73c",
            "sys_mod_count": "9",
            "sys_tags": "",
            "sys_updated_by": "system",
            "sys_updated_on": "2020-01-09 21:11:57",
            "time_worked": "",
            "upon_approval": "proceed",
            "upon_reject": "cancel",
            "urgency": "1",
            "user_input": "",
            "watch_list": "",
            "work_end": "",
            "work_notes": "",
            "work_notes_list": "",
            "work_start": ""
        },
    ]
mock_asset = [
    {
            "asset": {
                "link": "https://dev62495.service-now.com/api/now/table/alm_asset/05a9e40d3790200044e0bfc8bcbe5daa",
                "value": "05a9e40d3790200044e0bfc8bcbe5daa"
            },
            "asset_tag": "P1000429",
            "assigned": "2017-12-12 07:00:00",
            "assigned_to": {
                "link": "https://dev62495.service-now.com/api/now/table/sys_user/c6826bf03710200044e0bfc8bcbe5d90",
                "value": "c6826bf03710200044e0bfc8bcbe5d90"
            },
            "assignment_group": "",
            "attributes": "",
            "can_print": "false",
            "category": "Hardware",
            "cd_rom": "false",
            "cd_speed": "",
            "change_control": "",
            "chassis_type": "",
            "checked_in": "",
            "checked_out": "",
            "comments": "",
            "company": {
                "link": "https://dev62495.service-now.com/api/now/table/core_company/4b7d13f03710200044e0bfc8bcbe5db6",
                "value": "4b7d13f03710200044e0bfc8bcbe5db6"
            },
            "correlation_id": "",
            "cost": "2249.99",
            "cost_cc": "USD",
            "cost_center": {
                "link": "https://dev62495.service-now.com/api/now/table/cmn_cost_center/d9d01546c0a80a6403e18b82250c80a1",
                "value": "d9d01546c0a80a6403e18b82250c80a1"
            },
            "cpu_core_count": "1",
            "cpu_core_thread": "",
            "cpu_count": "1",
            "cpu_manufacturer": "",
            "cpu_name": "",
            "cpu_speed": "",
            "cpu_type": "",
            "default_gateway": "",
            "delivery_date": "2017-10-28 07:00:00",
            "department": {
                "link": "https://dev62495.service-now.com/api/now/table/cmn_department/a581ab703710200044e0bfc8bcbe5de8",
                "value": "a581ab703710200044e0bfc8bcbe5de8"
            },
            "discovery_source": "",
            "disk_space": "",
            "dns_domain": "",
            "due": "",
            "due_in": "",
            "fault_count": "0",
            "first_discovered": "",
            "floppy": "",
            "form_factor": "",
            "fqdn": "",
            "gl_account": "",
            "hardware_status": "installed",
            "hardware_substatus": "",
            "install_date": "2017-11-11 07:00:00",
            "install_status": "1",
            "invoice_number": "",
            "ip_address": "",
            "justification": "",
            "last_discovered": "",
            "lease_id": "",
            "location": {
                "link": "https://dev62495.service-now.com/api/now/table/cmn_location/24018ca93790200044e0bfc8bcbe5d32",
                "value": "24018ca93790200044e0bfc8bcbe5d32"
            },
            "mac_address": "",
            "maintenance_schedule": "",
            "managed_by": "",
            "manufacturer": {
                "link": "https://dev62495.service-now.com/api/now/table/core_company/aa0a6df8c611227601cd2ed45989e0ac",
                "value": "aa0a6df8c611227601cd2ed45989e0ac"
            },
            "model_id": {
                "link": "https://dev62495.service-now.com/api/now/table/cmdb_model/0c43b376c611227501522de28a4abfae",
                "value": "0c43b376c611227501522de28a4abfae"
            },
            "model_number": "",
            "monitor": "false",
            "name": "ThinkStation C20",
            "object_id": "",
            "operational_status": "1",
            "order_date": "2017-10-01 07:00:00",
            "os": "Windows XP Professional",
            "os_address_width": "",
            "os_domain": "",
            "os_service_pack": "",
            "os_version": "",
            "owned_by": "",
            "po_number": "PO100006",
            "purchase_date": "2017-10-15",
            "ram": "",
            "schedule": "",
            "serial_number": "QXN-744-B67838-LL",
            "short_description": "",
            "skip_sync": "false",
            "start_date": "",
            "subcategory": "Computer",
            "support_group": "",
            "supported_by": "",
            "sys_class_name": "cmdb_ci_computer",
            "sys_class_path": "/!!/!2/!(",
            "sys_created_by": "admin",
            "sys_created_on": "2012-02-18 08:12:30",
            "sys_domain": {
                "link": "https://dev62495.service-now.com/api/now/table/sys_user_group/global",
                "value": "global"
            },
            "sys_domain_path": "/",
            "sys_id": "01a9e40d3790200044e0bfc8bcbe5dab",
            "sys_mod_count": "8",
            "sys_tags": "",
            "sys_updated_by": "system",
            "sys_updated_on": "2020-05-06 07:49:43",
            "unverified": "false",
            "vendor": {
                "link": "https://dev62495.service-now.com/api/now/table/core_company/aa0a6df8c611227601cd2ed45989e0ac",
                "value": "aa0a6df8c611227601cd2ed45989e0ac"
            },
            "virtual": "false",
            "warranty_expiration": "2020-11-10"
    }
]
mock_table = {
    "access": "",
    "actions_access": "true",
    "alter_access": "true",
    "client_scripts_access": "true",
    "configuration_access": "false",
    "create_access": "true",
    "create_access_controls": "false",
    "delete_access": "false",
    "extension_model": "",
    "is_extendable": "false",
    "label": "Incident",
    "live_feed_enabled": "true",
    "name": "incident",
    "number_ref": {
        "link": "https://dev62495.service-now.com/api/now/table/sys_number/3",
        "value": "3"
    },
    "read_access": "true",
    "super_class": {
        "link": "https://dev62495.service-now.com/api/now/table/sys_db_object/2a17c5b41c120010785061945362ade2",
        "value": "2a17c5b41c120010785061945362ade2"
    },
    "sys_class_code": "",
    "sys_class_name": "sys_db_object",
    "sys_class_path": "",
    "sys_created_by": "system",
    "sys_created_on": "2020-01-09 20:38:12",
    "sys_id": "fbe9cd301cd20010785061945362ad0a",
    "sys_mod_count": "1",
    "sys_name": "Incident",
    "sys_package": {
        "link": "https://dev62495.service-now.com/api/now/table/sys_package/abe98d301cd20010785061945362adac",
        "value": "abe98d301cd20010785061945362adac"
    },
    "sys_policy": "",
    "sys_scope": {
        "link": "https://dev62495.service-now.com/api/now/table/sys_scope/global",
        "value": "global"
    },
    "sys_update_name": "sys_db_object_fbe9cd301cd20010785061945362ad0a",
    "sys_updated_by": "system",
    "sys_updated_on": "2020-01-09 20:55:25",
    "update_access": "true",
    "user_role": "",
    "ws_access": "true"
}
mock_users = [
    {
        "active": "true",
        "avatar": "",
        "building": "",
        "calendar_integration": "1",
        "city": "",
        "company": {
            "link": "https://dev62495.service-now.com/api/now/table/core_company/81fd65ecac1d55eb42a426568fc87a63",
            "value": "81fd65ecac1d55eb42a426568fc87a63"
        },
        "cost_center": {
            "link": "https://dev62495.service-now.com/api/now/table/cmn_cost_center/91e8bbf43710200044e0bfc8bcbe5daa",
            "value": "91e8bbf43710200044e0bfc8bcbe5daa"
        },
        "country": "",
        "date_format": "",
        "default_perspective": "",
        "department": {
            "link": "https://dev62495.service-now.com/api/now/table/cmn_department/5d7f17f03710200044e0bfc8bcbe5d43",
            "value": "5d7f17f03710200044e0bfc8bcbe5d43"
        },
        "email": "lucius.bagnoli@example.com",
        "employee_number": "",
        "enable_multifactor_authn": "false",
        "failed_attempts": "",
        "first_name": "Lucius",
        "gender": "Male",
        "home_phone": "",
        "internal_integration_user": "false",
        "introduction": "",
        "last_login": "",
        "last_login_time": "",
        "last_name": "Bagnoli",
        "ldap_server": "",
        "location": {
            "link": "https://dev62495.service-now.com/api/now/table/cmn_location/0002c0a93790200044e0bfc8bcbe5df5",
            "value": "0002c0a93790200044e0bfc8bcbe5df5"
        },
        "locked_out": "false",
        "manager": {
            "link": "https://dev62495.service-now.com/api/now/table/sys_user/02826bf03710200044e0bfc8bcbe5d88",
            "value": "02826bf03710200044e0bfc8bcbe5d88"
        },
        "middle_name": "",
        "mobile_phone": "",
        "name": "Lucius Bagnoli",
        "notification": "2",
        "password_needs_reset": "false",
        "phone": "",
        "photo": "",
        "preferred_language": "",
        "roles": "",
        "schedule": "",
        "source": "",
        "state": "",
        "street": "",
        "sys_class_name": "sys_user",
        "sys_created_by": "admin",
        "sys_created_on": "2012-02-18 03:04:49",
        "sys_domain": {
            "link": "https://dev62495.service-now.com/api/now/table/sys_user_group/global",
            "value": "global"
        },
        "sys_domain_path": "/",
        "sys_id": "02826bf03710200044e0bfc8bcbe5d3f",
        "sys_mod_count": "5",
        "sys_tags": "",
        "sys_updated_by": "developer.program@snc",
        "sys_updated_on": "2020-05-05 22:30:57",
        "time_format": "",
        "time_zone": "",
        "title": "",
        "user_name": "lucius.bagnoli",
        "user_password": "iSl4Du6x08",
        "vip": "false",
        "web_service_access_only": "false",
        "zip": ""
    },
    {
        "active": "true",
        "avatar": "",
        "building": "",
        "calendar_integration": "1",
        "city": "",
        "company": {
            "link": "https://dev62495.service-now.com/api/now/table/core_company/227cdfb03710200044e0bfc8bcbe5d6b",
            "value": "227cdfb03710200044e0bfc8bcbe5d6b"
        },
        "cost_center": {
            "link": "https://dev62495.service-now.com/api/now/table/cmn_cost_center/91e8bbf43710200044e0bfc8bcbe5daa",
            "value": "91e8bbf43710200044e0bfc8bcbe5daa"
        },
        "country": "",
        "date_format": "",
        "default_perspective": "",
        "department": {
            "link": "https://dev62495.service-now.com/api/now/table/cmn_department/5d7f17f03710200044e0bfc8bcbe5d43",
            "value": "5d7f17f03710200044e0bfc8bcbe5d43"
        },
        "email": "jimmie.barninger@example.com",
        "employee_number": "",
        "enable_multifactor_authn": "false",
        "failed_attempts": "",
        "first_name": "Jimmie",
        "gender": "Male",
        "home_phone": "",
        "internal_integration_user": "false",
        "introduction": "",
        "last_login": "",
        "last_login_time": "",
        "last_name": "Barninger",
        "ldap_server": "",
        "location": {
            "link": "https://dev62495.service-now.com/api/now/table/cmn_location/25b672780a0a0bb30090fae60e51bd31",
            "value": "25b672780a0a0bb30090fae60e51bd31"
        },
        "locked_out": "false",
        "manager": {
            "link": "https://dev62495.service-now.com/api/now/table/sys_user/06826bf03710200044e0bfc8bcbe5d81",
            "value": "06826bf03710200044e0bfc8bcbe5d81"
        },
        "middle_name": "",
        "mobile_phone": "",
        "name": "Jimmie Barninger",
        "notification": "2",
        "password_needs_reset": "false",
        "phone": "",
        "photo": "",
        "preferred_language": "",
        "roles": "",
        "schedule": "",
        "source": "",
        "state": "",
        "street": "",
        "sys_class_name": "sys_user",
        "sys_created_by": "admin",
        "sys_created_on": "2012-02-18 03:04:49",
        "sys_domain": {
            "link": "https://dev62495.service-now.com/api/now/table/sys_user_group/global",
            "value": "global"
        },
        "sys_domain_path": "/",
        "sys_id": "02826bf03710200044e0bfc8bcbe5d55",
        "sys_mod_count": "5",
        "sys_tags": "",
        "sys_updated_by": "developer.program@snc",
        "sys_updated_on": "2020-05-05 22:30:57",
        "time_format": "",
        "time_zone": "",
        "title": "",
        "user_name": "jimmie.barninger",
        "user_password": "xA3HD4oOV9",
        "vip": "false",
        "web_service_access_only": "false",
        "zip": ""
    },
    {
        "active": "true",
        "avatar": "",
        "building": "",
        "calendar_integration": "1",
        "city": "",
        "company": {
            "link": "https://dev62495.service-now.com/api/now/table/core_company/a66b1fb03710200044e0bfc8bcbe5d08",
            "value": "a66b1fb03710200044e0bfc8bcbe5d08"
        },
        "cost_center": {
            "link": "https://dev62495.service-now.com/api/now/table/cmn_cost_center/91e8bbf43710200044e0bfc8bcbe5daa",
            "value": "91e8bbf43710200044e0bfc8bcbe5daa"
        },
        "country": "",
        "date_format": "",
        "default_perspective": "",
        "department": {
            "link": "https://dev62495.service-now.com/api/now/table/cmn_department/5d7f17f03710200044e0bfc8bcbe5d43",
            "value": "5d7f17f03710200044e0bfc8bcbe5d43"
        },
        "email": "melinda.carleton@example.com",
        "employee_number": "",
        "enable_multifactor_authn": "false",
        "failed_attempts": "",
        "first_name": "Melinda",
        "gender": "Female",
        "home_phone": "",
        "internal_integration_user": "false",
        "introduction": "",
        "last_login": "",
        "last_login_time": "",
        "last_name": "Carleton",
        "ldap_server": "",
        "location": {
            "link": "https://dev62495.service-now.com/api/now/table/cmn_location/8225b668ac1d55eb679878e192fca315",
            "value": "8225b668ac1d55eb679878e192fca315"
        },
        "locked_out": "false",
        "manager": {
            "link": "https://dev62495.service-now.com/api/now/table/sys_user/02826bf03710200044e0bfc8bcbe5d3f",
            "value": "02826bf03710200044e0bfc8bcbe5d3f"
        },
        "middle_name": "",
        "mobile_phone": "",
        "name": "Melinda Carleton",
        "notification": "2",
        "password_needs_reset": "false",
        "phone": "",
        "photo": "",
        "preferred_language": "",
        "roles": "",
        "schedule": "",
        "source": "",
        "state": "",
        "street": "",
        "sys_class_name": "sys_user",
        "sys_created_by": "admin",
        "sys_created_on": "2012-02-18 03:04:49",
        "sys_domain": {
            "link": "https://dev62495.service-now.com/api/now/table/sys_user_group/global",
            "value": "global"
        },
        "sys_domain_path": "/",
        "sys_id": "02826bf03710200044e0bfc8bcbe5d5e",
        "sys_mod_count": "5",
        "sys_tags": "",
        "sys_updated_by": "developer.program@snc",
        "sys_updated_on": "2020-05-05 22:30:57",
        "time_format": "",
        "time_zone": "",
        "title": "",
        "user_name": "melinda.carleton",
        "user_password": "v4WP02WVuR",
        "vip": "false",
        "web_service_access_only": "false",
        "zip": ""
    },
    {
        "active": "true",
        "avatar": "",
        "building": "",
        "calendar_integration": "1",
        "city": "",
        "company": {
            "link": "https://dev62495.service-now.com/api/now/table/core_company/a66b1fb03710200044e0bfc8bcbe5d08",
            "value": "a66b1fb03710200044e0bfc8bcbe5d08"
        },
        "cost_center": {
            "link": "https://dev62495.service-now.com/api/now/table/cmn_cost_center/91e8bbf43710200044e0bfc8bcbe5daa",
            "value": "91e8bbf43710200044e0bfc8bcbe5daa"
        },
        "country": "",
        "date_format": "",
        "default_perspective": "",
        "department": {
            "link": "https://dev62495.service-now.com/api/now/table/cmn_department/5d7f17f03710200044e0bfc8bcbe5d43",
            "value": "5d7f17f03710200044e0bfc8bcbe5d43"
        },
        "email": "jewel.agresta@example.com",
        "employee_number": "",
        "enable_multifactor_authn": "false",
        "failed_attempts": "",
        "first_name": "Jewel",
        "gender": "Female",
        "home_phone": "",
        "internal_integration_user": "false",
        "introduction": "",
        "last_login": "",
        "last_login_time": "",
        "last_name": "Agresta",
        "ldap_server": "",
        "location": {
            "link": "https://dev62495.service-now.com/api/now/table/cmn_location/8225b668ac1d55eb679878e192fca315",
            "value": "8225b668ac1d55eb679878e192fca315"
        },
        "locked_out": "false",
        "manager": {
            "link": "https://dev62495.service-now.com/api/now/table/sys_user/02826bf03710200044e0bfc8bcbe5d3f",
            "value": "02826bf03710200044e0bfc8bcbe5d3f"
        },
        "middle_name": "",
        "mobile_phone": "",
        "name": "Jewel Agresta",
        "notification": "2",
        "password_needs_reset": "false",
        "phone": "",
        "photo": "",
        "preferred_language": "",
        "roles": "",
        "schedule": "",
        "source": "",
        "state": "",
        "street": "",
        "sys_class_name": "sys_user",
        "sys_created_by": "admin",
        "sys_created_on": "2012-02-18 03:04:49",
        "sys_domain": {
            "link": "https://dev62495.service-now.com/api/now/table/sys_user_group/global",
            "value": "global"
        },
        "sys_domain_path": "/",
        "sys_id": "02826bf03710200044e0bfc8bcbe5d64",
        "sys_mod_count": "5",
        "sys_tags": "",
        "sys_updated_by": "developer.program@snc",
        "sys_updated_on": "2020-05-05 22:30:57",
        "time_format": "",
        "time_zone": "",
        "title": "",
        "user_name": "jewel.agresta",
        "user_password": "h3XxaYzkVn",
        "vip": "false",
        "web_service_access_only": "false",
        "zip": ""
    },
    {
        "active": "true",
        "avatar": "",
        "building": "",
        "calendar_integration": "1",
        "city": "",
        "company": {
            "link": "https://dev62495.service-now.com/api/now/table/core_company/31bea3d53790200044e0bfc8bcbe5dec",
            "value": "31bea3d53790200044e0bfc8bcbe5dec"
        },
        "cost_center": {
            "link": "https://dev62495.service-now.com/api/now/table/cmn_cost_center/91e8bbf43710200044e0bfc8bcbe5daa",
            "value": "91e8bbf43710200044e0bfc8bcbe5daa"
        },
        "country": "",
        "date_format": "",
        "default_perspective": "",
        "department": {
            "link": "https://dev62495.service-now.com/api/now/table/cmn_department/5d7f17f03710200044e0bfc8bcbe5d43",
            "value": "5d7f17f03710200044e0bfc8bcbe5d43"
        },
        "email": "sean.bonnet@example.com",
        "employee_number": "",
        "enable_multifactor_authn": "false",
        "failed_attempts": "",
        "first_name": "Sean",
        "gender": "Male",
        "home_phone": "",
        "internal_integration_user": "false",
        "introduction": "",
        "last_login": "",
        "last_login_time": "",
        "last_name": "Bonnet",
        "ldap_server": "",
        "location": {
            "link": "https://dev62495.service-now.com/api/now/table/cmn_location/25ab93750a0a0bb30067bd2ef3d4a5c9",
            "value": "25ab93750a0a0bb30067bd2ef3d4a5c9"
        },
        "locked_out": "false",
        "manager": {
            "link": "https://dev62495.service-now.com/api/now/table/sys_user/0e826bf03710200044e0bfc8bcbe5d61",
            "value": "0e826bf03710200044e0bfc8bcbe5d61"
        },
        "middle_name": "",
        "mobile_phone": "",
        "name": "Sean Bonnet",
        "notification": "2",
        "password_needs_reset": "false",
        "phone": "",
        "photo": "",
        "preferred_language": "",
        "roles": "",
        "schedule": "",
        "source": "",
        "state": "",
        "street": "",
        "sys_class_name": "sys_user",
        "sys_created_by": "admin",
        "sys_created_on": "2012-02-18 03:04:50",
        "sys_domain": {
            "link": "https://dev62495.service-now.com/api/now/table/sys_user_group/global",
            "value": "global"
        },
        "sys_domain_path": "/",
        "sys_id": "02826bf03710200044e0bfc8bcbe5d6d",
        "sys_mod_count": "6",
        "sys_tags": "",
        "sys_updated_by": "developer.program@snc",
        "sys_updated_on": "2020-05-05 22:30:57",
        "time_format": "",
        "time_zone": "",
        "title": "",
        "user_name": "sean.bonnet",
        "user_password": "h1Ao9ZfC1n",
        "vip": "false",
        "web_service_access_only": "false",
        "zip": ""
    }
]
mock_user_groups = [
    {
        "active": "true",
        "cost_center": "",
        "default_assignee": "",
        "description": "Team Develops ITSM Applications in London",
        "email": "",
        "exclude_manager": "false",
        "include_members": "false",
        "manager": {
            "link": "https://dev62495.service-now.com/api/now/table/sys_user/506c0f9cd7011200f2d224837e61030f",
            "value": "506c0f9cd7011200f2d224837e61030f"
        },
        "name": "Application Development",
        "parent": "",
        "roles": "",
        "source": "",
        "sys_created_by": "admin",
        "sys_created_on": "2020-01-08 16:42:02",
        "sys_id": "0a52d3dcd7011200f2d224837e6103f2",
        "sys_mod_count": "1",
        "sys_tags": "",
        "sys_updated_by": "admin",
        "sys_updated_on": "2020-01-08 16:42:02",
        "type": ""
    },
    {
        "active": "true",
        "cost_center": "",
        "default_assignee": "",
        "description": "Group that works on analyzing and fixing problems.\n\t\t",
        "email": "",
        "exclude_manager": "false",
        "include_members": "false",
        "manager": "",
        "name": "Problem Analyzers",
        "parent": "",
        "roles": "",
        "source": "",
        "sys_created_by": "admin",
        "sys_created_on": "2020-01-08 05:11:33",
        "sys_id": "0c4e7b573b331300ad3cc9bb34efc461",
        "sys_mod_count": "0",
        "sys_tags": "",
        "sys_updated_by": "admin",
        "sys_updated_on": "2020-01-08 05:11:33",
        "type": ""
    },
    {
        "active": "true",
        "cost_center": "",
        "default_assignee": "",
        "description": "Incident Management Group",
        "email": "",
        "exclude_manager": "false",
        "include_members": "false",
        "manager": "",
        "name": "Incident Management",
        "parent": "",
        "roles": "",
        "source": "",
        "sys_created_by": "admin",
        "sys_created_on": "2017-05-16 11:13:49",
        "sys_id": "12a586cd0bb23200ecfd818393673a30",
        "sys_mod_count": "0",
        "sys_tags": "",
        "sys_updated_by": "admin",
        "sys_updated_on": "2017-05-16 11:13:49",
        "type": ""
    },
    {
        "active": "true",
        "cost_center": "",
        "default_assignee": "",
        "description": "Demo user group for Password Reset Application.",
        "email": "",
        "exclude_manager": "false",
        "include_members": "false",
        "manager": "",
        "name": "US Presidents Group 2",
        "parent": "",
        "roles": "",
        "source": "",
        "sys_created_by": "admin",
        "sys_created_on": "2013-07-25 22:21:07",
        "sys_id": "1be289a1eb32010045e1a5115206fea1",
        "sys_mod_count": "0",
        "sys_tags": "",
        "sys_updated_by": "admin",
        "sys_updated_on": "2013-07-25 22:21:07",
        "type": ""
    }
]
mock_attachments = [
    {
        "download_link": "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf",
        "file_name": "dummy.pdf"
    }
]

BASE_URL = '/api/now'.strip('/')
INTEGRATION = 'servicenow_api'
servicenow_api = Blueprint(f'{INTEGRATION}', __name__)
logger = logging.getLogger(__name__)


@servicenow_api.route(f'/{BASE_URL}/table/incident', methods=['GET', 'POST'])
def fetch_incidents():
    now = datetime.now()
    method = request.method
    if method == "GET":
        sysparm_limit = int(request.args.get('sysparm_limit'))
        if sysparm_limit:
            sysparm_limit = max_limit if sysparm_limit > max_limit else sysparm_limit
            return_data = [x for x in mock_incidents[0:sysparm_limit]]
        else:
            return_data = mock_incidents
    elif method == "POST":
        return_data = [mock_incidents[0]]
        
    else:
        return_data = []

    incidents = list()
    for incident in return_data:
        incident['opened_at'] = now.strftime("%Y-%m-%d %H:%M:%S")
        incidents.append(incident)
    return json.dumps({
        "result": incidents
    })


@servicenow_api.route(f'/{BASE_URL}/table/incident/<sys_id>', methods=['GET', 'PATCH', 'DELETE'])
def incident(sys_id):
    sys_id = sys_id
    return_data = json.dumps({"result": []})
    method = request.method
    if method == "GET":
        if sys_id:
            incident = [x for x in mock_incidents if x.get('sys_id') == sys_id]
            if len(incident) < 1:
                incident = mock_incidents[0]
                incident['sys_id'] = sys_id
        else:
            incident = mock_incidents[0]
    elif method == 'PATCH':
        incident = {
            "sys_id": sys_id
        }
    elif method == 'DELETE':
        incident = {
            "sys_id": sys_id
        }
    else:
        incident = []
    return json.dumps({"result": incident})


@servicenow_api.route(f'/{BASE_URL}/table/cmdb_ci_computer')
def get_computers():
    sysparm_query = request.args.get('sysparm_query')
    sysparm_query = "" if not sysparm_query else sysparm_query
    if "name" in sysparm_query:
        computer_name = sysparm_query.split("name=")[1].replace("+", " ")
    else:
        computer_name = "ThinkStation C20"
    mock_asset[0]['name'] = computer_name
    if "asset_tag" in sysparm_query:
        asset_tag = sysparm_query.split("asset_tag=")[1].replace("+", "")
    else:
        asset_tag = "P1000429"
    mock_asset[0]['asset_tag'] = asset_tag
    return json.dumps({"result": mock_asset})


@servicenow_api.route(f'/{BASE_URL}/table/cmdb_ci_computer/<id>')
def get_computer(id):
    method = request.method
    if method == "GET":
        sysparm_query = request.args.get('sysparm_query')
        sysparm_query = "" if not sysparm_query else sysparm_query
        if "name" in sysparm_query:
            computer_name = sysparm_query.split("name=")[1].replace("+", " ")
        else:
            computer_name = "ThinkStation C20"
        mock_asset[0]['name'] = computer_name
        if "asset_tag" in sysparm_query:
            asset_tag = sysparm_query.split("asset_tag=")[1].replace("+", "")
        else:
            asset_tag = "P1000429"
        mock_asset[0]['asset_tag'] = asset_tag
        if id:
            mock_asset[0]['sys_id'] = id
        else:
            mock_asset[0]['sys_id'] = "01a9e40d3790200044e0bfc8bcbe5dab"
        return json.dumps({"result": mock_asset})
    else:
        return {"result": []}


@servicenow_api.route(f'/{BASE_URL}/table/sys_db_object')
def get_table():
    table = mock_table
    sysparm_query = request.args.get('sysparm_query')
    sysparm_query = "" if not sysparm_query else sysparm_query
    if "label" in sysparm_query:
        label = sysparm_query.split("label=")[1]
    else:
        label = "incident"
    table['name'] = label
    table['sys_name'] = label

    return json.dumps({"result": [table]})


@servicenow_api.route(f'/{BASE_URL}/table/sys_user_group')
def get_groups():
    sysparm_limit = request.args.get('sysparm_limit')
    sysparm_limit = int(sysparm_limit) if sysparm_limit else sysparm_limit
    sysparm_limit = max_limit if sysparm_limit > max_limit else sysparm_limit
    sysparm_query = request.args.get('sysparm_query')
    sysparm_query = "" if not sysparm_query else sysparm_query
    groups = []

    if "name" in sysparm_query:
        group_name = sysparm_query.split("name=")[1]
        groups = [x for x in mock_user_groups if x.get('name') == group_name]
    else:
        groups = mock_user_groups[0:sysparm_limit]

    return json.dumps({"result": groups})


@servicenow_api.route(f'/{BASE_URL}/table/sys_user_group/<sys_id>')
def get_group(sys_id):
    sysparm_limit = request.args.get('sysparm_limit')
    sysparm_limit = int(sysparm_limit) if sysparm_limit else sysparm_limit
    sysparm_limit = max_limit if sysparm_limit > max_limit else sysparm_limit
    sysparm_query = request.args.get('sysparm_query')
    sysparm_query = "" if not sysparm_query else sysparm_query
    groups = []

    if sys_id:
        groups = [x for x in mock_user_groups if x.get('sys_id') == sys_id]

    elif "name" in sysparm_query:
        group_name = sysparm_query.split("name=")[1]
        groups = [x for x in mock_user_groups if x.get('name') == group_name]
    else:
        groups = mock_user_groups[0:sysparm_limit]

    return json.dumps({"result": groups})


@servicenow_api.route(f'/{BASE_URL}/table/sys_user')
def get_users():
    sysparm_limit = request.args.get('sysparm_limit')
    if sysparm_limit:
        sysparm_limit = int(sysparm_limit) if sysparm_limit else -1
        sysparm_limit = max_limit if sysparm_limit > max_limit else sysparm_limit
    sysparm_query = request.args.get('sysparm_query')
    sysparm_query = "" if not sysparm_query else sysparm_query
    users = mock_users
    if "name" in sysparm_query:
        user_name = sysparm_query.split("name=")[1].replace("+", " ")
        users = [x for x in mock_users if x.get('user_name') == user_name]
    else:
        users = mock_users[0:sysparm_limit]
    return json.dumps({"result": users})


@servicenow_api.route(f'/{BASE_URL}/table/sys_user/<sys_id>')
def get_user(sys_id):
    sysparm_limit = request.args.get('sysparm_limit')
    if sysparm_limit:
        sysparm_limit = int(sysparm_limit) if sysparm_limit else sysparm_limit
        sysparm_limit = max_limit if sysparm_limit > max_limit else -1
    sysparm_query = request.args.get('sysparm_query')
    sysparm_query = "" if not sysparm_query else sysparm_query
    users = []

    if sys_id:
        users = [x for x in mock_users if x.get('sys_id') == sys_id]

    else:
        users = mock_users[0:sysparm_limit]

    return json.dumps({"result": users})


@servicenow_api.route(f'/{BASE_URL}/attachment')
def get_attachment():
    return json.dumps({"result": mock_attachments})