## Xmocky integrations:
[XMocky integrations](https://docs.google.com/spreadsheets/d/190IYBq2yEVnO9qTUx0iXnb89k7awsfSErVVyGSdKVqk/edit#gid=0)

[Instructions for specific Xmocky integrations](https://github.com/demisto/sa-content/blob/master/Code/Tools/xmocky/integrations.MD)

## Instructions:

[Video with instructions to mock a new integration](https://drive.google.com/open?id=1Xi8T9adkQQ68-6T6YRmycwEKbBl9ZW3h)

1. Setup the project

```bash
git clone git@github.com:demisto/sa-content.git

cd sa-content/

.hooks/bootstrap
```

2. Install the required packages:
```bash
pip3 install -r requirements.txt
```

3. Run XMocky app
```bash
python3 XMocky.py
```

4. Verify the server is running by doing an HTTP GET request to **https**://<server_ip>:3000/json

### XMocky integration mock development

Before you start developing, make sure you have the latest version of code:
```bash
git pull
```

1. Create a feature branch:
```bash
git checkout -b <your-branch-name>
```

2. In XMocky.py you’ll need to add two lines in order to add a new integration. Example with Backstory:
```python
from Backstory import backstory_api
app.register_blueprint(backstory_api)
```
3. Create a new Python file from Template.py with the name of the integration, i.e.: Backstory.py
    
    ```bash
    cp Template.py Backstory.py
    ```

4. Make the necessary changes specific to your integration as explained in the video above

5. Follow the existing integrations as an example when creating routes. Also check the [Flask routing docuementation](https://flask.palletsprojects.com/en/1.1.x/quickstart/#routing) if you want to better understand how it works

6. The routes can be quite simple if you just want to return static data. Follow the API documentation or Demisto integration code to determine the URI and method and provide the response from the server as a Dict, the code will take care of jsonify it and build the response

7. The HTTP method in the routes default to GET. If you need to change/add other methods you’ll need to add the argument to the route. Example from Anomali integration:
```python
@anomali_api.route('/api/v1/submit/new/', methods=['POST', 'GET'])
```

8. Once you are happy with your code, push to your branch upstream:
```bash
git push origin <your-branch-name>
```

9. Go to GitHub and create a pull request

## Running XMocky in a Docker container

1. Build the XMocky image with:
```
cd Code/Tools/xmocky

docker build -t xmocky .
```

2.  Run it with (binds to all local interfaces):

```
docker run -ti --rm -p 0.0.0.0:3000:3000/tcp xmocky
```