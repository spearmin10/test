#!/usr/bin/python3

import re
import requests

# get autofocus daily threatfeed

url = 'https://autofocus.paloaltonetworks.com/api/v1.0/output/threatFeedResult'
headers = {'Content-Type':'Content-Type','apiKey':'7f11299c-a953-43c1-8179-37283476cc3e'}
r = requests.get(url, headers=headers)

# parse out hashes and save to file
hashes = re.findall('[A-Fa-f0-9]{64}\n',r.text)

bh = open('badhashes.txt', 'w')
bh.writelines(''.join(hashes))
bh.close()

# parse out urls and save to file
url_cont = re.sub('[A-Fa-f0-9]{64}\n', '', r.text)
lines = url_cont.splitlines()

urls=""

for line in lines: 
   urls = urls + 'https://' + str(line) + '\n'  

bu = open('badurls.txt', 'w')
bu.writelines(''.join(urls))
bu.close()
