from flask import Blueprint, request
import json
import logging

BASE_URL = ''.strip('/')
INTEGRATION = 'nessus_api'

nessus_api = Blueprint(f'{INTEGRATION}', __name__)
logger = logging.getLogger(__name__)

scan_status = [
    "aborted",
    "canceled",
    "completed",
    "empty",
    "imported",
    "pausing",
    "running",
    "stopping"
]


@nessus_api.route(f'/{BASE_URL}/nessus/session', methods=["POST", "DELETE"])
def test():
    return {'token': 'XMOCKY_TOKEN'}

@nessus_api.route(f'/{BASE_URL}/nessus/scans', methods=["GET"])
def scans():

    result = {
        "scans": [
            {
                "uuid": "2776e999-1f5b-45b9-2e15-65a7be35b2e3ab8f7ecb158c480e",
                "name": "X_MOCKY_SCAN_1",
                "status": "Running",
                "folder_id": "Folder_ID_1",
                "id": 45,
                "type": "X_Type",
                "policy": "PCI_DSS",
                "user_permissions": "Read",
                "creation_date": "2020-05-28",
                "last_modification_date": "2020-05-29",
            },
            {
                "uuid": "2776e999-1f5b-45b9-2e15-65a7be35b2e3ab8f7ecb158c480e",
                "name": "X_MOCKY_SCAN_2",
                "status": "Running",
                "folder_id": "Folder_ID_2",
                "id": 46,
                "type": "X_Type",
                "policy": "PCI_DSS",
                "user_permissions": "Read",
                "creation_date": "2020-05-28",
                "last_modification_date": "2020-05-29",
            }
        ],
        "folders": [
            {
                "unread_count": 3,
                "custom": "custom",
                "default_tag": "default_tag",
                "type": "Type",
                "name": "Name",
                "id": 23
            }
        ]


    }

    return json.dumps(result)


@nessus_api.route(f'/{BASE_URL}/nessus/scans/<id>/launch', methods=["POST", "GET"])
def launch(id):
    result = {
        "scan_uuid": "XMOCKY_UUID"
    }

    return json.dumps(result)


@nessus_api.route(f'/{BASE_URL}/nessus/scans/<id>', methods=["GET"])
def scan_details(id):
    result = {
        "info": {
            "owner": "user2@example.com",
            "name": "KitchenSinkScan",
            "no_target": False,
            "folder_id": 9,
            "control": False,
            "user_permissions": 128,
            "schedule_uuid": "0fafc7a8-c5f6-fe9d-68b9-4d60ab0d9d2cf60557ee0e264228",
            "edit_allowed": False,
            "scanner_name": None,
            "policy": None,
            "shared": False,
            "object_id": 11,
            "tag_targets": [],
            "acls": [],
            "hostcount": 10,
            "uuid": "2776e999-1f5b-45b9-2e15-65a7be35b2e3ab8f7ecb158c480e",
            "status": scan_status[int(id) % len(scan_status)],
            "scan_type": None,
            "targets": None,
            "alt_targets_used": None,
            "pci-can-upload": None,
            "scan_start": 1430933086,
            "timestamp": 1430934526,
            "is_archived": False,
            "scan_end": 1430934526,
            "haskb": True,
            "hasaudittrail": True,
            "scanner_start": None,
            "scanner_end": None
        },
        "history": [
            {
                "history_id": 10328682,
                "owner_id": 2,
                "creation_date": 1430933086,
                "last_modification_date": 1430934526,
                "uuid": "2776e999-1f5b-45b9-2e15-65a7be35b2e3ab8f7ecb158c480e",
                "type": None,
                "status": "imported",
                "scheduler": 0,
                "alt_targets_used": False,
                "is_archived": False
            }
        ],
        "hosts": [
            {
                "asset_id": 5,
                "host_id": 5,
                "hostname": "172.204.81.57",
                "progress": "100-100/200-200",
                "scanprogresscurrent": 100,
                "scanprogresstotal": 100,
                "numchecksconsidered": 100,
                "totalchecksconsidered": 100,
                "severitycount": {},
                "severity": 166,
                "score": 3766,
                "info": 156,
                "low": 1,
                "medium": 6,
                "high": 3,
                "critical": 0,
                "host_index": 0
            },
            {
                "asset_id": 3,
                "host_id": 3,
                "hostname": "172.204.81.57",
                "progress": "100-100/200-200",
                "scanprogresscurrent": 100,
                "scanprogresstotal": 100,
                "numchecksconsidered": 100,
                "totalchecksconsidered": 100,
                "severitycount": {},
                "severity": 253,
                "score": 388162,
                "info": 52,
                "low": 11,
                "medium": 100,
                "high": 58,
                "critical": 32,
                "host_index": 1
            },
            {
                "asset_id": 9,
                "host_id": 9,
                "hostname": "172.204.81.57",
                "progress": "100-100/200-200",
                "scanprogresscurrent": 100,
                "scanprogresstotal": 100,
                "numchecksconsidered": 100,
                "totalchecksconsidered": 100,
                "severitycount": {},
                "severity": 202,
                "score": 207265,
                "info": 115,
                "low": 5,
                "medium": 21,
                "high": 45,
                "critical": 16,
                "host_index": 2
            }
        ],
        "vulnerabilities": [
            {
                "count": 68,
                "plugin_id": 34220,
                "plugin_name": "Netstat Portscanner (WMI)",
                "severity": 0,
                "plugin_family": "Port scanners",
                "vuln_index": 1
            },
            {
                "count": 65,
                "plugin_id": 34252,
                "plugin_name": "Microsoft Windows Remote Listeners Enumeration (WMI)",
                "severity": 0,
                "plugin_family": "Windows",
                "vuln_index": 2
            },
            {
                "count": 41,
                "plugin_id": 14272,
                "plugin_name": "netstat portscanner (SSH)",
                "severity": 0,
                "plugin_family": "Port scanners",
                "vuln_index": 3
            }
        ],
        "comphosts": [
            {
                "asset_id": 5,
                "host_id": 5,
                "hostname": "172.204.81.57",
                "progress": "100-100/200-200",
                "scanprogresscurrent": 100,
                "scanprogresstotal": 100,
                "numchecksconsidered": 100,
                "totalchecksconsidered": 100,
                "severitycount": {},
                "score": 867650,
                "info": 0,
                "low": 145,
                "medium": 62,
                "high": 0,
                "critical": 86,
                "host_index": 0,
                "severity": 293
            },
            {
                "asset_id": 3,
                "host_id": 3,
                "hostname": "172.204.81.57",
                "progress": "100-100/200-200",
                "scanprogresscurrent": 100,
                "scanprogresstotal": 100,
                "numchecksconsidered": 100,
                "totalchecksconsidered": 100,
                "severitycount": {},
                "score": 450620,
                "info": 0,
                "low": 52,
                "medium": 1,
                "high": 0,
                "critical": 45,
                "host_index": 1,
                "severity": 98
            },
            {
                "asset_id": 9,
                "host_id": 9,
                "hostname": "172.204.81.57",
                "progress": "100-100/200-200",
                "scanprogresscurrent": 100,
                "scanprogresstotal": 100,
                "numchecksconsidered": 100,
                "totalchecksconsidered": 100,
                "severitycount": {},
                "score": 642910,
                "info": 0,
                "low": 61,
                "medium": 23,
                "high": 0,
                "critical": 64,
                "host_index": 2,
                "severity": 148
            }
        ],
        "compliance": [
            {
                "count": 5,
                "host_id": 0,
                "hostname": None,
                "plugin_family": "Unix Compliance Checks",
                "plugin_id": "143e17d31e1a30830fcc2c3539d803d0",
                "plugin_name": "BSI-100-2: S 4.13: /etc/group consistency - Careful allocation of identifiers",
                "severity": 1,
                "severity_index": 0
            },
            {
                "count": 5,
                "host_id": 0,
                "hostname": None,
                "plugin_family": "Unix Compliance Checks",
                "plugin_id": "21361aed1df4e64051bc939431ca3096",
                "plugin_name": "BSI-100-2: S 4.105: No world writeable files - Preventing unauthorised acquisition of administrator  ",
                "severity": 3,
                "severity_index": 1
            },
            {
                "count": 5,
                "host_id": 0,
                "hostname": None,
                "plugin_family": "Unix Compliance Checks",
                "plugin_id": "5784176f032f448cb73b6cd4d4cff8be",
                "plugin_name": "BSI-100-2: S 4.105: Rlogind must be deactivated",
                "severity": 3,
                "severity_index": 2
            }
        ],
        "filters": [
            {
                "name": "host.id",
                "readable_name": "Asset ID",
                "control": {},
                "operators": [],
                "group_name":"vulnerability"
            },
            {
                "name": "plugin.attributes.bid",
                "readable_name": "Bugtraq ID",
                "control": {},
                "operators": [],
                "group_name":"vulnerability"
            },
            {
                "name": "plugin.attributes.exploit_framework_canvas",
                "readable_name": "CANVAS Exploit Framework",
                "control": {},
                "operators": [],
                "group_name":"vulnerability"
            }
        ],
        "notes": [
            {
                "message": "One or more AirWatch API settings are not set",
                "title": "MDM501 AirWatch API settings misconfiguration",
            },
            {
                "message": "Unable to connect to the ActiveSync server.",
                "title": "MDM501 ActiveSync connection error",
            },
            {
                "message": "ADSI server (matrix.tenablesecurity.com) could not connect to server.",
                "title": "adsi_enum_directory_trusts.nbin: ADSI error",
            }
        ],
        "remediations": {
            "num_cves": 2536,
            "num_hosts": 10,
            "num_remediated_cves": 2283,
            "num_impacted_hosts": 8,
            "remediations": [
                {
                    "vulns": 1,
                    "value": "96a449d372af3d23ca9a4f9f9a2ea73e",
                    "hosts": 1,
                    "remediation": "FreeBSD : gpgme -- heap-based buffer overflow in gpgsm status handler (90ca3ba5-19e6-11e4-8616-001b3 ",
                },
                {
                    "vulns": 296,
                    "value": "319a8ba9e264c876028b2a5abf5a1b0e",
                    "hosts": 1,
                    "remediation": "FreeBSD : mozilla -- multiple vulnerabilities (d0c97697-df2c-4b8b-bff2-cec24dc35af8): Update the aff ",
                }, {
                    "vulns": 0,
                    "value": "c22105fdc2756d11c39d1380e58c8fbc",
                    "hosts": 1,
                    "remediation": "RHEL 6 / 7 : postgresql (RHSA-2015:0750): Update the affected packages.",
                }
            ]
        }
    }

    return json.dumps(result)


@nessus_api.route(f'/{BASE_URL}/nessus/scans', methods=["POST"])
def scan_create():
    name = request.json['settings']['name']
    result = {
        "scan":
            {
                "uuid": "2776e999-1f5b-45b9-2e15-65a7be35b2e3ab8f7ecb158c480e",
                "name": name,
                "status": "Running",
                "folder_id": "Folder_ID_1",
                "id": 45,
                "type": "X_Type",
                "policy": "PCI_DSS",
                "user_permissions": "Read",
                "creation_date": "2020-05-28",
                "last_modification_date": "2020-05-29",
            }
    }
    return json.dumps(result)


@nessus_api.route(f'/{BASE_URL}/nessus/editor/scan/templates', methods=["GET"])
def geteditors():
    result = {
        "templates":
        [
            {
                "unsupported": False,
                "cloud_only": False,
                "desc": "A full system scan suitable for any host.",
                "order": None,
                "subscription_only": False,
                "is_was": None,
                "title": "Basic Network Scan",
                "is_agent": None,
                "uuid": "731a8e52-3ea6-a291-ec0a-d2ff0619c19d7bd788d6be818b65",
                "manager_only": False,
                "name": "basic"
            },
            {
                "unsupported": False,
                "cloud_only": False,
                "desc": "Audit systems connected via Nessus Agents.",
                "order": None,
                "subscription_only": False,
                "is_was": None,
                "title": "Policy Compliance Auditing",
                "is_agent": True,
                "uuid": "523c833f-e434-a05f-5a52-0c0c2c160b7cd9c901634c382c2d",
                "manager_only": False,
                "name": "agent_compliance"
            }
        ]

    }

    return json.dumps(result)

@nessus_api.route(f'/{BASE_URL}/nessus/scans/<id>/hosts/<hid>', methods=["GET"])
def scanHostDetails(id, hid):

    result = {

        "info": {
            "mac-address": None,
            "host-fqdn": "matrixcentos5_matrix",
            "host-ip": "172.204.81.57",
            "operating-system": [],
            "host_end": "Fri Dec 7 21:46:59 2018",
            "host_start": "Fri Dec 7 21:46:59 2018"
        },
        "vulnerabilities": [
            {
                "count": 7,
                "host_id": 9,
                "hostname": "172.204.81.57",
                "plugin_family": "Port scanners",
                "plugin_id": 14272,
                "plugin_name": "Netstat Portscanner (SSH)",
                "severity": 0,
                "severity_index": 0,
                "vuln_index": 0
            },
            {
                "count": 7,
                "host_id": 9,
                "hostname": "172.204.81.57",
                "plugin_family": "Service detection",
                "plugin_id": 25221,
                "plugin_name": "Remote listeners enumeration (Linux / AIX)",
                "severity": 0,
                "severity_index": 0,
                "vuln_index": 0
            },
            {
                "count": 4,
                "host_id": 9,
                "hostname": "172.204.81.57",
                "plugin_family": "Service detection",
                "plugin_id": 11111,
                "plugin_name": "RPC Services Enumeration",
                "severity": 0,
                "severity_index": 0,
                "vuln_index": 0,
            }
        ],
        "compliance": [
            {
                "count": 1,
                "host_id": 9,
                "hostname": "172.204.81.57",
                "plugin_family": "Unix Compliance Checks",
                "plugin_id": "0042cf05a8358f531c68c8bd249a4874",
                "plugin_name": "BSI-100-2: S 4.105: Telnet should be replaced by SSH.",
                "severity": 1,
                "severity_index": 0,
            },
            {
                "count": 1,
                "host_id": 9,
                "hostname": "172.204.81.57",
                "plugin_family": "Unix Compliance Checks",
                "plugin_id": "0483f10c66f3ecf1f2ec55cf47365416",
                "plugin_name": "BSI-100-2: S 4.105: /usr/X11R6/bin/startx - `xhost +` should never be used.",
                "severity": 3,
                "severity_index": 1
            },
            {
                "count": 1,
                "host_id": 9,
                "hostname": "172.204.81.57",
                "plugin_family": "Unix Compliance Checks",
                "plugin_id": "04a999b7e2dbe28fc1c76b15237a39a2",
                "plugin_name": "Red Hat 6 is not installed on target",
                "severity": 2,
                "severity_index": 2
            }
        ]
    }

    return json.dumps(result)


@nessus_api.route(f'/{BASE_URL}/nessus/scans/<id>/export/download', methods=["GET"])
@nessus_api.route(f'/{BASE_URL}/nessus/scans/<id>/export/<fid>/download', methods=["GET"])
def returnNothing(id,fid):
    return "Nothing to see here"


@nessus_api.route(f'/{BASE_URL}/nessus/scans/<id>/export', methods=["POST"])
def returnNullFile(id):
    return { "file" : None}

@nessus_api.route(f'/{BASE_URL}/nessus/scans/<id>/export/<fid>/status', methods=["GET"])
def checkScanExportStatus(id,fid):
    return {
        "status":"ready"
    }


#  var tbToEntity = {'hosts':'Endpoint','comphosts':'Endpoint','vulnerabilities':'Vulnerability',/*'compliance':'Vulnerability',*/'notes':'Note','filters':'Filter','history':'History','remediations':'Remediations'};
"""
NessusScan: {
        uuid:                   'UUID',
        name:                   'Name' ,
        status:                 'Status',
        folder_id:              'FolderID',
        id:                     'ID',
        type:                   'Type',
        policy:                 'Policy',
        user_permissions:       'UserPermissions',
        creation_date:          'CreationDate'  ,
        last_modification_date: 'LastModificationDate'
    }
"""
